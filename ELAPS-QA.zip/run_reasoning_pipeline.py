#!/usr/bin/env python
"""Compatibility launcher for the enhanced Chain-of-Table/PCFG-BF experiment."""
import runpy
if __name__ == "__main__":
    runpy.run_module("experiments.chain_of_table.run_enhanced", run_name="__main__")
