#!/usr/bin/env python
from __future__ import annotations
"""Generate and optionally run paper-grade TQA experiment commands.

This script keeps every experiment in its existing separate result_dir.
Runs resume by default; use --force_restart only when a clean usage/latency run
is explicitly required.
"""
import argparse
import os
import subprocess
from pathlib import Path

BASE = [
    "python", "run_symbolic_dataset_agent.py",
    "--scales", "128k",
    "--domains", "all",
    "--db_ids", "0,1,2,3,4",
    "--votes", "3",
    "--parallel_votes", "1",
    "--max_schema_chars", "8000",
    "--max_sql_candidates", "3",
    "--value_hint_mode", "adaptive",
    "--candidate_sources", "all",
    "--posterior_selection", "answer_marginal",
    "--repair_rounds", "0",
]


def cmd(name, model="deepseek-v4-pro", result_root="results/paper_strict", first_n=None, extra=None, no_resume=False):
    out = Path(result_root) / name
    c = list(BASE)
    if first_n is not None:
        c += ["--first_n", str(first_n)]
    c += ["--model_name", model, "--result_dir", str(out)]
    if extra:
        c += list(extra)
    if no_resume:
        c += ["--no_resume"]
    return c


def build_plan(plan: str, result_root: str):
    smoke_n = 20
    subset_n = 100
    jobs = []
    if plan == "smoke":
        jobs.append(cmd("smoke_ours", first_n=smoke_n, result_root=result_root, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector"]))
        jobs.append(cmd("smoke_program_map", first_n=smoke_n, result_root=result_root, extra=["--selection_policy", "multitable_bayes", "--posterior_selection", "program_map"]))
        jobs.append(cmd("smoke_no_repair", first_n=smoke_n, result_root=result_root, extra=["--selection_policy", "hybrid_multitable_bayes", "--disable_safe_repairs"]))
        jobs.append(cmd("smoke_symbolic", first_n=smoke_n, result_root=result_root, extra=["--selection_policy", "multitable_bayes", "--disable_llm_candidates", "--candidate_sources", "schema_rule"]))
        return jobs

    # Main performance / selection ablations.
    jobs += [
        cmd("tqa_ours_deepseek", result_root=result_root, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector"]),
        cmd("tqa_primary_majority", result_root=result_root, extra=["--selection_policy", "primary_majority"]),
        cmd("tqa_candidate_majority", result_root=result_root, extra=["--selection_policy", "candidate_majority"]),
        cmd("tqa_multitable_bayes_answer_marginal", result_root=result_root, extra=["--selection_policy", "multitable_bayes", "--posterior_selection", "answer_marginal", "--enable_result_selector"]),
        cmd("tqa_multitable_bayes_program_map", result_root=result_root, extra=["--selection_policy", "multitable_bayes", "--posterior_selection", "program_map", "--enable_result_selector"]),
    ]
    # Candidate source and repair ablations.
    jobs += [
        cmd("tqa_no_schema_rule_candidates", result_root=result_root, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector", "--disable_schema_graph_candidates"]),
        cmd("tqa_symbolic_schema_rule_only", result_root=result_root, extra=["--selection_policy", "multitable_bayes", "--disable_llm_candidates", "--candidate_sources", "schema_rule"]),
        cmd("tqa_no_safe_repairs", result_root=result_root, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector", "--disable_safe_repairs"]),
    ]
    # Schema graph attribution. Use subset by default because this is explanatory.
    for ab in ["no_edges", "no_foreign_keys", "no_inferred_edges", "no_column_links"]:
        jobs.append(cmd(f"schema_ablation_{ab}", result_root=result_root, first_n=subset_n, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector", "--schema_graph_ablation", ab]))
    # BF sensitivity. Subset is enough for paper appendix.
    for th in [1, 2, 3, 5, 10]:
        jobs.append(cmd(f"bf_threshold_{th}", result_root=result_root, first_n=subset_n, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector", "--bf_threshold", str(th)]))
    # Cross-model efficiency / upper-bound validation.
    jobs += [
        cmd("tqa_ours_gpt4o_mini", model="gpt-4o-mini", result_root=result_root, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector"]),
        cmd("tqa_ours_gpt4o_subset", model="gpt-4o", first_n=subset_n, result_root=result_root, extra=["--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector"]),
    ]
    return jobs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", choices=["smoke", "standard"], default="standard")
    ap.add_argument("--result_root", default="results/paper_strict")
    ap.add_argument("--execute", action="store_true")
    ap.add_argument("--dry_run", action="store_true")
    ap.add_argument("--force_restart", action="store_true", help="Append --no_resume for a clean run. Default: resume.")
    args = ap.parse_args()
    jobs = build_plan(args.plan, args.result_root)
    for c in jobs:
        c[:] = [token for token in c if token != "--no_resume"]
        if args.force_restart:
            c.append("--no_resume")
    for i, c in enumerate(jobs, 1):
        print(f"\n# [{i}/{len(jobs)}] {' '.join(c)}")
        if args.execute and not args.dry_run:
            env = os.environ.copy()
            if env.get("DEEPSEEK_API_KEY") and not env.get("OPENAI_API_KEY"):
                env["OPENAI_API_KEY"] = env["DEEPSEEK_API_KEY"]
            env.setdefault("TQA_VOTE_TEMPERATURE", "0.0")
            subprocess.run(c, check=True, env=env)

if __name__ == "__main__":
    main()
