#!/usr/bin/env python
from __future__ import annotations
"""Aggregate strict TQA experiment outputs into CSV tables for paper writing."""
import argparse, csv, json, os, re
from pathlib import Path
from collections import Counter, defaultdict


def read_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def read_jsonl(path):
    rows=[]
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
    except Exception:
        pass
    return rows


def analyze_dir(d: Path):
    m = read_json(d/'metrics.json')
    usage = m.get('llm_usage') or read_json(d/'llm_usage_summary.json')
    results = read_jsonl(d/'results.jsonl')
    scopes=Counter(); sources=Counter(); repairs=Counter(); changed_by_agg=0
    program_map_win_loss=Counter()
    answer_covered=0; total_oc=0; valid_cands=0
    for r in results:
        tqa=(r.get('tqabench_symdataset_sql') or {})
        scopes[str(tqa.get('candidate_framework_engine_scope'))]+=1
        oc=tqa.get('oracle_coverage') or {}
        if oc:
            total_oc += 1; answer_covered += int(bool(oc.get('oracle_covered'))); valid_cands += int(oc.get('valid_candidate_count') or 0)
        mt=tqa.get('multitable_bayes') or {}
        if mt.get('posterior_selection') == 'answer_marginal':
            # If best program answer key differs from chosen answer group, answer aggregation changed the MAP decision.
            cands=tqa.get('executed_candidates') or []
            if cands:
                ranked=sorted([c for c in cands if c.get('posterior') is not None], key=lambda x: x.get('posterior',0), reverse=True)
                if ranked:
                    best_key = ranked[0].get('answer_key')
                    ans_post = mt.get('answer_posterior') or {}
                    chosen_key = next(iter(ans_post.keys()), None) if isinstance(ans_post, dict) else None
                    if chosen_key is not None and best_key is not None and str(chosen_key)!=str(best_key):
                        changed_by_agg += 1
        for c in (tqa.get('executed_candidates') or []):
            sources[str(c.get('stage') or 'unknown')]+=1
            for a in (c.get('attempts') or []):
                if a.get('repair_reason'):
                    repairs[str(a.get('repair_reason'))]+=1
    row={
        'name': d.name,
        'total': m.get('total'), 'correct': m.get('correct'), 'accuracy': m.get('accuracy'), 'invalid': m.get('invalid'),
        'topk_oracle_coverage': m.get('topk_oracle_coverage'), 'generation_miss_rate': m.get('generation_miss_rate'),
        'ranking_error_rate': m.get('ranking_error_rate'), 'avg_valid_candidate_count': m.get('avg_valid_candidate_count'),
        'llm_calls': usage.get('total_calls'),
        'llm_calls_per_sample': round(float(usage.get('total_calls') or 0)/max(1,int(m.get('total') or 0)),4),
        'latency_sec_total': round(float(usage.get('total_latency_sec') or 0),3),
        'latency_sec_per_sample': round(float(usage.get('total_latency_sec') or 0)/max(1,int(m.get('total') or 0)),3),
        'estimated_total_tokens': usage.get('estimated_total_tokens'),
        'actual_total_tokens': usage.get('actual_total_tokens'),
        'estimated_cost_usd': usage.get('estimated_cost_usd'),
        'engine_scopes': json.dumps(scopes, ensure_ascii=False),
        'candidate_sources_count': json.dumps(sources, ensure_ascii=False),
        'top_repairs': json.dumps(dict(repairs.most_common(12)), ensure_ascii=False),
        'answer_aggregation_changed_samples': changed_by_agg,
        'config': json.dumps(m.get('experiment_config') or {}, ensure_ascii=False),
    }
    return row


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('dirs', nargs='+')
    ap.add_argument('--out', default='results/paper_strict_summary.csv')
    args=ap.parse_args()
    dirs=[]
    for x in args.dirs:
        p=Path(x)
        if (p/'metrics.json').exists():
            dirs.append(p)
        elif p.is_dir():
            dirs += [q for q in sorted(p.iterdir()) if (q/'metrics.json').exists()]
    rows=[analyze_dir(d) for d in dirs]
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    if rows:
        with open(args.out, 'w', encoding='utf-8-sig', newline='') as f:
            w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
    print(f'Wrote {args.out} with {len(rows)} rows')

if __name__=='__main__':
    main()
