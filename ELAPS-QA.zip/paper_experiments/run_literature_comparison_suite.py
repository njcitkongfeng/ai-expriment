#!/usr/bin/env python
"""Run OUR method for the paper and keep literature baselines separate.

This script intentionally does NOT pretend to reproduce Binder/Dater/Chain-of-Table/etc.
Those are external published methods. Their numbers are stored in
published_baselines_tablemaster.csv and merged during analysis.

It runs only the experiments we actually implement in this repository:
  - Ours on WikiTQ, TabFact, Spider, and TQA-Bench/SymDataset
  - Optional internal ablations for mechanism analysis, not external comparison.
"""
from __future__ import annotations

import argparse
import os
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional

MODELS: Dict[str, Dict[str, str]] = {
    "deepseek-v4-pro": {
        "model_name": "deepseek-v4-pro",
        "api_base": "https://api.deepseek.com",
        "api_key_env": "DEEPSEEK_API_KEY",
    },
    "gpt-4o-mini": {
        "model_name": "gpt-4o-mini",
        "api_base": "",
        "api_key_env": "OPENAI_API_KEY",
    },
}

@dataclass
class Job:
    name: str
    dataset: str
    model: str
    experiment: str
    cmd: List[str]
    result_dir: str


def _key_arg(model_key: str) -> List[str]:
    """Return non-secret model arguments.

    Do NOT append --openai_api_key here. The subprocess receives API keys via
    environment variables in run_job(), which avoids leaking keys into
    run_meta.json, generated .bat files, and terminal logs.
    """
    spec = MODELS[model_key]
    args = ["--model_name", spec["model_name"]]
    if spec["api_base"]:
        args += ["--openai_api_base", spec["api_base"]]
    return args


def _safe_name(s: str) -> str:
    return s.replace("/", "_").replace(" ", "_").replace(",", "_")


def _single_table_job_cmd(dataset: str, model_key: str, result_dir: Path, first_n: int, single_table_mode: str) -> List[str]:
    """Build single-table commands.

    Important: keep this wrapper aligned with the user's original single-table
    commands. Do not inject PCFG/MCMC tuning flags such as --beam_width,
    --n_mcmc, or --max_refinement here. run_reasoning_pipeline.py already has its own
    defaults, and adding explicit values makes the paper-suite results diverge
    from earlier standalone runs.
    """
    if single_table_mode == "enhanced":
        cmd = [
            "python", "run_reasoning_pipeline.py",
            "--dataset", dataset,
            "--mode", "enhanced",
            "--result_dir", str(result_dir),
        ] + _key_arg(model_key)
        if first_n and first_n > 0:
            cmd += ["--first_n", str(first_n)]
        return cmd

    if single_table_mode == "original_llm":
        if dataset == "wikitq":
            return [
                "python", "run_table_qa.py",
                "--dataset_path", "data/wikitq/test.jsonl",
                "--first_n", str(first_n),
                "--result_dir", str(result_dir),
            ] + _key_arg(model_key)
        return [
            "python", "run_fact_verification.py",
            "--dataset_path", "data/tabfact/test.jsonl",
            "--raw2clean_path", "data/tabfact/raw2clean.jsonl",
            "--first_n", str(first_n),
            "--result_dir", str(result_dir),
        ] + _key_arg(model_key)

    if single_table_mode == "pcfg_bf":
        if dataset == "wikitq":
            return [
                "python", "run_table_qa.py",
                "--dataset_path", "data/wikitq/test.jsonl",
                "--use_pcfg_bf",
                "--first_n", str(first_n),
                "--result_dir", str(result_dir),
            ]
        return [
            "python", "run_fact_verification.py",
            "--dataset_path", "data/tabfact/test.jsonl",
            "--raw2clean_path", "data/tabfact/raw2clean.jsonl",
            "--use_pcfg_bf",
            "--first_n", str(first_n),
            "--result_dir", str(result_dir),
        ]

    if single_table_mode == "candidate_ours":
        if dataset == "wikitq":
            return [
                "python", "run_table_qa.py",
                "--dataset_path", "data/wikitq/test.jsonl",
                "--use_candidate_framework",
                "--candidate_sources", "all",
                "--framework_max_candidates", "18",
                "--max_repair_rounds", "1",
                "--agent90_votes", "3",
                "--first_n", str(first_n),
                "--result_dir", str(result_dir),
            ] + _key_arg(model_key)
        return [
            "python", "run_fact_verification.py",
            "--dataset_path", "data/tabfact/test.jsonl",
            "--raw2clean_path", "data/tabfact/raw2clean.jsonl",
            "--use_candidate_framework",
            "--candidate_sources", "all",
            "--framework_max_candidates", "22",
            "--max_repair_rounds", "1",
            "--agent90_votes", "3",
            "--agent90_temperature", "0.0",
            "--posterior_selection", "answer_marginal",
            "--first_n", str(first_n),
            "--result_dir", str(result_dir),
        ] + _key_arg(model_key)

    if single_table_mode == "candidate_framework":
        if dataset == "wikitq":
            return [
                "python", "run_table_qa.py",
                "--dataset_path", "data/wikitq/test.jsonl",
                "--use_candidate_framework",
                "--framework_max_candidates", "12",
                "--first_n", str(first_n),
                "--result_dir", str(result_dir),
            ] + _key_arg(model_key)
        return [
            "python", "run_fact_verification.py",
            "--dataset_path", "data/tabfact/test.jsonl",
            "--raw2clean_path", "data/tabfact/raw2clean.jsonl",
            "--use_candidate_framework",
            "--framework_max_candidates", "16",
            "--first_n", str(first_n),
            "--result_dir", str(result_dir),
        ] + _key_arg(model_key)

    raise ValueError(f"Unknown single_table_mode: {single_table_mode}")


def ours_jobs(result_root: str, models: Iterable[str], first_n: int, spider_max_per_db: int, single_table_mode: str = "enhanced") -> List[Job]:
    jobs: List[Job] = []
    root = Path(result_root)
    for m in models:
        # WikiTQ: single-table QA
        rd = root / "ours" / "wikitq" / m
        cmd = _single_table_job_cmd("wikitq", m, rd, first_n, single_table_mode)
        jobs.append(Job(f"ours_wikitq_{m}_{single_table_mode}", "WikiTQ", m, f"ours_{single_table_mode}", cmd, str(rd)))

        # TabFact: single-table fact verification
        rd = root / "ours" / "tabfact" / m
        cmd = _single_table_job_cmd("tabfact", m, rd, first_n, single_table_mode)
        jobs.append(Job(f"ours_tabfact_{m}_{single_table_mode}", "TabFact", m, f"ours_{single_table_mode}", cmd, str(rd)))

        # Spider: multi-database Text-to-SQL
        rd = root / "ours" / "spider" / m
        cmd = [
            "python", "run_relational_candidate_agent.py",
            "--spider_root", "data/spider_data",
            "--split", "dev",
            "--db_ids", "all",
            "--votes", "3",
            "--parallel_votes", "1",
            "--max_schema_chars", "8000",
            "--max_sql_candidates", "5",
            "--selection_policy", "hybrid_multitable_bayes",
            "--candidate_sources", "all",
            "--posterior_selection", "answer_marginal",
            "--max_repair_rounds", "1",
            "--result_dir", str(rd),
        ] + _key_arg(m)
        if first_n and first_n > 0:
            cmd += ["--first_n", str(first_n)]
        if spider_max_per_db and spider_max_per_db > 0:
            cmd += ["--max_per_db", str(spider_max_per_db)]
        jobs.append(Job(f"ours_spider_{m}", "Spider", m, "ours", cmd, str(rd)))

        # TQA-Bench/SymDataset: multi-table QA
        rd = root / "ours" / "tqabench" / m
        cmd = [
            "python", "run_symbolic_dataset_agent.py",
            "--scales", "128k",
            "--domains", "all",
            "--db_ids", "0,1,2,3,4",
            "--votes", "3",
            "--parallel_votes", "1",
            "--max_schema_chars", "8000",
            "--max_sql_candidates", "3",
            "--selection_policy", "hybrid_multitable_bayes",
            "--candidate_sources", "all",
            "--posterior_selection", "answer_marginal",
            "--enable_result_selector",
            "--value_hint_mode", "adaptive",
            "--repair_rounds", "0",
            "--result_dir", str(rd),
        ] + _key_arg(m)
        if first_n and first_n > 0:
            cmd += ["--first_n", str(first_n)]
        jobs.append(Job(f"ours_tqabench_{m}", "TQA-Bench", m, "ours", cmd, str(rd)))
    return jobs


def ablation_jobs(result_root: str, models: Iterable[str], first_n: int, spider_max_per_db: int) -> List[Job]:
    """Internal mechanism ablations. These are NOT external method comparisons."""
    jobs: List[Job] = []
    root = Path(result_root)
    for m in models:
        # Spider ablations
        spider_common = [
            "python", "run_relational_candidate_agent.py", "--spider_root", "data/spider_data", "--split", "dev", "--db_ids", "all",
            "--votes", "3", "--parallel_votes", "1", "--max_schema_chars", "8000", "--max_sql_candidates", "5",
            "--selection_policy", "hybrid_multitable_bayes", "--max_repair_rounds", "1",
        ] + _key_arg(m)
        if first_n and first_n > 0:
            spider_common += ["--first_n", str(first_n)]
        if spider_max_per_db and spider_max_per_db > 0:
            spider_common += ["--max_per_db", str(spider_max_per_db)]
        variants = {
            "spider_program_map": ["--candidate_sources", "all", "--posterior_selection", "program_map"],
            "spider_llm_only": ["--candidate_sources", "llm", "--posterior_selection", "answer_marginal"],
            "spider_schema_rule_only": ["--candidate_sources", "schema_rule", "--posterior_selection", "answer_marginal"],
            "spider_no_repair": ["--candidate_sources", "all", "--posterior_selection", "answer_marginal", "--disable_safe_repairs"],
        }
        for v, extra in variants.items():
            rd = root / "ablations" / v / m
            cmd = spider_common + extra + ["--result_dir", str(rd)]
            jobs.append(Job(f"{v}_{m}", "Spider", m, v, cmd, str(rd)))

        # TQA ablations
        tqa_common = [
            "python", "run_symbolic_dataset_agent.py", "--scales", "128k", "--domains", "all", "--db_ids", "0,1,2,3,4",
            "--votes", "3", "--parallel_votes", "1", "--max_schema_chars", "8000", "--max_sql_candidates", "3",
            "--selection_policy", "hybrid_multitable_bayes", "--enable_result_selector", "--value_hint_mode", "adaptive", "--repair_rounds", "0",
        ] + _key_arg(m)
        if first_n and first_n > 0:
            tqa_common += ["--first_n", str(first_n)]
        variants = {
            "tqa_program_map": ["--posterior_selection", "program_map"],
            "tqa_llm_only": ["--candidate_sources", "llm"],
            "tqa_schema_rule_only": ["--candidate_sources", "schema_rule"],
            "tqa_no_repair": ["--disable_safe_repairs"],
        }
        for v, extra in variants.items():
            rd = root / "ablations" / v / m
            cmd = tqa_common + extra + ["--result_dir", str(rd)]
            jobs.append(Job(f"{v}_{m}", "TQA-Bench", m, v, cmd, str(rd)))
    return jobs


def efficiency_jobs(result_root: str, models: Iterable[str]) -> List[Job]:
    jobs: List[Job] = []
    root = Path(result_root)
    budgets = [
        ("low", 1, 1, 4000, 1),
        ("mid", 1, 3, 8000, 1),
        ("std", 3, 3, 8000, 1),
        ("high", 5, 5, 12000, 2),
    ]
    for m in models:
        for tag, votes, cand, schema, repair in budgets:
            rd = root / "efficiency" / f"spider_{tag}" / m
            cmd = [
                "python", "run_relational_candidate_agent.py", "--spider_root", "data/spider_data", "--split", "dev", "--db_ids", "all",
                "--max_per_db", "10", "--votes", str(votes), "--parallel_votes", "1", "--max_schema_chars", str(schema),
                "--max_sql_candidates", str(cand), "--selection_policy", "hybrid_multitable_bayes", "--candidate_sources", "all",
                "--posterior_selection", "answer_marginal", "--max_repair_rounds", str(repair), "--result_dir", str(rd),
            ] + _key_arg(m)
            jobs.append(Job(f"spider_eff_{tag}_{m}", "Spider", m, f"efficiency_{tag}", cmd, str(rd)))
    return jobs



def _parse_float_list(text: str) -> List[float]:
    out: List[float] = []
    for x in str(text).split(","):
        x = x.strip()
        if not x:
            continue
        try:
            out.append(float(x))
        except ValueError:
            raise ValueError(f"Invalid float value in list: {x!r}")
    if not out:
        raise ValueError("At least one BF threshold must be provided.")
    return out


def threshold_sensitivity_jobs(
    result_root: str,
    models: Iterable[str],
    thresholds: Iterable[float],
    first_n: int,
    spider_max_per_db: int,
    tqa_scales: str,
) -> List[Job]:
    """Bayes-factor threshold sensitivity analysis.

    BF threshold is used by the hybrid_multitable_bayes selector to mark low-confidence
    choices and trigger conservative answer-level selection behavior. It is meaningful
    mainly for multi-table / SQL-style tasks, so we run it on Spider and TQA-Bench.
    """
    jobs: List[Job] = []
    root = Path(result_root)
    for m in models:
        for th in thresholds:
            th_tag = str(th).replace(".", "p")
            # Spider threshold sweep
            rd = root / "threshold_sensitivity" / "spider" / f"bf_{th_tag}" / m
            cmd = [
                "python", "run_relational_candidate_agent.py",
                "--spider_root", "data/spider_data",
                "--split", "dev",
                "--db_ids", "all",
                "--votes", "3",
                "--parallel_votes", "1",
                "--max_schema_chars", "8000",
                "--max_sql_candidates", "5",
                "--selection_policy", "hybrid_multitable_bayes",
                "--candidate_sources", "all",
                "--posterior_selection", "answer_marginal",
                "--bf_threshold", str(th),
                "--max_repair_rounds", "1",
                "--result_dir", str(rd),
            ] + _key_arg(m)
            if first_n and first_n > 0:
                cmd += ["--first_n", str(first_n)]
            if spider_max_per_db and spider_max_per_db > 0:
                cmd += ["--max_per_db", str(spider_max_per_db)]
            jobs.append(Job(f"spider_bf_threshold_{th}_{m}", "Spider", m, f"bf_threshold_{th}", cmd, str(rd)))

            # TQA-Bench / SymDataset threshold sweep
            rd = root / "threshold_sensitivity" / "tqabench" / f"bf_{th_tag}" / m
            cmd = [
                "python", "run_symbolic_dataset_agent.py",
                "--scales", str(tqa_scales),
                "--domains", "all",
                "--db_ids", "0,1,2,3,4",
                "--votes", "3",
                "--parallel_votes", "1",
                "--max_schema_chars", "8000",
                "--max_sql_candidates", "3",
                "--selection_policy", "hybrid_multitable_bayes",
                "--candidate_sources", "all",
                "--enable_result_selector",
                "--posterior_selection", "answer_marginal",
                "--bf_threshold", str(th),
                "--value_hint_mode", "adaptive",
                "--repair_rounds", "0",
                "--result_dir", str(rd),
                ] + _key_arg(m)
            if first_n and first_n > 0:
                cmd += ["--first_n", str(first_n)]
            jobs.append(Job(f"tqabench_bf_threshold_{th}_{m}", "TQA-Bench", m, f"bf_threshold_{th}", cmd, str(rd)))
    return jobs

def build_jobs(args: argparse.Namespace) -> List[Job]:
    models = [m.strip() for m in args.models.split(",") if m.strip()]
    jobs: List[Job] = []
    if args.plan in {"ours", "all"}:
        jobs += ours_jobs(args.result_root, models, args.first_n, args.spider_max_per_db, args.single_table_mode)
    if args.plan in {"ablations", "all"}:
        jobs += ablation_jobs(args.result_root, models if args.ablation_models == "same" else args.ablation_models.split(","), args.ablation_first_n, args.ablation_spider_max_per_db)
    if args.plan in {"efficiency", "all"}:
        jobs += efficiency_jobs(args.result_root, models)
    if args.plan in {"threshold_sensitivity", "all"}:
        threshold_models = models if args.threshold_models == "same" else [m.strip() for m in args.threshold_models.split(",") if m.strip()]
        jobs += threshold_sensitivity_jobs(
            args.result_root,
            threshold_models,
            _parse_float_list(args.bf_thresholds),
            args.threshold_first_n,
            args.threshold_spider_max_per_db,
            args.threshold_tqa_scales,
        )
    return jobs


def quote_cmd(cmd: List[str]) -> str:
    return " ".join(shlex.quote(x) for x in cmd)


def _job_env(job: Job) -> Dict[str, str]:
    env = os.environ.copy()
    # DeepSeek is OpenAI-compatible. Most existing runners read OPENAI_API_KEY,
    # so map DEEPSEEK_API_KEY into OPENAI_API_KEY for this subprocess only.
    if job.model == "deepseek-v4-pro" and env.get("DEEPSEEK_API_KEY"):
        env["OPENAI_API_KEY"] = env["DEEPSEEK_API_KEY"]
    env.setdefault("WIKITQ_VOTE_TEMPERATURE", "0.0")
    env.setdefault("SPIDER_VOTE_TEMPERATURE", "0.0")
    env.setdefault("TQA_VOTE_TEMPERATURE", "0.0")
    return env


def run_job(job: Job) -> int:
    print("\n" + "=" * 100)
    print(f"[RUN] {job.name}")
    print(quote_cmd(job.cmd))
    print("=" * 100)
    Path(job.result_dir).mkdir(parents=True, exist_ok=True)
    meta = Path(job.result_dir) / "run_meta.json"
    meta.write_text(
        "{\n"
        f'  "name": "{job.name}",\n'
        f'  "dataset": "{job.dataset}",\n'
        f'  "model": "{job.model}",\n'
        f'  "experiment": "{job.experiment}",\n'
        f'  "cmd": "{quote_cmd(job.cmd).replace(chr(34), chr(39))}",\n'
        f'  "api_key_source": "environment"\n'
        "}\n",
        encoding="utf-8",
    )
    return subprocess.call(job.cmd, env=_job_env(job))


def main() -> None:
    parser = argparse.ArgumentParser(description="Literature-comparison experiment suite for table understanding.")
    parser.add_argument("--plan", choices=["ours", "ablations", "efficiency", "threshold_sensitivity", "all"], default="ours")
    parser.add_argument("--models", default="deepseek-v4-pro")
    parser.add_argument("--single_table_mode", choices=["candidate_ours", "enhanced", "original_llm", "pcfg_bf", "candidate_framework"], default="candidate_ours",
                        help="Single-table path. candidate_ours is the paper Ours path; enhanced is the old Chain-of-Table baseline; candidate_framework is schema-rule/internal-check style.")
    parser.add_argument("--result_root", default="results/literature_comparison")
    parser.add_argument("--first_n", type=int, default=-1, help="Use for quick subset; -1 full.")
    parser.add_argument("--spider_max_per_db", type=int, default=0, help="0 full Spider; 10 for balanced subset.")
    parser.add_argument("--ablation_first_n", type=int, default=200)
    parser.add_argument("--ablation_spider_max_per_db", type=int, default=10)
    parser.add_argument("--ablation_models", default="deepseek-v4-pro", help="same or comma list")
    parser.add_argument("--threshold_models", default="deepseek-v4-pro", help="same or comma list. Default only DeepSeek to control cost.")
    parser.add_argument("--bf_thresholds", default="1.0,1.5,2.0,3.0,5.0,10.0", help="Comma-separated BF thresholds for sensitivity analysis.")
    parser.add_argument("--threshold_first_n", type=int, default=200, help="Subset size for threshold sweep; use -1 for full.")
    parser.add_argument("--threshold_spider_max_per_db", type=int, default=10, help="Use 10 for balanced Spider subset; 0 for full Spider.")
    parser.add_argument("--threshold_tqa_scales", default="128k", help="TQA scales for BF sweep, e.g. 16k,32k,64k,128k or 128k.")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--force_restart", action="store_true", help="Append --no_resume to Spider/TQA jobs. Default: resume.")
    parser.add_argument("--write_bat", default=None)
    args = parser.parse_args()

    jobs = build_jobs(args)
    for job in jobs:
        # Keep all old result folder names; only control resume behaviour here.
        job.cmd = [token for token in job.cmd if token != "--no_resume"]
        if args.force_restart and job.dataset in {"Spider", "TQA-Bench"}:
            job.cmd.append("--no_resume")
    if args.write_bat:
        Path(args.write_bat).parent.mkdir(parents=True, exist_ok=True)
        with open(args.write_bat, "w", encoding="utf-8") as f:
            f.write("@echo off\r\n")
            f.write("REM Generated by run_literature_comparison_suite.py\r\n")
            for job in jobs:
                f.write(f"echo Running {job.name}\r\n")
                f.write(" ".join(job.cmd) + "\r\n")
                f.write("if errorlevel 1 exit /b 1\r\n")
        print(f"Wrote {args.write_bat} with {len(jobs)} jobs.")
        return

    for i, job in enumerate(jobs, 1):
        print(f"[{i:03d}/{len(jobs):03d}] {job.name}: {quote_cmd(job.cmd)}")
    if not args.execute:
        print("\nDry run only. Add --execute to run.")
        return
    for job in jobs:
        code = run_job(job)
        if code != 0:
            raise SystemExit(code)

if __name__ == "__main__":
    main()
