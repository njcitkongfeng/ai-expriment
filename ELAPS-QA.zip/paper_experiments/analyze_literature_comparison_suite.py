#!/usr/bin/env python
"""Analyze OUR runs and merge them with published literature baselines.

Outputs:
  - ours_results.csv: metrics from local runs
  - single_table_external_comparison.csv: WikiTQ/TabFact external baselines + ours
  - multitable_external_context.csv: TQA-Bench published context baselines + ours if present
  - ablation_results.csv: internal ablations only
  - efficiency_results.csv: cost/latency budget sweep
  - comparison_tables.md: paper-ready markdown tables
"""
from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

SCRIPT_DIR = Path(__file__).resolve().parent


def load_json(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def infer_score(metrics: Dict[str, Any]) -> Optional[float]:
    for key in ["execution_accuracy", "denotation_accuracy", "accuracy", "acc", "score"]:
        if key in metrics and metrics[key] is not None:
            try:
                return float(metrics[key]) * (100.0 if float(metrics[key]) <= 1.0 else 1.0)
            except Exception:
                pass
    total = metrics.get("total") or metrics.get("n")
    correct = metrics.get("correct")
    if total and correct is not None:
        return float(correct) / float(total) * 100.0
    return None


def read_run_meta(run_dir: Path) -> Dict[str, Any]:
    meta = load_json(run_dir / "run_meta.json") or {}
    parts = run_dir.parts
    # fallback path inference
    if "ours" in parts:
        i = parts.index("ours")
        if len(parts) > i + 2:
            meta.setdefault("experiment", "ours")
            meta.setdefault("dataset", parts[i + 1])
            meta.setdefault("model", parts[i + 2])
    if "paper_ablation" in parts:
        i = parts.index("paper_ablation")
        # New scripts write results/paper_ablation/<model_tag>/<dataset>/<variant>.
        if len(parts) > i + 3:
            meta.setdefault("model", parts[i + 1])
            meta.setdefault("dataset", parts[i + 2])
            meta.setdefault("experiment", parts[i + 3])
    if "paper_main" in parts:
        i = parts.index("paper_main")
        if len(parts) > i + 1:
            meta.setdefault("model", parts[i + 1])
        tail = parts[i + 2:]
        for ds in ["wikitq", "tabfact", "spider", "tqabench", "tqa"]:
            if any(ds in str(x).lower() for x in tail):
                meta.setdefault("dataset", "tqabench" if ds == "tqa" else ds)
                break
        if tail:
            meta.setdefault("experiment", "/".join(tail))
    if "paper_efficiency" in parts or "paper_mechanism" in parts:
        label = "paper_efficiency" if "paper_efficiency" in parts else "paper_mechanism"
        i = parts.index(label)
        if len(parts) > i + 2:
            meta.setdefault("model", parts[i + 1])
            meta.setdefault("experiment", parts[i + 2])
            if "spider" in str(parts[i + 2]).lower():
                meta.setdefault("dataset", "spider")
            elif "wikitq" in str(parts[i + 2]).lower():
                meta.setdefault("dataset", "wikitq")
    if "ablations" in parts:
        i = parts.index("ablations")
        if len(parts) > i + 2:
            meta.setdefault("experiment", parts[i + 1])
            meta.setdefault("model", parts[i + 2])
    if "efficiency" in parts:
        i = parts.index("efficiency")
        if len(parts) > i + 2:
            meta.setdefault("experiment", parts[i + 1])
            meta.setdefault("model", parts[i + 2])
    return meta


def find_metric_files(roots: Iterable[Path]) -> List[Path]:
    files: List[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for name in ["metrics.json", "summary.json", "result.json"]:
            files.extend(root.rglob(name))
    # dedupe while preserving order
    out: List[Path] = []
    seen = set()
    for p in files:
        if p not in seen:
            out.append(p); seen.add(p)
    return out


def extract_runs(roots: Iterable[Path]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for mf in find_metric_files(roots):
        metrics = load_json(mf) or {}
        rd = mf.parent
        meta = read_run_meta(rd)
        usage = load_json(rd / "llm_usage_summary.json") or {}
        score = infer_score(metrics)
        dataset = str(meta.get("dataset", metrics.get("dataset", "unknown")))
        dataset_map = {"wikitq":"WikiTQ", "tabfact":"TabFact", "spider":"Spider", "tqabench":"TQA-Bench"}
        dataset = dataset_map.get(dataset.lower(), dataset)
        row = {
            "dataset": dataset,
            "model": meta.get("model", metrics.get("model", "unknown")),
            "experiment": meta.get("experiment", "unknown"),
            "method": "Ours" if meta.get("experiment") == "ours" else meta.get("experiment", "unknown"),
            "category": "ours" if meta.get("experiment") == "ours" else "internal_ablation",
            "score": score,
            "total": metrics.get("total"),
            "correct": metrics.get("correct"),
            "invalid_rate": metrics.get("invalid_rate"),
            "topk_oracle_coverage": metrics.get("topk_oracle_coverage"),
            "generation_miss_rate": metrics.get("generation_miss_rate"),
            "ranking_error_rate": metrics.get("ranking_error_rate"),
            "avg_valid_candidate_count": metrics.get("avg_valid_candidate_count"),
            "llm_calls": usage.get("total_calls") or usage.get("calls"),
            "total_tokens": usage.get("actual_total_tokens") or usage.get("total_tokens"),
            "estimated_cost_usd": usage.get("estimated_cost_usd"),
            "result_dir": str(rd),
        }
        rows.append(row)
    return rows


def read_csv_dict(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = sorted({k for r in rows for k in r.keys()})
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(rows)


def fmt(x: Any) -> str:
    if x is None or x == "":
        return "-"
    try:
        return f"{float(x):.2f}"
    except Exception:
        return str(x)



def parse_bf_threshold(experiment: Any) -> Optional[float]:
    text = str(experiment or "")
    if not text.startswith("bf_threshold_"):
        return None
    try:
        return float(text.replace("bf_threshold_", "", 1))
    except Exception:
        return None

def markdown_table(rows: List[Dict[str, Any]], cols: List[str], title: str) -> str:
    out = [f"### {title}", "", "| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(fmt(r.get(c)) for c in cols) + " |")
    out.append("")
    return "\n".join(out)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("roots", nargs="+", help="Result roots to scan")
    p.add_argument("--out_dir", default="results/literature_comparison_tables")
    args = p.parse_args()
    roots = [Path(x) for x in args.roots]
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    ours = extract_runs(roots)
    write_csv(out / "ours_results.csv", ours)

    external_single = read_csv_dict(SCRIPT_DIR / "published_baselines_tablemaster.csv")
    external_multi = read_csv_dict(SCRIPT_DIR / "published_baselines_multitable.csv")

    ours_main = [r for r in ours if r.get("category") == "ours"]
    ours_external_rows = []
    for r in ours_main:
        ours_external_rows.append({
            "method": "Ours",
            "reference": "This work",
            "category": "ours",
            "dataset": r.get("dataset"),
            "backbone": r.get("model"),
            "accuracy": fmt(r.get("score")),
            "source_note": r.get("result_dir"),
        })

    single_rows = [r for r in external_single if r.get("dataset") in {"WikiTQ", "TabFact"}] + [r for r in ours_external_rows if r.get("dataset") in {"WikiTQ", "TabFact"}]
    multi_rows = external_multi + [r for r in ours_external_rows if r.get("dataset") in {"Spider", "TQA-Bench"}]
    write_csv(out / "single_table_external_comparison.csv", single_rows)
    write_csv(out / "multitable_external_context.csv", multi_rows)

    # Separate internal analysis tables. BF threshold sensitivity is a hyper-parameter
    # stability experiment, not a component ablation and not an external baseline.
    sensitivity = []
    for r in ours:
        th = parse_bf_threshold(r.get("experiment"))
        if th is not None:
            rr = dict(r)
            rr["bf_threshold"] = th
            sensitivity.append(rr)
    sensitivity.sort(key=lambda r: (str(r.get("dataset")), str(r.get("model")), float(r.get("bf_threshold", 0.0))))

    ablations = [
        r for r in ours
        if r.get("category") == "internal_ablation"
        and "efficiency" not in str(r.get("experiment", ""))
        and parse_bf_threshold(r.get("experiment")) is None
    ]
    efficiency = [r for r in ours if "efficiency" in str(r.get("experiment", "")) or "eff_" in str(r.get("experiment", ""))]
    write_csv(out / "ablation_results.csv", ablations)
    write_csv(out / "efficiency_results.csv", efficiency)
    write_csv(out / "bf_threshold_sensitivity.csv", sensitivity)

    md = []
    md.append("# Literature Comparison and Internal Analysis\n")
    md.append("Published external baselines are not re-run in this repository; they are cited from the corresponding papers. Internal ablations are reported separately and must not be mixed with external method comparisons.\n")
    md.append(markdown_table(single_rows, ["dataset", "method", "backbone", "accuracy", "reference"], "External Comparison on Single-table Benchmarks"))
    md.append(markdown_table(multi_rows, ["dataset", "method", "backbone", "accuracy", "reference"], "External Context for Multi-table Benchmarks"))
    if ablations:
        md.append(markdown_table(ablations, ["dataset", "experiment", "model", "score", "invalid_rate", "topk_oracle_coverage", "ranking_error_rate"], "Internal Ablation Results"))
    if sensitivity:
        md.append(markdown_table(sensitivity, ["dataset", "model", "bf_threshold", "score", "invalid_rate", "topk_oracle_coverage", "generation_miss_rate", "ranking_error_rate"], "Bayes-Factor Threshold Sensitivity"))
    if efficiency:
        md.append(markdown_table(efficiency, ["dataset", "experiment", "model", "score", "llm_calls", "total_tokens", "estimated_cost_usd"], "Efficiency Results"))
    (out / "comparison_tables.md").write_text("\n".join(md), encoding="utf-8")
    print(f"Wrote tables to {out}")

if __name__ == "__main__":
    main()
