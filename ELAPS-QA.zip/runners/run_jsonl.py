from __future__ import annotations
"""Generic JSONL runner for precomputed candidates.

Input JSONL example for SQL:
{"task_id":"1","task_type":"sqlite_multitable_qa","question":"...","db_path":"/path/a.db","candidates":["SELECT ..."]}

Input JSONL example for pandas:
{"task_id":"2","task_type":"csv_excel_multitable_qa","question":"...","tables":{"students":"students.csv"},"candidates":["answer = ..."]}

This runner is intentionally simple: it is for framework-level tests when you already
have generated candidates. LLM generation can be added as a CandidateGenerator.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse, json, sys
from pathlib import Path

from candidate_framework import TaskContext, CandidateProgramEngine
from adapters.sql import SQLListGenerator, SQLSchemaRuleGenerator, SQLiteExecutor, SQLVerifier, SQLRepairer, build_sqlite_schema_graph
from adapters.pandas_table import PandasCodeGenerator, SafePandasExecutor, PandasVerifier, PandasRepairer, load_table_files
from adapters.table_ops import TableOpsGenerator, TableOpsExecutor, TableOpsVerifier, TableOpsRepairer
from adapters.fact_verify import EvidenceChainGenerator, EvidenceExecutor, EvidenceVerifier, EvidenceRepairer


def build_engine_and_context(obj):
    task_type = obj.get("task_type")
    q = obj.get("question") or obj.get("claim") or ""
    tid = str(obj.get("task_id", ""))
    candidates = obj.get("candidates", [])
    if task_type in {"sqlite_multitable_qa", "sql", "tqa", "spider"}:
        db_path = obj["db_path"]
        ctx = TaskContext(tid, q, None, task_type="sqlite_multitable_qa", metadata={"db_path": db_path, "entity_id_column": obj.get("entity_id_column")})
        ctx.metadata["schema_graph"] = build_sqlite_schema_graph(db_path)
        engine = CandidateProgramEngine([SQLListGenerator(candidates, "provided_sql"), SQLSchemaRuleGenerator()], SQLiteExecutor(), SQLVerifier(), [SQLRepairer()], max_repair_rounds=1)
        return engine, ctx
    if task_type in {"csv_excel_multitable_qa", "pandas"}:
        data = load_table_files(obj.get("tables", {}))
        ctx = TaskContext(tid, q, data, task_type="csv_excel_multitable_qa", metadata={"entity_id_column": obj.get("entity_id_column")})
        engine = CandidateProgramEngine([PandasCodeGenerator(candidates)], SafePandasExecutor(), PandasVerifier(), [PandasRepairer()], max_repair_rounds=1)
        return engine, ctx
    if task_type in {"single_table_qa", "wikitq", "table_ops"}:
        import pandas as pd
        data = pd.DataFrame(obj.get("table", []))
        ctx = TaskContext(tid, q, data, task_type="single_table_qa")
        engine = CandidateProgramEngine([TableOpsGenerator(candidates)], TableOpsExecutor(), TableOpsVerifier(), [TableOpsRepairer()], max_repair_rounds=1)
        return engine, ctx
    if task_type in {"fact_verification", "tabfact"}:
        import pandas as pd
        data = pd.DataFrame(obj.get("table", []))
        ctx = TaskContext(tid, q, data, task_type="fact_verification")
        engine = CandidateProgramEngine([EvidenceChainGenerator(candidates)], EvidenceExecutor(), EvidenceVerifier(), [EvidenceRepairer()], max_repair_rounds=1)
        return engine, ctx
    raise ValueError(f"Unsupported task_type: {task_type}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    out_path = Path(args.output); out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(args.input, "r", encoding="utf-8") as f, open(out_path, "w", encoding="utf-8") as out:
        for line in f:
            if not line.strip(): continue
            obj = json.loads(line)
            engine, ctx = build_engine_and_context(obj)
            result = engine.solve(ctx)
            selected = result.get("selected_candidate")
            row = {
                "task_id": result["task_id"],
                "task_type": result["task_type"],
                "answer": result["answer"],
                "answer_mass": result["answer_mass"],
                "num_initial_candidates": result["num_initial_candidates"],
                "num_evaluated_candidates": result["num_evaluated_candidates"],
                "selected_program": selected.program.content if selected else None,
                "selected_program_type": selected.program.program_type if selected else None,
                "selected_source": selected.program.source if selected else None,
                "selected_posterior": selected.posterior if selected else None,
            }
            out.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"Wrote {out_path}")

if __name__ == "__main__":
    main()
