from __future__ import annotations
"""Run four task instances through the same CandidateProgramEngine.

This demo proves the framework is not tied to TQA or SQL:
1) SQL / SQLite multi-table QA
2) CSV/Excel-style pandas multi-table QA
3) WikiTQ-style single-table operation chain
4) TabFact-style evidence verification chain
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import os
import sqlite3
import tempfile
import pandas as pd

from candidate_framework import TaskContext, CandidateProgramEngine
from candidate_framework.generators import ProvidedProgramGenerator
from adapters.sql import SQLListGenerator, SQLSchemaRuleGenerator, SQLiteExecutor, SQLVerifier, SQLRepairer, build_sqlite_schema_graph
from adapters.pandas_table import PandasCodeGenerator, SafePandasExecutor, PandasVerifier, PandasRepairer
from adapters.table_ops import TableOpsGenerator, TableOpsExecutor, TableOpsVerifier, TableOpsRepairer
from adapters.fact_verify import EvidenceChainGenerator, EvidenceExecutor, EvidenceVerifier, EvidenceRepairer


def run_sql_demo(tmpdir: str):
    db = os.path.join(tmpdir, "school.db")
    con = sqlite3.connect(db)
    con.executescript('''
    CREATE TABLE students(student_id INTEGER PRIMARY KEY, name TEXT, dept TEXT);
    CREATE TABLE courses(course_id INTEGER PRIMARY KEY, course_name TEXT);
    CREATE TABLE enrollments(student_id INTEGER, course_id INTEGER, score REAL);
    INSERT INTO students VALUES (1,'Alice','CS'),(2,'Bob','CS'),(3,'Cara','Math');
    INSERT INTO courses VALUES (10,'AI'),(11,'Database');
    INSERT INTO enrollments VALUES (1,10,95),(2,10,88),(3,11,91);
    ''')
    con.close()
    q = "How many students scored above 90 in AI courses?"
    ctx = TaskContext(
        task_id="sql_demo",
        task_type="sqlite_multitable_qa",
        question=q,
        data=None,
        metadata={"db_path": db, "entity_id_column": "student_id"},
    )
    ctx.metadata["schema_graph"] = build_sqlite_schema_graph(db)
    sqls = [
        "SELECT COUNT(*) FROM enrollments e JOIN courses c ON e.course_id=c.course_id WHERE c.course_name='AI' AND e.score>90",
        "SELECT COUNT(DISTINCT e.student_id) FROM enrollments e JOIN courses c ON e.course_id=c.course_id WHERE c.course_name='AI' AND e.score>90",
    ]
    engine = CandidateProgramEngine(
        generators=[SQLListGenerator(sqls, "llm_sql"), SQLSchemaRuleGenerator()],
        executor=SQLiteExecutor(),
        verifier=SQLVerifier(),
        repairers=[SQLRepairer()],
        max_repair_rounds=1,
    )
    return engine.solve(ctx)


def run_pandas_demo():
    students = pd.DataFrame({"student_id": [1, 2, 3], "name": ["Alice", "Bob", "Cara"], "dept": ["CS", "CS", "Math"]})
    courses = pd.DataFrame({"course_id": [10, 11], "course_name": ["AI", "Database"]})
    enrollments = pd.DataFrame({"student_id": [1, 2, 3], "course_id": [10, 10, 11], "score": [95, 88, 91]})
    q = "How many students scored above 90 in AI courses?"
    codes = [
        "df = enrollments.merge(courses, on='course_id')\nanswer = df[(df['course_name']=='AI') & (df['score']>90)]['student_id'].count()",
        "df = enrollments.merge(courses, on='course_id')\nanswer = df[(df['course_name']=='AI') & (df['score']>90)]['student_id'].nunique()",
    ]
    ctx = TaskContext("pandas_demo", q, {"students": students, "courses": courses, "enrollments": enrollments}, task_type="csv_excel_multitable_qa", metadata={"entity_id_column": "student_id"})
    engine = CandidateProgramEngine(
        generators=[PandasCodeGenerator(codes, "llm_pandas")],
        executor=SafePandasExecutor(),
        verifier=PandasVerifier(),
        repairers=[PandasRepairer()],
        max_repair_rounds=1,
    )
    return engine.solve(ctx)


def run_wikitq_style_demo():
    df = pd.DataFrame({"Player": ["Ann", "Ben", "Cat"], "Score": [8, 12, 10]})
    q = "Which player has the highest score?"
    chains = [
        [{"op": "sort", "column": "Score", "ascending": False}, {"op": "first"}, {"op": "return", "column": "Player"}],
        [{"op": "aggregate", "column": "Score", "func": "avg"}],
    ]
    ctx = TaskContext("wikitq_style_demo", q, df, task_type="single_table_qa")
    engine = CandidateProgramEngine(
        generators=[TableOpsGenerator(chains, "llm_table_ops")],
        executor=TableOpsExecutor(),
        verifier=TableOpsVerifier(),
        repairers=[TableOpsRepairer()],
    )
    return engine.solve(ctx)


def run_tabfact_style_demo():
    df = pd.DataFrame({"Player": ["Ann", "Ben", "Cat"], "Score": [8, 12, 10]})
    claim = "Ben is the player with the highest score."
    chains = [
        [{"op": "argmax", "column": "Score"}, {"op": "check", "column": "Player", "cmp": "==", "value": "Ben"}],
        [{"op": "argmin", "column": "Score"}, {"op": "check", "column": "Player", "cmp": "==", "value": "Ben"}],
    ]
    ctx = TaskContext("tabfact_style_demo", claim, df, task_type="fact_verification")
    engine = CandidateProgramEngine(
        generators=[EvidenceChainGenerator(chains, "llm_evidence_chain")],
        executor=EvidenceExecutor(),
        verifier=EvidenceVerifier(),
        repairers=[EvidenceRepairer()],
    )
    return engine.solve(ctx)


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as td:
        results = {
            "sql_multitable": run_sql_demo(td),
            "pandas_multitable": run_pandas_demo(),
            "single_table_ops": run_wikitq_style_demo(),
            "fact_verification": run_tabfact_style_demo(),
        }
    for name, result in results.items():
        print("\n===", name, "===")
        print("answer:", result["answer"])
        print("answer_mass:", result["answer_mass"])
        selected = result["selected_candidate"]
        if selected:
            print("selected_type:", selected.program.program_type, "source:", selected.program.source)
            print("selected_program:", selected.program.content)
            print("posterior:", round(selected.posterior, 4), "score:", round(selected.bayes_score, 4))
