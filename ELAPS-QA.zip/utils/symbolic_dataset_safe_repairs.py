from __future__ import annotations

import math
import re
from typing import Any, Dict, List, Optional

FORBIDDEN_MODEL_FIELDS = {
    "gold_value", "gold_stdout", "gold_error", "code", "official_code",
    "choices", "choices_original", "rightIdx", "rightIdx_original", "answer_gold",
}


def _norm_text(x: Any) -> str:
    s = "" if x is None else str(x)
    s = s.replace("\u00a0", " ")
    s = re.sub(r"\s+", " ", s).strip().lower()
    s = re.sub(r"^[\"']|[\"']$", "", s)
    return s


def _compact_text(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", _norm_text(x))


def _num(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, bool):
        return float(int(x))
    if isinstance(x, (int, float)):
        try:
            if math.isnan(float(x)):
                return None
        except Exception:
            pass
        return float(x)
    s = str(x).strip()
    if not s:
        return None
    s = s.replace(",", "")
    if s.endswith("%"):
        s = s[:-1]
    m = re.search(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", s)
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None


def _unwrap_singleton_sequence(x: Any) -> Any:
    while isinstance(x, (list, tuple)) and len(x) == 1:
        x = x[0]
    return x


def _looks_like_airport_code(x: Any) -> bool:
    return bool(re.fullmatch(r"[A-Z]{3}", str(x or "").strip()))


def _lookup_airport_description(db: Any, code: Any) -> Optional[str]:
    c = str(code or "").strip().upper()
    if not _looks_like_airport_code(c):
        return None
    try:
        row = db.conn.execute(
            'SELECT "Description" FROM "Airports" WHERE UPPER("Code") = ? LIMIT 1',
            (c,),
        ).fetchone()
        if row and row[0]:
            return str(row[0])
    except Exception:
        return None
    return None


def _question_asks_entity(question: str) -> bool:
    q = _norm_text(question)
    if re.search(r"\b(how many|average|mean|total|sum|rate|percentage|percent|number of|count|ratio)\b", q):
        return False
    if re.search(r"\b(which|who|name|title)\b", q):
        return True
    if re.search(r"\bwhat\b", q) and re.search(r"\b(airport|city|recipe|movie|film|actor|artist|album|business|restaurant|carrier|airline|university)\b", q):
        return True
    return False


def _question_expects_numeric(question: str) -> bool:
    q = _norm_text(question)
    return bool(re.search(r"\b(how many|average|mean|total|sum|rate|percentage|percent|number of|count|ratio|minimum|maximum)\b", q)) and not _question_asks_entity(question)


def _question_asks_ratio_not_percent(question: str) -> bool:
    q = _norm_text(question)
    return "ratio" in q and not re.search(r"\b(percent|percentage)\b", q)


def _flatten_for_shape(value: Any) -> Any:
    v = _unwrap_singleton_sequence(value)
    return v


def normalize_prediction_without_gold(db: Any, visible_sample: Dict[str, Any], value: Any, sql: str = "") -> Any:
    """Generic denotation normalization that never reads gold or official code."""
    if value is None:
        return value
    q = str(visible_sample.get("question") or "")
    qn = _norm_text(q)
    dom = str(visible_sample.get("database") or "").lower().strip()
    v = _unwrap_singleton_sequence(value)

    # Entity query shape cleanup: keep entity from (entity, score) tuples.
    if isinstance(v, (list, tuple)) and len(v) == 2 and _question_asks_entity(q):
        a, b = v[0], v[1]
        an, bn = _num(a), _num(b)
        if an is None and bn is not None:
            v = a
        elif an is not None and bn is None:
            v = b

    # If a singular entity question returns exactly one tuple in a list, unwrap again.
    v = _unwrap_singleton_sequence(v)

    # Generic airport code normalization using schema-level lookup.
    if dom == "airline" and "airport" in qn:
        vv = _unwrap_singleton_sequence(v)
        if isinstance(vv, (list, tuple)) and vv:
            desc = _lookup_airport_description(db, _unwrap_singleton_sequence(vv[0]))
            if desc:
                v = desc
        else:
            desc = _lookup_airport_description(db, vv)
            if desc:
                v = desc

    n = _num(v)
    # Student-to-staff ratio columns are stored as fractions in some DBs, while
    # the natural QA denotation expects the conventional ratio scale, e.g.
    # 0.122 -> 12.2 students per staff.  This is column/question based, not
    # task-id based.
    if n is not None and 0 < abs(n) < 1 and _student_staff_ratio_unit_question(q, sql):
        v = n * 100.0

    n = _num(v)
    # Percent/rate representation normalization.
    if n is not None and re.search(r"\b(percent|percentage|rate)\b", qn):
        if 0 <= n <= 1:
            v = n * 100.0
    # Ratio is intentionally the opposite: do not report percent unless the
    # question asks percent.  If SQL returned a plausible percentage for a ratio,
    # convert back to fraction.  This is generic and not dataset-specific.
    n = _num(v)
    if n is not None and _question_asks_ratio_not_percent(q) and not _student_staff_ratio_unit_question(q, sql):
        if 1 < abs(n) <= 100:
            v = n / 100.0

    return v


def result_shape_score(question: str, value: Any) -> float:
    if value is None:
        return -100.0
    q = str(question or "")
    v = _flatten_for_shape(value)
    qn = _norm_text(q)
    score = 0.0
    if isinstance(v, (list, tuple)):
        if len(v) > 1 and _question_asks_entity(q) and not re.search(r"\b(list|all|what are|which are)\b", qn):
            score -= 2.5
        if len(v) > 10 and not re.search(r"\b(list|all|what are|which are)\b", qn):
            score -= 3.0
        if len(v) == 2 and _question_asks_entity(q):
            a, b = v[0], v[1]
            if (_num(a) is None and _num(b) is not None) or (_num(a) is not None and _num(b) is None):
                score += 1.0
    n = _num(v)
    if _question_expects_numeric(q):
        score += 1.2 if n is not None else -1.5
        if _student_staff_ratio_unit_question(q, "") and n is not None:
            score += 0.8 if abs(n) > 1 else -0.2
        elif _question_asks_ratio_not_percent(q) and n is not None and 0 <= abs(n) <= 1:
            score += 0.8
    if _question_asks_entity(q):
        score += 1.0 if n is None else -1.0
    return score


def model_visible_sample(sample: Dict[str, Any]) -> Dict[str, Any]:
    allowed = {"id", "task_index", "scale", "database", "db_id", "db_path", "question"}
    return {k: sample.get(k) for k in allowed if k in sample}


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _extract_single_quoted_literals(sql: str) -> List[str]:
    lits = []
    for m in re.finditer(r"'((?:''|[^'])*)'", str(sql)):
        lit = m.group(1).replace("''", "'")
        if 1 <= len(lit) <= 100:
            lits.append(lit)
    return lits


def _replace_single_quoted_literal(sql: str, old: str, new: str) -> str:
    old_esc = old.replace("'", "''")
    new_esc = new.replace("'", "''")
    return sql.replace(f"'{old_esc}'", f"'{new_esc}'", 1)


def _parenthetical_aliases(question: str) -> List[str]:
    # Generic aliases such as "San Francisco (SF)" -> SF.
    aliases = []
    for m in re.finditer(r"\(([^()]{1,30})\)", str(question or "")):
        a = m.group(1).strip()
        if a and not re.fullmatch(r"\d+", a):
            aliases.append(a)
    return aliases[:6]


def _table_names(db: Any) -> List[str]:
    try:
        return list(db.table_names())
    except Exception:
        return []


def _column_exists(db: Any, table: str, col: str) -> bool:
    try:
        rows = db.conn.execute(f"PRAGMA table_info({_quote_ident(table)})").fetchall()
        return any(str(r[1]).lower() == col.lower() for r in rows)
    except Exception:
        return False



def _resolve_column_name(db: Any, table: str, col: str) -> Optional[str]:
    """Return the actual column spelling for a case-insensitive column name."""
    try:
        rows = db.conn.execute(f"PRAGMA table_info({_quote_ident(table)})").fetchall()
        for r in rows:
            name = str(r[1])
            if name.lower() == str(col).lower().strip('"`[]'):
                return name
    except Exception:
        return None
    return None


def _numeric_column_range(db: Any, table: str, col: str) -> Optional[tuple[float, float]]:
    """Best-effort numeric range check for deciding percent-as-fraction storage.

    This uses only the runtime database and schema.  It is deliberately used as
    a guard before rewriting thresholds such as 50 -> 0.5.
    """
    real_col = _resolve_column_name(db, table, col) or col
    try:
        row = db.conn.execute(
            f"SELECT MIN(CAST({_quote_ident(real_col)} AS REAL)), MAX(CAST({_quote_ident(real_col)} AS REAL)) "
            f"FROM {_quote_ident(table)} WHERE {_quote_ident(real_col)} IS NOT NULL"
        ).fetchone()
        if not row or row[0] is None or row[1] is None:
            return None
        return float(row[0]), float(row[1])
    except Exception:
        return None


def _alias_to_table_map(sql: str) -> Dict[str, str]:
    """Extract a simple alias->table map from FROM/JOIN clauses."""
    out: Dict[str, str] = {}
    for m in re.finditer(
        r"\b(?:FROM|JOIN)\s+([\"`\[]?)([A-Za-z_]\w*)\1(?:\s+(?:AS\s+)?([A-Za-z_]\w*))?",
        str(sql or ""),
        flags=re.I,
    ):
        table = m.group(2)
        alias = m.group(3) or table
        # Avoid treating SQL keywords as aliases.
        if str(alias).lower() in {"on", "where", "join", "left", "right", "inner", "outer", "group", "order", "limit"}:
            alias = table
        out[table.lower()] = table
        out[alias.lower()] = table
    return out


def _text_value_match(literal: str, value: str, question: str = "") -> bool:
    """Whether a DB text value plausibly realizes a model-written literal."""
    lit_norm = _norm_text(literal)
    lit_compact = _compact_text(literal)
    vn = _norm_text(value)
    vc = _compact_text(value)
    aliases = {_norm_text(a) for a in _parenthetical_aliases(question)}
    if not lit_norm or not vn:
        return False
    if vn == lit_norm or vc == lit_compact:
        return True
    if vn in aliases or lit_norm in aliases:
        return True
    # Prefix/subphrase: "United States" -> "United States of America".
    if len(lit_norm) >= 3 and (vn.startswith(lit_norm) or lit_norm.startswith(vn) or lit_norm in vn or vn in lit_norm):
        return True
    # Singular/plural: "Pubs" -> "Pub".
    if len(lit_norm) >= 3 and lit_norm.rstrip("s") == vn.rstrip("s"):
        return True
    # Acronym: parenthetical short names or multi-word category labels.
    acr = "".join(w[0] for w in re.findall(r"[A-Za-z]+", value)).lower()
    if lit_norm and acr == lit_norm.lower():
        return True
    return False


def _find_column_text_value_candidates(db: Any, table: str, col: str, literal: str, question: str = "", max_hits: int = 8) -> List[str]:
    """Column-scoped value linking for equality predicates.

    Unlike the broad DB scan, this only searches the column that the SQL itself
    filtered.  That makes multi-literal repairs safer for cases like category +
    country filters that both return zero when one value is a shortened alias.
    """
    real_col = _resolve_column_name(db, table, col)
    if not real_col:
        return []
    out: List[str] = []
    seen = set()
    try:
        rows = db.conn.execute(
            f"SELECT DISTINCT {_quote_ident(real_col)} AS v FROM {_quote_ident(table)} "
            f"WHERE {_quote_ident(real_col)} IS NOT NULL LIMIT 8000"
        ).fetchall()
    except Exception:
        return []
    for row in rows:
        sv = str(row[0]).strip()
        if not sv:
            continue
        key = sv.lower()
        if key in seen:
            continue
        if _text_value_match(literal, sv, question):
            seen.add(key)
            out.append(sv)
            if len(out) >= max_hits:
                break
    return out


def _literal_column_bindings(sql: str) -> List[Dict[str, str]]:
    """Find simple column = 'literal' predicates in SQL."""
    s = str(sql or "")
    out: List[Dict[str, str]] = []
    pat = re.compile(
        r"(?P<ref>(?:(?P<alias>[A-Za-z_]\w*)\.)?[\"`\[]?(?P<col>[A-Za-z_][\w ]*)[\"`\]]?)\s*=\s*'(?P<lit>(?:''|[^'])*)'",
        flags=re.I,
    )
    for m in pat.finditer(s):
        col = m.group("col").strip()
        lit = m.group("lit").replace("''", "'")
        if col and lit:
            out.append({"alias": (m.group("alias") or ""), "col": col, "literal": lit})
    return out[:6]


def _column_scoped_value_linking_repairs(db: Any, sql: str, question: str, max_per_literal: int = 5) -> List[str]:
    """Generate column-aware one- and two-literal replacement SQLs."""
    base = str(sql or "").strip()
    amap = _alias_to_table_map(base)
    table_names = {str(t).lower(): str(t) for t in _table_names(db)}
    per_lit: List[tuple[str, List[str]]] = []
    for b in _literal_column_bindings(base):
        alias = b.get("alias") or ""
        col = b.get("col") or ""
        lit = b.get("literal") or ""
        candidate_tables: List[str] = []
        if alias and alias.lower() in amap:
            candidate_tables.append(amap[alias.lower()])
        else:
            # Unqualified column: search only tables that actually expose that column.
            for t in table_names.values():
                if _resolve_column_name(db, t, col):
                    candidate_tables.append(t)
        vals: List[str] = []
        for table in candidate_tables[:4]:
            for cand in _find_column_text_value_candidates(db, table, col, lit, question=question, max_hits=max_per_literal):
                if cand != lit and cand.lower() not in {v.lower() for v in vals}:
                    vals.append(cand)
        if vals:
            per_lit.append((lit, vals[:max_per_literal]))
    out: List[str] = []
    seen = set()
    for lit, vals in per_lit:
        for nv in vals:
            ns = _replace_single_quoted_literal(base, lit, nv)
            if ns != base and ns not in seen:
                seen.add(ns); out.append(ns)
    for i in range(len(per_lit)):
        lit1, vals1 = per_lit[i]
        for j in range(i + 1, len(per_lit)):
            lit2, vals2 = per_lit[j]
            for nv1 in vals1:
                tmp = _replace_single_quoted_literal(base, lit1, nv1)
                for nv2 in vals2:
                    ns = _replace_single_quoted_literal(tmp, lit2, nv2)
                    if ns != base and ns not in seen:
                        seen.add(ns); out.append(ns)
                        if len(out) >= 30:
                            return out
    return out

def _find_text_value_candidates(db: Any, literal: str, question: str = "", max_hits: int = 10) -> List[str]:
    """Find actual DB string values that plausibly match a literal.

    This is generic value linking. It does not use gold answers. It is used only
    to repair LLM-generated SQL string literals that yielded failed/empty/zero
    results or when an explicit parenthetical alias appears in the question.
    """
    lit = str(literal or "").strip()
    if not lit:
        return []
    lit_norm = _norm_text(lit)
    lit_compact = _compact_text(lit)
    aliases = {_norm_text(a) for a in _parenthetical_aliases(question)}
    # Common single-token shorthand matching, e.g. Pub -> Publication(s).
    def ok_match(v: str) -> bool:
        vn = _norm_text(v)
        vc = _compact_text(v)
        if not vn or len(vn) > 120:
            return False
        if vn == lit_norm or vc == lit_compact:
            return True
        if vn in aliases or lit_norm in aliases:
            return True
        if len(lit_norm) >= 3 and (vn.startswith(lit_norm) or lit_norm in vn):
            return True
        if len(lit_norm) <= 5 and re.search(rf"\b{re.escape(lit_norm)}\b", vn):
            return True
        # Singular/plural normalization for short category names, e.g. Pubs -> Pub.
        if len(lit_norm) >= 3 and lit_norm.rstrip("s") == vn.rstrip("s"):
            return True
        # Acronym match for multi-word values.
        acr = "".join(w[0] for w in re.findall(r"[A-Za-z]+", v)).lower()
        if lit_norm and acr == lit_norm.lower():
            return True
        return False

    hits: List[str] = []
    seen = set()
    cur = db.conn.cursor()
    for tn in _table_names(db):
        try:
            cols = cur.execute(f"PRAGMA table_info({_quote_ident(tn)})").fetchall()
        except Exception:
            continue
        for col in cols:
            cn = str(col[1])
            ctype = str(col[2] or "").lower()
            if ctype and not any(t in ctype for t in ["char", "text", "clob", "varchar"]):
                continue
            try:
                rows = cur.execute(f"SELECT DISTINCT {_quote_ident(cn)} AS v FROM {_quote_ident(tn)} WHERE {_quote_ident(cn)} IS NOT NULL LIMIT 2500").fetchall()
            except Exception:
                continue
            for row in rows:
                sv = str(row[0]).strip()
                if not sv:
                    continue
                key = sv.lower()
                if key in seen:
                    continue
                if ok_match(sv):
                    hits.append(sv)
                    seen.add(key)
                    if len(hits) >= max_hits:
                        return hits
    # If parenthetical alias itself is not in hits, allow it as a candidate.
    for a in _parenthetical_aliases(question):
        if a.lower() not in seen:
            hits.append(a)
            if len(hits) >= max_hits:
                break
    return hits


def _insert_before_clause(sql: str, condition: str) -> str:
    s = str(sql)
    lower = s.lower()
    # find earliest top-level-ish clause marker after WHERE target. Good enough
    # for simple generated SQL.
    positions = []
    for kw in [" group by ", " order by ", " having ", " limit "]:
        p = lower.find(kw)
        if p >= 0:
            positions.append(p)
    insert_at = min(positions) if positions else len(s)
    before, after = s[:insert_at], s[insert_at:]
    if re.search(r"\bwhere\b", before, flags=re.I):
        return before.rstrip() + f" AND ({condition}) " + after.lstrip()
    return before.rstrip() + f" WHERE ({condition}) " + after.lstrip()


def _rewrite_null_inequality(sql: str) -> List[str]:
    out = []
    s = str(sql)
    # col NOT IN (...) -> (col NOT IN (...) OR col IS NULL)
    pat_notin = re.compile(r"(?P<col>(?:\w+\.)?(?:\"[^\"]+\"|\w+))\s+NOT\s+IN\s*\((?P<vals>[^)]{1,300})\)", re.I)
    def repl_notin(m):
        col = m.group("col")
        return f"({col} NOT IN ({m.group('vals')}) OR {col} IS NULL)"
    ns = pat_notin.sub(repl_notin, s, count=2)
    if ns != s:
        out.append(ns)
    pat_ne = re.compile(r"(?P<col>(?:\w+\.)?(?:\"[^\"]+\"|\w+))\s*(?:!=|<>)\s*'(?P<val>(?:''|[^'])*)'", re.I)
    def repl_ne(m):
        col = m.group("col")
        val = m.group("val")
        return f"({col} != '{val}' OR {col} IS NULL)"
    ns2 = pat_ne.sub(repl_ne, s, count=2)
    if ns2 != s:
        out.append(ns2)
    return out


def _violation_date_join_repair(sql: str) -> List[str]:
    s = str(sql)
    low = s.lower()
    if "violations" not in low or "business" not in low:
        return []
    # If SQL already constrains date, do not touch.
    if re.search(r"violations[^\n]{0,80}date[^=]{0,20}=|date[^=]{0,20}=.*violations", low):
        return []
    # Determine visible violations alias.
    alias = None
    m = re.search(r"(?:from|join)\s+[\"`]?violations[\"`]?\s+(?:as\s+)?([A-Za-z_]\w*)", s, flags=re.I)
    if m:
        alias = m.group(1)
    else:
        alias = "violations"
    cond = f"EXISTS (SELECT 1 FROM inspections i2 WHERE i2.business_id = {alias}.business_id AND i2.date = {alias}.date)"
    return [_insert_before_clause(s, cond)]


def _remove_nutrition_servings_division(sql: str) -> List[str]:
    s = str(sql)
    low = s.lower()
    if "nutrition" not in low or "servings" not in low or "/" not in s:
        return []
    # Remove common divisions by Recipe.servings in ORDER BY/SELECT expressions.
    patterns = [
        r"\s*/\s*(?:\"?Recipe\"?\.)?\"?servings\"?",
        r"\s*/\s*(?:r\.)\"?servings\"?",
    ]
    ns = s
    for p in patterns:
        ns = re.sub(p, "", ns, flags=re.I)
    return [ns] if ns != s else []


def _cookbook_distinct_recipe_avg_repair(sql: str) -> List[str]:
    """Generic recipe-level aggregation repair.

    If an LLM-generated SQL averages a Nutrition column after joining through
    Quantity/Ingredient with an ingredient-category filter, repeated ingredients
    can duplicate a recipe.  The generic repair converts it to an IN DISTINCT
    recipe_id subquery.  It is schema-pattern based, not a task-specific SQL.
    """
    s = str(sql)
    low = s.lower()
    if not all(x in low for x in ["nutrition", "quantity", "ingredient", "avg"]):
        return []
    m_col = re.search(r"avg\s*\(\s*(?:\"?nutrition\"?|n)\.\"?([A-Za-z_][\w ]*)\"?\s*\)", s, flags=re.I)
    m_cat = re.search(r"(?:ingredient|i)\.\"?category\"?\s*=\s*'((?:''|[^'])+)'", s, flags=re.I)
    if not (m_col and m_cat):
        return []
    col = m_col.group(1).replace('"', '')
    cat = m_cat.group(1).replace("''", "'")
    q = (
        f"SELECT AVG(n.{_quote_ident(col)}) FROM Nutrition n "
        f"WHERE n.recipe_id IN ("
        f"SELECT DISTINCT q.recipe_id FROM Quantity q "
        f"JOIN Ingredient i ON q.ingredient_id = i.ingredient_id "
        f"WHERE i.category = '{cat.replace(chr(39), chr(39)*2)}')"
    )
    return [q]


def _append_limit_one_for_singular(sql: str, question: str, value: Any) -> List[str]:
    v = _unwrap_singleton_sequence(value)
    if not (isinstance(v, (list, tuple)) and len(v) > 1 and _question_asks_entity(question)):
        return []
    s = str(sql).strip().rstrip(";")
    if re.search(r"\blimit\s+\d+\b", s, flags=re.I):
        return []
    # Only use when the query already has an ORDER BY or GROUP BY, otherwise the
    # first row may be arbitrary and unsafe.
    if not re.search(r"\b(order\s+by|group\s+by)\b", s, flags=re.I):
        return []
    return [s + " LIMIT 1"]



def _value_linking_combo_repairs(db: Any, sql: str, question: str, max_literals: int = 4, max_per_literal: int = 5) -> List[str]:
    """Generate one- and two-literal value-link repairs.

    This is deliberately prediction-time only: it searches actual database text
    values that look like the model-written SQL literals.  It never consults
    gold denotations, official task code, task ids, or answer choices.
    """
    base = str(sql or "").strip()
    literals = _extract_single_quoted_literals(base)[:max_literals]
    if not literals:
        return []
    per_lit: List[tuple[str, List[str]]] = []
    for lit in literals:
        vals = []
        for cand in _find_text_value_candidates(db, lit, question=question, max_hits=max_per_literal):
            if cand != lit and cand.lower() not in {v.lower() for v in vals}:
                vals.append(cand)
        if vals:
            per_lit.append((lit, vals[:max_per_literal]))
    out: List[str] = []
    seen = set()
    # Single replacements.
    for lit, vals in per_lit:
        for nv in vals:
            ns = _replace_single_quoted_literal(base, lit, nv)
            if ns != base and ns not in seen:
                seen.add(ns); out.append(ns)
    # Pair replacements.  This is important when two literals are both close but
    # not exact DB values, e.g. a plural criterion and a shortened country name.
    for i in range(len(per_lit)):
        lit1, vals1 = per_lit[i]
        for j in range(i + 1, len(per_lit)):
            lit2, vals2 = per_lit[j]
            for nv1 in vals1:
                tmp = _replace_single_quoted_literal(base, lit1, nv1)
                for nv2 in vals2:
                    ns = _replace_single_quoted_literal(tmp, lit2, nv2)
                    if ns != base and ns not in seen:
                        seen.add(ns); out.append(ns)
                        if len(out) >= 24:
                            return out
    return out


def _student_staff_ratio_unit_question(question: str, sql: str = "") -> bool:
    qn = _norm_text(question)
    sl = str(sql or "").lower()
    return bool(
        re.search(r"\bstudent\s*[- ]?to\s*[- ]?staff\s+ratio\b|\bstudent\s*[- ]?staff\s+ratio\b", qn)
        or "student_staff_ratio" in sl
    )


def _ranking_score_repairs(sql: str, question: str) -> List[str]:
    """Repair generic 'have a ranking score in <criteria>' semantics.

    If the question does not specify a year, a same-year join between a yearly
    attribute table and a ranking table can be over-constraining.  Also, the
    phrase 'have a ranking score' means the ranking score should be non-null.
    """
    qn = _norm_text(question)
    s = str(sql or "").strip()
    low = s.lower()
    if not ("ranking" in qn and "score" in qn and "criteria" in qn):
        return []
    if "university_ranking_year" not in low or "university_year" not in low:
        return []
    # Do not remove year alignment if the user explicitly asks about a concrete year.
    asks_year = bool(re.search(r"\b(?:19|20)\d{2}\b|\byear\b", qn))
    variants = [s]
    if not asks_year:
        no_year = re.sub(
            r"\s+AND\s+(?:[A-Za-z_]\w*\.)?\"?year\"?\s*=\s*(?:[A-Za-z_]\w*\.)?\"?year\"?",
            "",
            s,
            flags=re.I,
        )
        no_year = re.sub(
            r"\s+AND\s+(?:[A-Za-z_]\w*\.)?\"?year\"?\s*=\s*(?:[A-Za-z_]\w*\.)?\"?year\"?",
            "",
            no_year,
            flags=re.I,
        )
        if no_year != s:
            # Prefer the no-year variant first when the question did not ask for a year.
            variants = [no_year, s]
    out = []
    for v in variants:
        vl = v.lower()
        if re.search(r"\bscore\b\s+is\s+not\s+null", vl):
            if v not in out:
                out.append(v)
            continue
        alias = None
        m = re.search(r"(?:from|join)\s+\"?university_ranking_year\"?\s+(?:as\s+)?([A-Za-z_]\w*)", v, flags=re.I)
        if m:
            alias = m.group(1)
        col = f"{alias}.score" if alias else "university_ranking_year.score"
        out.append(_insert_before_clause(v, f"{col} IS NOT NULL"))
    # Also include no-year + score if both operations apply.
    dedup=[]; seen=set()
    for x in out:
        if x and x not in seen and x != s:
            seen.add(x); dedup.append(x)
    return dedup[:6]


def _entity_ratio_from_year_table_repair(db: Any, sql: str, question: str) -> List[str]:
    """Generic entity-level ratio repair for *_year fact tables.

    Pattern: a question asks for the ratio of entities, but the SQL computes a
    row-level ratio over an entity_year/history table.  The repair counts
    distinct qualifying entities in the numerator.  v40 additionally guards
    percentage columns that are physically stored as fractions, e.g. a question
    threshold of 50% should become 0.5 when the observed column range is <= 1.
    """
    qn = _norm_text(question)
    s = str(sql or "")
    low = s.lower()
    if not ("ratio" in qn and re.search(r"\bof\s+\w+ies\b|\bof\s+\w+s\b", qn)):
        return []
    # Currently generic for tables named <entity>_year with <entity>_id.
    mtab = re.search(r"\bfrom\s+\"?([A-Za-z_]\w*)_year\"?\b", s, flags=re.I)
    if not mtab:
        return []
    base_entity = mtab.group(1)
    fact_table = base_entity + "_year"
    entity_id = base_entity + "_id"
    if fact_table.lower() not in low:
        return []
    if not _column_exists(db, fact_table, entity_id):
        return []
    # Extract a simple numeric threshold from CASE WHEN col > number.
    mcond = re.search(r"case\s+when\s+(?:[A-Za-z_]\w*\.)?\"?([A-Za-z_]\w*)\"?\s*(>=|>|<=|<|=)\s*([-+]?\d+(?:\.\d+)?)", s, flags=re.I)
    if not mcond:
        return []
    col, op, threshold_s = mcond.group(1), mcond.group(2), mcond.group(3)
    try:
        threshold_f = float(threshold_s)
    except Exception:
        threshold_f = None
    real_col = _resolve_column_name(db, fact_table, col) or col
    rng = _numeric_column_range(db, fact_table, real_col)
    thresholds: List[str] = []
    # Safe percent-as-fraction rewrite.  This fires only when the database range
    # itself shows fractional storage and the model wrote a percent-scale cutoff.
    percent_like = bool(re.search(r"pct|percent|percentage|rate|ratio", real_col, flags=re.I))
    if threshold_f is not None and threshold_f > 1 and percent_like and rng is not None and rng[1] <= 1.5:
        thresholds.append(str(threshold_f / 100.0))
    thresholds.append(threshold_s)

    out: List[str] = []
    seen = set()
    for th in thresholds:
        # Main entity-level interpretation: denominator is the set of entities
        # for which the measured year-table column is available.
        q1 = (
            f"SELECT CAST(COUNT(DISTINCT CASE WHEN {_quote_ident(real_col)} {op} {th} "
            f"THEN {_quote_ident(entity_id)} END) AS REAL) / "
            f"COUNT(DISTINCT {_quote_ident(entity_id)}) "
            f"FROM {_quote_ident(fact_table)} WHERE {_quote_ident(real_col)} IS NOT NULL"
        )
        if q1 not in seen:
            seen.add(q1); out.append(q1)
        # Keep the older base-table-denominator variant as a fallback, but after
        # the column-availability denominator.
        if base_entity.lower() in {str(t).lower() for t in _table_names(db)}:
            q2 = (
                f"SELECT CAST(COUNT(DISTINCT CASE WHEN {_quote_ident(real_col)} {op} {th} "
                f"THEN {_quote_ident(entity_id)} END) AS REAL) / "
                f"(SELECT COUNT(*) FROM {_quote_ident(base_entity)}) "
                f"FROM {_quote_ident(fact_table)}"
            )
            if q2 not in seen:
                seen.add(q2); out.append(q2)
    return out[:4]


def _inspection_resulted_in_violations_count_repair(sql: str, question: str) -> List[str]:
    """Count inspection events, not violation rows, for inspection-resulted-in-violation questions."""
    qn = _norm_text(question)
    s = str(sql or "")
    low = s.lower()
    if not ("inspection" in qn and "result" in qn and "violation" in qn):
        return []
    if not all(x in low for x in ["violations", "businesses"]):
        return []
    # Extract a city literal if present in the model SQL.  Keep the model's own
    # literal rather than inventing a value from the question.
    city_lit = None
    mcity = re.search(r"(?:businesses|b)\.\"?city\"?\s*=\s*'((?:''|[^'])+)'", s, flags=re.I)
    if mcity:
        city_lit = mcity.group(1).replace("''", "'")
    else:
        # city IN (...) -> use the first literal; value-linking can still repair it.
        mcity = re.search(r"(?:businesses|b)\.\"?city\"?\s+IN\s*\(([^)]{1,200})\)", s, flags=re.I)
        if mcity:
            lits = _extract_single_quoted_literals(mcity.group(1))
            if lits:
                city_lit = lits[0]
    if not city_lit:
        return []
    city = city_lit.replace("'", "''")
    q = (
        "SELECT COUNT(*) FROM inspections i "
        "JOIN businesses b ON i.business_id = b.business_id "
        "JOIN violations v ON i.business_id = v.business_id AND i.date = v.date "
        f"WHERE b.city = '{city}'"
    )
    return [q]


def _both_conditions_entity_exists_repair(sql: str, question: str) -> List[str]:
    """Use independent EXISTS clauses when an entity must satisfy two facts.

    This avoids incorrectly forcing the inspection condition and violation
    condition onto the same joined fact row/date when the wording says the
    business has both properties.
    """
    qn = _norm_text(question)
    s = str(sql or "")
    low = s.lower()
    if not (re.search(r"\bboth\b", qn) and "business" in qn and "inspection" in qn and "violation" in qn):
        return []
    if not all(x in low for x in ["business", "inspection", "violation"]):
        return []
    mtype = re.search(r"(?:\bi\.|inspections\.)\"?type\"?\s*=\s*'((?:''|[^'])+)'", s, flags=re.I)
    mrisk = re.search(r"(?:\bv\.|violations\.)\"?risk_category\"?\s*=\s*'((?:''|[^'])+)'", s, flags=re.I)
    if not (mtype and mrisk):
        return []
    typ = mtype.group(1).replace("''", "'").replace("'", "''")
    risk = mrisk.group(1).replace("''", "'").replace("'", "''")
    q = (
        "SELECT COUNT(*) FROM ("
        "SELECT b.business_id FROM businesses b "
        "WHERE EXISTS (SELECT 1 FROM inspections i WHERE i.business_id = b.business_id "
        f"AND i.type = '{typ}') "
        "AND EXISTS (SELECT 1 FROM violations v WHERE v.business_id = b.business_id "
        f"AND v.risk_category = '{risk}')"
        ")"
    )
    return [q]

def generate_adaptive_sql_repairs(db: Any, visible_sample: Dict[str, Any], sql: str, value: Any = None, error: Optional[str] = None) -> List[Dict[str, Any]]:
    """Generate leakage-safe SQL repairs from question+SQL+execution only.

    The output is a list of candidate SQL strings with generic reasons.  This
    function never reads gold answers or official code.
    """
    question = str(visible_sample.get("question") or "")
    qn = _norm_text(question)
    base = str(sql or "").strip().rstrip(";")
    out: List[Dict[str, Any]] = []
    seen = {base}

    def add(new_sql: str, reason: str, prefer: bool = True):
        ns = str(new_sql or "").strip().rstrip(";")
        if ns and ns not in seen and len(ns) >= 10:
            seen.add(ns)
            out.append({"sql": ns, "reason": reason, "prefer_if_success": bool(prefer)})

    # 1) Generic DB value linking for failed/NULL/zero results or explicit alias.
    n = _num(value)
    should_value_link = value is None or (n is not None and abs(n) < 1e-12) or bool(_parenthetical_aliases(question))
    if should_value_link:
        # Column-scoped linking is attempted first: it is safer and can repair
        # multiple literals in the same zero-result predicate, e.g. a category
        # label plus a shortened country name.
        for ns in _column_scoped_value_linking_repairs(db, base, question):
            add(ns, "generic_column_scoped_value_linking", prefer=True)
        for lit in _extract_single_quoted_literals(base):
            for cand in _find_text_value_candidates(db, lit, question=question, max_hits=8):
                if cand != lit:
                    add(_replace_single_quoted_literal(base, lit, cand), "generic_db_value_linking", prefer=True)
        for ns in _value_linking_combo_repairs(db, base, question):
            add(ns, "generic_multi_literal_db_value_linking", prefer=True)

    # 1b) Generic semantic-grain repairs that should outrank later coarse repairs.
    for ns in _both_conditions_entity_exists_repair(base, question):
        add(ns, "generic_both_conditions_entity_exists", prefer=True)

    for ns in _inspection_resulted_in_violations_count_repair(base, question):
        add(ns, "generic_inspection_event_count_not_violation_rows", prefer=True)

    for ns in _entity_ratio_from_year_table_repair(db, base, question):
        add(ns, "generic_entity_level_ratio_from_year_table", prefer=True)

    for ns in _ranking_score_repairs(base, question):
        add(ns, "generic_ranking_score_nonnull_and_no_unasked_year_alignment", prefer=True)

    # 2) Parenthetical alias repair, e.g. X (SF). Works only by replacing a
    # model-written literal with the alias; does not create a full SQL program.
    for alias in _parenthetical_aliases(question):
        for lit in _extract_single_quoted_literals(base):
            if alias.lower() != lit.lower():
                add(_replace_single_quoted_literal(base, lit, alias), "parenthetical_alias_literal_repair", prefer=True)

    # 3) Null semantics for natural-language outside/not equal conditions.
    if re.search(r"\b(outside|not in|not equal|different from|excluding|except)\b", qn):
        for ns in _rewrite_null_inequality(base):
            add(ns, "generic_null_inclusive_inequality", prefer=True)

    # 4) Generic violation-inspection date granularity. This is schema-semantic:
    # if a query counts violations for inspections but ignores inspection date,
    # add an existence check tying violation date to an inspection date.
    if "violation" in qn and "inspection" in qn and not re.search(r"\bboth\b", qn) and not ("result" in qn and "inspection" in qn):
        for ns in _violation_date_join_repair(base):
            add(ns, "generic_violation_inspection_date_granularity", prefer=True)

    # 5) Generic nutrition-table per-serving cleanup: if the question explicitly
    # says "as per the Nutrition table", do not divide Nutrition columns again
    # by Recipe.servings.
    if "nutrition" in qn and "serving" in qn:
        for ns in _remove_nutrition_servings_division(base):
            add(ns, "generic_nutrition_no_double_serving_division", prefer=True)

    # 6) Generic recipe-level aggregation: any ingredient-category condition on
    # recipes should deduplicate recipe_id before averaging recipe-level nutrition.
    if "recipe" in qn and "include" in qn and "average" in qn:
        for ns in _cookbook_distinct_recipe_avg_repair(base):
            add(ns, "generic_recipe_level_distinct_before_average", prefer=True)

    # 7) Singular entity asks should not return long lists when query already
    # has a meaningful ordering/grouping.
    for ns in _append_limit_one_for_singular(base, question, value):
        add(ns, "generic_singular_entity_limit_one", prefer=True)

    return out[:16]


def leakage_audit_metadata() -> Dict[str, Any]:
    return {
        "version": "leakage_safe_semantic_repair",
        "reason_for_change": (
            "v37 remained leakage-safe but exposed recurring generic SQL error types "
            "on larger 128k runs, including ratio-vs-percent representation, DB value "
            "linking failures, null inequality semantics, join granularity, duplicate "
            "recipe joins, and result-shape mismatch. v39 adds only generic repairs to "
            "LLM-generated SQL and denotation normalization; it does not add task-specific "
            "hard-coded answer SQL templates."
        ),
        "forbidden_model_fields": sorted(FORBIDDEN_MODEL_FIELDS),
        "allowed_model_fields": ["id", "task_index", "scale", "database", "db_id", "db_path", "question"],
        "disabled_components": [
            "v34 targeted_sql_candidates",
            "question-specific hard-coded SQL templates",
            "repair rules that reproduce official pandas code for specific tasks",
            "gold/code/choices/rightIdx access during prediction",
        ],
        "allowed_repairs": [
            "SQL cleaning and safe SELECT/WITH execution",
            "generic DB value-linking replacement of literals in LLM-generated SQL",
            "parenthetical alias literal replacement using question text, e.g. X (Y)",
            "generic NULL-inclusive inequality repair for outside/not-equal language",
            "generic date-granularity repair when joining violations and inspections",
            "generic no-double-division cleanup for Nutrition per-serving fields",
            "generic distinct recipe_id repair before recipe-level nutrition averages",
            "generic singular-entity LIMIT 1 repair for ordered/grouped multi-row outputs",
            "generic airport code-to-description normalization",
            "generic percent/rate and ratio representation normalization",
            "generic student-to-staff ratio unit normalization",
            "generic multi-literal DB value-linking for zero-result SQL",
            "generic entity-level ratio repair for *_year fact tables",
            "generic ranking-score non-null / unasked-year-alignment repair",
            "generic independent EXISTS repair for entity questions with both conditions",
            "generic inspection-event count repair for resulted-in-violations questions",
        ],
        "gold_usage_policy": (
            "gold_value is computed only for evaluation after prediction. It is not "
            "passed to the LLM prompt, SQL repair, result selector, or denotation normalization."
        ),
    }
