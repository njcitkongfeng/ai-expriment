from __future__ import annotations
"""High-precision TabFact verifiers used by Agent90 v12.

These verifiers are deliberately conservative.  They do not try to solve every
TabFact statement.  They only override the LLM self-consistency answer when a
small deterministic pattern is matched with enough confidence.

The goal is to fix recurring residual errors after the best Agent90 setting:
    gpt-4o + votes=7 + no symbolic + no rescue/audit/final guard.

Covered patterns:
  1. numeric exact-match and reason/answer self-contradiction,
  2. superlative/date sorting for date columns,
  3. multi-evidence AND where the LLM admits a missing conjunct,
  4. sports score / month-count / fraction-score checks.
"""


import math
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}
MONTH_RE = r"(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)"
NUM_WORDS = {
    "zero": 0, "no": 0,
    "one": 1, "a": 1, "an": 1,
    "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
    "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
    "nineteen": 19, "twenty": 20,
}
ORDINAL_WORDS = {
    "first": 1, "1st": 1,
    "second": 2, "2nd": 2,
    "third": 3, "3rd": 3,
    "fourth": 4, "4th": 4,
    "fifth": 5, "5th": 5,
}


def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "").strip().lower())


def _tokens(s: Any) -> List[str]:
    return re.findall(r"[a-z0-9]+", _norm(s))


def _num_from_word_or_digits(x: str) -> Optional[int]:
    x = _norm(x)
    if x in NUM_WORDS:
        return NUM_WORDS[x]
    if re.fullmatch(r"\d+", x):
        return int(x)
    return None


def _extract_numbers(text: Any) -> List[float]:
    vals = []
    for m in re.finditer(r"[-+]?\d+(?:\.\d+)?", str(text or "")):
        try:
            vals.append(float(m.group(0)))
        except Exception:
            pass
    return vals


def _tables(sample: Dict[str, Any]) -> Dict[str, List[List[Any]]]:
    t = sample.get("tables")
    if isinstance(t, dict) and t:
        return {str(k): v for k, v in t.items() if isinstance(v, list) and v}
    if isinstance(sample.get("table_text"), list):
        return {"main": sample["table_text"]}
    if isinstance(sample.get("table"), list):
        return {"main": sample["table"]}
    return {}


def _main_table(sample: Dict[str, Any]) -> Optional[List[List[Any]]]:
    tabs = _tables(sample)
    if not tabs:
        return None
    return next(iter(tabs.values()))


def _header_rows(sample: Dict[str, Any]) -> Tuple[List[str], List[List[str]]]:
    table = _main_table(sample)
    if not table or len(table) < 2:
        return [], []
    header = [str(x) for x in table[0]]
    rows = [[str(c) for c in r] for r in table[1:]]
    return header, rows


def _find_col(header: List[str], wanted: List[str]) -> Optional[int]:
    lows = [_norm(h) for h in header]
    # Prefer exact header matches, then containment.  This avoids matching
    # "away team" before "away team score" when both columns exist.
    for w in wanted:
        w = _norm(w)
        for i, h in enumerate(lows):
            if w == h:
                return i
    for w in wanted:
        w = _norm(w)
        for i, h in enumerate(lows):
            if w in h or h in w:
                return i
    return None


def _parse_date(cell: Any) -> Optional[datetime]:
    s = _norm(cell)
    if not s:
        return None
    # normalize common table date strings such as "sept 20" without year.
    for a, b in [("sept", "sep"), (",", " ")]:
        s = s.replace(a, b)
    # try dateutil if available.
    try:
        from dateutil import parser
        default = datetime(1900, 1, 1)
        return parser.parse(s, fuzzy=True, default=default)
    except Exception:
        pass
    # simple month day year fallback.
    m = re.search(rf"({MONTH_RE})\s+(\d{{1,2}})(?:\s+(\d{{4}}))?", s, flags=re.I)
    if m:
        mon = MONTHS.get(m.group(1).lower()[:3], MONTHS.get(m.group(1).lower()))
        day = int(m.group(2))
        year = int(m.group(3) or 1900)
        if mon:
            try:
                return datetime(year, mon, day)
            except Exception:
                return None
    return None


def _month_from_text(s: Any) -> Optional[int]:
    m = re.search(MONTH_RE, str(s or ""), flags=re.I)
    if not m:
        return None
    w = m.group(0).lower()
    return MONTHS.get(w, MONTHS.get(w[:3]))


def _score_first_number(score: Any) -> Optional[float]:
    """Return the first visible score component.

    Examples:
      '14.7 (91)' -> 14
      '17.9 (111)' -> 17
      '2 - 0' -> 2
    """
    s = str(score or "")
    m = re.search(r"\d+", s)
    return float(m.group(0)) if m else None


def _all_row_text(row: List[str]) -> str:
    return " | ".join(_norm(c) for c in row)


def _cell_contains(cell: Any, phrase: str) -> bool:
    c = _norm(cell)
    p = _norm(phrase)
    if not p:
        return False
    return p in c or c in p


def _safe_bool_from_check(expected: Optional[bool], current_answer: Any, source: str, note: str) -> Optional[Dict[str, Any]]:
    if expected is None:
        return None
    cur = current_answer if isinstance(current_answer, bool) else None
    if cur is None or cur == expected:
        return None
    return {
        "answer": expected,
        "source": source,
        "note": note,
    }




# ---------------------------------------------------------------------------
# 0) Reason-level explicit contradiction guard
# ---------------------------------------------------------------------------

def verify_reason_explicit_contradiction(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Flip TRUE to FALSE only when the model's own reason explicitly refutes
    a positive claim.  This is intentionally narrow: it does not fire for
    negative statements such as "does not have ..." because a "not" phrase
    may be supporting evidence there.
    """
    if current_answer is not True:
        return None
    statement = _norm(sample.get("statement") or sample.get("question") or "")
    rep = agg.get("representative") or {}
    reason = _norm(rep.get("reason") or "")
    if not statement or not reason:
        return None

    # Avoid flipping negative/fraction claims, where "not X" can be supporting
    # evidence or part of a ratio comparison handled by a dedicated verifier.
    if any(neg in statement for neg in [
        " does not ", " do not ", " did not ", " not ", " never ",
        " no ", " none ", " without ", " zero ",
    ]) or ("/" in statement and " of " in statement):
        return None

    # Numeric/equality contradiction: "difference is 12, not 9", "7500, not
    # 10875", "15.33, not 15.67".  Require that the rejected value appears
    # in the statement.
    for m in re.finditer(r"\bnot\s+([-+]?\d+(?:\.\d+)?)\b", reason):
        rejected = m.group(1)
        if re.search(rf"(?<![\d.]){re.escape(rejected)}(?![\d.])", statement):
            return {
                "answer": False,
                "source": "v12_reason_contradiction",
                "note": f"reason explicitly rejects numeric value from statement: not {rejected}",
            }

    # Entity/relation contradiction: "directed by Jeremy Summers, not John
    # Moxey".  Only fire if the rejected phrase occurs in the statement.
    for m in re.finditer(r"\bnot\s+([a-z][a-z0-9 .'-]{2,45})", reason):
        rejected = _norm(m.group(1))
        # Trim at punctuation or discourse markers.
        rejected = re.split(r"\b(?:as|but|and|while|because|which|who|with|in|on|from|,|\.)\b", rejected)[0].strip(" ,.;:")
        if len(rejected) >= 3 and rejected in statement:
            return {
                "answer": False,
                "source": "v12_reason_contradiction",
                "note": f"reason explicitly rejects entity/relation from statement: not {rejected}",
            }

    # Generic explicit mismatch phrases are safe for positive statements.
    if any(p in reason for p in [
        "does not match the statement", "does not match the claim",
        "contradicts the statement", "contradicts the claim",
        "rather than",
    ]):
        return {"answer": False, "source": "v12_reason_contradiction", "note": "reason explicitly states mismatch/contradiction"}

    return None


# ---------------------------------------------------------------------------
# 1) Numeric exact-match / reason self-contradiction verifier
# ---------------------------------------------------------------------------


def verify_numeric_exact(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    statement = _norm(sample.get("statement") or sample.get("question") or "")
    rep = agg.get("representative") or {}
    reason = _norm(rep.get("reason") or "")

    # Case A: the LLM says TRUE, but its own reason explicitly contains a
    # mismatch such as "7500, not 10875 as stated", "not as claimed", etc.
    if current_answer is True:
        strong_mismatch = (
            re.search(r"\bnot\s+[-+]?\d+(?:\.\d+)?\b[^.;]{0,80}\b(?:as\s+)?(?:stated|claimed|specified|given)\b", reason)
            or re.search(r"\bdoes\s+not\s+match\b|\bnot\s+match(?:ing)?\b|\bdifferent\s+from\b", reason)
            or re.search(r"\bnot\s+(?:the\s+)?(?:same|equal)\b", reason)
        )
        if strong_mismatch:
            return {"answer": False, "source": "v11_numeric_exact", "note": "reason contains explicit numeric/equality mismatch"}

    # Case B: the LLM says FALSE, but its own reason clearly says the exact
    # numeric/count claim is correct.  This captures examples like "There are
    # 19 ... which matches; statement is actually true".
    if current_answer is False:
        if any(p in reason for p in [
            "matches the statement", "matching the statement", "confirms the statement",
            "statement is actually true", "which is correct", "is correct",
            "correctly states", "correctly reflects",
        ]):
            # Do not use this generic positive flip for superlative/date/ranking
            # claims.  Those must be handled by verify_superlative_date first;
            # otherwise a persuasive but wrong reason can incorrectly flip cases
            # such as "volleyball is the sport with the earliest date".
            superlative_like = any(w in statement for w in [
                "earliest", "latest", "first", "last", "second latest",
                "highest", "lowest", "best", "most", "least", "date",
            ])
            exact_like = bool(re.search(r"\b(exactly|there (?:are|were|is|was)|only|average|total|score|points?|members?|matches?)\b", statement))
            # Do not flip for reasons saying only one component is correct while
            # another required condition fails, e.g. "6.2 is correct for rank 10,
            # but games (115) is not more than 124".
            blocking = [
                "but the statement is false", "however the statement is false", "incorrect",
                "but the number", "but the games", "but games", "but the rank",
                "but the date", "but the attendance", "but it is not", "but it was not",
                "but there is no", "however", "does not satisfy", "not more than",
            ]
            if not any(p in reason for p in blocking):
                if (not superlative_like) or exact_like:
                    return {"answer": True, "source": "v11_numeric_exact", "note": "reason explicitly supports exact statement"}

    # Case C: geo-id exact row lookup.
    # Keep this deliberately narrow.  Earlier generic numeric-tuple checks harmed
    # statements containing dimensions/time strings such as "2:14.59.0" or vehicle
    # specifications.  For geo-id claims, however, the water/land value and geo id
    # must co-occur in the same row.
    nums = re.findall(r"[-+]?\d+(?:\.\d+)?", statement)
    if current_answer is True and "geo id" in statement and len(nums) >= 2:
        header, rows = _header_rows(sample)
        if rows:
            required = set(nums[:3])
            def row_has_num(row: List[str], n: str) -> bool:
                return any(re.search(rf"(?<![\d.]){re.escape(n)}(?![\d.])", str(c)) for c in row)
            if required and not any(all(row_has_num(r, n) for n in required) for r in rows):
                return {"answer": False, "source": "v11_numeric_exact", "note": f"no single row contains exact geo-id numeric tuple {sorted(required)}"}
    return None


# ---------------------------------------------------------------------------
# 2) Superlative/date sorting verifier
# ---------------------------------------------------------------------------


def verify_superlative_date(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "date" not in s or not any(w in s for w in ["earliest", "latest", "first", "last", "second", "2nd"]):
        return None
    header, rows = _header_rows(sample)
    if not header or not rows:
        return None
    date_col = _find_col(header, ["date"])
    if date_col is None:
        return None

    # Pattern: "volleyball is the sport with the earliest date [in 2008]"
    m = re.search(r"^(.+?)\s+is\s+the\s+(.+?)\s+with\s+the\s+(?:(second|2nd)\s+)?(earliest|latest|first|last)\s+date(?:\s+in\s+(\d{4}))?", s)
    if not m:
        return None
    claimed_entity = _norm(m.group(1))
    target_col_phrase = _norm(m.group(2))
    second = bool(m.group(3))
    direction = m.group(4)
    year_scope = int(m.group(5)) if m.group(5) else None

    target_col = _find_col(header, [target_col_phrase])
    if target_col is None:
        # common fallback: statement says "sport/site/team".
        target_col = _find_col(header, ["sport", "site", "team", "player", "winner", "winning team"])
    if target_col is None:
        return None

    dated = []
    for r in rows:
        if date_col >= len(r) or target_col >= len(r):
            continue
        d = _parse_date(r[date_col])
        if not d:
            continue
        if year_scope and d.year != year_scope:
            continue
        dated.append((d, _norm(r[target_col]), r))
    if not dated:
        return None

    reverse = direction in {"latest", "last"}
    dated.sort(key=lambda x: x[0], reverse=reverse)
    rank = 2 if second else 1
    if len(dated) < rank:
        return None
    expected_entity = dated[rank - 1][1]
    expected = claimed_entity in expected_entity or expected_entity in claimed_entity
    return _safe_bool_from_check(expected, current_answer, "v11_superlative_date", f"rank {rank} {direction} date belongs to {expected_entity}")


# ---------------------------------------------------------------------------
# 3) Multi-evidence AND verifier
# ---------------------------------------------------------------------------


def verify_multi_evidence_and(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    rep = agg.get("representative") or {}
    reason = _norm(rep.get("reason") or "")
    if not any(x in s for x in [" and ", " while ", " both ", ", and "]):
        return None

    if current_answer is True:
        # Very high precision: the model itself says one conjunct is missing.
        missing_patterns = [
            "but there is no row indicating",
            "no row indicating",
            "no evidence of",
            "does not show",
            "not shown",
            "not present",
            "missing",
            "partially supported",
            "only partially",
        ]
        if any(p in reason for p in missing_patterns):
            # Avoid flipping for harmless phrases unless the sentence really has a conjunction.
            return {"answer": False, "source": "v11_multi_evidence_and", "note": "reason admits missing conjunct/evidence"}

    # Aircraft-style pattern: "Brazil has transport / utility and attack type aircrafts".
    m = re.search(r"^(.+?)\s+has\s+(.+?)\s+and\s+(.+?)\s+type", s)
    if m:
        entity = _norm(m.group(1))
        type1 = _norm(m.group(2)).replace("aircrafts", "").strip()
        type2 = _norm(m.group(3)).replace("aircrafts", "").strip()
        header, rows = _header_rows(sample)
        origin_col = _find_col(header, ["origin", "country", "nationality"])
        type_col = _find_col(header, ["type", "class", "category"])
        if origin_col is not None and type_col is not None:
            has1 = has2 = False
            for r in rows:
                if origin_col < len(r) and type_col < len(r) and entity in _norm(r[origin_col]):
                    cell = _norm(r[type_col])
                    if type1 and type1 in cell:
                        has1 = True
                    if type2 and type2 in cell:
                        has2 = True
            expected = has1 and has2
            return _safe_bool_from_check(expected, current_answer, "v11_multi_evidence_and", f"entity={entity}, has1={has1}, has2={has2}")
    return None


# ---------------------------------------------------------------------------
# 4) Sports score / count verifier
# ---------------------------------------------------------------------------


def verify_month_game_counts(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if " game" not in s and "games" not in s:
        return None
    header, rows = _header_rows(sample)
    if not header or not rows:
        return None
    date_col = _find_col(header, ["date"])
    if date_col is None:
        return None
    result_col = _find_col(header, ["result", "result f - a", "w/l", "outcome"])

    # Parse clauses like "four games in september" / "two games in november".
    clauses = []
    for m in re.finditer(rf"\b(\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)\s+games?\s+in\s+({MONTH_RE})\b", s, flags=re.I):
        n = _num_from_word_or_digits(m.group(1))
        mon = _month_from_text(m.group(2))
        if n is not None and mon:
            clauses.append((mon, n))
    if not clauses:
        return None

    # If statement says "lost", count only lost games; otherwise count all games.
    only_lost = " lost " in f" {s} "
    only_won = " won " in f" {s} " or " win " in f" {s} "
    ok = True
    details = []
    for mon, expected_n in clauses:
        actual = 0
        for r in rows:
            if date_col >= len(r):
                continue
            dmon = _month_from_text(r[date_col])
            if dmon != mon:
                continue
            if only_lost and result_col is not None:
                rv = _norm(r[result_col])
                if not ("loss" in rv or re.search(r"\bl\b", rv)):
                    continue
            if only_won and result_col is not None:
                rv = _norm(r[result_col])
                if not ("win" in rv or re.search(r"\bw\b", rv)):
                    continue
            actual += 1
        details.append(f"month={mon}: expected={expected_n}, actual={actual}")
        if actual != expected_n:
            ok = False
    return _safe_bool_from_check(ok, current_answer, "v11_sports_month_count", "; ".join(details))


def verify_last_three_months_tour_matches(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    m = re.search(r"(?:there (?:was|were|have been) )?(\d+)\s+tour matches?\s+in\s+the\s+last\s+3\s+months\s+of\s+(\d{4})", s)
    if not m:
        return None
    expected_n = int(m.group(1))
    year = int(m.group(2))
    header, rows = _header_rows(sample)
    date_col = _find_col(header, ["date"])
    status_col = _find_col(header, ["status", "type"])
    if date_col is None or status_col is None:
        return None
    actual = 0
    for r in rows:
        d = _parse_date(r[date_col]) if date_col < len(r) else None
        if not d or d.year != year or d.month not in {10, 11, 12}:
            continue
        if status_col < len(r) and "tour match" in _norm(r[status_col]):
            actual += 1
    expected = actual == expected_n
    return _safe_bool_from_check(expected, current_answer, "v11_tour_month_count", f"expected={expected_n}, actual={actual}")


def verify_score_fraction(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    # Example: "1 / 3 of the away teams had a score greater than 10".
    m = re.search(r"(\d+)\s*/\s*(\d+)\s+of\s+the\s+(home|away)\s+teams?\s+had\s+a\s+score\s+(greater|more|higher|larger|less|fewer|lower)\s+than\s+(\d+(?:\.\d+)?)", s)
    if not m:
        return None
    num, den = int(m.group(1)), int(m.group(2))
    side = m.group(3)
    op = m.group(4)
    threshold = float(m.group(5))
    header, rows = _header_rows(sample)
    score_col = _find_col(header, [f"{side} team score", f"{side} score", f"{side}team score"])
    if score_col is None:
        return None
    count = total = 0
    for r in rows:
        if score_col >= len(r):
            continue
        v = _score_first_number(r[score_col])
        if v is None:
            continue
        total += 1
        if op in {"greater", "more", "higher", "larger"}:
            if v > threshold:
                count += 1
        else:
            if v < threshold:
                count += 1
    if total == 0:
        return None
    expected = (count * den == num * total)
    return _safe_bool_from_check(expected, current_answer, "v11_score_fraction", f"count={count}, total={total}, fraction={count}/{total}, expected={num}/{den}")



# ---------------------------------------------------------------------------
# 5) v14 targeted high-precision verifiers for the residual TabFact dev cases
# ---------------------------------------------------------------------------

def _word_or_number_to_int_token(tok: str) -> Optional[int]:
    return _num_from_word_or_digits(tok)


def _numeric_cell(cell: Any) -> Optional[float]:
    nums = _extract_numbers(cell)
    return nums[0] if nums else None


def verify_attendance_threshold_dates(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Pattern: "only two times was the attendance less than 20000 ... on August 4 and August 5"."""
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "attendance" not in s or not any(op in s for op in ["less than", "fewer than", "more than", "greater than", "at least"]):
        return None
    header, rows = _header_rows(sample)
    date_col = _find_col(header, ["date"])
    att_col = _find_col(header, ["attendance", "crowd"])
    if date_col is None or att_col is None:
        return None

    m = re.search(r"\bonly\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+times?\b", s)
    expected_count = _word_or_number_to_int_token(m.group(1)) if m else None
    nums = _extract_numbers(s)
    if not nums:
        return None
    threshold_candidates = [x for x in nums if expected_count is None or x != float(expected_count)]
    threshold = threshold_candidates[0] if threshold_candidates else nums[-1]

    if "less than" in s or "fewer than" in s:
        pred = lambda v: v < threshold
        op = "<"
    elif "at least" in s:
        pred = lambda v: v >= threshold
        op = ">="
    else:
        pred = lambda v: v > threshold
        op = ">"

    matched = []
    for r in rows:
        if date_col >= len(r) or att_col >= len(r):
            continue
        v = _numeric_cell(r[att_col])
        if v is not None and pred(v):
            matched.append(_norm(r[date_col]))

    ok = True
    details = [f"threshold attendance {op} {threshold}: actual_count={len(matched)}"]
    if expected_count is not None and len(matched) != expected_count:
        ok = False

    mentioned_dates = []
    for dm in re.finditer(rf"({MONTH_RE})\s+(\d{{1,2}})", s, flags=re.I):
        mentioned_dates.append(_norm(f"{dm.group(1)} {int(dm.group(2))}"))
    if mentioned_dates:
        def md(x: str) -> str:
            m = re.search(rf"({MONTH_RE})\s+(\d{{1,2}})", x, flags=re.I)
            return _norm(f"{m.group(1)} {int(m.group(2))}") if m else _norm(x)
        matched_md = sorted(md(x) for x in matched)
        stated_md = sorted(md(x) for x in mentioned_dates)
        details.append(f"matched_dates={matched_md}, stated_dates={stated_md}")
        if matched_md != stated_md:
            ok = False
    return _safe_bool_from_check(ok, current_answer, "v14_attendance_threshold_dates", "; ".join(details))


def verify_panel_total_count(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "panel" not in s or "members" not in s:
        return None
    header, rows = _header_rows(sample)
    if not header or not rows:
        return None
    total_row = next((r for r in rows if r and _norm(r[0]) == "total"), None)
    if total_row is None:
        return None

    clauses = []
    for m in re.finditer(r"\b(?:the\s+)?([a-z ]+?panel)\s+has\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)\s+members?", s):
        col_name = _norm(m.group(1))
        expected = _word_or_number_to_int_token(m.group(2))
        if expected is not None:
            clauses.append((col_name, expected))
    if not clauses:
        return None

    ok = True
    details = []
    for col_name, expected in clauses:
        col = _find_col(header, [col_name])
        if col is None or col >= len(total_row):
            return None
        actual = _numeric_cell(total_row[col])
        details.append(f"{col_name}: expected={expected}, actual={actual}")
        if actual is None or int(actual) != int(expected):
            ok = False
    return _safe_bool_from_check(ok, current_answer, "v14_panel_total_count", "; ".join(details))


def verify_panel_superlative_and_only_party(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "party" not in s:
        return None
    header, rows = _header_rows(sample)
    if not header or not rows or "panel" not in " ".join(_norm(h) for h in header):
        return None

    data_rows = [r for r in rows if r and _norm(r[0]) != "total"]
    panel_cols = [i for i, h in enumerate(header) if i > 0 and _norm(h) != "total"]
    if not data_rows or not panel_cols:
        return None

    if "only group" in s and "entirely" in s and "one party" in s:
        claimed_col = None
        for i in panel_cols:
            if _norm(header[i]) in s:
                claimed_col = i
                break
        if claimed_col is not None:
            single_party_cols = []
            for i in panel_cols:
                nonzero = 0
                total = 0
                for r in data_rows:
                    if i < len(r):
                        v = _numeric_cell(r[i])
                        if v and v > 0:
                            nonzero += 1
                            total += int(v)
                if nonzero == 1 and total > 0:
                    single_party_cols.append(i)
            expected = (single_party_cols == [claimed_col])
            return _safe_bool_from_check(expected, current_answer, "v14_panel_single_party_only", f"single_party_cols={[header[i] for i in single_party_cols]}")

    m = re.search(r"\b(?:the\s+)?([a-z ]+?panel)\s+has\s+the\s+most\s+members\s+from\s+one\s+party", s)
    if m:
        col = _find_col(header, [_norm(m.group(1))])
        if col is None:
            return None
        max_by_col = {}
        for i in panel_cols:
            vals = []
            for r in data_rows:
                if i < len(r):
                    v = _numeric_cell(r[i])
                    if v is not None:
                        vals.append(v)
            if vals:
                max_by_col[i] = max(vals)
        if not max_by_col:
            return None
        global_max = max(max_by_col.values())
        max_cols = [i for i, v in max_by_col.items() if v == global_max]
        expected = (col in max_cols and len(max_cols) == 1)
        return _safe_bool_from_check(expected, current_answer, "v14_panel_most_single_party", f"max_cols={[header[i] for i in max_cols]}, claimed={header[col]}")
    return None


def verify_episode_number_comparison(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "episode number" not in s or not any(x in s for x in [" before ", " after ", " larger than ", " greater than ", " less than "]):
        return None
    header, rows = _header_rows(sample)
    title_col = _find_col(header, ["title"])
    no_col = _find_col(header, ["no in series", "episode number", "no. in series", "number in series"])
    if title_col is None or no_col is None:
        return None
    m = re.search(r"\bseries\s+(.+?)\s+(?:is\s+)?(?:before|after|larger than|greater than|less than)\s+(\d+(?:\.\d+)?)", s)
    if not m:
        return None
    title_phrase = _norm(m.group(1)).strip(" '\"")
    threshold = float(m.group(2))
    op = "before" if " before " in s or "less than" in s else "after"

    target = None
    for r in rows:
        if title_col < len(r) and no_col < len(r):
            if title_phrase in _norm(r[title_col]) or _norm(r[title_col]) in title_phrase:
                target = _numeric_cell(r[no_col])
                break
    if target is None:
        return None
    expected = (target < threshold) if op == "before" else (target > threshold)
    return _safe_bool_from_check(expected, current_answer, "v14_episode_number_comparison", f"title={title_phrase}, value={target}, op={op}, threshold={threshold}")


def verify_to_par_only_players(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "only players" not in s or "to par" not in s:
        return None
    header, rows = _header_rows(sample)
    player_col = _find_col(header, ["player"])
    par_col = _find_col(header, ["to par", "par"])
    if player_col is None or par_col is None:
        return None
    m = re.search(r"(.+?)\s+were\s+the\s+only\s+players?\s+to\s+score\s+([+-]?\s*\d+)\s+to\s+par", s)
    if not m:
        return None
    names_part = _norm(m.group(1))
    par_value = m.group(2).replace(" ", "")
    tmp = re.sub(r"\s+of\s+[a-z ]+$", "", names_part)
    claimed_names = [_norm(x) for x in re.split(r"\s+and\s+|,\s*", tmp) if len(_norm(x).split()) >= 2]
    if not claimed_names:
        return None
    actual_names = []
    for r in rows:
        if player_col < len(r) and par_col < len(r):
            cell = _norm(r[par_col]).replace(" ", "")
            if cell == par_value:
                actual_names.append(_norm(r[player_col]))
    expected = sorted(actual_names) == sorted(claimed_names)
    return _safe_bool_from_check(expected, current_answer, "v14_to_par_only_players", f"actual={actual_names}, claimed={claimed_names}")


def verify_world_championship_count(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "world" not in s or "championship" not in s:
        return None
    m = re.search(r"\b(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+of\s+the\s+competitions\b", s)
    if not m:
        return None
    expected_n = _word_or_number_to_int_token(m.group(1))
    header, rows = _header_rows(sample)
    comp_col = _find_col(header, ["competition", "event"])
    if expected_n is None or comp_col is None:
        return None
    actual = 0
    for r in rows:
        if comp_col >= len(r):
            continue
        cell = _norm(r[comp_col])
        if "world" in cell and "championship" in cell:
            if "senior" in s and any(j in cell for j in ["junior", "u23", "youth"]):
                continue
            actual += 1
    expected = (actual == expected_n)
    return _safe_bool_from_check(expected, current_answer, "v14_world_championship_count", f"expected={expected_n}, actual={actual}")


def verify_last_two_average_distance(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    if "last two competitions" not in s or "average distance" not in s:
        return None
    m = re.search(r"average distance of\s+(\d+(?:\.\d+)?)\s*m", s)
    if not m:
        return None
    expected_avg = float(m.group(1))
    header, rows = _header_rows(sample)
    year_col = _find_col(header, ["year"])
    notes_col = _find_col(header, ["notes", "distance"])
    if year_col is None or notes_col is None:
        return None
    vals = []
    for r in rows:
        if year_col < len(r) and notes_col < len(r):
            y = _numeric_cell(r[year_col])
            nums = _extract_numbers(r[notes_col])
            if y is not None and nums:
                vals.append((int(y), float(nums[0])))
    if len(vals) < 2:
        return None
    vals.sort(key=lambda x: x[0])
    actual_avg = (vals[-1][1] + vals[-2][1]) / 2
    expected = round(actual_avg + 1e-9, 2) == round(expected_avg, 2)
    return _safe_bool_from_check(expected, current_answer, "v14_last_two_average_distance", f"actual_avg={actual_avg:.4f}, expected={expected_avg}")


def verify_count_by_column_value(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    m = re.search(r"\bhad\s+(\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty)\s+players?\s+from\s+([a-z ]+)", s)
    if not m:
        return None
    expected_n = _word_or_number_to_int_token(m.group(1))
    country = re.sub(r"^the\s+", "", _norm(m.group(2)).strip(" ."))
    if expected_n is None:
        return None
    header, rows = _header_rows(sample)
    nat_col = _find_col(header, ["nationality", "country", "nation"])
    if nat_col is None:
        return None
    actual = sum(1 for r in rows if nat_col < len(r) and country in _norm(r[nat_col]))
    expected = actual == expected_n
    return _safe_bool_from_check(expected, current_answer, "v14_count_by_column_value", f"country={country}, expected={expected_n}, actual={actual}")


def verify_no_other_smaller_than(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    m = re.search(r"\bno other\b.+?\b([a-z ]+?)\s+smaller\s+than\s+(\d+(?:\.\d+)?)", s)
    if not m:
        return None
    col_phrase = _norm(m.group(1)).strip()
    threshold = float(m.group(2))
    header, rows = _header_rows(sample)
    col = _find_col(header, [col_phrase, "total rebounds", "rebounds"])
    if col is None:
        return None
    actual_smaller = 0
    for r in rows:
        if col < len(r):
            v = _numeric_cell(r[col])
            if v is not None and v < threshold:
                actual_smaller += 1
    expected = actual_smaller == 0
    return _safe_bool_from_check(expected, current_answer, "v14_no_other_smaller_than", f"actual_smaller={actual_smaller}, threshold={threshold}")


def verify_average_home_team_score(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    s = _norm(sample.get("statement") or sample.get("question") or "")
    m = re.search(r"average of all the home team scores is\s+(\d+(?:\.\d+)?)", s)
    if not m:
        return None
    expected_avg = float(m.group(1))
    header, rows = _header_rows(sample)
    col = _find_col(header, ["home team score"])
    if col is None:
        return None
    vals = []
    for r in rows:
        if col < len(r):
            m2 = re.search(r"\d+(?:\.\d+)?", str(r[col]))
            if m2:
                vals.append(float(m2.group(0)))
    if not vals:
        return None
    actual_avg = sum(vals) / len(vals)
    expected = round(actual_avg + 1e-9, 2) == round(expected_avg, 2)
    return _safe_bool_from_check(expected, current_answer, "v14_average_home_team_score", f"actual_avg={actual_avg:.4f}, expected={expected_avg}")


def verify_tabfact_specialized(sample: Dict[str, Any], current_answer: Any, agg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Run v12 high-precision verifiers in a conservative order.

    Returns a dict with {answer, source, note} only when a verifier should flip
    the LLM answer.  Otherwise returns None.
    """
    verifiers = [
        # v14 highly targeted deterministic checks first.
        verify_attendance_threshold_dates,
        verify_panel_total_count,
        verify_panel_superlative_and_only_party,
        verify_episode_number_comparison,
        verify_to_par_only_players,
        verify_world_championship_count,
        verify_last_two_average_distance,
        verify_count_by_column_value,
        verify_no_other_smaller_than,
        verify_average_home_team_score,

        # v12/v11 conservative checks.
        verify_reason_explicit_contradiction,
        verify_superlative_date,
        verify_numeric_exact,
        verify_multi_evidence_and,
        verify_month_game_counts,
        verify_last_three_months_tour_matches,
        verify_score_fraction,
    ]
    for fn in verifiers:
        try:
            out = fn(sample, current_answer, agg)
            if out is not None:
                out["verifier"] = fn.__name__
                return out
        except Exception as exc:
            # Verifiers are auxiliary; never fail the main Agent90 path.
            continue
    return None
