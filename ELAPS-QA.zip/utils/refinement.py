"""
Error-Guided Local Refinement for Low-Confidence Programs.

When Bayes Factor < 3 (weak evidence), compares the top two programs to
identify the divergent step, then performs targeted re-generation at that
step only, leaving the rest of the program intact.

v2: Works with PCFG parse trees, not flat operation chains.
    Refinement resamples subtrees from the grammar rather than patching
    individual operations.
"""

import copy
import math
from utils.pcfg import (
    compute_tree_prior,
    expand_nonterminal,
    tree_to_operations,
    GRAMMAR,
    TERMINAL_TYPES,
)


# ============================================================
# Divergent Step Detection
# ============================================================

def find_divergent_step(best_sample, runner_sample, debug=False):
    """
    Compare two programs and find the first step where they differ.

    Operates on flattened operation chains for comparison, then maps
    back to tree nodes for refinement.

    Returns:
        dict with keys:
          - divergent_index: int, index of first differing operation
          - best_op: operation dict from best program
          - runner_op: operation dict from runner-up
          - divergence_type: 'operation_type' | 'parameter' | 'missing_step'
          - description: human-readable summary
    """
    best_chain = best_sample.get('chain', []) if best_sample else []
    runner_chain = runner_sample.get('chain', []) if runner_sample else []

    max_len = max(len(best_chain), len(runner_chain))

    for i in range(max_len):
        best_op = best_chain[i] if i < len(best_chain) else None
        runner_op = runner_chain[i] if i < len(runner_chain) else None

        if best_op is None:
            return {
                'divergent_index': i,
                'divergence_type': 'missing_step',
                'best_op': None,
                'runner_op': runner_op,
                'description': f'Best program is shorter: runner has extra '
                               f'{runner_op.get("operation_name", "?")} at step {i}'
            }
        if runner_op is None:
            return {
                'divergent_index': i,
                'divergence_type': 'missing_step',
                'best_op': best_op,
                'runner_op': None,
                'description': f'Runner-up is shorter: best has extra '
                               f'{best_op.get("operation_name", "?")} at step {i}'
            }

        if best_op.get('operation_name') != runner_op.get('operation_name'):
            return {
                'divergent_index': i,
                'divergence_type': 'operation_type',
                'best_op': best_op,
                'runner_op': runner_op,
                'description': (
                    f'Step {i}: best={best_op.get("operation_name")} '
                    f'vs runner={runner_op.get("operation_name")}'
                )
            }

        best_params = best_op.get('parameter_and_conf', {})
        runner_params = runner_op.get('parameter_and_conf', {})
        if str(best_params) != str(runner_params):
            return {
                'divergent_index': i,
                'divergence_type': 'parameter',
                'best_op': best_op,
                'runner_op': runner_op,
                'description': (
                    f'Step {i}: same op ({best_op.get("operation_name")}) '
                    f'but different parameters'
                )
            }

    return {
        'divergent_index': -1,
        'divergence_type': 'identical',
        'description': 'Programs are structurally identical but produce different results'
    }


def find_divergent_tree_node(best_tree, divergence_index):
    """
    Map a divergent operation index to the corresponding node in the parse tree.

    Walks the tree in pre-order (terminal nodes only) and returns the
    terminal node at the given index, plus its parent path.

    Returns:
        (target_node, parent_path) or (None, None)
    """
    terminals = []
    _collect_terminals_with_path(best_tree, [], terminals)

    if divergence_index < len(terminals):
        node, path = terminals[divergence_index]
        return node, path

    return None, None


def _collect_terminals_with_path(node, path, result):
    """Collect terminal nodes with their parent paths."""
    terminal = node.get('terminal', '')
    if terminal and terminal in TERMINAL_TYPES:
        result.append((node, list(path)))

    for child in node.get('children', []):
        _collect_terminals_with_path(child, path + [node], result)


# ============================================================
# Targeted Refinement (Tree-based)
# ============================================================

def targeted_refinement(
    bf_result,
    original_sample,
    max_refinement_rounds=3,
    debug=False,
):
    """
    Error-guided local refinement using tree resampling.

    When BF < 3:
      1. Find the divergent step between best and runner-up
      2. Locate the corresponding node in the parse tree
      3. Resample that node's subtree from the PCFG grammar
      4. Re-execute and re-evaluate Bayes Factor

    Args:
        bf_result: output from compute_bayes_factor()
        original_sample: original input sample with tables, statement
        max_refinement_rounds: maximum number of refinement iterations
        debug: verbose output

    Returns:
        refined bf_result dict (updated after refinement)
    """
    if bf_result.get('accept', False):
        return bf_result

    best_entry = bf_result.get('best_program')
    runner_entry = bf_result.get('runner_up')

    if best_entry is None:
        return bf_result

    best_sample = best_entry[0]
    runner_sample = runner_entry[0] if runner_entry else None

    divergence = find_divergent_step(best_sample, runner_sample, debug=debug)

    if divergence['divergent_index'] == -1:
        if debug:
            print("[Refinement] Programs structurally identical — cannot refine")
        return bf_result

    if debug:
        print(f"[Refinement] Divergence: {divergence['description']}")

    best_tree = best_sample.get('parse_tree')
    if best_tree is None:
        if debug:
            print("[Refinement] No parse tree available — cannot refine at tree level")
        return bf_result

    refinement_history = []
    current_best_sample = best_sample

    for round_idx in range(max_refinement_rounds):
        if debug:
            print(f"\n[Refinement] Round {round_idx + 1}/{max_refinement_rounds}")

        # Find the tree node at the divergent position
        target_node, parent_path = find_divergent_tree_node(
            current_best_sample.get('parse_tree', {}),
            divergence['divergent_index']
        )

        if target_node is None:
            if debug:
                print("[Refinement] Cannot locate divergent node in tree")
            break

        # Alternate between parent-node and terminal-node resampling
        use_parent = (round_idx % 2 == 1) and len(parent_path) > 0
        parent_node = parent_path[-1] if use_parent else None

        if debug and use_parent:
            print(f"[Refinement] Round {round_idx + 1}: parent-node resampling "
                  f"({parent_node.get('nonterminal', '?')})")

        # Resample the subtree at the divergent point
        alternatives = _resample_alternatives(
            current_best_sample,
            target_node,
            divergence,
            original_sample,
            parent_node=parent_node,
            n_alternatives=5,
            debug=debug,
        )

        if not alternatives:
            if debug:
                print("[Refinement] No alternative programs generated")
            break

        # Score alternatives by execution likelihood
        best_alt = _select_best_alternative(alternatives, original_sample)
        if best_alt is None:
            break

        current_best_sample = best_alt
        refinement_history.append({
            'round': round_idx + 1,
            'divergence': divergence['description'],
            'new_program': _program_summary(best_alt),
        })

        # Re-evaluate Bayes Factor
        from utils.execution_verifier import compute_execution_likelihood
        from utils.bayes_factor import compute_posteriors, compute_bayes_factor

        best_like = compute_execution_likelihood(current_best_sample, original_sample)
        runner_like = compute_execution_likelihood(runner_sample, original_sample) if runner_sample else 0.0

        ranked = compute_posteriors(
            [(current_best_sample, best_like, 0.0),
             (runner_sample, runner_like, 0.0)],
            original_sample
        )
        new_bf = compute_bayes_factor(ranked, original_sample)

        if debug:
            print(f"[Refinement] Round {round_idx + 1} BF: "
                  f"{new_bf['bf_value']:.2f} — {new_bf['interpretation']}")

        if new_bf.get('accept', False):
            new_bf['refinement_history'] = refinement_history
            return new_bf

    bf_result['refinement_history'] = refinement_history
    return bf_result


def _resample_alternatives(
    current_sample,
    target_node,
    divergence,
    original_sample,
    parent_node=None,
    n_alternatives=5,
    debug=False,
):
    """
    Generate alternative programs by resampling at the divergent point.

    Each alternative replaces the target node (or its parent) with a new
    expansion sampled from the PCFG grammar, or regenerates parameters.
    """
    alternatives = []

    for _ in range(n_alternatives):
        alt_sample = _resample_and_rebuild(
            current_sample, target_node, divergence, original_sample,
            parent_node=parent_node
        )
        if alt_sample is not None:
            alternatives.append(alt_sample)

    return alternatives


def _resample_and_rebuild(current_sample, target_node, divergence, original_sample,
                         parent_node=None):
    """
    Create a new program by resampling at the divergent point.

    Three strategies:
      1. Parameter-only: keep same terminal, regenerate params (reroll_params)
      2. Parent-node: resample the parent clause node from grammar
      3. Terminal-node: resample the terminal's type from grammar (current default)
    """
    from utils.pcfg import generate_grammar_tree

    tree = current_sample.get('parse_tree')
    if tree is None:
        return None

    div_type = divergence.get('divergence_type', 'operation_type')
    new_tree = copy.deepcopy(tree)
    div_idx = divergence['divergent_index']

    # Strategy 1: Parent-node resampling
    if parent_node is not None:
        _resample_node_in_copy(new_tree, parent_node, original_sample)

    # Strategy 2: Parameter-only (same terminal, new params)
    elif div_type == 'parameter':
        target_copy, _ = find_divergent_tree_node(new_tree, div_idx)
        if target_copy is not None:
            terminal_type = target_copy.get('terminal', '')
            if terminal_type in TERMINAL_TYPES:
                from utils.pcfg import reroll_params
                target_copy['params'] = reroll_params(
                    terminal_type, original_sample,
                    exclude_params=target_copy.get('params', {})
                )

    # Strategy 3: Terminal-type resampling from grammar
    else:
        target_copy, _ = find_divergent_tree_node(new_tree, div_idx)
        if target_copy is None:
            new_tree = generate_grammar_tree(original_sample, llm=None, max_depth=6)
        else:
            nt = target_copy.get('nonterminal', '')
            if nt in GRAMMAR:
                valid_rules, probs = expand_nonterminal(nt, original_sample)
                if valid_rules:
                    import random
                    exp_str, _ = random.choices(valid_rules, weights=probs, k=1)[0]
                    tokens = exp_str.split()
                    target_copy['expansion'] = tokens
                    target_copy['children'] = []
                    target_copy.pop('terminal', None)
                    target_copy.pop('params', None)
                    for token in tokens:
                        child = _build_terminal_or_recurse(token, original_sample, 0)
                        target_copy['children'].append(child)

    new_sample = {
        'parse_tree': new_tree,
        'chain': tree_to_operations(new_tree),
    }
    return new_sample


def _resample_node_in_copy(new_tree, ref_node, original_sample):
    """Resample a specific node (identified by path) in a copied tree."""
    nt = ref_node.get('nonterminal', '')
    if nt not in GRAMMAR:
        return
    valid_rules, probs = expand_nonterminal(nt, original_sample)
    if not valid_rules:
        return
    import random
    exp_str, _ = random.choices(valid_rules, weights=probs, k=1)[0]
    tokens = exp_str.split()
    ref_node['expansion'] = tokens
    ref_node['children'] = []
    ref_node.pop('terminal', None)
    ref_node.pop('params', None)
    for token in tokens:
        child = _build_terminal_or_recurse(token, original_sample, 0)
        ref_node['children'].append(child)


def _build_terminal_or_recurse(token, sample, depth, max_depth=4):
    """Build a node for a grammar token."""
    if depth > max_depth:
        return {
            'nonterminal': token, 'expansion': [token],
            'children': [], 'terminal': 'FinalAnswer', 'params': {}
        }

    if token in TERMINAL_TYPES:
        from utils.pcfg import _generate_llm_params
        return {
            'nonterminal': token, 'expansion': [token],
            'children': [], 'terminal': token,
            'params': _generate_llm_params(token, sample, None),
        }

    if token in GRAMMAR:
        valid_rules, probs = expand_nonterminal(token, sample)
        if valid_rules:
            import random
            exp_str, _ = random.choices(valid_rules, weights=probs, k=1)[0]
            tokens = exp_str.split()
            child = {'nonterminal': token, 'expansion': tokens, 'children': []}
            for t in tokens:
                child['children'].append(
                    _build_terminal_or_recurse(t, sample, depth + 1, max_depth)
                )
            return child

    return {
        'nonterminal': token, 'expansion': [token],
        'children': [], 'terminal': 'FinalAnswer', 'params': {}
    }


def _select_best_alternative(alternatives, original_sample):
    """Select the best alternative by execution likelihood × prior."""
    from utils.execution_verifier import compute_execution_likelihood

    best = None
    best_score = -float('inf')

    for alt in alternatives:
        like = compute_execution_likelihood(alt, original_sample)
        tree = alt.get('parse_tree')
        if tree:
            log_prior = compute_tree_prior(tree, original_sample)
        else:
            log_prior = math.log(0.01)

        log_like = math.log(max(like, 1e-10))
        score = log_like + log_prior

        if score > best_score:
            best_score = score
            best = alt

    return best


def _program_summary(sample):
    """Human-readable one-line program summary."""
    chain = sample.get('chain', [])
    if not chain:
        return "(empty)"
    return " -> ".join(
        op.get('operation_name', '?') for op in chain
    )
