from __future__ import annotations

"""Answer-level posterior aggregation for PCFG-BF.

Instead of selecting the single program with the largest posterior, this module
marginalizes posterior mass over executable programs that produce the same final
answer.  This is important for table QA: many different SQL programs can be
semantically equivalent and return the same answer, while a single spurious
program may have the largest individual posterior.
"""


import json
import math
import re
from typing import Any, Dict, List, Optional, Tuple


def _norm_answer_key(answer: Any) -> str:
    """Stable key for grouping equivalent answers."""
    if answer is None:
        return "<NONE>"
    if isinstance(answer, bool):
        return "true" if answer else "false"
    if isinstance(answer, (int, float)):
        try:
            return f"{float(answer):.8g}"
        except Exception:
            return str(answer).strip().lower()
    if isinstance(answer, (list, tuple)):
        return json.dumps([_norm_answer_key(x) for x in answer], ensure_ascii=False, sort_keys=True)
    text = re.sub(r"\s+", " ", str(answer).strip().lower())
    # Normalize simple numeric strings such as "1,234.0".
    try:
        num = float(text.replace(",", ""))
        return f"{num:.8g}"
    except Exception:
        return text


def _display_answer(answer: Any) -> str:
    if isinstance(answer, (list, tuple)):
        return json.dumps(answer[:5] if len(answer) > 5 else answer, ensure_ascii=False)
    return str(answer)


def aggregate_by_answer(bf_result: Dict[str, Any], original_sample: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Aggregate posterior mass by final answer.

    Args:
        bf_result: output of utils.bayes_factor.rank_and_verify.
        original_sample: original dataset sample.

    Returns:
        A dict with the best answer group and its representative program entry.
        The returned ``representative_entry`` is intentionally kept separate
        from the serializable summary so callers can use the best program within
        the winning answer group for evidence extraction.
    """
    ranked = list(bf_result.get("all_posteriors") or [])
    if not ranked:
        return None

    probs = list(bf_result.get("all_probs") or [])
    if len(probs) != len(ranked):
        try:
            from utils.bayes_factor import normalize_posteriors
            probs = normalize_posteriors(ranked)
        except Exception:
            probs = [1.0 / len(ranked)] * len(ranked)

    from utils.execution_verifier import score_execution_with_sql

    groups: Dict[str, Dict[str, Any]] = {}
    for entry, prob in zip(ranked, probs):
        prog, log_post, likelihood, search_score = entry
        try:
            enriched = score_execution_with_sql(prog, original_sample)
        except Exception:
            enriched = {"answer": None, "program": None, "execution_result": None, "likelihood": 0.0}

        answer = enriched.get("answer")
        key = _norm_answer_key(answer)
        if key not in groups:
            groups[key] = {
                "key": key,
                "answer": answer,
                "posterior_mass": 0.0,
                "group_size": 0,
                "representative_entry": entry,
                "representative_log_post": log_post,
                "representative_likelihood": likelihood,
                "representative_program": enriched.get("program"),
            }

        g = groups[key]
        g["posterior_mass"] += float(prob)
        g["group_size"] += 1
        # Keep the highest-posterior program as representative evidence.
        if log_post > g.get("representative_log_post", float("-inf")):
            g["representative_entry"] = entry
            g["representative_log_post"] = log_post
            g["representative_likelihood"] = likelihood
            g["representative_program"] = enriched.get("program")

    ordered = sorted(groups.values(), key=lambda x: x["posterior_mass"], reverse=True)
    if not ordered:
        return None

    top = ordered[0]
    second_mass = ordered[1]["posterior_mass"] if len(ordered) > 1 else 0.0
    if second_mass <= 0:
        answer_bf = float("inf")
    else:
        answer_bf = top["posterior_mass"] / max(second_mass, 1e-12)

    summaries = []
    for g in ordered[:5]:
        summaries.append({
            "answer": _display_answer(g.get("answer")),
            "posterior_mass": round(float(g.get("posterior_mass", 0.0)), 6),
            "group_size": int(g.get("group_size", 0)),
            "program": g.get("representative_program"),
        })

    return {
        "answer": top.get("answer"),
        "answer_key": top.get("key"),
        "posterior_mass": float(top.get("posterior_mass", 0.0)),
        "group_size": int(top.get("group_size", 0)),
        "answer_bayes_factor": answer_bf,
        "answer_margin": float(top.get("posterior_mass", 0.0)) - float(second_mass),
        "n_answer_groups": len(ordered),
        "representative_entry": top.get("representative_entry"),
        "representative_program": top.get("representative_program"),
        "summary": summaries,
    }
