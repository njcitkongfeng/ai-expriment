from __future__ import annotations
"""TQA-Bench SQL-execution agent (additive module).

This module is intentionally separate from Agent90.  It solves TQA-Bench as a
multi-table SQLite QA task rather than as truncated-table text QA:

    question + choices + SQLite schema
        -> LLM generates SELECT/WITH SQL candidates
        -> SQLite executes candidates over the full database
        -> result is mapped to A/B/C/D choices
        -> optional LLM choice mapping only sees executed SQL results

It does not modify TabFact/WikiTQ/Spider code paths.
"""

import copy
import json
import math
import os
import pickle
import re
import sqlite3
import tempfile
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    from tqdm import tqdm
except Exception:  # pragma: no cover
    def tqdm(x, **kwargs):
        return x

LETTER_RE = re.compile(r"^\s*\(?\s*([A-F])\s*\)?\s*(?:\)|\.|:)?\s*(.*)$", re.I)


def _json_dumps(obj: Any, max_chars: int = 12000) -> str:
    text = json.dumps(obj, ensure_ascii=False, default=str)
    return text if len(text) <= max_chars else text[:max_chars] + " ...[truncated]"


def _safe_cache_name(sample: Dict[str, Any], idx: int) -> str:
    sid = str(sample.get("id", idx))
    sid = re.sub(r"[^a-zA-Z0-9_.-]+", "_", sid)
    return f"case-{idx}-{sid}.pkl"


def parse_choices(choices: Sequence[Any]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for i, c in enumerate(choices or []):
        s = str(c).strip()
        m = LETTER_RE.match(s)
        if m:
            out[m.group(1).upper()] = m.group(2).strip()
        else:
            out[chr(ord("A") + i)] = s
    return out


def _norm_text(x: Any) -> str:
    s = str(x if x is not None else "")
    s = s.replace("\u00a0", " ")
    s = re.sub(r"\s+", " ", s).strip().lower()
    s = re.sub(r"^[\"']|[\"']$", "", s)
    return s


def _num(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, bool):
        return float(int(x))
    if isinstance(x, (int, float)):
        try:
            if math.isnan(float(x)):
                return None
        except Exception:
            pass
        return float(x)
    s = str(x).strip()
    # Ignore choice labels such as "A) 52".
    s = LETTER_RE.sub(r"\2", s).strip()
    # Percent sign is treated as the displayed number (e.g., 98.2%).
    s = s.replace(",", "")
    m = re.search(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", s)
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None


def _num_close(a: float, b: float, rel_tol: float = 1e-3, abs_tol: float = 1e-6) -> bool:
    return abs(a - b) <= max(abs_tol, rel_tol * max(abs(b), 1.0))


def choice_letter_from_text(text: Any, choices: Sequence[Any]) -> str:
    """Map a raw model answer or SQL result to a choice letter.

    Returns "?" when no reliable mapping exists.
    """
    if text is None:
        return "?"
    if isinstance(text, dict):
        for k in ("answer", "choice", "option", "final", "final_answer"):
            if text.get(k) is not None:
                return choice_letter_from_text(text[k], choices)
    if isinstance(text, (list, tuple)) and len(text) == 1:
        return choice_letter_from_text(text[0], choices)

    s = str(text).strip()
    if not s:
        return "?"
    # JSON response.
    obj = _extract_json_object(s)
    if isinstance(obj, dict):
        for k in ("answer", "choice", "option", "final", "final_answer"):
            if obj.get(k) is not None:
                return choice_letter_from_text(obj[k], choices)
    # Explicit letter.
    m = re.search(r"<\s*(?:answer|choice|option|final)\s*>\s*([A-F])\s*<\s*/\s*(?:answer|choice|option|final)\s*>", s, re.I)
    if m:
        return m.group(1).upper()
    m = re.search(r"\b(?:answer|choice|option|final(?: answer)?)\s*(?:is|=|:)?\s*\(?\s*([A-F])\s*\)?\b", s, re.I)
    if m:
        return m.group(1).upper()
    m = re.match(r"^\s*\(?\s*([A-F])\s*\)?\s*(?:\)|\.|:|$)", s, re.I)
    if m:
        return m.group(1).upper()
    if s.upper() in {"A", "B", "C", "D", "E", "F"}:
        return s.upper()

    choices_map = parse_choices(choices)
    # Numeric matching.
    pn = _num(s)
    if pn is not None:
        numeric_matches = []
        for letter, val in choices_map.items():
            cn = _num(val)
            if cn is not None and _num_close(pn, cn):
                numeric_matches.append(letter)
        if len(numeric_matches) == 1:
            return numeric_matches[0]
        if numeric_matches:
            return numeric_matches[0]

    # Text matching.
    st = _norm_text(s)
    st_compact = re.sub(r"[^a-z0-9.\-]+", "", st)
    for letter, val in choices_map.items():
        vt = _norm_text(val)
        if st == vt:
            return letter
        if st and vt and (st in vt or vt in st):
            return letter
        vc = re.sub(r"[^a-z0-9.\-]+", "", vt)
        if st_compact and vc and (st_compact == vc or st_compact in vc or vc in st_compact):
            return letter
    return "?"


def gold_letter(sample: Dict[str, Any]) -> str:
    g = sample.get("answer_gold", sample.get("answer", ""))
    if isinstance(g, int):
        return chr(ord("A") + int(g))
    return str(g).strip().upper()[:1] or "?"


def _extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    s = str(text).strip()
    s = re.sub(r"^```(?:json)?\s*", "", s, flags=re.I).strip()
    s = re.sub(r"\s*```$", "", s).strip()
    try:
        obj = json.loads(s)
        return obj if isinstance(obj, dict) else None
    except Exception:
        pass
    m = re.search(r"\{.*\}", s, flags=re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            return obj if isinstance(obj, dict) else None
        except Exception:
            return None
    return None


def extract_sql_candidates(raw: str) -> List[Dict[str, Any]]:
    """Extract SQL candidate dicts from LLM output."""
    if not raw:
        return []
    raw = str(raw).strip()
    obj = _extract_json_object(raw)
    items: List[Any] = []
    if isinstance(obj, dict):
        if isinstance(obj.get("queries"), list):
            items.extend(obj["queries"])
        elif isinstance(obj.get("sql"), str):
            items.append(obj)
        elif isinstance(obj.get("candidates"), list):
            items.extend(obj["candidates"])
    # Fallback code fences / SELECT snippets.
    for block in re.findall(r"```(?:sql)?\s*(.*?)```", raw, flags=re.I | re.S):
        if re.search(r"\b(select|with)\b", block, re.I):
            items.append({"sql": block.strip()})
    for m in re.finditer(r"(?is)\b(with\b.*?|select\b.*?)(?:;|$)", raw):
        sql = m.group(1).strip()
        if sql and len(sql) >= 10:
            items.append({"sql": sql})
    out: List[Dict[str, Any]] = []
    seen = set()
    for it in items:
        if isinstance(it, str):
            sql = it.strip()
            d = {"sql": sql}
        elif isinstance(it, dict):
            sql = str(it.get("sql") or it.get("query") or "").strip()
            d = dict(it)
            d["sql"] = sql
        else:
            continue
        sql = _clean_sql(sql)
        if not sql or sql in seen:
            continue
        seen.add(sql)
        d["sql"] = sql
        out.append(d)
    return out[:8]


def _clean_sql(sql: str) -> str:
    sql = str(sql or "").strip()
    sql = re.sub(r"^```(?:sql)?", "", sql, flags=re.I).strip()
    sql = re.sub(r"```$", "", sql).strip()
    # Keep only first statement.
    parts = [p.strip() for p in sql.split(";") if p.strip()]
    if parts:
        sql = parts[0]
    return sql


def _is_safe_select_sql(sql: str) -> bool:
    s = re.sub(r"--.*?$|/\*.*?\*/", "", str(sql), flags=re.S | re.M).strip().lower()
    if not (s.startswith("select") or s.startswith("with")):
        return False
    forbidden = ["insert", "update", "delete", "drop", "alter", "create", "attach", "detach", "replace", "pragma", "vacuum"]
    return not any(re.search(rf"\b{kw}\b", s) for kw in forbidden)


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


class DBHandle:
    """SQLite connection wrapper; may use on-disk DB or an in-memory fallback."""

    def __init__(self, sample: Dict[str, Any], cwd: Optional[str] = None):
        self.sample = sample
        self.cwd = cwd or os.getcwd()
        self.temp_path: Optional[str] = None
        self.path = self._resolve_path(sample.get("db_path"))
        if self.path and os.path.exists(self.path):
            self.conn = sqlite3.connect(self.path, timeout=30)
            self.source = self.path
        else:
            self.conn = sqlite3.connect(":memory:")
            self.source = "in_memory_from_sample_tables"
            self._load_tables_into_memory(sample.get("tables") or {})
        self.conn.row_factory = sqlite3.Row

    def _resolve_path(self, path: Any) -> Optional[str]:
        if not path:
            return None
        p = str(path)
        if os.path.exists(p):
            return p
        p2 = os.path.join(self.cwd, p)
        if os.path.exists(p2):
            return p2
        return p

    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def _load_tables_into_memory(self, tables: Dict[str, List[List[Any]]]):
        cur = self.conn.cursor()
        for tn, table in (tables or {}).items():
            if not isinstance(table, list) or not table:
                continue
            headers = [str(h) if str(h).strip() else f"col_{i}" for i, h in enumerate(table[0])]
            seen = defaultdict(int)
            final_headers = []
            for h in headers:
                seen[h] += 1
                final_headers.append(h if seen[h] == 1 else f"{h}_{seen[h]}")
            cols = ", ".join(_quote_ident(h) + " TEXT" for h in final_headers)
            cur.execute(f"CREATE TABLE {_quote_ident(str(tn))} ({cols})")
            ph = ",".join("?" for _ in final_headers)
            for row in table[1:]:
                vals = list(row)[:len(final_headers)] + [None] * max(0, len(final_headers) - len(row))
                cur.execute(f"INSERT INTO {_quote_ident(str(tn))} VALUES ({ph})", vals)
        self.conn.commit()

    def schema_summary(self, max_chars: int = 14000, sample_rows: int = 3) -> str:
        cur = self.conn.cursor()
        cur.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
        rows = cur.fetchall()
        chunks = []
        for r in rows:
            tn = r[0]
            ddl = r[1] or ""
            chunks.append(f"TABLE {tn}\nDDL: {ddl}")
            try:
                cur.execute(f"SELECT COUNT(*) AS n FROM {_quote_ident(tn)}")
                n = cur.fetchone()[0]
                chunks.append(f"row_count: {n}")
            except Exception:
                pass
            try:
                cur.execute(f"PRAGMA table_info({_quote_ident(tn)})")
                cols = [dict(c) for c in cur.fetchall()]
                chunks.append("columns: " + ", ".join(str(c.get("name")) for c in cols))
            except Exception:
                pass
            try:
                cur.execute(f"SELECT * FROM {_quote_ident(tn)} LIMIT {int(sample_rows)}")
                sample = [dict(x) for x in cur.fetchall()]
                chunks.append("sample_rows: " + _json_dumps(sample, max_chars=3000))
            except Exception as exc:
                chunks.append(f"sample_rows_error: {exc}")
            chunks.append("")
            if sum(len(x) for x in chunks) > max_chars:
                break
        text = "\n".join(chunks)
        return text if len(text) <= max_chars else text[:max_chars] + "\n...[schema truncated]"

    def execute(self, sql: str, max_rows: int = 50) -> Tuple[bool, Any, Optional[str]]:
        sql = _clean_sql(sql)
        if not _is_safe_select_sql(sql):
            return False, None, "unsafe_or_not_select"
        try:
            cur = self.conn.cursor()
            cur.execute(sql)
            rows = cur.fetchmany(max_rows + 1)
            cols = [d[0] for d in (cur.description or [])]
            out = []
            for r in rows[:max_rows]:
                if isinstance(r, sqlite3.Row):
                    out.append({k: r[k] for k in r.keys()})
                elif cols:
                    out.append({cols[i]: r[i] for i in range(len(cols))})
                else:
                    out.append(list(r))
            return True, out, None
        except Exception as exc:
            return False, None, str(exc)


def _result_scalar(result_rows: Any) -> Any:
    if not isinstance(result_rows, list) or not result_rows:
        return None
    first = result_rows[0]
    if isinstance(first, dict):
        vals = list(first.values())
        if len(vals) == 1:
            return vals[0]
        return " | ".join(str(v) for v in vals if v is not None)
    if isinstance(first, (list, tuple)):
        if len(first) == 1:
            return first[0]
        return " | ".join(str(v) for v in first if v is not None)
    return first


def _flatten_result_text(result_rows: Any, max_chars: int = 500) -> str:
    if result_rows is None:
        return ""
    if isinstance(result_rows, list):
        parts = []
        for r in result_rows[:20]:
            if isinstance(r, dict):
                parts.append(" | ".join(str(v) for v in r.values() if v is not None))
            else:
                parts.append(str(r))
        s = "; ".join(parts)
    else:
        s = str(result_rows)
    return s[:max_chars]


def map_sql_result_to_choice(result_rows: Any, choices: Sequence[Any]) -> str:
    scalar = _result_scalar(result_rows)
    letter = choice_letter_from_text(scalar, choices)
    if letter != "?":
        return letter
    text = _flatten_result_text(result_rows)
    return choice_letter_from_text(text, choices)


def build_sql_prompt(sample: Dict[str, Any], schema: str, max_sql_candidates: int = 3) -> str:
    question = str(sample.get("question") or sample.get("statement") or "")
    choices = sample.get("choices") or []
    choice_block = "\n".join(str(c) for c in choices)
    return f"""You are a SQLite expert solving a TQA-Bench multi-table multiple-choice question.

Your job is NOT to guess from sample rows. Generate SQL that computes the answer from the full SQLite database.

Rules:
- Use only SQLite SELECT or WITH queries.
- Use table and column names exactly as shown in the schema. Quote identifiers with double quotes when they contain spaces or special characters.
- Do not use INSERT, UPDATE, DELETE, CREATE, DROP, PRAGMA, or multiple statements.
- Prefer one query that computes the target value, count, average, percentage, max/min entity, etc.
- If a question mentions an airline/business/recipe/etc., join lookup tables if needed to map names to IDs.
- Return JSON only. Do not include markdown.

Question:
{question}

Choices:
{choice_block}

SQLite schema and small samples:
{schema}

Return this JSON schema:
{{
  "queries": [
    {{"sql": "SELECT ...", "rationale": "why this computes the answer"}}
  ]
}}
Return at most {max_sql_candidates} SQL candidates.
"""


def build_choice_prompt(sample: Dict[str, Any], sql: str, result_rows: Any) -> str:
    question = str(sample.get("question") or sample.get("statement") or "")
    choices = "\n".join(str(c) for c in sample.get("choices") or [])
    return f"""You are mapping a SQLite execution result to a multiple-choice answer.

Use the executed SQL result below, not prior assumptions.
Return ONLY JSON: {{"answer":"A", "confidence":0.0, "reason":"brief"}}
The answer field must be one of A, B, C, D, E, F.

Question:
{question}

Choices:
{choices}

Executed SQL:
{sql}

SQL result JSON:
{_json_dumps(result_rows, max_chars=5000)}
"""


def call_llm_text(llm: Any, prompt: str, max_tokens: int = 1200, temperature: float = 0.0) -> str:
    opts = llm.get_model_options(temperature=temperature, per_example_max_decode_steps=max_tokens, per_example_top_p=1.0, n_sample=1)
    try:
        return llm.generate(prompt, opts)
    except AttributeError:
        return llm.generate_plus_with_score(prompt, opts)[0][0]


def solve_one_sample_sql(
    sample: Dict[str, Any],
    llm: Any,
    idx: int = 0,
    votes: int = 3,
    parallel_votes: int = 1,
    max_schema_chars: int = 14000,
    max_sql_candidates: int = 3,
    sql_timeout_rows: int = 50,
    use_llm_result_mapper: bool = True,
    debug: bool = False,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    db = DBHandle(sample)
    try:
        schema = db.schema_summary(max_chars=max_schema_chars)
        prompt = build_sql_prompt(sample, schema, max_sql_candidates=max_sql_candidates)

        raw_outputs: List[str] = []
        def _one(vote_idx: int) -> str:
            temp = 0.0 if vote_idx == 0 else 0.2
            return call_llm_text(llm, prompt, max_tokens=1400, temperature=temp)

        workers = max(1, min(int(parallel_votes or 1), int(votes or 1)))
        if workers == 1:
            for vi in range(max(1, int(votes or 1))):
                raw_outputs.append(_one(vi))
        else:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = [ex.submit(_one, vi) for vi in range(max(1, int(votes or 1)))]
                for fut in as_completed(futs):
                    raw_outputs.append(fut.result())

        evidence: List[Dict[str, Any]] = []
        choice_votes: List[str] = []
        seen_sql = set()
        for raw in raw_outputs:
            candidates = extract_sql_candidates(raw)
            if not candidates:
                evidence.append({"stage": "sql_generation", "raw": raw, "error": "no_sql_extracted"})
                continue
            for cand in candidates:
                sql = cand.get("sql", "")
                if not sql or sql in seen_sql:
                    continue
                seen_sql.add(sql)
                ok, rows, err = db.execute(sql, max_rows=sql_timeout_rows)
                ev = {"stage": "sql_execution", "sql": sql, "ok": ok, "rows": rows, "error": err, "rationale": cand.get("rationale")}
                if ok:
                    letter = map_sql_result_to_choice(rows, sample.get("choices") or [])
                    ev["deterministic_choice"] = letter
                    if letter != "?":
                        choice_votes.append(letter)
                    elif use_llm_result_mapper:
                        try:
                            mapper_raw = call_llm_text(llm, build_choice_prompt(sample, sql, rows), max_tokens=300, temperature=0.0)
                            mapped = choice_letter_from_text(mapper_raw, sample.get("choices") or [])
                            ev["llm_mapper_raw"] = mapper_raw
                            ev["llm_mapper_choice"] = mapped
                            if mapped != "?":
                                choice_votes.append(mapped)
                        except Exception as exc:
                            ev["llm_mapper_error"] = str(exc)
                evidence.append(ev)

        if choice_votes:
            counts = Counter(choice_votes)
            final, count = counts.most_common(1)[0]
            confidence = count / max(1, len(choice_votes))
            source = "tqabench_sql_execution"
        else:
            # Last-resort direct choice from schema.  This is recorded separately
            # so it can be excluded from strict SQL-only analysis if desired.
            direct_prompt = f"""Choose the best option for this TQA-Bench question using the schema and samples. Return ONLY JSON {{"answer":"A", "confidence":0.0, "reason":"brief"}}.

Question: {sample.get('question')}
Choices:\n{chr(10).join(str(c) for c in sample.get('choices') or [])}
Schema and samples:\n{schema}
"""
            direct_raw = call_llm_text(llm, direct_prompt, max_tokens=500, temperature=0.0)
            final = choice_letter_from_text(direct_raw, sample.get("choices") or [])
            confidence = 0.0 if final == "?" else 0.35
            source = "tqabench_direct_schema_fallback"
            evidence.append({"stage": "direct_schema_fallback", "raw": direct_raw, "choice": final})

        result = copy.deepcopy(sample)
        result["answer"] = final if final != "?" else None
        result["pred_answer"] = final if final != "?" else None
        result["answer_source"] = source
        result["tqabench_sql"] = {
            "version": "v30_sql_execution_additive",
            "db_source": db.source,
            "votes": votes,
            "parallel_votes": parallel_votes,
            "choice_votes": choice_votes,
            "confidence": confidence,
            "evidence": evidence,
        }
        report = {
            "method": "tqabench_sql_execution_v30",
            "answer_source": source,
            "pred": result.get("pred_answer"),
            "gold": gold_letter(sample),
            "correct": result.get("pred_answer") == gold_letter(sample),
            "choice_votes": choice_votes,
        }
        return result, report
    finally:
        db.close()


def solve_dataset_sql(
    samples: List[Dict[str, Any]],
    llm: Any,
    result_dir: str,
    votes: int = 3,
    parallel_votes: int = 1,
    max_schema_chars: int = 14000,
    max_sql_candidates: int = 3,
    resume: bool = True,
    debug: bool = False,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    os.makedirs(result_dir, exist_ok=True)
    cache_dir = os.path.join(result_dir, "tqabench_sql_cache_v30")
    os.makedirs(cache_dir, exist_ok=True)
    results: List[Dict[str, Any]] = []
    reports: List[Dict[str, Any]] = []
    for idx, sample in enumerate(tqdm(samples, total=len(samples))):
        cp = os.path.join(cache_dir, _safe_cache_name(sample, idx))
        if resume and os.path.exists(cp):
            try:
                r, rep = pickle.load(open(cp, "rb"))
                results.append(r)
                reports.append(rep)
                continue
            except Exception:
                pass
        try:
            r, rep = solve_one_sample_sql(
                sample, llm, idx=idx, votes=votes, parallel_votes=parallel_votes,
                max_schema_chars=max_schema_chars, max_sql_candidates=max_sql_candidates, debug=debug,
            )
        except Exception as exc:
            r = copy.deepcopy(sample)
            r.update({"answer": None, "pred_answer": None, "answer_source": "tqabench_sql_error", "tqabench_sql": {"error": str(exc)}})
            rep = {"method": "tqabench_sql_error", "error": str(exc), "gold": gold_letter(sample), "pred": None, "correct": False}
            if debug:
                print(f"[TQA-SQL] case {idx} failed: {exc}", flush=True)
        results.append(r)
        reports.append(rep)
        try:
            pickle.dump((r, rep), open(cp, "wb"))
        except Exception:
            pass
    metrics = evaluate_multichoice(results, samples)
    return results, reports, metrics


def evaluate_multichoice(results: List[Dict[str, Any]], samples: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    sample_map = {str(s.get("id")): s for s in (samples or [])}
    total = correct = invalid = 0
    by_source = defaultdict(lambda: {"total": 0, "correct": 0, "invalid": 0})
    for r in results:
        if r is None:
            continue
        total += 1
        sid = str(r.get("id"))
        s = sample_map.get(sid, r)
        gold = gold_letter(s)
        pred = choice_letter_from_text(r.get("pred_answer", r.get("answer")), s.get("choices") or [])
        src = str(r.get("answer_source", "unknown"))
        by_source[src]["total"] += 1
        if pred == "?":
            invalid += 1
            by_source[src]["invalid"] += 1
            continue
        if pred == gold:
            correct += 1
            by_source[src]["correct"] += 1
    source_stats = {k: {**v, "accuracy": round(v["correct"] / max(v["total"], 1), 4)} for k, v in by_source.items()}
    return {"total": total, "correct": correct, "invalid": invalid, "accuracy": round(correct / max(total, 1), 4), "by_source": source_stats}
