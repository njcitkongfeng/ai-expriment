from __future__ import annotations
"""
Executable Table Reasoning Engine
==================================

Unified five-step pipeline for table QA and fact verification.

Architecture::

   claim / question
        │
        ▼
   ┌─────────────────────────────────────────────┐
   │ Step 1 — Generate Reasoning Plans            │
   │   ├─ PCFG grammar tree sampling              │
   │   ├─ Schema-aware deterministic patterns     │
   │   ├─ Claim-to-predicate parser (TabFact)     │
   │   └─ Heuristic RawSQL candidates             │
   └──────────────────┬──────────────────────────┘
                      ▼
   ┌─────────────────────────────────────────────┐
   │ Step 2 — Execute Plans                       │
   │   └─ Compile to SQL → SQLite execution       │
   └──────────────────┬──────────────────────────┘
                      ▼
   ┌─────────────────────────────────────────────┐
   │ Step 3 — Verify (Bayes Factor)               │
   │   ├─ PCFG structural prior                   │
   │   ├─ Formal execution likelihood             │
   │   └─ Posterior = prior × likelihood          │
   └──────────────────┬──────────────────────────┘
                      ▼
   ┌─────────────────────────────────────────────┐
   │ Step 4 — Decide                              │
   │   BF ≥ 3 → Accept                           │
   │   BF < 3 → Grammar-guided local repair       │
   └──────────────────┬──────────────────────────┘
                      ▼
   ┌─────────────────────────────────────────────┐
   │ Step 5 — LLM Verification (optional)         │
   │   └─ LLM reviews table + candidates → answer │
   └─────────────────────────────────────────────┘

Single entry point for all datasets:
  TabFact, WikiTQ, Spider, FinQA, FeTaQA, TQA-Bench.
"""


import os
from typing import Any, Dict, List, Optional, Tuple


def execute_reasoning_plan(
    sample: Dict[str, Any],
    llm: Any = None,
    llm_options: Optional[Dict[str, Any]] = None,
    beam_width: int = 8,
    n_mcmc: int = 40,
    max_repair_rounds: int = 3,
    llm_refine_mode: str = "never",
    llm_refine_min_bf: float = 3.0,
    debug: bool = False,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Execute the full five-step table reasoning pipeline.

    Args:
        sample: dict with tables/table_text, question/statement
        llm: optional LLM for Step 5 verification
        llm_options: generation options for LLM
        beam_width, n_mcmc: PCFG search parameters
        max_repair_rounds: grammar repair rounds in Step 4
        llm_refine_mode: 'never', 'low_confidence', 'always'
        debug: verbose output

    Returns:
        (result_sample, pipeline_report)
    """
    from utils.chain import pcfg_bf_chain_exec_one_sample

    return pcfg_bf_chain_exec_one_sample(
        sample=sample, llm=llm, llm_options=llm_options,
        beam_width=beam_width, n_mcmc=n_mcmc,
        max_refinement_rounds=max_repair_rounds, debug=debug,
        llm_refine_mode=llm_refine_mode,
        llm_refine_min_bf=llm_refine_min_bf,
    )


def execute_dataset(
    all_samples: List[Dict[str, Any]],
    llm: Any = None,
    llm_options: Optional[Dict[str, Any]] = None,
    beam_width: int = 8,
    n_mcmc: int = 40,
    max_repair_rounds: int = 3,
    llm_refine_mode: str = "never",
    llm_refine_min_bf: float = 3.0,
    debug: bool = False,
    cache_dir: str = "./results/cache",
) -> Tuple[List[Optional[Dict[str, Any]]], List[Optional[Dict[str, Any]]]]:
    """Run the pipeline over an entire dataset."""
    from utils.chain import pcfg_bf_chain_exec_dataset

    return pcfg_bf_chain_exec_dataset(
        all_samples=all_samples, llm=llm, llm_options=llm_options,
        beam_width=beam_width, n_mcmc=n_mcmc,
        max_refinement_rounds=max_repair_rounds, debug=debug,
        cache_dir=cache_dir, llm_refine_mode=llm_refine_mode,
        llm_refine_min_bf=llm_refine_min_bf,
    )
