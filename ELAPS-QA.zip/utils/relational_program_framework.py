from __future__ import annotations
"""Spider adapter for the universal CandidateProgramEngine.

This module routes official Spider samples through the SQL CandidateProgram
path: candidate SQL generation -> SQLite execution -> structural/semantic
verification -> posterior ranking -> answer-level aggregation.

Gold SQL / gold answers are never placed in TaskContext; they are used only by
run_spider.py for post-hoc evaluation.
"""

import json
import re
from typing import Any, Dict, List, Optional

from candidate_framework import TaskContext, CandidateProgramEngine, CandidateProgram, CandidateGenerator
from adapters.sql import (
    SQLListGenerator,
    SQLSchemaRuleGenerator,
    SQLiteExecutor,
    SQLVerifier,
    SQLRepairer,
)
from adapters.sql.schema_graph import build_sqlite_schema_graph


def _clean_sql(sql: str) -> str:
    s = str(sql or "").strip()
    s = re.sub(r"^```(?:sql)?", "", s, flags=re.I).strip()
    s = re.sub(r"```$", "", s).strip()
    return s.rstrip(";")


def _extract_sql_candidates(text: str) -> List[str]:
    """Robustly extract SQL candidates from LLM output."""
    if not text:
        return []
    out: List[str] = []
    # JSON object/list first.
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            vals = obj.get("sql_candidates") or obj.get("candidates") or obj.get("sql") or []
            if isinstance(vals, str):
                vals = [vals]
            if isinstance(vals, list):
                for v in vals:
                    if isinstance(v, dict):
                        v = v.get("sql") or v.get("query") or ""
                    q = _clean_sql(str(v))
                    if q.lower().startswith(("select", "with")):
                        out.append(q)
        elif isinstance(obj, list):
            for v in obj:
                if isinstance(v, dict):
                    v = v.get("sql") or v.get("query") or ""
                q = _clean_sql(str(v))
                if q.lower().startswith(("select", "with")):
                    out.append(q)
    except Exception:
        pass
    # Code fences / raw SQL.
    for m in re.finditer(r"```(?:sql)?\s*(.*?)```", text, flags=re.I | re.S):
        q = _clean_sql(m.group(1))
        if q.lower().startswith(("select", "with")):
            out.append(q)
    # SELECT...; spans.
    for m in re.finditer(r"((?:SELECT|WITH)\b.*?)(?:;|$)", text, flags=re.I | re.S):
        q = _clean_sql(m.group(1))
        if q.lower().startswith(("select", "with")):
            out.append(q)
    # Dedupe in order.
    seen = set()
    deduped = []
    for q in out:
        k = re.sub(r"\s+", " ", q.lower()).strip()
        if k not in seen:
            seen.add(k)
            deduped.append(q)
    return deduped


class SpiderSchemaRuleGenerator(CandidateGenerator):
    """Conservative Spider-specific schema/rule SQL candidates.

    This branch is not intended to solve Spider alone. It provides a symbolic
    lower-bound and supplements LLM SQL candidates inside CandidateProgramEngine.
    """

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        graph = ctx.metadata.get("schema_graph")
        if graph is None and ctx.metadata.get("db_path"):
            graph = build_sqlite_schema_graph(ctx.metadata["db_path"])
            ctx.metadata["schema_graph"] = graph
        if graph is None:
            return []
        q = (ctx.question or "").lower()
        programs: List[CandidateProgram] = []

        def _mentioned(table: str) -> bool:
            name = table.lower()
            singular = re.sub(r"s$", "", name)
            plural = name if name.endswith("s") else name + "s"
            variants = {name, singular, plural, name.replace("_", " "), singular.replace("_", " "), plural.replace("_", " ")}
            return any(re.search(rf"\b{re.escape(v)}\b", q) for v in variants if v)

        count_q = bool(re.search(r"\b(how many|number of|total number|count)\b", q))
        for table in graph.tables:
            if count_q and _mentioned(table):
                pk = next(iter(graph.primary_keys.get(table, [])), None)
                if pk:
                    sql = f"SELECT COUNT(DISTINCT {table}.{pk}) FROM {table}"
                else:
                    sql = f"SELECT COUNT(*) FROM {table}"
                programs.append(CandidateProgram(sql, "sql", "schema_graph_rule_candidate", f"spider_schema_rule:count:{table}"))
        return programs[:8]


class SpiderLLMSQLGenerator(CandidateGenerator):
    """Generate Spider SQL candidates from an LLM under the common interface."""

    def __init__(self, llm: Any = None, llm_options: Optional[Dict[str, Any]] = None, max_candidates: int = 3):
        self.llm = llm
        self.llm_options = dict(llm_options or {})
        self.max_candidates = max(1, int(max_candidates or 3))

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        if self.llm is None:
            return []
        schema_text = ctx.metadata.get("schema_text") or ""
        prompt = f"""
You are solving a Spider text-to-SQL task. Generate {self.max_candidates} diverse SQLite SELECT queries for the question.
Return only JSON in this format: {{"sql_candidates": ["SELECT ...", "SELECT ..."]}}.
Do not include explanations. Do not use INSERT/UPDATE/DELETE/DDL.

Question:
{ctx.question}

Database schema:
{schema_text}
""".strip()
        options = dict(self.llm_options or {})
        options.setdefault("temperature", 0.0)
        options.setdefault("top_p", 1.0)
        options.setdefault("max_tokens", options.get("per_example_max_decode_steps", 512))
        # Ask once for a JSON list. This keeps LLM calls/sample low.
        try:
            text = self.llm.generate(prompt, options=options)
        except TypeError:
            text = self.llm.generate(prompt, options)
        except Exception as exc:
            print(f"[SpiderFramework] LLM SQL generation failed: {exc}", flush=True)
            return []
        sqls = _extract_sql_candidates(text)[: self.max_candidates]
        return [CandidateProgram(sql, "sql", "llm_sql_candidate", f"spider_llm:{i}") for i, sql in enumerate(sqls)]


def _candidate_to_record(ec, sample: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "sql": str(ec.program.content),
        "answer": ec.execution.answer,
        "source": ec.program.source,
        "program_id": ec.program.program_id,
        "posterior": ec.posterior,
        "bayes_score": ec.bayes_score,
        "ok": ec.execution.ok,
        "error": ec.execution.error,
        "candidate_framework": {
            "engine_used": True,
            "engine_scope": "sample_candidate_pool",
            "task_type": "spider_sql",
            "program_type": ec.program.program_type,
            "source": ec.program.source,
            "bayes_score": ec.bayes_score,
            "posterior": ec.posterior,
            "verification": {
                "static_score": ec.verification.static_score,
                "execution_score": ec.verification.execution_score,
                "semantic_score": ec.verification.semantic_score,
                "risk_signals": list(ec.verification.risk_signals or []),
                "details": dict(ec.verification.details or {}),
            },
        },
    }


def solve_spider_sample_with_framework(
    sample: Dict[str, Any],
    *,
    llm: Any = None,
    llm_options: Optional[Dict[str, Any]] = None,
    candidate_sources: str = "all",
    max_sql_candidates: int = 3,
    max_repair_rounds: int = 1,
) -> Dict[str, Any]:
    """Solve one Spider sample via CandidateProgramEngine."""
    db_path = sample.get("db_path")
    if not db_path:
        raise ValueError("Spider sample missing db_path; use the native official loader.")
    graph = build_sqlite_schema_graph(db_path)
    schema_text = graph.summary(max_cols=20)
    sources = {x.strip().lower() for x in str(candidate_sources or "all").split(",") if x.strip()}
    use_all = "all" in sources

    generators = []
    if use_all or "llm" in sources:
        generators.append(SpiderLLMSQLGenerator(llm, llm_options, max_candidates=max_sql_candidates))
    if use_all or "schema_rule" in sources or "schema" in sources:
        generators.append(SpiderSchemaRuleGenerator())
    # Optional provided candidates, but never use gold_sql here.
    provided = sample.get("sql_candidates") or []
    if provided and (use_all or "provided" in sources):
        generators.append(SQLListGenerator(provided, source="provided_sql_candidate"))

    ctx = TaskContext(
        task_id=str(sample.get("id") or "spider_case"),
        question=str(sample.get("question") or sample.get("statement") or ""),
        data=None,
        schema=schema_text,
        task_type="spider_sql",
        metadata={
            "db_path": db_path,
            "db_id": sample.get("db_id") or sample.get("database"),
            "schema_graph": graph,
            "schema_text": schema_text,
        },
    )
    engine = CandidateProgramEngine(
        generators=generators,
        executor=SQLiteExecutor(db_path_key="db_path"),
        verifier=SQLVerifier(),
        repairers=[SQLRepairer()] if max_repair_rounds > 0 else [],
        max_repair_rounds=max_repair_rounds,
        keep_failed_candidates=True,
    )
    solved = engine.solve(ctx)
    ranked = list(solved.get("ranked_candidates") or [])
    selected = solved.get("selected_candidate")
    answer = solved.get("answer")
    if selected is not None and selected.execution is not None:
        answer = selected.execution.answer
    return {
        "id": sample.get("id"),
        "db_id": sample.get("db_id") or sample.get("database"),
        "question": sample.get("question"),
        "answer": answer,
        "answers": sample.get("answers", []),
        "gold_sql": sample.get("gold_sql", ""),
        "program": str(selected.program.content) if selected else None,
        "candidate_framework_engine_used": True,
        "candidate_framework_engine_scope": "sample_candidate_pool",
        "candidate_framework_result": {
            "engine_used": True,
            "engine_scope": "sample_candidate_pool",
            "task_type": "spider_sql",
            "num_initial_candidates": solved.get("num_initial_candidates"),
            "num_evaluated_candidates": solved.get("num_evaluated_candidates"),
            "answer_key": solved.get("answer_key"),
            "answer_mass": solved.get("answer_mass"),
            "answer_bayes_factor": solved.get("answer_bayes_factor"),
            "supporters": solved.get("supporters"),
        },
        "framework_ranked_candidates": [_candidate_to_record(ec, sample) for ec in ranked],
    }


def solve_spider_dataset_with_framework(
    dataset: List[Dict[str, Any]],
    *,
    llm: Any = None,
    llm_options: Optional[Dict[str, Any]] = None,
    candidate_sources: str = "all",
    max_sql_candidates: int = 3,
    max_repair_rounds: int = 1,
    debug: bool = False,
) -> List[Dict[str, Any]]:
    from tqdm import tqdm
    out: List[Dict[str, Any]] = []
    for sample in tqdm(dataset, total=len(dataset), desc="Spider CandidateProgramEngine"):
        try:
            out.append(solve_spider_sample_with_framework(
                sample,
                llm=llm,
                llm_options=llm_options,
                candidate_sources=candidate_sources,
                max_sql_candidates=max_sql_candidates,
                max_repair_rounds=max_repair_rounds,
            ))
        except Exception as exc:
            if debug:
                import traceback; traceback.print_exc()
            out.append({
                "id": sample.get("id"),
                "question": sample.get("question"),
                "answer": None,
                "answers": sample.get("answers", []),
                "gold_sql": sample.get("gold_sql", ""),
                "error": str(exc),
                "candidate_framework_engine_used": True,
                "candidate_framework_engine_scope": "sample_candidate_pool",
            })
    return out
