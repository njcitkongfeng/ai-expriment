from __future__ import annotations
"""TQA/SymDataset adapter that routes SQL candidates through CandidateProgramEngine.

This module is intentionally thin: it does not replace the optimized TQA logic.
Instead it instantiates the universal candidate-program interfaces for each SQL
candidate while delegating execution/repair/verification to the existing
TQA-Bench modules that produced the reported 94.37% result.

The important architectural point is that TQA is now an SQL instance of the
universal framework rather than a completely separate bypass path.
"""

from typing import Any, Callable, Dict, List, Optional

from candidate_framework.core import (
    TaskContext,
    CandidateProgram,
    ExecutionTrace,
    VerificationResult,
    CandidateGenerator,
    ProgramExecutor,
    ProgramVerifier,
    CandidateProgramEngine,
    EvaluatedCandidate,
)
from utils.multitable_bayes import annotate_executed_candidate


class TQASingleSQLGenerator(CandidateGenerator):
    """Wrap one SQL string as a CandidateProgram."""

    def __init__(self, sql: str, rationale: Any = None, stage: str = "llm_sql_candidate"):
        self.sql = str(sql or "")
        self.rationale = rationale
        self.stage = stage

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        if not self.sql.strip():
            return []
        return [
            CandidateProgram(
                content=self.sql,
                program_type="sql",
                source=self.stage,
                metadata={"rationale": self.rationale, "candidate_stage": self.stage},
            )
        ]


class TQASQLExecutor(ProgramExecutor):
    """Universal-framework executor for TQA SQL candidates.

    It delegates to the optimized TQA `execute_sql_with_repairs` function.  That
    function already performs safe SELECT execution, leakage-safe semantic
    repairs, and result-shape based repair acceptance.
    """

    def __init__(
        self,
        db: Any,
        visible_sample: Dict[str, Any],
        execute_sql_with_repairs_fn: Callable[[Any, str, Optional[Dict[str, Any]]], Any],
        normalize_prediction_without_gold_fn: Callable[[Any, Dict[str, Any], Any, str], Any],
        clean_sql_fn: Callable[[str], str],
    ):
        self.db = db
        self.visible_sample = visible_sample
        self.execute_sql_with_repairs_fn = execute_sql_with_repairs_fn
        self.normalize_prediction_without_gold_fn = normalize_prediction_without_gold_fn
        self.clean_sql_fn = clean_sql_fn

    def execute(self, ctx: TaskContext, program: CandidateProgram) -> ExecutionTrace:
        sql = self.clean_sql_fn(str(program.content or ""))
        try:
            ok, value, err, attempts, used_sql = self.execute_sql_with_repairs_fn(self.db, sql, self.visible_sample)
            if ok and value is not None:
                value = self.normalize_prediction_without_gold_fn(self.db, self.visible_sample, value, used_sql)
            return ExecutionTrace(
                ok=bool(ok),
                answer=value,
                trace={"sql": used_sql, "raw_sql": sql, "attempts": attempts},
                error=err,
                evidence={
                    "used_sql": used_sql,
                    "raw_sql": sql,
                    "attempts": attempts,
                    "used_repair": self.clean_sql_fn(sql) != self.clean_sql_fn(used_sql),
                },
            )
        except Exception as exc:
            return ExecutionTrace(
                ok=False,
                answer=None,
                trace={"sql": sql, "attempts": []},
                error=str(exc),
                evidence={"used_sql": sql, "raw_sql": sql, "attempts": []},
            )


class TQAMultitableVerifier(ProgramVerifier):
    """Verifier adapter for TQA multi-table SQL candidates.

    It reuses the existing multitable static/dynamic/semantic scorer so the
    universal framework and the optimized TQA ranking use the same evidence.
    """

    def __init__(self, question: str, schema_graph: Dict[str, Any], result_shape_score_fn: Callable[[str, Any], float]):
        self.question = question
        self.schema_graph = schema_graph or {}
        self.result_shape_score_fn = result_shape_score_fn

    def verify(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace) -> VerificationResult:
        used_sql = str(execution.evidence.get("used_sql") or program.content or "")
        attempts = execution.evidence.get("attempts") or []
        candidate = {
            "sql": used_sql,
            "raw_sql": execution.evidence.get("raw_sql") or program.content,
            "value": execution.answer,
            "attempts": attempts,
            "stage": program.source,
            "shape_score": self.result_shape_score_fn(self.question, execution.answer),
            "used_repair": bool(execution.evidence.get("used_repair")),
        }
        annotated = annotate_executed_candidate(candidate, self.question, self.schema_graph)
        static = float(annotated.get("static_prior") or 0.0)
        dynamic = float(annotated.get("execution_likelihood") or 0.0)
        semantic = float(annotated.get("semantic_score") or 0.0)
        risks: List[str] = []
        for key in ("static_risks", "dynamic_risks", "semantic_signals"):
            vals = annotated.get(key) or []
            risks.extend([str(x) for x in vals])
        return VerificationResult(
            static_score=static,
            execution_score=dynamic,
            semantic_score=semantic,
            risk_signals=risks,
            details=annotated,
        )


def execute_tqa_sql_candidate_via_framework(
    *,
    db: Any,
    visible_sample: Dict[str, Any],
    schema_graph: Dict[str, Any],
    sql: str,
    rationale: Any,
    stage: str,
    execute_sql_with_repairs_fn: Callable[[Any, str, Optional[Dict[str, Any]]], Any],
    normalize_prediction_without_gold_fn: Callable[[Any, Dict[str, Any], Any, str], Any],
    result_shape_score_fn: Callable[[str, Any], float],
    clean_sql_fn: Callable[[str], str],
) -> Dict[str, Any]:
    """Run one SQL candidate through the universal CandidateProgramEngine.

    The returned dict is compatible with the legacy TQA candidate records so the
    guarded hybrid multitable-bayes selector remains unchanged.
    """

    ctx = TaskContext(
        task_id=str(visible_sample.get("id") or visible_sample.get("task_index") or "tqa_case"),
        question=str(visible_sample.get("question") or ""),
        data=None,
        schema=schema_graph,
        task_type="tqabench_sql",
        metadata={
            "visible_sample": visible_sample,
            "schema_graph": schema_graph,
            "db_path": visible_sample.get("db_path"),
        },
    )
    engine = CandidateProgramEngine(
        generators=[TQASingleSQLGenerator(sql, rationale=rationale, stage=stage)],
        executor=TQASQLExecutor(
            db=db,
            visible_sample=visible_sample,
            execute_sql_with_repairs_fn=execute_sql_with_repairs_fn,
            normalize_prediction_without_gold_fn=normalize_prediction_without_gold_fn,
            clean_sql_fn=clean_sql_fn,
        ),
        verifier=TQAMultitableVerifier(
            question=str(visible_sample.get("question") or ""),
            schema_graph=schema_graph,
            result_shape_score_fn=result_shape_score_fn,
        ),
        repairers=[],
        max_repair_rounds=0,
        keep_failed_candidates=True,
    )
    solved = engine.solve(ctx)
    ranked = solved.get("ranked_candidates") or []
    if not ranked:
        return {
            "ok": False,
            "value": None,
            "error": "no_candidate_evaluated_by_framework",
            "attempts": [],
            "used_sql": clean_sql_fn(sql),
            "raw_sql": clean_sql_fn(sql),
            "framework": {"engine_used": True, "num_evaluated_candidates": 0},
        }

    ec = ranked[0]
    execution = ec.execution
    used_sql = str(execution.evidence.get("used_sql") or clean_sql_fn(sql))
    attempts = execution.evidence.get("attempts") or []
    return {
        "ok": bool(execution.ok),
        "value": execution.answer,
        "error": execution.error,
        "attempts": attempts,
        "used_sql": used_sql,
        "raw_sql": str(execution.evidence.get("raw_sql") or clean_sql_fn(sql)),
        "framework": {
            "engine_used": True,
            "task_type": solved.get("task_type"),
            "num_initial_candidates": solved.get("num_initial_candidates"),
            "num_evaluated_candidates": solved.get("num_evaluated_candidates"),
            "program_id": ec.program.program_id,
            "program_type": ec.program.program_type,
            "source": ec.program.source,
            "bayes_score": ec.bayes_score,
            "posterior": ec.posterior,
            "verification": {
                "static_score": ec.verification.static_score,
                "execution_score": ec.verification.execution_score,
                "semantic_score": ec.verification.semantic_score,
                "risk_signals": ec.verification.risk_signals,
            },
        },
    }


class TQAPrebuiltSQLCandidateGenerator(CandidateGenerator):
    """Generate a whole TQA SQL candidate pool as CandidateProgram objects.

    This is the end-to-end adapter used by the TQA main path.  Unlike the older
    single-candidate wrapper, this lets CandidateProgramEngine own the candidate
    pool generation/execution/verification/ranking step for the sample.
    """

    def __init__(self, candidate_specs: List[Dict[str, Any]]):
        self.candidate_specs = list(candidate_specs or [])

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        programs: List[CandidateProgram] = []
        for i, spec in enumerate(self.candidate_specs):
            sql = str(spec.get("sql") or "").strip()
            if not sql:
                continue
            meta = dict(spec)
            meta.setdefault("global_index", i)
            programs.append(
                CandidateProgram(
                    content=sql,
                    program_type="sql",
                    source=str(spec.get("stage") or spec.get("source") or "sql_candidate"),
                    metadata=meta,
                )
            )
        return programs


def _evaluated_candidate_to_tqa_record(
    ec: EvaluatedCandidate,
    *,
    question: str,
    result_shape_score_fn: Callable[[str, Any], float],
    clean_sql_fn: Callable[[str], str],
) -> Optional[Dict[str, Any]]:
    execution = ec.execution
    if not execution.ok or execution.answer is None:
        return None
    prog = ec.program
    meta = dict(prog.metadata or {})
    used_sql = str(execution.evidence.get("used_sql") or clean_sql_fn(str(prog.content or "")))
    raw_sql = str(execution.evidence.get("raw_sql") or clean_sql_fn(str(prog.content or "")))
    verification = ec.verification
    return {
        "sql": used_sql,
        "raw_sql": raw_sql,
        "value": execution.answer,
        "rationale": meta.get("rationale"),
        "stage": prog.source,
        "shape_score": result_shape_score_fn(question, execution.answer),
        "attempts": execution.evidence.get("attempts") or [],
        "used_repair": bool(execution.evidence.get("used_repair")),
        "vote_index": meta.get("vote_index"),
        "candidate_index": meta.get("candidate_index"),
        "global_index": meta.get("global_index"),
        "primary_eligible": bool(meta.get("primary_eligible", False)),
        "candidate_framework": {
            "engine_used": True,
            "engine_scope": "sample_candidate_pool",
            "task_type": "tqabench_sql",
            "program_id": prog.program_id,
            "program_type": prog.program_type,
            "source": prog.source,
            "bayes_score": ec.bayes_score,
            "posterior": ec.posterior,
            "verification": {
                "static_score": verification.static_score,
                "execution_score": verification.execution_score,
                "semantic_score": verification.semantic_score,
                "risk_signals": list(verification.risk_signals or []),
                "details": verification.details,
            },
            "metadata": meta,
        },
    }


def execute_tqa_sql_candidate_pool_via_framework(
    *,
    db: Any,
    visible_sample: Dict[str, Any],
    schema_graph: Dict[str, Any],
    candidate_specs: List[Dict[str, Any]],
    execute_sql_with_repairs_fn: Callable[[Any, str, Optional[Dict[str, Any]]], Any],
    normalize_prediction_without_gold_fn: Callable[[Any, Dict[str, Any], Any, str], Any],
    result_shape_score_fn: Callable[[str, Any], float],
    clean_sql_fn: Callable[[str], str],
) -> Dict[str, Any]:
    """Run the full TQA SQL candidate pool through CandidateProgramEngine.

    This is the function that makes TQA genuinely use the universal framework:
    the sample-level candidate pool is generated, executed, verified, ranked, and
    answer-aggregated inside CandidateProgramEngine.  The returned TQA records are
    then passed to the existing guarded hybrid multitable-bayes selector, so the
    high-performing TQA decision policy is preserved.
    """
    question = str(visible_sample.get("question") or "")
    ctx = TaskContext(
        task_id=str(visible_sample.get("id") or visible_sample.get("task_index") or "tqa_case"),
        question=question,
        data=None,
        schema=schema_graph,
        task_type="tqabench_sql",
        metadata={
            "visible_sample": visible_sample,
            "schema_graph": schema_graph,
            "db_path": visible_sample.get("db_path"),
            "candidate_pool_size": len(candidate_specs or []),
        },
    )
    engine = CandidateProgramEngine(
        generators=[TQAPrebuiltSQLCandidateGenerator(candidate_specs)],
        executor=TQASQLExecutor(
            db=db,
            visible_sample=visible_sample,
            execute_sql_with_repairs_fn=execute_sql_with_repairs_fn,
            normalize_prediction_without_gold_fn=normalize_prediction_without_gold_fn,
            clean_sql_fn=clean_sql_fn,
        ),
        verifier=TQAMultitableVerifier(
            question=question,
            schema_graph=schema_graph,
            result_shape_score_fn=result_shape_score_fn,
        ),
        repairers=[],
        max_repair_rounds=0,
        keep_failed_candidates=True,
    )
    solved = engine.solve(ctx)
    ranked: List[EvaluatedCandidate] = list(solved.get("ranked_candidates") or [])

    records: List[Dict[str, Any]] = []
    evidence: List[Dict[str, Any]] = []
    for ec in ranked:
        prog = ec.program
        meta = dict(prog.metadata or {})
        attempts = ec.execution.evidence.get("attempts") or []
        for ev in attempts:
            ev2 = dict(ev)
            ev2["rationale"] = meta.get("rationale")
            ev2["candidate_stage"] = prog.source
            ev2["candidate_framework_used"] = True
            ev2["candidate_framework_scope"] = "sample_candidate_pool"
            ev2["vote_index"] = meta.get("vote_index")
            ev2["candidate_index"] = meta.get("candidate_index")
            ev2["global_index"] = meta.get("global_index")
            evidence.append(ev2)
        rec = _evaluated_candidate_to_tqa_record(
            ec,
            question=question,
            result_shape_score_fn=result_shape_score_fn,
            clean_sql_fn=clean_sql_fn,
        )
        if rec is not None:
            records.append(rec)

    # Preserve original generation order for primary-vote reconstruction; the
    # framework-ranked order is still stored in each record through posterior.
    records_by_generation = sorted(
        records,
        key=lambda r: (
            10**9 if r.get("global_index") is None else int(r.get("global_index")),
            str(r.get("sql") or ""),
        ),
    )
    return {
        "executed_candidates": records_by_generation,
        "framework_ranked_candidates": records,
        "evidence": evidence,
        "framework_result": {
            "engine_used": True,
            "engine_scope": "sample_candidate_pool",
            "task_type": solved.get("task_type"),
            "num_initial_candidates": solved.get("num_initial_candidates"),
            "num_evaluated_candidates": solved.get("num_evaluated_candidates"),
            "answer": solved.get("answer"),
            "answer_key": solved.get("answer_key"),
            "answer_bayes_factor": solved.get("answer_bayes_factor"),
            "answer_mass": solved.get("answer_mass"),
        },
    }
