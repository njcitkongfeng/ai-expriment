from __future__ import annotations
"""LLM verification for table reasoning — TableMaster + Chain-of-Table fusion.

Architecture::
  Claim → CoT semantic parsing → Operation planning → SQL execution → Answer
"""


import json
import re
from typing import Any, Dict, List, Optional, Tuple

from utils.helper import table2string
from utils.execution_verifier import score_execution_with_sql


def _clip(text: Any, max_chars: int = 6000) -> str:
    text = str(text)
    return text if len(text) <= max_chars else text[:max_chars] + "\n...[truncated]"


def _format_tables(sample: Dict[str, Any], max_chars: int = 5000) -> str:
    tables = sample.get("tables") or {}
    if tables:
        blocks = []
        for name, table in tables.items():
            try:
                blocks.append(f"Table {name}:\n{table2string(table)}")
            except Exception:
                blocks.append(f"Table {name}:\n{str(table)[:500]}")
        return _clip("\n\n".join(blocks), max_chars)
    table = sample.get("table_text") or sample.get("table") or []
    try:
        return _clip(table2string(table), max_chars)
    except Exception:
        return _clip(str(table)[:500], max_chars)


def _get_question(sample: Dict[str, Any]) -> str:
    return str(sample.get("question") or sample.get("statement") or sample.get("claim") or "")


def _task_type(sample: Dict[str, Any]) -> str:
    if "label" in sample and sample.get("label") in (0, 1):
        return "fact_verification"
    return "question_answering"


def _candidate_rows(bf_result, original_sample, top_k=3):
    rows = []
    if not bf_result:
        return rows
    ranked = bf_result.get("all_posteriors") or []
    for rank, entry in enumerate(ranked[:top_k], start=1):
        try:
            program_sample, log_post, likelihood, search_score = entry
            enriched = score_execution_with_sql(program_sample, original_sample)
            rows.append({
                "rank": rank, "sql": enriched.get("program"),
                "execution_result": enriched.get("execution_result"),
                "answer": enriched.get("answer"),
                "likelihood": likelihood, "log_posterior": log_post,
                "search_score": search_score,
            })
        except Exception:
            rows.append({"rank": rank, "error": "parse error"})
    return rows


# ══════════════════════════════════════════════════════════════════════
# Main refinement prompt — CoT operation planning
# ══════════════════════════════════════════════════════════════════════

def build_llm_refinement_prompt(
    original_sample, bf_result=None, failure_context=None, top_k=3
):
    """CoT operation planning prompt (TableMaster + Chain-of-Table fusion)."""
    question = _get_question(original_sample)
    candidates = _candidate_rows(bf_result, original_sample, top_k=top_k)

    from utils.cot_planner import build_cot_operation_prompt
    prompt = build_cot_operation_prompt(original_sample, bf_result)
    prompt += f"""

Candidate SQL evidence (from PCFG-BF symbolic executor):
{_clip(json.dumps(candidates, ensure_ascii=False, indent=2), 6000)}
"""
    if failure_context:
        prompt += f"""

Additional context:
{failure_context}
"""
    return prompt


# ══════════════════════════════════════════════════════════════════════
# JSON extraction and normalization
# ══════════════════════════════════════════════════════════════════════

def _extract_json_object(text: str):
    if not text:
        return None
    text = text.strip()
    text = re.sub(r"^```(?:json)?", "", text, flags=re.IGNORECASE).strip()
    text = re.sub(r"```$", "", text).strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except Exception:
            return None
    return None


def _normalize_bool_answer(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        if value == 1: return True
        if value == 0: return False
    if isinstance(value, str):
        v = value.strip().lower()
        if v in ("true", "yes", "supported", "entailed", "1", "t"): return True
        if v in ("false", "no", "refuted", "unsupported", "0", "f"): return False
    return value


# ══════════════════════════════════════════════════════════════════════
# LLM refinement entry point
# ══════════════════════════════════════════════════════════════════════

def llm_refine_answer(
    llm, original_sample, bf_result=None, llm_options=None,
    failure_context=None, top_k=3, debug=False
):
    """Call LLM for refinement and return parsed answer."""
    if llm is None:
        return {"used": False, "error": "No LLM object provided."}

    options = dict(llm_options or {})
    options.setdefault("temperature", 0.0)
    options.setdefault("top_p", 1.0)
    options.setdefault("max_tokens", options.pop("per_example_max_decode_steps", 256))
    options.setdefault("n", options.pop("n_sample", 1))

    prompt = build_llm_refinement_prompt(
        original_sample=original_sample, bf_result=bf_result,
        failure_context=failure_context, top_k=top_k)

    try:
        raw = llm.generate(prompt, options=options)
        parsed = _extract_json_object(raw)
        if not parsed:
            return {"used": True, "success": False,
                    "error": "LLM did not return parseable JSON.",
                    "raw_response": raw, "prompt_chars": len(prompt)}

        answer = parsed.get("answer")
        operations = parsed.get("operations", [])
        is_bool = _task_type(original_sample) == "fact_verification"
        if is_bool:
            answer = _normalize_bool_answer(answer)
        else:
            cand_rank = parsed.get("candidate_rank")
            if cand_rank is not None:
                try:
                    r = int(cand_rank)
                    ranked = (bf_result or {}).get("all_posteriors") or []
                    if 1 <= r <= len(ranked):
                        enriched = score_execution_with_sql(ranked[r - 1][0], original_sample)
                        answer = enriched.get("answer", answer)
                except (ValueError, TypeError):
                    pass

        # ── Execute LLM-planned operations (diagnostic only) ──────
        # Engine execution is deterministic but LLM-planned ops may be
        # semantically wrong.  Record for analysis, never override LLM.
        exec_result = None
        exec_answer = None
        if operations:
            try:
                from utils.cot_planner import _execute_chain_operations, _execute_chain_full
                tables = original_sample.get("tables") or (
                    {"t": original_sample["table_text"]}
                    if original_sample.get("table_text") else {})
                exec_result = _execute_chain_operations(tables, operations)
                exec_answer = _execute_chain_full(tables, operations, is_bool)
            except Exception:
                pass

        try:
            confidence = float(parsed.get("confidence", 0.0))
            confidence = max(0.0, min(1.0, confidence))
        except Exception:
            confidence = 0.0

        return {"used": True, "success": True, "answer": answer,
                "confidence": confidence, "reason": parsed.get("reason", ""),
                "operations": operations,
                "operation_exec_result": exec_result,
                "operation_exec_answer": exec_answer,
                "raw_response": raw, "prompt_chars": len(prompt)}

    except Exception as exc:
        if debug: print(f"[LLM-Refine] failed: {exc}", flush=True)
        return {"used": True, "success": False, "error": str(exc),
                "prompt_chars": len(prompt)}
