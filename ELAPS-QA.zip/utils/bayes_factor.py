"""
Bayes Factor Ranking for Candidate Reasoning Programs.

Computes posterior probabilities p(R | Q, T) for each candidate program using:
  log p(R | Q, T) ∝ log p(Q | R, T) + log p(R | T)
                     = log_likelihood + log_tree_prior

Where log_likelihood comes from real SQLite execution (execution_verifier.py)
and log_tree_prior comes from the PCFG parse tree (pcfg.py v2).

Ranks candidates and computes Bayes Factor between top two.
Uses Jeffreys' (1961) scale for interpretation:
  BF > 100 : Decisive
  BF > 10  : Strong
  BF > 3   : Moderate
  BF < 3   : Weak → triggers targeted refinement
"""

import math
from utils.pcfg import compute_tree_prior


# ============================================================
# Posterior Computation
# ============================================================

def compute_posteriors(candidates_with_likelihood, original_sample):
    """
    Compute unnormalized log-posterior for each candidate program.

    Posterior = execution likelihood × PCFG tree prior

    For each candidate:
      log p(R | Q, T) ∝ log p(Q | R, T) + log p(R | T)

    Args:
        candidates_with_likelihood: list of (program_sample, likelihood, search_score)
        original_sample: original input sample with tables, statement

    Returns:
        list of (program_sample, log_posterior, likelihood, search_score),
        sorted by log_posterior descending
    """
    results = []

    for program_sample, likelihood, search_score in candidates_with_likelihood:
        # Compute PCFG tree prior
        parse_tree = program_sample.get('parse_tree')
        if parse_tree is not None:
            log_prior = compute_tree_prior(parse_tree, original_sample)
        else:
            # Fallback: uniform prior for flat-chain programs without trees
            log_prior = math.log(0.01)

        # ── Semantic prior bonus ──────────────────────────────────
        # Reward programs whose columns/operations/tables match the
        # question, penalise irrelevant-but-executable programs.
        # Scale controlled by env var SEMANTIC_PRIOR_SCALE (default 3.0).
        from utils.pcfg import compute_semantic_prior_bonus
        import os as _os
        _scale = float(_os.environ.get("SEMANTIC_PRIOR_SCALE", "3.0"))
        semantic_bonus = compute_semantic_prior_bonus(
            program_sample, original_sample, log_prior, scale=_scale)
        log_prior = log_prior + semantic_bonus

        log_like = math.log(max(likelihood, 1e-10))
        log_posterior = log_like + log_prior

        results.append((program_sample, log_posterior, likelihood, search_score))

    results.sort(key=lambda x: x[1], reverse=True)
    return results


def normalize_posteriors(ranked_results):
    """
    Softmax-normalize log posteriors to get valid probabilities that sum to 1.
    """
    log_posts = [lp for _, lp, _, _ in ranked_results]
    if not log_posts:
        return []
    max_lp = max(log_posts)
    exp_posts = [math.exp(lp - max_lp) for lp in log_posts]
    total = sum(exp_posts)
    if total == 0:
        return [1.0 / len(exp_posts)] * len(exp_posts)
    return [ep / total for ep in exp_posts]


# ============================================================
# Bayes Factor Computation
# ============================================================

def compute_bayes_factor(ranked_results, original_sample):
    """
    Compute Bayes Factor between top two candidate programs.

    BF = p(R_best | Q, T) / p(R_runner | Q, T)

    On log scale: log BF = log_post_best - log_post_runner

    Args:
        ranked_results: sorted list of (sample, log_post, like, score) tuples
        original_sample: original input sample

    Returns:
        dict with keys: bf_value, interpretation, accept, best_program,
                        runner_up, all_posteriors, all_probs
    """
    if len(ranked_results) < 2:
        return {
            'bf_value': float('inf'),
            'log_bf': float('inf'),
            'interpretation': 'Only one candidate available',
            'accept': True,
            'best_program': ranked_results[0] if ranked_results else None,
            'runner_up': None,
            'all_posteriors': ranked_results,
            'all_probs': normalize_posteriors(ranked_results),
        }

    best_log_post = ranked_results[0][1]
    runner_log_post = ranked_results[1][1]

    log_bf = best_log_post - runner_log_post
    bf_value = math.exp(log_bf)

    interpretation, accept = _interpret_bf(bf_value)

    return {
        'bf_value': bf_value,
        'log_bf': log_bf,
        'interpretation': interpretation,
        'accept': accept,
        'best_program': ranked_results[0],
        'runner_up': ranked_results[1],
        'all_posteriors': ranked_results,
        'all_probs': normalize_posteriors(ranked_results),
    }


def _interpret_bf(bf):
    """Interpret Bayes Factor using Jeffreys' (1961) scale."""
    if bf >= 100:
        return "Decisive evidence for best program", True
    elif bf >= 10:
        return "Strong evidence for best program", True
    elif bf >= 3:
        return "Moderate evidence for best program — accept with caution", True
    elif bf >= 1:
        return "Weak/anecdotal evidence — refinement recommended", False
    else:
        return "Evidence favors runner-up — refinement required", False


# ============================================================
# Combined Ranking Pipeline
# ============================================================

def rank_and_verify(candidates_with_likelihood, original_sample, debug=False):
    """
    Full pipeline: compute posteriors → rank → compute Bayes Factor.

    Args:
        candidates_with_likelihood: list of (sample, likelihood, score) tuples
        original_sample: original input
        debug: verbose output

    Returns:
        Bayes Factor result dict
    """
    ranked = compute_posteriors(candidates_with_likelihood, original_sample)
    bf_result = compute_bayes_factor(ranked, original_sample)

    if debug:
        print(f"\n{'='*50}")
        print(f"[Bayes Factor] BF₁₀ = {bf_result['bf_value']:.2f}")
        print(f"[Bayes Factor]     = exp({bf_result['log_bf']:.2f})")
        print(f"[Bayes Factor] Interpretation: {bf_result['interpretation']}")
        print(f"[Bayes Factor] Accept: {bf_result['accept']}")
        if len(ranked) >= 2:
            print(f"[Bayes Factor] Best posterior:     {ranked[0][1]:.4f}")
            print(f"[Bayes Factor] Runner-up posterior: {ranked[1][1]:.4f}")
            print(f"[Bayes Factor] Best likelihood:     {ranked[0][2]:.4f}")
            print(f"[Bayes Factor] Runner-up likelihood: {ranked[1][2]:.4f}")
        print(f"{'='*50}\n")

    return bf_result


# ============================================================
# Confidence Report
# ============================================================

def get_confidence_report(bf_result):
    """
    Generate a human-readable confidence report from Bayes Factor results.
    """
    best = bf_result.get('best_program')
    if best is None:
        return {'error': 'No valid program', 'needs_refinement': True}

    best_prog, best_post, best_like, _ = best
    bf = bf_result['bf_value']
    interp = bf_result['interpretation']

    report = {
        'bayes_factor': round(bf, 2),
        'interpretation': interp,
        'best_log_posterior': round(best_post, 4),
        'best_likelihood': round(best_like, 4),
        'needs_refinement': not bf_result['accept'],
        'confidence_level': (
            'high' if bf >= 10 else 'medium' if bf >= 3 else 'low'
        ),
    }

    runner = bf_result.get('runner_up')
    if runner:
        _, runner_post, runner_like, _ = runner
        report['runner_up_log_posterior'] = round(runner_post, 4)
        report['runner_up_likelihood'] = round(runner_like, 4)

    return report
