# Copyright 2024 The Chain-of-Table authors
#
# Licensed under the Apache License, Version 2.0

"""
Multi-backend LLM wrapper.

Supported modes
---------------
1) Local HuggingFace Transformers (default for model ids like ``Qwen/Qwen2.5-Coder-14B-Instruct``)
   - Downloads public models from Hugging Face without requiring HF_TOKEN.
   - Needs local GPU/CPU resources.

2) HuggingFace Inference API
   - Set USE_HF_INFERENCE_API=1.
   - HF_TOKEN is optional for some public endpoints but recommended; private/gated models need it.

3) OpenAI-compatible API
   - Set OPENAI_API_BASE / OPENAI_BASE_URL, e.g. local vLLM/Ollama endpoint.
   - OPENAI_API_KEY can be dummy for local endpoints.

4) OpenAI official API
   - Set OPENAI_API_KEY.
"""

import os
import re
import time
import json
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

_PRINTED_ENDPOINT = False

# ─────────────────────────────────────────────────────────────
# LLM usage logger for paper-grade efficiency/cost analysis
# ─────────────────────────────────────────────────────────────
_USAGE_LOCK = threading.Lock()
_USAGE_LOG_PATH = None
_USAGE_SUMMARY = {
    "total_calls": 0,
    "total_latency_sec": 0.0,
    "estimated_prompt_tokens": 0,
    "estimated_completion_tokens": 0,
    "estimated_total_tokens": 0,
    "actual_prompt_tokens": 0,
    "actual_completion_tokens": 0,
    "actual_total_tokens": 0,
    "estimated_cost_usd": 0.0,
    "by_model": {},
    "by_call_type": {},
}


def _usage_cost_rates(model_name: str) -> Tuple[float, float]:
    """Return input/output USD-per-1M-token rates.

    Defaults are zero to avoid silently baking stale vendor prices into paper
    experiments.  Set either global rates:
        LLM_INPUT_COST_PER_1M, LLM_OUTPUT_COST_PER_1M
    or model-specific rates, for example:
        LLM_COST_GPT_4O_MINI_INPUT_PER_1M
        LLM_COST_GPT_4O_MINI_OUTPUT_PER_1M
    where non-alphanumeric characters in model names become underscores.
    """
    safe = re.sub(r"[^A-Za-z0-9]+", "_", str(model_name or "model")).strip("_").upper()
    def _get(name: str, default: float = 0.0) -> float:
        try:
            return float(os.environ.get(name, default) or 0.0)
        except Exception:
            return default
    inp = _get(f"LLM_COST_{safe}_INPUT_PER_1M", _get("LLM_INPUT_COST_PER_1M", 0.0))
    out = _get(f"LLM_COST_{safe}_OUTPUT_PER_1M", _get("LLM_OUTPUT_COST_PER_1M", 0.0))
    return inp, out


def configure_llm_usage_logger(result_dir: Optional[str] = None, enabled: bool = True):
    """Enable JSONL usage logging under result_dir/llm_usage.jsonl."""
    global _USAGE_LOG_PATH, _USAGE_SUMMARY
    with _USAGE_LOCK:
        _USAGE_SUMMARY = {
            "total_calls": 0,
            "total_latency_sec": 0.0,
            "estimated_prompt_tokens": 0,
            "estimated_completion_tokens": 0,
            "estimated_total_tokens": 0,
            "actual_prompt_tokens": 0,
            "actual_completion_tokens": 0,
            "actual_total_tokens": 0,
            "estimated_cost_usd": 0.0,
            "by_model": {},
            "by_call_type": {},
        }
        if enabled and result_dir:
            os.makedirs(result_dir, exist_ok=True)
            _USAGE_LOG_PATH = os.path.join(result_dir, "llm_usage.jsonl")
            try:
                open(_USAGE_LOG_PATH, "w", encoding="utf-8").close()
            except Exception:
                _USAGE_LOG_PATH = None
        else:
            _USAGE_LOG_PATH = None


def _infer_call_type(prompt: str) -> str:
    p = str(prompt or "").lower()
    if "choose the best candidate" in p or "candidate" in p and "execution" in p and "json" in p:
        return "result_selector"
    if "repair" in p and "sql" in p:
        return "sql_repair"
    if "return json" in p and "select" in p and "sql" in p:
        return "sql_generation"
    if "sql" in p:
        return "sql_generation"
    return "llm_call"


def _usage_to_dict(usage: Any) -> Dict[str, int]:
    if usage is None:
        return {}
    if isinstance(usage, dict):
        d = usage
    else:
        try:
            d = usage.model_dump()
        except Exception:
            d = {k: getattr(usage, k) for k in ["prompt_tokens", "completion_tokens", "total_tokens"] if hasattr(usage, k)}
    def _int(*names: str) -> int:
        for name in names:
            try:
                v = d.get(name)
                if v is not None:
                    return int(v)
            except Exception:
                pass
        return 0
    return {
        "prompt_tokens": _int("prompt_tokens", "input_tokens"),
        "completion_tokens": _int("completion_tokens", "output_tokens"),
        "total_tokens": _int("total_tokens"),
    }


def record_llm_usage(model_name: str, prompt: str, options: Optional[Dict[str, Any]], *, backend: str, call_type: Optional[str] = None, latency_sec: float = 0.0, usage: Any = None, success: bool = True, error: Optional[str] = None, n_choices: int = 1):
    options = dict(options or {})
    call_type = call_type or _infer_call_type(prompt)
    est_prompt = max(1, len(prompt or "") // 4)
    est_completion = int(options.get("max_tokens", options.get("per_example_max_decode_steps", 0)) or 0) * max(1, int(options.get("n", 1) or 1))
    est_total = est_prompt + est_completion
    u = _usage_to_dict(usage)
    actual_prompt = int(u.get("prompt_tokens") or 0)
    actual_completion = int(u.get("completion_tokens") or 0)
    actual_total = int(u.get("total_tokens") or (actual_prompt + actual_completion))
    cost_prompt_tokens = actual_prompt or est_prompt
    cost_completion_tokens = actual_completion or est_completion
    in_rate, out_rate = _usage_cost_rates(model_name)
    est_cost = (cost_prompt_tokens * in_rate + cost_completion_tokens * out_rate) / 1_000_000.0
    rec = {
        "ts": time.time(),
        "backend": backend,
        "model": model_name,
        "call_type": call_type,
        "success": bool(success),
        "error": error,
        "latency_sec": float(latency_sec or 0.0),
        "prompt_chars": len(prompt or ""),
        "estimated_prompt_tokens": est_prompt,
        "estimated_completion_tokens": est_completion,
        "estimated_total_tokens": est_total,
        "actual_prompt_tokens": actual_prompt,
        "actual_completion_tokens": actual_completion,
        "actual_total_tokens": actual_total,
        "estimated_cost_usd": est_cost,
        "n_choices": int(n_choices or 1),
    }
    with _USAGE_LOCK:
        _USAGE_SUMMARY["total_calls"] += 1
        _USAGE_SUMMARY["total_latency_sec"] += rec["latency_sec"]
        for k in ["estimated_prompt_tokens", "estimated_completion_tokens", "estimated_total_tokens", "actual_prompt_tokens", "actual_completion_tokens", "actual_total_tokens"]:
            _USAGE_SUMMARY[k] += int(rec[k] or 0)
        _USAGE_SUMMARY["estimated_cost_usd"] += float(est_cost or 0.0)
        for group_key, group_val in [("by_model", model_name), ("by_call_type", call_type)]:
            g = _USAGE_SUMMARY[group_key].setdefault(str(group_val), {"calls": 0, "latency_sec": 0.0, "estimated_total_tokens": 0, "actual_total_tokens": 0, "estimated_cost_usd": 0.0})
            g["calls"] += 1
            g["latency_sec"] += rec["latency_sec"]
            g["estimated_total_tokens"] += rec["estimated_total_tokens"]
            g["actual_total_tokens"] += rec["actual_total_tokens"]
            g["estimated_cost_usd"] += rec["estimated_cost_usd"]
        if _USAGE_LOG_PATH:
            try:
                with open(_USAGE_LOG_PATH, "a", encoding="utf-8") as f:
                    f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
            except Exception:
                pass
    return rec


def get_llm_usage_summary() -> Dict[str, Any]:
    with _USAGE_LOCK:
        return json.loads(json.dumps(_USAGE_SUMMARY, ensure_ascii=False, default=str))


def write_llm_usage_summary(result_dir: str):
    if not result_dir:
        return
    try:
        os.makedirs(result_dir, exist_ok=True)
        with open(os.path.join(result_dir, "llm_usage_summary.json"), "w", encoding="utf-8") as f:
            json.dump(get_llm_usage_summary(), f, ensure_ascii=False, indent=2, default=str)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────
# OpenAI rate-limit guard
# ─────────────────────────────────────────────────────────────
# The OpenAI API may return 429 when the organization exceeds tokens-per-minute
# (TPM). Agent90 sends multi-vote requests, so a single request can be fairly
# token-heavy.  This lightweight process-local limiter spaces requests before
# they are sent and then still performs exponential backoff if the server returns
# 429.  It is intentionally conservative and can be controlled through CLI args
# in run_reasoning_pipeline.py, which set these environment variables:
#   OPENAI_TPM_LIMIT             default: 24000
#   OPENAI_MIN_INTERVAL_SECONDS  default: 0.8
#   OPENAI_MAX_RETRIES           default: 8
#   OPENAI_RETRY_BASE_SECONDS    default: 1.0

_RATE_LOCK = threading.Lock()
_RATE_EVENTS = deque()  # (timestamp, estimated_requested_tokens)
_LAST_OPENAI_CALL_TS = 0.0


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except Exception:
        return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(os.environ.get(name, default)))
    except Exception:
        return default


def _estimate_requested_tokens(prompt: str, options: Optional[Dict[str, Any]]) -> int:
    """Approximate requested tokens for TPM throttling.

    OpenAI's exact accounting is model/tokenizer dependent.  We deliberately use
    a stable approximation to avoid bursts.  The estimate does not need to be
    exact; it only needs to keep the rolling 60s budget below the configured TPM.
    """
    options = options or {}
    max_tokens = int(options.get("max_tokens", options.get("per_example_max_decode_steps", 700)) or 700)
    n = int(options.get("n", options.get("n_sample", 1)) or 1)
    # Empirically, counting every requested completion token for every vote is
    # overly conservative for this code path, while ignoring n is too optimistic.
    prompt_tokens = max(1, len(prompt or "") // 4)
    completion_budget = max_tokens * max(1.0, 0.35 * n)
    return max(256, int(prompt_tokens + completion_budget + 64))


def _preflight_openai_rate_limit(estimated_tokens: int):
    """Block before sending a request if it would exceed the local TPM budget."""
    global _LAST_OPENAI_CALL_TS
    tpm_limit = _env_int("OPENAI_TPM_LIMIT", 24000)
    min_interval = _env_float("OPENAI_MIN_INTERVAL_SECONDS", 0.8)
    # 0 or negative disables local preflight throttling.
    if tpm_limit <= 0 and min_interval <= 0:
        return

    while True:
        now = time.time()
        with _RATE_LOCK:
            while _RATE_EVENTS and now - _RATE_EVENTS[0][0] >= 60.0:
                _RATE_EVENTS.popleft()
            used = sum(tok for _, tok in _RATE_EVENTS)
            interval_wait = max(0.0, min_interval - (now - _LAST_OPENAI_CALL_TS)) if min_interval > 0 else 0.0
            token_wait = 0.0
            if tpm_limit > 0 and used + estimated_tokens > tpm_limit and _RATE_EVENTS:
                token_wait = max(0.0, 60.0 - (now - _RATE_EVENTS[0][0]) + 0.05)
            wait_s = max(interval_wait, token_wait)
            if wait_s <= 0:
                _RATE_EVENTS.append((now, estimated_tokens))
                _LAST_OPENAI_CALL_TS = now
                return
        if wait_s >= 1.0:
            print(f"[LLM-OpenAI] throttling {wait_s:.1f}s to stay within TPM budget", flush=True)
        time.sleep(wait_s)


def _extract_retry_after_seconds(err_text: str) -> Optional[float]:
    text = str(err_text or "")
    # Error messages often contain: "Please try again in 1.566s" or "240ms".
    m = re.search(r"try again in\s+([0-9]*\.?[0-9]+)\s*(ms|s)", text, flags=re.I)
    if not m:
        return None
    val = float(m.group(1))
    unit = m.group(2).lower()
    return val / 1000.0 if unit == "ms" else val


def _is_rate_limit_error(err_text: str) -> bool:
    text = str(err_text or "").lower()
    return (
        "429" in text
        or "402" in text
        or "payment required" in text
        or "rate limit" in text
        or "too many requests" in text
        or "tokens per min" in text
        or "today's quota" in text
        or "exceeded today" in text
        or "quota" in text
        or "monthly included credits" in text
        or "pre-paid credits" in text
        or "depleted your monthly" in text
        or "insufficient_quota" in text
        or "exceeded your current quota" in text
        or "billing" in text and "quota" in text
    )


def _is_auth_or_permission_error(err_text: str) -> bool:
    text = str(err_text or "").lower()
    return (
        "401" in text
        or "403" in text
        or "authenticationerror" in text
        or "invalid api key" in text
        or "incorrect api key" in text
        or "unauthorized" in text
        or "forbidden" in text
        or "permission" in text
    )


def _is_empty_provider_response_error(err_text: str) -> bool:
    text = str(err_text or "").lower()
    return (
        "returned no choices" in text
        or "choices': none" in text
        or '"choices": none' in text
    )


def _is_model_unavailable_error(err_text: str) -> bool:
    text = str(err_text or "").lower()
    return (
        "model not found" in text
        or "model_not_found" in text
    )



def _diagnostic(backend: str, model: str):
    global _PRINTED_ENDPOINT
    if not _PRINTED_ENDPOINT:
        _PRINTED_ENDPOINT = True
        print(f"[LLM] backend  : {backend}", flush=True)
        print(f"[LLM] model    : {model}", flush=True)


def _looks_like_hf_model_id(model_name: str) -> bool:
    return isinstance(model_name, str) and "/" in model_name and not model_name.startswith(("http://", "https://"))


# ══════════════════════════════════════════════════════════════════════
# Backend 1 — Local HuggingFace Transformers
# ══════════════════════════════════════════════════════════════════════

class LocalHFTransformersLLM:
    """Run a HuggingFace causal/instruction model locally.

    Public models can be pulled from Hugging Face without a token.  If the
    model is private/gated, pass ``key`` or set HF_TOKEN/HUGGINGFACE_TOKEN.
    """

    def __init__(self, model_name: str, key: str = None):
        self.model_name = model_name
        self.key = key or os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN") or None

        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as exc:
            raise ImportError(
                "Local HuggingFace mode requires transformers and torch.\n"
                "Install: pip install transformers accelerate torch\n"
                "Or use a vLLM/OpenAI-compatible endpoint with OPENAI_API_BASE."
            ) from exc

        self.torch = torch
        load_path = model_name
        self.processor = None
        model_class = AutoModelForCausalLM
        auto_class = str(os.environ.get("HF_MODEL_AUTO_CLASS", "") or "").strip().lower()
        is_gemma3_multimodal = "gemma-3" in str(model_name).lower() and "1b" not in str(model_name).lower()
        if auto_class in {"image_text_to_text", "image-text-to-text", "vision_text", "gemma3"} or (
            not auto_class and is_gemma3_multimodal
        ):
            try:
                from transformers import AutoModelForImageTextToText, AutoProcessor
                model_class = AutoModelForImageTextToText
                print(f"[LLM-HF] loading processor: {load_path}", flush=True)
                self.processor = AutoProcessor.from_pretrained(
                    load_path,
                    token=self.key,
                    trust_remote_code=True,
                )
                self.tokenizer = getattr(self.processor, "tokenizer", None)
            except Exception as exc:
                if auto_class:
                    raise
                print(f"[LLM-HF] processor load failed; falling back to tokenizer/CausalLM: {exc}", flush=True)
                self.processor = None
                model_class = AutoModelForCausalLM
                self.tokenizer = None
        else:
            self.tokenizer = None

        if self.tokenizer is None:
            print(f"[LLM-HF] loading tokenizer: {load_path}", flush=True)
            self.tokenizer = AutoTokenizer.from_pretrained(
                load_path,
                token=self.key,
                trust_remote_code=True,
            )
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        torch_dtype = os.environ.get("HF_TORCH_DTYPE", "auto")
        kwargs = dict(
            token=self.key,
            trust_remote_code=True,
            device_map=os.environ.get("HF_DEVICE_MAP", "auto"),
            low_cpu_mem_usage=True,
        )
        quantization = str(os.environ.get("HF_QUANTIZATION", "") or "").strip().lower()
        if quantization in {"4bit", "4-bit", "nf4"}:
            try:
                from transformers import BitsAndBytesConfig
            except ImportError as exc:
                raise ImportError("HF_QUANTIZATION=4bit requires bitsandbytes. Install: pip install bitsandbytes") from exc
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type=os.environ.get("HF_BNB_4BIT_QUANT_TYPE", "nf4"),
                bnb_4bit_compute_dtype=getattr(torch, os.environ.get("HF_BNB_4BIT_COMPUTE_DTYPE", "bfloat16")),
                bnb_4bit_use_double_quant=os.environ.get("HF_BNB_4BIT_USE_DOUBLE_QUANT", "1") not in {"0", "false", "False"},
            )
        elif quantization in {"8bit", "8-bit", "int8"}:
            try:
                from transformers import BitsAndBytesConfig
            except ImportError as exc:
                raise ImportError("HF_QUANTIZATION=8bit requires bitsandbytes. Install: pip install bitsandbytes") from exc
            kwargs["quantization_config"] = BitsAndBytesConfig(load_in_8bit=True)
        if torch_dtype != "auto":
            kwargs["torch_dtype"] = getattr(torch, torch_dtype)
        else:
            kwargs["torch_dtype"] = "auto"

        print(
            f"[LLM-HF] loading model: {load_path} "
            f"device_map={kwargs.get('device_map')} dtype={kwargs.get('torch_dtype')} "
            f"quantization={quantization or 'none'}",
            flush=True,
        )
        self.model = model_class.from_pretrained(load_path, **kwargs)
        self.model.eval()
        print(f"[LLM-HF] model ready: {model_name}", flush=True)
        _diagnostic("Local HuggingFace Transformers", model_name)

    @staticmethod
    def _normalize_chat_options(options):
        opts = dict(options or {})
        if "per_example_max_decode_steps" in opts:
            opts.setdefault("max_tokens", opts.pop("per_example_max_decode_steps"))
        if "per_example_top_p" in opts:
            opts.setdefault("top_p", opts.pop("per_example_top_p"))
        if "n_sample" in opts:
            opts.setdefault("n", opts.pop("n_sample"))
        for bad_key in (
            "max_new_tokens", "num_return_sequences", "do_sample",
            "return_dict_in_generate", "output_scores", "pad_token_id",
            "eos_token_id", "repetition_penalty", "use_cache",
        ):
            opts.pop(bad_key, None)
        return {k: v for k, v in opts.items() if v is not None}

    def get_model_options(
        self,
        temperature: float = 0,
        per_example_max_decode_steps: int = 150,
        per_example_top_p: float = 1.0,
        n_sample: int = 1,
    ):
        return dict(
            temperature=temperature,
            n=n_sample,
            top_p=per_example_top_p,
            max_tokens=per_example_max_decode_steps,
        )

    def _build_prompt(self, user_prompt: str) -> str:
        system_text = "Follow the examples and output only the requested answer."
        messages = [
            {"role": "system", "content": system_text},
            {"role": "user", "content": user_prompt},
        ]
        if self.processor is not None and hasattr(self.processor, "apply_chat_template"):
            rich_messages = [
                {"role": "system", "content": [{"type": "text", "text": system_text}]},
                {"role": "user", "content": [{"type": "text", "text": user_prompt}]},
            ]
            try:
                return self.processor.apply_chat_template(
                    rich_messages,
                    tokenize=False,
                    add_generation_prompt=True,
                )
            except Exception:
                pass
        if hasattr(self.tokenizer, "apply_chat_template"):
            try:
                return self.tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True,
                )
            except Exception:
                pass
        return messages[0]["content"] + "\n\n" + messages[1]["content"]

    def generate_plus_with_score(self, prompt, options=None, end_str=None):
        if options is None:
            options = self.get_model_options()
        options = dict(options)
        n_samples = int(options.get("n", 1) or 1)
        max_new_tokens = int(options.get("max_tokens", options.get("per_example_max_decode_steps", 150)) or 150)
        env_cap = os.environ.get("LOCAL_HF_MAX_NEW_TOKENS")
        if env_cap:
            try:
                max_new_tokens = min(max_new_tokens, max(1, int(env_cap)))
            except Exception:
                pass
        temperature = float(options.get("temperature", 0) or 0)
        top_p = float(options.get("top_p", 1.0) or 1.0)

        text_prompt = self._build_prompt(prompt)
        inputs = self.tokenizer(text_prompt, return_tensors="pt")
        device = next(self.model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        if os.environ.get("LOCAL_HF_LOG_PROMPT_TOKENS", "0") in {"1", "true", "True"}:
            print(
                f"[LLM-HF] prompt_tokens={inputs['input_ids'].shape[-1]} "
                f"max_new_tokens={max_new_tokens} n={n_samples}",
                flush=True,
            )

        do_sample = temperature > 1e-8
        gen_kwargs = dict(
            max_new_tokens=max_new_tokens,
            do_sample=do_sample,
            num_return_sequences=n_samples,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
        )
        if do_sample:
            gen_kwargs.update(temperature=temperature, top_p=top_p)

        with self.torch.no_grad():
            outputs = self.model.generate(**inputs, **gen_kwargs)

        prompt_len = inputs["input_ids"].shape[-1]
        results = []
        for i, out in enumerate(outputs):
            generated = self.tokenizer.decode(out[prompt_len:], skip_special_tokens=True).strip()
            if end_str and isinstance(end_str, str) and end_str in generated:
                generated = generated.split(end_str, 1)[0]
            fake_conf = (len(outputs) - i) / max(len(outputs), 1)
            results.append((generated, np.log(fake_conf)))
        return results

    def generate(self, prompt, options=None, end_str=None):
        if options is None:
            options = self.get_model_options()
        options = self._normalize_chat_options(options)
        options["n"] = 1
        return self.generate_plus_with_score(prompt, options, end_str)[0][0]

    def score_bool_logprob(self, prompt):
        """Score TRUE vs FALSE via token logprobs at the last position.

        Returns (answer, margin) where answer is True/False and margin
        is the logprob difference.  Higher margin = more confident.
        """
        text_prompt = self._build_prompt(prompt)
        # Append answer prefix to get model into "answering" state
        text_prompt += "\nAnswer:"

        inputs = self.tokenizer(text_prompt, return_tensors="pt")
        device = next(self.model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}

        # Get token IDs for " TRUE" and " FALSE" (with leading space)
        true_ids = self.tokenizer.encode(" TRUE", add_special_tokens=False)
        false_ids = self.tokenizer.encode(" FALSE", add_special_tokens=False)

        with self.torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits[0, -1, :]  # last token position

        # Log-softmax
        log_probs = self.torch.nn.functional.log_softmax(logits.float(), dim=-1)

        true_logprob = float(log_probs[true_ids[0]].cpu())
        false_logprob = float(log_probs[false_ids[0]].cpu())

        margin = abs(true_logprob - false_logprob)
        answer = True if true_logprob > false_logprob else False

        return answer, margin, {"true_logprob": true_logprob, "false_logprob": false_logprob}


# ══════════════════════════════════════════════════════════════════════
# Backend 2 — HuggingFace Inference API
# ══════════════════════════════════════════════════════════════════════

class HuggingFaceLLM:
    """Calls HuggingFace serverless Inference API via huggingface_hub.

    HF_TOKEN is optional here.  Public endpoints may work anonymously, while
    gated/private models and some provider routes require a token.
    """

    def __init__(self, model_name: str, key: str = None):
        self.model_name = model_name
        self.key = key or os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN") or None
        try:
            from huggingface_hub import InferenceClient
        except ImportError as exc:
            raise ImportError("huggingface_hub is required. Install: pip install huggingface_hub") from exc
        self._client = InferenceClient(model=model_name, token=self.key)
        _diagnostic("HuggingFace Inference API", model_name)

    def _message_text(self, msg):
        """Return usable text from OpenAI-compatible message objects.

        Some reasoning endpoints expose the final answer in ``content`` and
        intermediate thinking in ``reasoning_content``.  Some non-standard
        endpoints may return an empty content field.  Agent90 parsers can only
        work with a string, so fall back safely when needed.
        """
        content = getattr(msg, "content", None)
        if content is None and isinstance(msg, dict):
            content = msg.get("content")
        reasoning = getattr(msg, "reasoning_content", None)
        if reasoning is None and isinstance(msg, dict):
            reasoning = msg.get("reasoning_content")
        if content is not None and str(content).strip():
            return str(content)
        if reasoning is not None and str(reasoning).strip():
            return str(reasoning)
        return ""

    def get_model_options(self, temperature=0, per_example_max_decode_steps=150, per_example_top_p=1.0, n_sample=1):
        return dict(temperature=temperature, n=n_sample, top_p=per_example_top_p, max_tokens=per_example_max_decode_steps)

    @staticmethod
    def _normalize_chat_options(options):
        opts = dict(options or {})
        if "per_example_max_decode_steps" in opts:
            opts.setdefault("max_tokens", opts.pop("per_example_max_decode_steps"))
        if "per_example_top_p" in opts:
            opts.setdefault("top_p", opts.pop("per_example_top_p"))
        if "n_sample" in opts:
            opts.setdefault("n", opts.pop("n_sample"))
        for bad_key in (
            "max_new_tokens", "num_return_sequences", "do_sample",
            "return_dict_in_generate", "output_scores", "pad_token_id",
            "eos_token_id", "repetition_penalty", "use_cache",
        ):
            opts.pop(bad_key, None)
        return {k: v for k, v in opts.items() if v is not None}

    def generate_plus_with_score(self, prompt, options=None, end_str=None):
        if options is None:
            options = self.get_model_options()
        options = self._normalize_chat_options(options)
        messages = [
            {"role": "system", "content": "Follow the examples and output only the requested answer."},
            {"role": "user", "content": prompt},
        ]
        n_samples = int(options.get("n", 1) or 1)
        call_options = dict(options)
        call_options.pop("n", None)
        call_options.pop("n_sample", None)
        if end_str:
            call_options["stop"] = [end_str] if isinstance(end_str, str) else list(end_str)

        all_results = []
        for sample_idx in range(n_samples):
            response = None
            last_error = None
            for retry_num in range(4):
                try:
                    response = self._client.chat_completion(messages=messages, **call_options)
                    break
                except Exception as e:
                    last_error = str(e)
                    print(f"[LLM-HF] attempt {retry_num + 1} failed: {last_error}", flush=True)
                    if _is_auth_or_permission_error(last_error):
                        raise RuntimeError(
                            "HuggingFace Inference API authentication/permission failed; "
                            "verify HF_TOKEN and model access. Original error: " + last_error
                        )
                    if _is_rate_limit_error(last_error):
                        raise RuntimeError(
                            "HuggingFace Inference API quota/payment/rate limit hit; stopping safely "
                            "without caching placeholder outputs. Add credits/PRO, use another token, "
                            "or switch to --backend local_hf. Original error: " + last_error
                        )
                    if _is_model_unavailable_error(last_error):
                        raise RuntimeError(
                            "HuggingFace Inference API reports that the selected model is unavailable. "
                            "Try another model id. Original error: " + last_error
                        )
                    if "loading" in last_error.lower():
                        time.sleep(30)
                    elif "429" in last_error or "rate limit" in last_error.lower():
                        time.sleep(20)
                    else:
                        time.sleep(8)
            if response is None:
                raise RuntimeError(
                    "HuggingFace Inference API call failed after retries; stopping safely. "
                    "Last error: " + str(last_error)
                )
            choices = getattr(response, "choices", []) or []
            if not choices:
                raise RuntimeError("HuggingFace Inference API returned no choices.")
            for i, choice in enumerate(choices):
                text = choice.message.content
                fake_conf = (len(choices) - i) / max(len(choices), 1)
                all_results.append((text, np.log(fake_conf)))
        return all_results or [("PLACEHOLDER", np.log(1e-6))]

    def generate(self, prompt, options=None, end_str=None):
        if options is None:
            options = self.get_model_options()
        options = self._normalize_chat_options(options)
        options["n"] = 1
        return self.generate_plus_with_score(prompt, options, end_str)[0][0]


# ══════════════════════════════════════════════════════════════════════
# Backend 3 — OpenAI-compatible API
# ══════════════════════════════════════════════════════════════════════

class ChatGPT:
    """Thin wrapper around OpenAI ChatCompletion API v0.28.x-compatible calls."""

    def __init__(self, model_name: str, key: str = None):
        import openai
        self.model_name = model_name
        self.key = key or os.environ.get("OPENAI_API_KEY", "vllm")
        api_base = os.environ.get("OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL")
        self.api_base = api_base or "https://api.openai.com/v1"
        api_base_l = str(self.api_base).lower()
        model_l = str(self.model_name).lower()
        self._force_n1 = (
            "deepseek" in model_l
            or "deepseek" in api_base_l
        )
        self._supports_deepseek_thinking_control = ("deepseek" in model_l) or ("deepseek" in api_base_l)
        # DeepSeek V4 may use thinking-mode responses.  For Agent90 we want the
        # final JSON answer, not hidden reasoning.  By default we request non-thinking
        # mode; if the endpoint rejects the field, the call is retried without it.
        self._deepseek_disable_thinking = os.environ.get("DEEPSEEK_DISABLE_THINKING", "1") not in {"0", "false", "False"}

        # Support both old (<1.0) and new (>=1.0) OpenAI SDKs
        if hasattr(openai, "OpenAI"):
            request_timeout = _env_float("OPENAI_REQUEST_TIMEOUT", 120.0)
            sdk_retries = _env_int("OPENAI_SDK_MAX_RETRIES", 0)
            self._client = openai.OpenAI(
                api_key=self.key,
                base_url=self.api_base,
                timeout=request_timeout,
                max_retries=max(0, sdk_retries),
            )
            self._new_api = True
        else:
            if api_base:
                openai.api_base = api_base
            self._new_api = False

        _diagnostic(f"OpenAI ({api_base or 'default'})", model_name)

    def _message_text(self, msg):
        """Return usable text from OpenAI-compatible message objects.

        Some reasoning endpoints expose the final answer in ``content`` and
        intermediate thinking in ``reasoning_content``.  Some non-standard
        endpoints may return an empty content field.  Agent90 parsers can only
        work with a string, so fall back safely when needed.
        """
        content = getattr(msg, "content", None)
        if content is None and isinstance(msg, dict):
            content = msg.get("content")
        reasoning = getattr(msg, "reasoning_content", None)
        if reasoning is None and isinstance(msg, dict):
            reasoning = msg.get("reasoning_content")
        if content is not None and str(content).strip():
            return str(content)
        if reasoning is not None and str(reasoning).strip():
            return str(reasoning)
        return ""

    def get_model_options(self, temperature=0, per_example_max_decode_steps=150, per_example_top_p=1.0, n_sample=1):
        return dict(temperature=temperature, n=n_sample, top_p=per_example_top_p, max_tokens=per_example_max_decode_steps)

    @staticmethod
    def _normalize_chat_options(options):
        """Normalize legacy project options before calling OpenAI-compatible APIs.

        Older Chain-of-Table code uses HuggingFace/vLLM-style names such as
        ``per_example_max_decode_steps`` and ``per_example_top_p``.  The OpenAI
        Python SDK and DeepSeek's OpenAI-compatible endpoint reject those keys if
        they are forwarded directly.  Keep the old names available inside the
        project, but translate/drop them at the API boundary.
        """
        opts = dict(options or {})
        if "per_example_max_decode_steps" in opts:
            opts.setdefault("max_tokens", opts.pop("per_example_max_decode_steps"))
        if "per_example_top_p" in opts:
            opts.setdefault("top_p", opts.pop("per_example_top_p"))
        if "n_sample" in opts:
            opts.setdefault("n", opts.pop("n_sample"))
        # Some local/HF generation options occasionally leak into shared code.
        # They are harmless for local backends but invalid for OpenAI-compatible APIs.
        for bad_key in (
            "max_new_tokens", "num_return_sequences", "do_sample",
            "return_dict_in_generate", "output_scores", "pad_token_id",
            "eos_token_id", "repetition_penalty", "use_cache",
        ):
            opts.pop(bad_key, None)
        opts = {k: v for k, v in opts.items() if v is not None}
        return opts

    def generate_plus_with_score(self, prompt, options=None, end_str=None):
        if options is None:
            options = self.get_model_options()
        options = self._normalize_chat_options(options)

        # DeepSeek's OpenAI-compatible API currently accepts only n=1.
        # Agent90 uses n=votes on OpenAI to get multiple samples in one request.
        # For DeepSeek-compatible endpoints we emulate n>1 by sending n separate
        # requests with n=1, preserving Agent90's multi-vote semantics.
        try:
            requested_n = int(options.get("n", 1) or 1)
        except Exception:
            requested_n = 1
        if self._force_n1 and requested_n > 1:
            # DeepSeek-compatible endpoints only accept n=1.  To keep Agent90
            # self-consistency semantics, emulate n>1 by issuing several n=1
            # requests.  v20 did this serially, which made deepseek-v4-pro very
            # slow.  v21 supports bounded parallel votes.  Set
            # DEEPSEEK_PARALLEL_VOTES=1 to force serial behavior, or pass
            # --deepseek_parallel_votes in run_reasoning_pipeline.py.
            one_options = dict(options)
            one_options["n"] = 1
            try:
                max_workers = int(os.environ.get("DEEPSEEK_PARALLEL_VOTES", "3") or "3")
            except Exception:
                max_workers = 3
            max_workers = max(1, min(max_workers, requested_n))

            def _one_vote(vote_idx: int):
                return vote_idx, self.generate_plus_with_score(prompt, options=one_options, end_str=end_str)

            merged = []
            if max_workers == 1:
                for vote_idx in range(requested_n):
                    try:
                        _, one = _one_vote(vote_idx)
                        merged.extend(one)
                    except Exception as exc:
                        if _is_rate_limit_error(str(exc)):
                            raise
                        print(f"[LLM-OpenAI] DeepSeek vote {vote_idx + 1}/{requested_n} failed: {exc}", flush=True)
            else:
                with ThreadPoolExecutor(max_workers=max_workers) as ex:
                    futs = [ex.submit(_one_vote, i) for i in range(requested_n)]
                    for fut in as_completed(futs):
                        try:
                            _, one = fut.result()
                            merged.extend(one)
                        except Exception as exc:
                            if _is_rate_limit_error(str(exc)):
                                raise
                            print(f"[LLM-OpenAI] DeepSeek parallel vote failed: {exc}", flush=True)
            if not merged:
                raise RuntimeError("All DeepSeek n=1 vote calls failed; no valid response returned.")
            return merged[:requested_n]

        messages = [
            {"role": "system", "content": "Follow the examples and output only the requested answer."},
            {"role": "user", "content": prompt},
        ]
        response = None
        last_error = None
        estimated_tokens = _estimate_requested_tokens(prompt, options)
        max_retries = max(1, _env_int("OPENAI_MAX_RETRIES", 8))
        retry_base = max(0.1, _env_float("OPENAI_RETRY_BASE_SECONDS", 1.0))
        for retry_num in range(max_retries):
            try:
                _preflight_openai_rate_limit(estimated_tokens)
                if self._new_api:
                    call_options = dict(options)
                    if self._supports_deepseek_thinking_control and self._deepseek_disable_thinking:
                        eb = dict(call_options.get("extra_body") or {})
                        eb.setdefault("thinking", {"type": "disabled"})
                        call_options["extra_body"] = eb
                    try:
                        _call_start = time.time()
                        request_kwargs = dict(call_options)
                        if end_str is not None:
                            request_kwargs["stop"] = end_str
                        _response_obj = self._client.chat.completions.create(
                            model=self.model_name, messages=messages, **request_kwargs)
                        _call_latency = time.time() - _call_start
                    except Exception as inner_exc:
                        # Some OpenAI-compatible servers reject extra_body.  Retry once
                        # without the thinking-control field before falling back to the
                        # outer retry loop.
                        if self._force_n1 and "extra_body" in call_options:
                            call_options.pop("extra_body", None)
                            _call_start = time.time()
                            request_kwargs = dict(call_options)
                            if end_str is not None:
                                request_kwargs["stop"] = end_str
                            _response_obj = self._client.chat.completions.create(
                                model=self.model_name, messages=messages, **request_kwargs)
                            _call_latency = time.time() - _call_start
                        else:
                            raise inner_exc
                    # Convert to old-style dict for compatibility.  Use _message_text
                    # so empty content from reasoning APIs does not become a blank vote.
                    _usage_obj = getattr(_response_obj, "usage", None)
                    choices = getattr(_response_obj, "choices", None)
                    if not choices:
                        try:
                            raw_response = _response_obj.model_dump()
                        except Exception:
                            raw_response = str(_response_obj)
                        raise RuntimeError(f"OpenAI-compatible endpoint returned no choices: {raw_response}")
                    response = {
                        "choices": [{"message": {"content": self._message_text(c.message)}}
                                    for c in choices]
                    }
                    record_llm_usage(self.model_name, prompt, options, backend="openai", latency_sec=_call_latency, usage=_usage_obj, success=True, n_choices=len(response.get("choices", [])))
                else:
                    import openai
                    _call_start = time.time()
                    request_kwargs = dict(options)
                    if end_str is not None:
                        request_kwargs["stop"] = end_str
                    response = openai.ChatCompletion.create(
                        model=self.model_name, messages=messages,
                        api_key=self.key, **request_kwargs)
                    _call_latency = time.time() - _call_start
                    record_llm_usage(self.model_name, prompt, options, backend="openai_legacy", latency_sec=_call_latency, usage=(response.get("usage") if isinstance(response, dict) else None), success=True, n_choices=len(response.get("choices", [])) if isinstance(response, dict) else 1)
                break
            except Exception as e:
                last_error = str(e)
                lower_error = last_error.lower()
                if _is_auth_or_permission_error(last_error):
                    raise RuntimeError(
                        "OpenAI-compatible endpoint authentication/permission failed; stopping immediately. "
                        "Verify the API key, endpoint permissions, and account access before rerunning. "
                        "Original error: " + last_error
                    )
                if _is_empty_provider_response_error(last_error):
                    raise RuntimeError(
                        "OpenAI-compatible endpoint returned an empty response; stopping immediately. "
                        "This usually means the selected model/endpoint returned no generation. "
                        "Try another model id or endpoint before the full dataset. Original error: " + last_error
                    )
                if _is_model_unavailable_error(last_error):
                    raise RuntimeError(
                        "OpenAI-compatible endpoint reports that the selected model is unavailable; "
                        "stopping immediately. Try another model id or endpoint. Original error: " + last_error
                    )
                if _is_rate_limit_error(last_error):
                    # v19: fail fast on quota / rate-limit errors. Returning
                    # PLACEHOLDER corrupts evaluation; long sleeps can hang full runs.
                    raise RuntimeError(
                        "OpenAI quota/rate limit hit; stopping safely without caching an invalid result. "
                        "Wait for quota recovery, reduce votes/table chars, switch to gpt-4o-mini, "
                        "or rerun later to resume from cached completed cases. Original error: " + last_error
                    )
                if any(kw in lower_error for kw in ["maximum context length", "context length", "too long", "4003"]):
                    print(f"[LLM-OpenAI] context too long; returning PLACEHOLDER: {last_error}", flush=True)
                    response = {"choices": [{"message": {"content": "PLACEHOLDER"}}]}
                    break
                print(f"[LLM-OpenAI] attempt {retry_num + 1} failed: {last_error}", flush=True)
                time.sleep(min(30.0, retry_base * (2 ** retry_num)))
        if response is None:
            raise RuntimeError(
                "OpenAI call failed after retries; stopping safely without returning PLACEHOLDER. "
                "Last error: " + str(last_error)
            )
        results = []
        for i, res in enumerate(response["choices"]):
            text = res["message"]["content"]
            fake_conf = (len(response["choices"]) - i) / max(len(response["choices"]), 1)
            results.append((text, np.log(fake_conf)))
        return results

    def generate(self, prompt, options=None, end_str=None):
        if options is None:
            options = self.get_model_options()
        options = self._normalize_chat_options(options)
        options["n"] = 1
        return self.generate_plus_with_score(prompt, options, end_str)[0][0]


# ══════════════════════════════════════════════════════════════════════
# Factory
# ══════════════════════════════════════════════════════════════════════

def create_llm(model_name: str, key: str = None, backend: str = None):
    """Create an LLM backend.

    backend can be: ``local_hf``, ``hf_api``, ``openai`` or ``auto``.
    In auto mode, a HuggingFace model id such as ``Qwen/Qwen2.5-Coder-14B-Instruct``
    is loaded locally with transformers, so public models do not require a token.
    """
    backend = (backend or os.environ.get("LLM_BACKEND") or "auto").lower()
    # Many old runners pass the dummy local-vLLM key "vllm".  Do not forward
    # that value as a HuggingFace token.
    hf_key = None if key in (None, "", "vllm", "dummy") else key

    if backend in {"hf_api", "huggingface_api", "hf_inference"} or os.environ.get("USE_HF_INFERENCE_API") == "1":
        return HuggingFaceLLM(model_name, hf_key)
    if backend in {"local_hf", "transformers", "hf_local"}:
        return LocalHFTransformersLLM(model_name, hf_key)
    if backend in {"openai", "openai_compatible", "vllm", "ollama"}:
        return ChatGPT(model_name, key)

    # auto
    if _looks_like_hf_model_id(model_name) and not (os.environ.get("OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL")):
        return LocalHFTransformersLLM(model_name, hf_key)
    return ChatGPT(model_name, key)
