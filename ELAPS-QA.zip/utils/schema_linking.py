from __future__ import annotations
"""
Schema Linking + Join Path Discovery — zero LLM cost.
======================================================

For cross-table reasoning, maps natural-language question tokens to
specific table columns (schema linking) and discovers join paths
between tables (foreign-key inference via naming conventions and
value overlap).

Used as a preprocessing step before PCFG candidate generation.
"""


import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple


# ══════════════════════════════════════════════════════════════════════
# Schema Linking
# ══════════════════════════════════════════════════════════════════════

def link_schema(
    question: str,
    tables: Dict[str, List[List[Any]]],
    max_per_table: int = 4,
) -> Dict[str, List[Dict[str, Any]]]:
    """Map question tokens to table columns.

    Returns dict: {table_name: [{column, score, reason}, ...]}
    Only columns with score > 0 are returned, up to max_per_table.
    """
    ql = question.lower()
    q_tokens = set(re.findall(r"[a-zA-Z0-9]+", ql))
    q_numbers = set(re.findall(r"\d+", ql))
    results: Dict[str, List[Dict[str, Any]]] = {}

    for tn, table in tables.items():
        if not isinstance(table, list) or len(table) < 2:
            continue
        headers = [str(h) for h in table[0]]
        rows = table[1:]
        cols: List[Dict[str, Any]] = []

        for ci, h in enumerate(headers):
            hl = h.lower()
            h_tokens = set(re.findall(r"[a-zA-Z0-9]+", hl))
            score = 0.0
            reasons: List[str] = []

            # 1) Column name matches question tokens
            overlap = len(h_tokens & q_tokens)
            if overlap > 0:
                score += overlap * 0.30
                reasons.append(f"name overlap: {h_tokens & q_tokens}")

            # 2) Column name is substring of question
            if hl in ql:
                score += 0.50
                reasons.append(f"name in question")

            # 3) Column values match question entities
            matched_values = 0
            for row in rows:
                if ci >= len(row):
                    continue
                cell = str(row[ci]).strip().lower()
                if len(cell) >= 2 and cell in ql:
                    matched_values += 1
            if matched_values > 0:
                score += min(matched_values * 0.15, 0.60)
                reasons.append(f"{matched_values} value matches")

            # 4) Column values are numbers mentioned in question
            num_matches = 0
            for row in rows:
                if ci >= len(row):
                    continue
                cell = str(row[ci]).strip()
                if cell in q_numbers:
                    num_matches += 1
            if num_matches > 0:
                score += min(num_matches * 0.10, 0.30)
                reasons.append(f"{num_matches} number matches")

            # 5) Column is numeric and question asks for computation
            if any(w in ql for w in ["count", "sum", "average", "total",
                                       "highest", "lowest", "most", "how many"]):
                vals = [str(r[ci]).strip() for r in rows if ci < len(r)
                        and str(r[ci]).strip()]
                numeric = sum(1 for v in vals
                              if v.replace(".", "").replace("-", "").isdigit())
                if len(vals) > 0 and numeric / len(vals) >= 0.5:
                    score += 0.25
                    reasons.append("numeric for computation")

            # 6) Column is name/identifier and question asks "which/who"
            if any(w in ql for w in ["which", "who", "what", "name"]):
                id_keywords = ["name", "title", "id", "code", "player",
                               "team", "country", "city", "student", "course"]
                if any(kw in hl for kw in id_keywords):
                    score += 0.20
                    reasons.append("identifier for entity question")

            if score > 0:
                cols.append({"column": h, "score": round(score, 2),
                             "reasons": reasons})

        cols.sort(key=lambda x: x["score"], reverse=True)
        results[tn] = cols[:max_per_table]

    return results


# ══════════════════════════════════════════════════════════════════════
# Foreign-Key Inference
# ══════════════════════════════════════════════════════════════════════

def _infer_foreign_keys(
    tables: Dict[str, List[List[Any]]],
) -> List[Tuple[str, str, str, str, float]]:
    """Infer foreign keys via naming conventions and value overlap.

    Returns list of (from_table, from_col, to_table, to_col, confidence).
    """
    fks: List[Tuple[str, str, str, str, float]] = []
    tnames = list(tables.keys())

    for i, ta in enumerate(tnames):
        A = tables.get(ta)
        if not isinstance(A, list) or len(A) < 2:
            continue
        a_headers = [str(h).lower() for h in A[0]]
        a_rows = A[1:]

        for j, tb in enumerate(tnames):
            if i == j:
                continue
            B = tables.get(tb)
            if not isinstance(B, list) or len(B) < 2:
                continue
            b_headers = [str(h).lower() for h in B[0]]
            b_rows = B[1:]

            for ai, ah in enumerate(a_headers):
                for bi, bh in enumerate(b_headers):
                    conf = 0.0

                    # Naming convention — priority order by confidence
                    if ah == f"{tb}_id" or ah == f"{tb} id":
                        conf = 0.95  # perfect FK pattern: table_id
                    elif bh == f"{ta}_id" or bh == f"{ta} id":
                        conf = 0.95
                    elif ah == bh and "id" in ah:
                        conf = 0.90  # same column name with "id"
                    elif ah == bh:
                        conf = 0.80  # same column name
                    elif f"{tb}" in ah and "id" in ah:
                        conf = 0.70
                    elif f"{ta}" in bh and "id" in bh:
                        conf = 0.70
                    elif ah.endswith("_id") and bh == "id":
                        conf = 0.65
                    elif bh.endswith("_id") and ah == "id":
                        conf = 0.65

                    # Value overlap
                    if conf < 0.60:
                        a_vals = set()
                        for r in a_rows:
                            if ai < len(r):
                                v = str(r[ai]).strip().lower()
                                if v and v != "none":
                                    a_vals.add(v)
                        b_vals = set()
                        for r in b_rows:
                            if bi < len(r):
                                v = str(r[bi]).strip().lower()
                                if v and v != "none":
                                    b_vals.add(v)
                        if a_vals and b_vals:
                            overlap = len(a_vals & b_vals)
                            ratio = overlap / min(len(a_vals), len(b_vals))
                            if ratio >= 0.5:
                                conf = max(conf, ratio * 0.80)

                    if conf >= 0.50:
                        fks.append((ta, A[0][ai], tb, B[0][bi],
                                     round(conf, 2)))

    fks.sort(key=lambda x: x[4], reverse=True)
    return fks


# ══════════════════════════════════════════════════════════════════════
# Join Path Discovery
# ══════════════════════════════════════════════════════════════════════

def discover_join_paths(
    question: str,
    tables: Dict[str, List[List[Any]]],
) -> List[Dict[str, Any]]:
    """Find join paths connecting tables relevant to the question.

    Returns list of join paths, each with: tables, joins, confidence.
    """
    # 1) Schema link to find relevant tables
    linked = link_schema(question, tables)
    relevant_tables = [tn for tn in linked if linked[tn]]

    # 2) Infer foreign keys
    fks = _infer_foreign_keys(tables)

    # 3) Build adjacency graph
    graph: Dict[str, List[Tuple[str, str, str, str, float]]] = defaultdict(list)
    for ta, ac, tb, bc, conf in fks:
        graph[ta].append((tb, ac, bc, conf))
        graph[tb].append((ta, bc, ac, conf))

    # 4) If only one relevant table, no join needed
    if len(relevant_tables) <= 1:
        return [{"tables": relevant_tables or list(tables.keys())[:1],
                 "joins": [], "confidence": 1.0}]

    # 5) Find shortest paths between relevant tables using BFS
    paths: List[Dict[str, Any]] = []
    visited_paths: Set[Tuple] = set()

    for i, ta in enumerate(relevant_tables):
        for j, tb in enumerate(relevant_tables):
            if i >= j:
                continue
            if ta not in graph or tb not in graph:
                continue

            # BFS
            from collections import deque
            queue = deque([(ta, [ta], [], [])])  # (current, table_path, col_path, edges)
            seen = {ta}
            while queue:
                curr, tpath, cpath, edges = queue.popleft()
                if curr == tb and len(tpath) > 1:
                    path_key = tuple(tpath)
                    if path_key not in visited_paths:
                        visited_paths.add(path_key)
                        paths.append({
                            "tables": tpath,
                            "joins": edges,
                            "confidence": round(
                                sum(e[4] for e in edges) / max(len(edges), 1), 2
                            ),
                        })
                    break  # shortest path found
                for next_t, fc, tc, conf in graph[curr]:
                    if next_t not in seen:
                        seen.add(next_t)
                        queue.append((
                            next_t,
                            tpath + [next_t],
                            cpath + [fc],
                            edges + [(curr, fc, next_t, tc, conf)],
                        ))

    if not paths:
        # No join path found — use all tables independently
        return [{"tables": list(tables.keys()),
                 "joins": [], "confidence": 0.0}]

    paths.sort(key=lambda x: x["confidence"], reverse=True)
    return paths[:3]


# ══════════════════════════════════════════════════════════════════════
# Cross-Table Evidence Construction
# ══════════════════════════════════════════════════════════════════════

def build_cross_table_evidence(
    question: str,
    tables: Dict[str, List[List[Any]]],
    max_rows_per_table: int = 10,
) -> Dict[str, Any]:
    """Full pipeline: schema link → join path → cross-table evidence.

    Returns dict with keys:
      schema_links, join_paths, evidence_tables, verbalization
    """
    # Step 1: Schema linking
    schema_links = link_schema(question, tables)

    # Step 2: Join path discovery
    join_paths = discover_join_paths(question, tables)
    best_path = join_paths[0] if join_paths else {"tables": list(tables.keys()), "joins": []}

    # Step 3: Cross-table evidence — rows matching question entities
    evidence: Dict[str, List[List[Any]]] = {}
    ql = question.lower()

    for tn in best_path["tables"]:
        table = tables.get(tn)
        if not isinstance(table, list) or len(table) < 2:
            continue
        header = table[0]
        # Find rows with value matches
        matched = set()
        for ri, row in enumerate(table[1:], start=1):
            for cell in row:
                cs = str(cell).strip()
                if len(cs) >= 2 and cs.lower() in ql:
                    matched.add(ri)
                    break
        if matched:
            sr = sorted(matched)
            evidence[tn] = [header] + [table[ri] for ri in sr[:max_rows_per_table]]
        else:
            # Keep header + first few rows as context
            evidence[tn] = [header] + table[1:max_rows_per_table]

    # Step 4: Verbalization
    verbalization = _verbalize_schema(tables, best_path, schema_links)

    return {
        "schema_links": schema_links,
        "join_paths": join_paths,
        "evidence_tables": evidence,
        "verbalization": verbalization,
    }


def _verbalize_schema(
    tables: Dict[str, List[List[Any]]],
    join_path: Dict[str, Any],
    schema_links: Dict[str, List[Dict[str, Any]]],
) -> str:
    """Generate a natural-language description of table schemas and joins."""
    lines = []

    for tn in join_path.get("tables", list(tables.keys())):
        table = tables.get(tn)
        if not isinstance(table, list) or len(table) < 2:
            continue
        header = table[0]
        linked_cols = schema_links.get(tn, [])
        linked_names = {c["column"] for c in linked_cols if c["score"] > 0.3}

        # Describe the table
        relevant = [h for h in header if h in linked_names]
        desc = f"Table {tn}: columns {header}. "
        if relevant:
            desc += f"Question-relevant columns: {relevant}."
        lines.append(desc)

    # Describe joins
    for join in join_path.get("joins", []):
        ta, ac, tb, tc = join[0], join[1], join[2], join[3]
        lines.append(
            f"Join: {ta}.{ac} = {tb}.{tc} "
            f"(rows in {ta} link to {tb} through these columns)"
        )

    return "\n".join(lines)
