from __future__ import annotations
"""Failure-case analysis utilities for StructQA and TabFact experiments."""


import json
import os
from collections import Counter, defaultdict
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

from utils.evaluate import tabfact_match_from_pcfg_result
from utils.execution_verifier import _compare_answer


def _safe_get(report: Optional[Dict[str, Any]], key: str, default: Any = None) -> Any:
    return report.get(key, default) if isinstance(report, dict) else default


def _structqa_correct(sample: Dict[str, Any]) -> bool:
    gold = sample.get("original_answer")
    if gold is None:
        gold = sample.get("gold_answer", sample.get("answers", sample.get("target")))
    return _compare_answer(sample.get("answer"), gold) if gold is not None else False


def _tabfact_correct(sample: Dict[str, Any]) -> bool:
    return tabfact_match_from_pcfg_result(sample)


def _classify_failure(sample: Dict[str, Any], report: Optional[Dict[str, Any]]) -> str:
    if sample is None:
        return "pipeline_error"
    if not sample.get("program") and sample.get("answer") is None:
        return "no_program_no_answer"
    if not sample.get("program"):
        return "no_sql_program"
    if sample.get("execution_result") is None:
        return "sql_execution_failed_or_empty"
    bf = sample.get("bayes_factor", _safe_get(report, "bayes_factor", 0.0))
    try:
        if float(bf) < 3:
            return "low_bayes_factor"
    except Exception:
        pass
    if sample.get("llm_refinement", {}).get("used") and not sample.get("llm_refinement", {}).get("success"):
        return "llm_refinement_failed"
    return "wrong_answer_after_execution"


def _row_for_sample(
    sample: Optional[Dict[str, Any]],
    report: Optional[Dict[str, Any]],
    idx: int,
    dataset_type: str,
    correct_fn: Callable[[Dict[str, Any]], bool],
) -> Dict[str, Any]:
    if sample is None:
        return {
            "idx": idx,
            "id": None,
            "correct": False,
            "failure_type": "pipeline_error",
            "report": report,
        }
    correct = correct_fn(sample)
    gold = sample.get("original_answer")
    if gold is None:
        gold = sample.get("gold_answer", sample.get("answers", sample.get("target", sample.get("label"))))
    return {
        "idx": idx,
        "id": sample.get("id", idx),
        "dataset_type": dataset_type,
        "question_or_statement": sample.get("question") or sample.get("statement") or sample.get("claim"),
        "gold": gold,
        "prediction": sample.get("answer"),
        "correct": correct,
        "failure_type": None if correct else _classify_failure(sample, report),
        "program": sample.get("program"),
        "execution_result": sample.get("execution_result"),
        "bayes_factor": sample.get("bayes_factor", _safe_get(report, "bayes_factor")),
        "posterior_score": sample.get("posterior_score"),
        "likelihood": sample.get("likelihood"),
        "accepted": _safe_get(report, "accepted"),
        "interpretation": _safe_get(report, "interpretation"),
        "refinement_rounds": _safe_get(report, "refinement_rounds", 0),
        "llm_refinement": sample.get("llm_refinement"),
        "best_program_summary": _safe_get(report, "best_program_summary"),
    }


def analyze_failures(
    result_samples: List[Optional[Dict[str, Any]]],
    pipeline_reports: Optional[List[Optional[Dict[str, Any]]]],
    output_dir: str,
    dataset_type: str,
    top_k: int = 30,
) -> Dict[str, Any]:
    """Write failure_cases.jsonl and failure_summary.md, then return summary."""
    os.makedirs(output_dir, exist_ok=True)
    reports = pipeline_reports or [None] * len(result_samples)
    if len(reports) < len(result_samples):
        reports = list(reports) + [None] * (len(result_samples) - len(reports))

    correct_fn = _tabfact_correct if dataset_type.lower() == "tabfact" else _structqa_correct
    rows = [
        _row_for_sample(sample, reports[idx], idx, dataset_type, correct_fn)
        for idx, sample in enumerate(result_samples)
    ]
    total = len(rows)
    correct = sum(1 for r in rows if r.get("correct"))
    failures = [r for r in rows if not r.get("correct")]
    failure_counter = Counter(r.get("failure_type") for r in failures)
    bf_values = []
    for r in rows:
        try:
            bf_values.append(float(r.get("bayes_factor")))
        except Exception:
            pass
    llm_used = sum(1 for r in rows if isinstance(r.get("llm_refinement"), dict) and r["llm_refinement"].get("used"))
    llm_success = sum(1 for r in rows if isinstance(r.get("llm_refinement"), dict) and r["llm_refinement"].get("success"))

    summary = {
        "dataset_type": dataset_type,
        "total": total,
        "correct": correct,
        "accuracy": correct / total if total else 0.0,
        "failure_count": len(failures),
        "failure_rate": len(failures) / total if total else 0.0,
        "failure_types": dict(failure_counter),
        "avg_bayes_factor": sum(bf_values) / len(bf_values) if bf_values else 0.0,
        "llm_refinement_used": llm_used,
        "llm_refinement_success": llm_success,
    }

    with open(os.path.join(output_dir, "failure_cases.jsonl"), "w", encoding="utf-8") as f:
        for row in failures[:top_k]:
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    with open(os.path.join(output_dir, "all_cases_with_diagnostics.jsonl"), "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    with open(os.path.join(output_dir, "failure_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, default=str)

    lines = [
        "# Failure Case Analysis",
        "",
        f"- Dataset type: `{dataset_type}`",
        f"- Total cases: {total}",
        f"- Correct cases: {correct}",
        f"- Accuracy: {summary['accuracy']:.4f}",
        f"- Failure cases: {len(failures)}",
        f"- Failure rate: {summary['failure_rate']:.4f}",
        f"- Average Bayes Factor: {summary['avg_bayes_factor']:.4f}",
        f"- LLM refinement used: {llm_used}",
        f"- LLM refinement successful calls: {llm_success}",
        "",
        "## Failure Types",
        "",
    ]
    for typ, cnt in failure_counter.most_common():
        lines.append(f"- `{typ}`: {cnt}")
    lines.extend(["", "## Representative Failure Cases", ""])
    for row in failures[: min(top_k, 10)]:
        lines.extend([
            f"### Case {row.get('id')}",
            f"- Type: `{row.get('failure_type')}`",
            f"- Question/statement: {row.get('question_or_statement')}",
            f"- Gold: {row.get('gold')}",
            f"- Prediction: {row.get('prediction')}",
            f"- Bayes Factor: {row.get('bayes_factor')}",
            f"- Program: `{row.get('program')}`",
            "",
        ])
    with open(os.path.join(output_dir, "failure_summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    return summary
