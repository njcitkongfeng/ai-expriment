"""
Proper Probabilistic Context-Free Grammar for Table Reasoning Programs.

A PCFG is a 5-tuple G = (N, Σ, R, S, P) where:
  N = non-terminals (program structures: Query, Filter, Join, Agg, ...)
  Σ = terminals (concrete operations with parameters: f_select_row(...), ...)
  R = production rules (how non-terminals expand)
  S = start symbol (Root)
  P = rule probabilities conditioned on table structure

Key difference from v1: programs are TREES, not linear sequences.
The grammar enforces structural correctness by construction.
"""

import math
import re
from itertools import product


def _parse_number(value):
    """Parse table numeric strings while avoiding ID/date false positives.

    The previous implementation parsed IDs such as ``P1`` or ``O7`` as numbers,
    which caused product_id/order_id/student_id columns to be classified as
    numeric.  That badly affects cross-table candidate generation.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text or text in {"-", "—", "n/a", "N/A", "None"}:
        return None

    # Do not parse common ID strings or dates as numeric values.
    if re.search(r"[A-Za-z]", text):
        # Allow month-free currency/percentage strings, reject IDs like P1/O2/S3.
        # Strings containing letters are usually categorical in table QA.
        return None
    if re.search(r"\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}", text):
        return None

    neg = text.startswith("(") and text.endswith(")")
    if neg:
        text = text[1:-1]
    text = text.replace(",", "")
    text = re.sub(r"[%$€£¥]", "", text)
    text = re.sub(r"[^0-9+\-./]", "", text)
    if not text or text in {"+", "-", "."}:
        return None
    try:
        if "/" in text:
            a, b = text.split("/", 1)
            val = float(a) / float(b) if float(b) != 0 else None
        else:
            val = float(text)
        return -val if neg and val is not None else val
    except Exception:
        return None

def _is_numeric_column(table, col_idx, min_ratio=0.60):
    vals = []
    ok = 0
    if not isinstance(table, list):
        return False
    for row in table[1:]:
        if col_idx >= len(row):
            continue
        raw = row[col_idx]
        if str(raw).strip() == "":
            continue
        vals.append(raw)
        if _parse_number(raw) is not None:
            ok += 1
    return bool(vals) and ok / len(vals) >= min_ratio


# ============================================================
# NON-TERMINALS (N) — program structure types
# ============================================================

# Each non-terminal represents a semantic "slot" in a reasoning program.
# Non-terminals expand into either:
#   - A terminal operation (leaf in the syntax tree)
#   - A sequence of non-terminals (internal node)

# ============================================================
# TERMINALS (Σ) — concrete operations
# ============================================================

# Each terminal is a function that operates on tabular data.
# Terminals have parameters filled by LLM during generation.

TERMINAL_TYPES = {
    "SelectRows":    "f_select_row({col}, {op}, {value})",
    "SelectCols":    "f_select_column({cols})",
    "GroupBy":       "f_group_by({col})",
    "SortBy":        "f_sort_by({col}, {order})",
    "AddColumn":     "f_add_column({name}, {expr})",
    "Aggregate":     "f_aggregate({fn}, {col})",
    "JoinTables":    "f_join({table_a}, {table_b}, {on_col})",
    "FilterYear":    "f_filter_year({year})",
    "ComputeDiff":   "f_diff({col_a}, {col_b})",
    "Limit":         "f_limit({n})",
    "FinalAnswer":   "f_answer()",
    "RawSQL":        "f_raw_sql({sql})",
}

# ============================================================
# PRODUCTION RULES (R) with PROBABILITIES (P)
# ============================================================

# Grammar in Chomsky-like form:
#   NonTerminal → Terminal
#   NonTerminal → NonTerminal NonTerminal ...
#
# Each rule has a BASE probability. The actual probability is
# conditioned on table structure and question semantics.

GRAMMAR = {

    # ROOT — top-level program
    "Root": [
        # (expansion, base_prob, condition_fn)
        # Single-table patterns
        ("SingleTableQuery", 0.35, lambda s: len(s.get("tables", {})) <= 1),
        ("MultiTableQuery", 0.35, lambda s: len(s.get("tables", {})) >= 2),
        ("Comparison", 0.30, lambda s: _is_comparison_question(s.get("statement", ""))),
    ],

    # SINGLE TABLE QUERY — standard chain-of-table
    "SingleTableQuery": [
        ("FilterClause SelectClause AggregateClause", 0.40, None),
        ("SelectClause FilterClause AggregateClause", 0.25, None),
        ("SelectClause AggregateClause", 0.20, None),
        ("FilterClause GroupClause AggregateClause", 0.10, None),
        ("GroupClause AggregateClause", 0.05, None),
    ],

    # MULTI TABLE QUERY — requires at least one join
    "MultiTableQuery": [
        ("JoinClause FilterClause SelectClause AggregateClause", 0.35, None),
        ("JoinClause SelectClause FilterClause AggregateClause", 0.25, None),
        ("JoinClause FilterClause GroupClause AggregateClause", 0.20, None),
        ("JoinClause SelectClause SortClause LimitClause", 0.10, None),
        ("JoinClause FilterClause SelectClause SortClause LimitClause", 0.10, None),
    ],

    # COMPARISON — two sub-programs compared
    "Comparison": [
        ("SubProgram SubProgram DiffClause SortClause LimitClause", 0.40, None),
        ("SubProgram DiffClause SubProgram SortClause LimitClause", 0.30, None),
        ("SubProgram SubProgram DiffClause AggregateClause", 0.30, None),
    ],
    "SubProgram": [
        ("FilterClause SelectClause", 0.5, lambda s: True),
        ("JoinClause FilterClause SelectClause", 0.5, lambda s: len(s.get("tables", {})) >= 2),
    ],

    # CLAUSE NON-TERMINALS — expand to concrete operations
    # Note: avoid direct recursion (e.g. FilterClause → FilterClause) to
    # prevent unbounded chain depth. Multi-step patterns are explicit.
    "FilterClause": [
        ("SelectRows", 0.55, None),          # single filter
        ("SelectRows SelectRows", 0.25, None),  # two chained filters
        ("AddColumn SelectRows", 0.20, None),   # computed col + filter
    ],

    "JoinClause": [
        ("JoinTables", 0.65, None),              # single join
        ("JoinTables JoinTables", 0.35, None),   # two chained joins (3+ tables)
    ],

    "SelectClause": [
        ("SelectCols", 0.70, None),
        ("AddColumn SelectCols", 0.30, None),
    ],

    "AggregateClause": [
        ("Aggregate", 0.60, None),
        ("GroupBy Aggregate", 0.25, None),
        ("SortBy Aggregate", 0.15, None),
    ],

    "GroupClause": [
        ("GroupBy", 1.0, None),
    ],

    "SortClause": [
        ("SortBy", 1.0, None),
    ],

    "LimitClause": [
        ("Limit", 1.0, None),
    ],

    "DiffClause": [
        ("ComputeDiff", 1.0, None),
    ],
}


# ============================================================
# STRUCTURE-CONDITIONED PROBABILITY FUNCTIONS
# ============================================================

def _is_comparison_question(question):
    """Check if question asks for comparison."""
    q = question.lower()
    comparison_words = [
        'higher', 'lower', 'increase', 'decrease', 'compare',
        'difference', 'change', 'more than', 'less than',
        'highest', 'lowest', 'most', 'least', 'top', 'bottom',
        'from ... to', 'between ... and',
    ]
    return any(w in q for w in comparison_words)


def _count_columns(table):
    """Count columns in a table."""
    if isinstance(table, list) and len(table) > 0:
        return len(table[0])
    return 0


def _count_rows(table):
    """Count data rows in a table."""
    if isinstance(table, list):
        return max(0, len(table) - 1)
    return 0


def _column_cardinality(table, col_idx_or_name):
    """Estimate distinct values in a column."""
    if not isinstance(table, list) or len(table) < 2:
        return 1
    if isinstance(col_idx_or_name, str):
        # Find column index by name
        for i, h in enumerate(table[0]):
            if col_idx_or_name.lower() in str(h).lower():
                col_idx_or_name = i
                break
        else:
            return len(table) - 1  # default: high cardinality
    values = set()
    for row in table[1:]:
        if len(row) > col_idx_or_name:
            values.add(str(row[col_idx_or_name]).strip())
    return len(values)


def _detect_foreign_keys(tables):
    """
    Detect FK relationships between tables.
    Returns list of (table_a, col_a, table_b, col_b) tuples.
    """
    fks = []
    names = list(tables.keys())

    for i in range(len(names)):
        for j in range(len(names)):
            if i == j:
                continue
            t_a, t_b = names[i], names[j]
            table_a = tables[t_a]
            table_b = tables[t_b]

            if not isinstance(table_a, list) or not isinstance(table_b, list):
                continue
            if len(table_a) == 0 or len(table_b) == 0:
                continue

            headers_a = [str(h).strip().lower() for h in table_a[0]]
            headers_b = [str(h).strip().lower() for h in table_b[0]]

            for idx_a, h_a in enumerate(headers_a):
                for idx_b, h_b in enumerate(headers_b):
                    # FK naming patterns
                    name_match = (
                        h_a == h_b or
                        h_a.endswith('_id') and h_b == 'id' or
                        h_b.endswith('_id') and h_a == 'id' or
                        h_a.replace('_id', '') == h_b or
                        h_b.replace('_id', '') == h_a
                    )
                    if not name_match:
                        continue

                    # Check value overlap (FK evidence) — sample rows for speed
                    vals_a = set()
                    vals_b = set()
                    for row in table_a[1:51]:  # first 50 rows
                        if len(row) > idx_a:
                            vals_a.add(str(row[idx_a]).strip())
                    for row in table_b[1:51]:
                        if len(row) > idx_b:
                            vals_b.add(str(row[idx_b]).strip())

                    if not vals_a or not vals_b:
                        continue

                    overlap = len(vals_a & vals_b)
                    max_overlap = min(len(vals_a), len(vals_b))
                    overlap_ratio = overlap / max_overlap if max_overlap > 0 else 0

                    if overlap_ratio > 0.5:  # FK threshold
                        fks.append((t_a, h_a, t_b, h_b, overlap_ratio))
                        if len(fks) >= 20:  # cap: avoid O(n²) blowup
                            return fks

    return fks


def build_schema_graph(tables):
    """
    Build a schema graph from table structures.
    Returns dict with nodes (tables+columns) and edges (FK+semantic).
    """
    fks = _detect_foreign_keys(tables)
    graph = {
        'tables': {},
        'foreign_keys': fks,
        'num_tables': len(tables),
    }

    for t_name, table in tables.items():
        if not isinstance(table, list) or len(table) == 0:
            continue
        headers = table[0]
        columns = []
        for i, h in enumerate(headers):
            cardinality = _column_cardinality(table, i)
            columns.append({
                'name': h,
                'index': i,
                'cardinality': cardinality,
                'type': 'numeric' if _is_numeric_column(table, i) else 'text',
                'is_fk': any(str(h).lower() == fk[1] or str(h).lower() == fk[3] for fk in fks),
                'distinct_ratio': cardinality / max(_count_rows(table), 1),
            })
        graph['tables'][t_name] = {
            'columns': columns,
            'num_rows': _count_rows(table),
            'num_cols': len(columns),
        }

    return graph


# ============================================================
# SCHEMA-AWARE PARAMETER HELPERS
# ============================================================

def _get_table_data(tables):
    """Return the primary table's data (header + rows)."""
    if not tables:
        return None, None
    for t_name, table in tables.items():
        if isinstance(table, list) and len(table) >= 2:
            return t_name, table
    return None, None


def _get_column_names_from_schema(schema):
    """Extract {table_name: [(col_name, col_type), ...]} from schema."""
    col_map = {}
    for t_name, t_info in schema.get('tables', {}).items():
        cols = []
        for c in t_info.get('columns', []):
            name = str(c.get('name', ''))
            col_type = c.get('type') or 'text'
            cols.append((name, col_type))
        col_map[t_name] = cols
    return col_map

def _pick_column_by_statement(cols, statement):
    """Pick column with max word overlap with statement tokens."""
    if not cols or not statement:
        return cols[0] if cols else ''
    stmt_words = set(re.findall(r'[a-zA-Z0-9]+', statement.lower()))
    best_col = cols[0]
    best_score = -1
    for col_info in cols:
        name = col_info[0] if isinstance(col_info, tuple) else str(col_info)
        col_words = set(re.findall(r'[a-zA-Z0-9]+', name.lower().replace('_', ' ')))
        overlap = len(stmt_words & col_words)
        if overlap > best_score:
            best_score = overlap
            best_col = name
    return best_col


def _pick_numeric_column(schema, statement):
    """Pick a numeric column, preferring statement-relevant ones."""
    col_map = _get_column_names_from_schema(schema)
    numeric_cols = []
    for t_name, cols in col_map.items():
        for name, ctype in cols:
            if ctype == 'numeric':
                numeric_cols.append((name, ctype))
    if not numeric_cols:
        # Fallback: any column
        for t_name, cols in col_map.items():
            for name, ctype in cols:
                numeric_cols.append((name, ctype))
    return _pick_column_by_statement(numeric_cols, statement)


def _pick_categorical_column(schema, statement):
    """Pick a text/categorical column (low cardinality for GroupBy)."""
    col_map = _get_column_names_from_schema(schema)
    candidates = []
    for t_name, cols in col_map.items():
        for name, ctype in cols:
            if ctype == 'text':
                candidates.append((name, ctype))
    if not candidates:
        candidates = cols if cols else [('category', 'text')]
    return _pick_column_by_statement(candidates, statement)


def _pick_column_value(table_data, col_name, statement=None):
    """Pick a value from a column; prefer values explicitly mentioned in the question."""
    if not isinstance(table_data, list) or len(table_data) < 2:
        return 'value'
    header = table_data[0]
    col_idx = None
    for i, h in enumerate(header):
        if str(h).strip().lower() == str(col_name).strip().lower():
            col_idx = i
            break
    if col_idx is None:
        return 'value'
    values = []
    for row in table_data[1:]:
        if len(row) > col_idx and str(row[col_idx]).strip():
            values.append(str(row[col_idx]).strip())
    if not values:
        return 'value'
    q = str(statement or '').lower()
    for v in values:
        if str(v).lower() in q:
            return v
    # Token-level fallback for entities embedded in longer strings.
    q_tokens = set(re.findall(r"[a-zA-Z0-9]+", q))
    best_v, best_overlap = values[0], -1
    for v in values:
        toks = set(re.findall(r"[a-zA-Z0-9]+", str(v).lower()))
        overlap = len(q_tokens & toks)
        if overlap > best_overlap:
            best_v, best_overlap = v, overlap
    return best_v

def _pick_two_numeric(schema, statement):
    """Pick two distinct numeric columns for ComputeDiff/AddColumn."""
    col_map = _get_column_names_from_schema(schema)
    numeric_cols = []
    for t_name, cols in col_map.items():
        for name, ctype in cols:
            if ctype == 'numeric':
                numeric_cols.append(name)
    if len(numeric_cols) < 2:
        # Fallback: any columns
        for t_name, cols in col_map.items():
            for name, ctype in cols:
                if name not in numeric_cols:
                    numeric_cols.append(name)
    if len(numeric_cols) >= 2:
        return numeric_cols[0], numeric_cols[1]
    return 'col_a', 'col_b'


def _extract_year_from_statement(statement):
    """Extract a 4-digit year from the statement, or return 2022."""
    import re
    match = re.search(r'\b(19|20)\d{2}\b', str(statement))
    return int(match.group(0)) if match else 2022


# ============================================================
# PRIOR COMPUTATION FOR A GRAMMAR TREE
# ============================================================

def compute_rule_prob(rule_expansion, nonterminal, sample, grammar_entry):
    """
    Compute the structure-conditioned probability of a specific rule.
    """
    candidates = grammar_entry
    base_probs = []
    for cand, base_p, cond_fn in candidates:
        if cond_fn and not cond_fn(sample):
            base_probs.append(0.0)
        else:
            base_probs.append(base_p)
    total = sum(base_probs)
    if total == 0:
        return 1.0 / len(candidates)  # uniform fallback

    # Find the index of the rule
    for i, (cand, base_p, cond_fn) in enumerate(candidates):
        if cand == rule_expansion:
            if cond_fn and not cond_fn(sample):
                return 0.0  # rule not applicable
            return base_p / total

    return 0.0


def compute_tree_prior(parse_tree, sample):
    """
    Compute log prior of a complete parse tree.

    A parse tree looks like:
      {
        'nonterminal': 'Root',
        'expansion': ['MultiTableQuery'],
        'children': [
          {
            'nonterminal': 'MultiTableQuery',
            'expansion': ['JoinClause', 'FilterClause', 'SelectClause', 'AggregateClause'],
            'children': [
              { 'nonterminal': 'JoinClause', 'expansion': ['JoinTables'], 'terminal': 'JoinTables', 'params': {...} },
              { 'nonterminal': 'FilterClause', 'expansion': ['SelectRows'], 'terminal': 'SelectRows', 'params': {...} },
              { 'nonterminal': 'SelectClause', 'expansion': ['SelectCols'], 'terminal': 'SelectCols', 'params': {...} },
              { 'nonterminal': 'AggregateClause', 'expansion': ['Aggregate'], 'terminal': 'Aggregate', 'params': {...} },
            ]
          }
        ]
      }
    """
    log_prob = 0.0

    def _traverse(node):
        nonlocal log_prob
        nt = node.get('nonterminal', '')
        expansion = node.get('expansion', [])
        grammar_rules = GRAMMAR.get(nt, [])

        if grammar_rules:
            exp_str = ' '.join(expansion)
            rule_p = compute_rule_prob(exp_str, nt, sample, grammar_rules)
            if rule_p > 0:
                log_prob += math.log(rule_p)
            else:
                log_prob += math.log(1e-6)

        for child in node.get('children', []):
            _traverse(child)

    _traverse(parse_tree)
    return log_prob


# ============================================================
# SEMANTIC PRIOR BONUS
# ============================================================

def compute_semantic_prior_bonus(program_sample, original_sample, log_prior=0.0,
                                 scale=3.0):
    """Augment grammar-tree prior with question-relevance reward.

    Generic programs (e.g. ``SELECT * FROM a JOIN b``) can execute
    successfully on any database, giving them high likelihood under
    the PCFG-BF framework.  This bonus penalises programs that do not
    reference columns / values / operations mentioned in the question,
    preventing irrelevant-but-executable programs from out-ranking
    semantically relevant ones.

    Returns a *delta* to add to the existing ``log_prior``, so the
    effective prior becomes ``log_prior + bonus`` (bonus is negative for
    irrelevant programs, near-zero for well-matched ones).

    Args:
        program_sample: dict with parse_tree or chain
        original_sample: dict with question, tables
        log_prior: current log-prior from PCFG tree (unused, for API compat)
        scale: multiplier for the bonus strength.  1.0 = gentle nudge,
               3.0 (default) = strong preference, 5.0+ = very aggressive.
               Tune this if generic programs still dominate.
    """
    import re

    bonus = 0.0
    question = str(original_sample.get("question") or
                   original_sample.get("statement") or "").lower()
    if not question:
        return 0.0

    q_tokens = set(re.findall(r"[a-zA-Z0-9]+", question))
    tables = (original_sample.get("tables") or
              {"t": original_sample.get("table_text", [])})

    # ── Extract program features ──────────────────────────────────
    # Walk the parse tree or chain to find all terminals and params
    def _collect_terminals(node, acc):
        if isinstance(node, dict):
            term = node.get("terminal", "")
            params = node.get("params", {})
            if term:
                acc.append((term, params))
            for child in node.get("children", []):
                _collect_terminals(child, acc)
        elif isinstance(node, list):
            for item in node:
                _collect_terminals(item, acc)

    terminals = []
    tree = program_sample.get("parse_tree")
    if tree:
        _collect_terminals(tree, terminals)
    else:
        # Flat chain
        for op in program_sample.get("chain", []):
            terminals.append((op.get("operation_name", ""),
                              op.get("parameter_and_conf", {})))

    # Also check for raw_sql
    raw_sql = ""
    for t, p in terminals:
        if t == "RawSQL":
            raw_sql = str(p.get("sql", ""))
            break

    if raw_sql:
        sql_upper = raw_sql.upper().replace("  ", " ")
        sql_tokens = set(re.findall(r"[a-zA-Z0-9]+", raw_sql.lower()))
        # Heavy bonus for SQL that references many question tokens
        token_overlap = len(q_tokens & sql_tokens)
        bonus += min(token_overlap * 0.08, 0.40)
        # Penalise SQL that references NO question tokens
        if token_overlap == 0:
            bonus -= 0.50

    collected_cols = set()
    collected_tables = set()
    collected_values = set()
    operation_types = set()

    for term_type, params in terminals:
        operation_types.add(term_type)
        # Columns
        for k in ("column", "columns", "col_a", "col_b", "on_col",
                  "group_col", "order_col"):
            v = params.get(k, "")
            if isinstance(v, str) and v:
                collected_cols.add(v.lower())
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, str):
                        collected_cols.add(item.lower())
        # Tables
        for k in ("table_a", "table_b", "table"):
            v = params.get(k, "")
            if isinstance(v, str) and v:
                collected_tables.add(v.lower())
        # Values (for WHERE filters)
        for k in ("value", "operator"):
            v = params.get(k, "")
            if isinstance(v, str) and len(v) >= 2:
                collected_values.add(v.lower())

    # ── Column relevance ─────────────────────────────────────────
    col_hits = 0
    for col in collected_cols:
        col_tokens = set(re.findall(r"[a-zA-Z0-9]+", col))
        if col_tokens & q_tokens:
            col_hits += 1
    # Reward: each question-relevant column
    bonus += min(col_hits * 0.06, 0.30)
    # Penalty: program uses columns but none relevant
    if collected_cols and col_hits == 0:
        bonus -= 0.20

    # ── Table relevance ──────────────────────────────────────────
    table_hits = 0
    for tbl in collected_tables:
        tbl_tokens = set(re.findall(r"[a-zA-Z0-9]+", tbl))
        if tbl_tokens & q_tokens:
            table_hits += 1
    bonus += min(table_hits * 0.05, 0.15)
    if collected_tables and table_hits == 0:
        bonus -= 0.15

    # ── Value relevance ──────────────────────────────────────────
    val_hits = 0
    for val in collected_values:
        if val in question:
            val_hits += 1
    bonus += min(val_hits * 0.07, 0.25)
    if collected_values and val_hits == 0:
        bonus -= 0.10

    # ── Operation relevance ──────────────────────────────────────
    op_bonus = 0.0
    for op in operation_types:
        op_l = op.lower()
        if op_l in ("sortby", "orderby") and any(
            w in question for w in ["oldest", "youngest", "highest",
                                     "lowest", "earliest", "latest",
                                     "order", "descending", "ascending"]):
            op_bonus += 0.10
        if op_l == "aggregate" and any(
            w in question for w in ["how many", "count", "number of",
                                     "total", "sum", "average", "avg",
                                     "minimum", "maximum", "max", "min"]):
            op_bonus += 0.08
        if op_l in ("groupby", "group_by") and any(
            w in question for w in ["each", "per", "every", "group"]):
            op_bonus += 0.10
        if op_l in ("selectrows", "whererows") and any(
            w in question for w in ["where", "filter", "above", "below",
                                     "greater", "older", "younger",
                                     "between", "from", "in"]):
            op_bonus += 0.06
        if op_l in ("limit",) and any(
            w in question for w in ["youngest", "oldest", "first",
                                     "top", "highest", "lowest"]):
            op_bonus += 0.10
        if op_l in ("jointables",) and any(
            w in question for w in ["join", "across", "both",
                                     "related", "combined"]):
            op_bonus += 0.05
        # RawSQL with good token overlap already rewarded above
    bonus += min(op_bonus, 0.35)

    # ── Complexity reward ────────────────────────────────────────
    # Programs that do more work (JOIN + WHERE + GROUP BY + ORDER)
    # are more likely to be correct for complex questions.
    n_ops = len(operation_types)
    if n_ops >= 4:
        bonus += 0.15
    elif n_ops >= 3:
        bonus += 0.08
    elif n_ops >= 2:
        bonus += 0.03
    # But penalise programs that do nothing useful (just SELECT *)
    if n_ops <= 1 and not raw_sql:
        bonus -= 0.15

    return bonus * scale


# ── Tuning guide ──────────────────────────────────────────────
# scale=1.0  → bonus range [-0.50, +0.50] — gentle, generic programs may still win
# scale=3.0  → bonus range [-1.50, +1.50] — strong (default)
# scale=5.0+ → bonus range [-2.50, +2.50] — aggressive, may overfit to keywords
#
# To change: set SEMANTIC_PRIOR_SCALE env var or pass scale= to the function.
# ============================================================

def expand_nonterminal(nonterminal, sample):
    """
    Sample an expansion for a non-terminal, returning
    (expansion_list, probability).

    Returns None if no rule applies.
    """
    rules = GRAMMAR.get(nonterminal, [])
    if not rules:
        return None, 0.0

    # Compute conditional probabilities
    probs = []
    valid_rules = []
    for expansion, base_p, cond_fn in rules:
        if cond_fn is None or cond_fn(sample):
            valid_rules.append((expansion, base_p))
            probs.append(base_p)

    if not valid_rules:
        return None, 0.0

    # Normalize
    total = sum(probs)
    probs = [p / total for p in probs]

    return valid_rules, probs


def generate_grammar_tree(sample, llm, max_depth=6):
    """
    Generate a full parse tree from the PCFG grammar.

    This is the main entry point: given a sample (Q + tables),
    produces a tree-structured reasoning program.

    Returns:
      parse_tree dict, or None if generation fails
    """
    import random

    def _build_node(nonterminal, depth):
        if depth > max_depth:
            return {'nonterminal': nonterminal, 'expansion': ['FinalAnswer'],
                    'children': [], 'terminal': 'FinalAnswer', 'params': {}}

        valid_rules, probs = expand_nonterminal(nonterminal, sample)
        if valid_rules is None:
            return {'nonterminal': nonterminal, 'expansion': ['FinalAnswer'],
                    'children': [], 'terminal': 'FinalAnswer', 'params': {}}

        # Sample one expansion
        expansion_str, _ = random.choices(valid_rules, weights=probs, k=1)[0]
        tokens = expansion_str.split()

        node = {
            'nonterminal': nonterminal,
            'expansion': tokens,
            'children': [],
        }

        for token in tokens:
            if token in TERMINAL_TYPES:
                # Leaf node — terminal operation
                child = {
                    'nonterminal': token,
                    'expansion': [token],
                    'children': [],
                    'terminal': token,
                    'params': _generate_llm_params(token, sample, llm),
                }
                node['children'].append(child)
            elif token in GRAMMAR:
                # Internal node — recurse
                child = _build_node(token, depth + 1)
                node['children'].append(child)
            elif token == 'SubProgram':
                # SubProgram expands differently
                child = _build_node('SubProgram', depth + 1)
                node['children'].append(child)
            else:
                # Unknown token — try as non-terminal
                child = _build_node(token, depth + 1) if token in GRAMMAR else {
                    'nonterminal': token, 'expansion': [token], 'children': [],
                    'terminal': 'FinalAnswer', 'params': {}
                }
                node['children'].append(child)

        return node

    return _build_node('Root', 0)


def _generate_llm_params(terminal_type, sample, llm):
    """Fill concrete parameters for a terminal operation using actual schema."""
    statement = sample.get('statement', '')
    table_text = sample.get('table_text', [])
    tables = sample.get('tables', {'default': table_text} if table_text else {})
    schema = build_schema_graph(tables)
    _, table_data = _get_table_data(tables)

    params = {'operation': terminal_type}

    if terminal_type == 'SelectRows':
        col = _pick_column_by_statement(
            _get_column_names_from_schema(schema).get(
                list(tables.keys())[0] if tables else 't', []),
            statement
        )
        params['column'] = col
        params['operator'] = '='
        params['value'] = _pick_column_value(
            tables.get(list(tables.keys())[0], table_text) if tables else table_text,
            col,
            statement
        )

    elif terminal_type == 'SelectCols':
        col_map = _get_column_names_from_schema(schema)
        all_cols = []
        for t_name, cols in col_map.items():
            all_cols.extend([c[0] for c in cols])
        if not all_cols and table_data:
            all_cols = [str(h) for h in table_data[0]]
        # Pick top 3 most statement-relevant columns
        ranked = sorted(all_cols, key=lambda c: _col_statement_overlap(c, statement), reverse=True)
        params['columns'] = ranked[:3] if len(ranked) >= 3 else ranked

    elif terminal_type == 'GroupBy':
        params['column'] = _pick_categorical_column(schema, statement)

    elif terminal_type == 'SortBy':
        params['column'] = _pick_numeric_column(schema, statement)
        q = statement.lower()
        if any(w in q for w in ['highest', 'top', 'most', 'largest', 'max', 'desc']):
            params['order'] = 'DESC'
        else:
            params['order'] = 'ASC'

    elif terminal_type == 'Aggregate':
        q = statement.lower()
        if 'avg' in q or 'average' in q or 'mean' in q:
            params['function'] = 'AVG'
        elif 'max' in q or 'highest' in q or 'largest' in q or 'most' in q:
            params['function'] = 'MAX'
        elif 'min' in q or 'lowest' in q or 'smallest' in q or 'least' in q:
            params['function'] = 'MIN'
        elif 'sum' in q or 'total' in q:
            params['function'] = 'SUM'
        elif 'count' in q or 'number of' in q or 'how many' in q:
            params['function'] = 'COUNT'
        else:
            params['function'] = 'AVG'
        if params['function'] == 'COUNT':
            params['column'] = '*'
        else:
            params['column'] = _pick_numeric_column(schema, statement)

    elif terminal_type == 'JoinTables':
        fks = schema.get('foreign_keys', [])
        if fks:
            fk = fks[0]
            params['table_a'] = fk[0]
            params['table_b'] = fk[2]
            params['on_col_a'] = fk[1]
            params['on_col_b'] = fk[3]
        else:
            t_names = list(tables.keys())
            params['table_a'] = t_names[0] if t_names else 't1'
            params['table_b'] = t_names[1] if len(t_names) > 1 else 't2'
            params['on_col_a'] = 'id'
            params['on_col_b'] = 'id'

    elif terminal_type == 'ComputeDiff':
        col_a, col_b = _pick_two_numeric(schema, statement)
        params['col_a'] = col_a
        params['col_b'] = col_b

    elif terminal_type == 'AddColumn':
        col_a, col_b = _pick_two_numeric(schema, statement)
        params['name'] = f"{col_a}_minus_{col_b}" if col_a != 'col_a' else 'diff'
        params['expr'] = f"{col_a} - {col_b}"

    elif terminal_type == 'FilterYear':
        params['year'] = _extract_year_from_statement(statement)

    elif terminal_type == 'Limit':
        params['n'] = 1

    return params


def _col_statement_overlap(col_name, statement):
    """Score how relevant a column name is to a statement (word overlap)."""
    if not statement:
        return 0
    stmt_words = set(re.findall(r'[a-zA-Z0-9]+', statement.lower()))
    col_words = set(re.findall(r'[a-zA-Z0-9]+', str(col_name).lower().replace('_', ' ')))
    return len(stmt_words & col_words)


def reroll_params(terminal_type, sample, exclude_params=None):
    """
    Regenerate parameters for a terminal, optionally excluding a prior set.
    Used by refinement for parameter-only resampling.
    """
    params = _generate_llm_params(terminal_type, sample, None)
    if exclude_params:
        # If the regenerated params match the excluded ones, try different values
        if terminal_type == 'SelectRows':
            col = params.get('column', '')
            tables = sample.get('tables', {})
            table_text = sample.get('table_text', [])
            primary_table = list(tables.values())[0] if tables else table_text
            if isinstance(primary_table, list) and col:
                # Try a different value from the same column
                try:
                    header = primary_table[0]
                    for i, h in enumerate(header):
                        if str(h).strip().lower() == str(col).strip().lower():
                            values = set()
                            for row in primary_table[1:]:
                                if len(row) > i and str(row[i]).strip():
                                    values.add(str(row[i]).strip())
                            if exclude_params.get('value') in values:
                                values.discard(exclude_params['value'])
                            if values:
                                params['value'] = list(values)[0]
                except (IndexError, ValueError):
                    pass
    return params


# ============================================================
# TREE → FLAT OPERATION SEQUENCE
# ============================================================

def tree_to_operations(parse_tree):
    """Flatten a parse tree into an ordered list of terminal operations."""
    operations = []

    def _traverse(node):
        terminal = node.get('terminal', '')
        if terminal and terminal in TERMINAL_TYPES:
            operations.append({
                'operation_name': terminal,
                'parameter_and_conf': node.get('params', {}),
            })
        for child in node.get('children', []):
            _traverse(child)

    _traverse(parse_tree)
    return operations


def tree_to_summary(parse_tree, indent=0):
    """Pretty-print a parse tree."""
    lines = []
    prefix = "  " * indent
    nt = parse_tree.get('nonterminal', '?')
    terminal = parse_tree.get('terminal', '')
    params = parse_tree.get('params', {})

    if terminal:
        param_str = ", ".join(f"{k}={v}" for k, v in params.items() if k != 'operation')
        lines.append(f"{prefix}[{terminal}] {param_str}")
    else:
        lines.append(f"{prefix}{nt}")

    for child in parse_tree.get('children', []):
        lines.extend(tree_to_summary(child, indent + 1))

    return lines
