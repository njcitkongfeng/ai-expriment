"""
Execution-based likelihood verifier for PCFG-BF StructQA experiments.

This module compiles PCFG parse trees into SQLite queries, executes them
against in-memory tables, and computes answer/claim likelihoods from actual
execution results. It is designed to be runnable without external LLM APIs.
"""

import os
import re
import sqlite3
from typing import Any, Dict, Iterable, List, Optional, Tuple


# ============================================================
# Identifier and value normalization
# ============================================================

def _safe_ident(name: Any) -> str:
    """Sanitize a SQL identifier and keep it deterministic."""
    ident = re.sub(r"[^a-zA-Z0-9_]", "_", str(name).strip())
    ident = re.sub(r"_+", "_", ident).strip("_")
    if ident and ident[0].isdigit():
        ident = "_" + ident
    return ident or "col"


def _make_unique_idents(headers: Iterable[Any]) -> List[str]:
    seen: Dict[str, int] = {}
    out: List[str] = []
    for h in headers:
        base = _safe_ident(h)
        idx = seen.get(base, 0)
        seen[base] = idx + 1
        out.append(base if idx == 0 else f"{base}_{idx}")
    return out


# ── Date pattern detection ──────────────────────────────────────────
# Many table datasets contain values like "2 may 1999", "January 15, 2000",
# "1999-05-02", "05/02/1999".  _parse_number would extract lone digits
# from these strings, causing a date column to be classified as INTEGER
# and leading to wrong SQL comparisons (e.g. WHERE date = 21999.0).

_DATE_PATTERNS = [
    re.compile(r'\d{1,2}\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{4}', re.I),
    re.compile(r'(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{1,2},?\s+\d{4}', re.I),
    re.compile(r'\d{4}-\d{2}-\d{2}'),                   # ISO date 1999-05-02
    re.compile(r'\d{2}/\d{2}/\d{4}'),                    # US/EU slash dates
    re.compile(r'\d{1,2}-\d{1,2}-\d{4}'),                # dash dates like 5-2-1999
]

def _looks_like_date(value: str) -> bool:
    """Return True if the value matches a common date pattern."""
    for pat in _DATE_PATTERNS:
        if pat.search(str(value)):
            return True
    return False


def _parse_number(value: Any) -> Optional[float]:
    """Parse common numeric strings while avoiding IDs and dates.

    Critical for multi-table QA: IDs such as T1/P1/O7 must stay TEXT, otherwise
    SQL predicates like home_id = 'T1' fail because the DB stored 1.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip()
    if not s or s in {"-", "—", "n/a", "N/A", "None"}:
        return None
    if _looks_like_date(s):
        return None
    # Avoid parsing alphanumeric identifiers and names as numbers.
    if re.search(r"[A-Za-z]", s):
        return None

    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]
    s = s.replace(",", "")
    s = re.sub(r"[%$€£¥]", "", s)
    s = re.sub(r"[^0-9+\-./]", "", s)
    if not s or s in {"+", "-", "."}:
        return None
    try:
        if "/" in s and not s.startswith("http"):
            a, b = s.split("/", 1)
            if a and b and float(b) != 0:
                val = float(a) / float(b)
            else:
                return None
        else:
            val = float(s)
        return -val if neg else val
    except Exception:
        return None

def _normalize_cell(value: Any, sql_type: str) -> Any:
    if sql_type in ("REAL", "INTEGER"):
        num = _parse_number(value)
        if num is None:
            return None
        if sql_type == "INTEGER" and abs(num - round(num)) < 1e-9:
            return int(round(num))
        return float(num)
    return "" if value is None else str(value)


def _infer_sql_type(table: List[List[Any]], col_idx: int, min_ratio: float = 0.60) -> str:
    """Infer SQL column type.

    Returns "TEXT" for date-heavy columns even when _parse_number would
    extract numerical fragments, preventing e.g. "2 may 1999" → 21999.0.
    """
    vals = []
    numeric = 0
    integer_like = 0
    date_like = 0
    for row in table[1:]:
        if col_idx >= len(row):
            continue
        raw = row[col_idx]
        s = str(raw).strip()
        if s == "":
            continue
        vals.append(raw)
        if _looks_like_date(s):
            date_like += 1
        num = _parse_number(raw)
        if num is not None:
            numeric += 1
            if abs(num - round(num)) < 1e-9:
                integer_like += 1
    if not vals:
        return "TEXT"
    # If more than 30% of values look like dates, treat as TEXT.
    if date_like / len(vals) >= 0.30:
        return "TEXT"
    if vals and numeric / len(vals) >= min_ratio:
        return "INTEGER" if integer_like / max(numeric, 1) >= 0.90 else "REAL"
    return "TEXT"




def _quote_ident(name: Any) -> str:
    """Quote a SQLite identifier without changing its visible name."""
    return '"' + str(name).replace('"', '""') + '"'


def _connect_external_sqlite_with_safe_views(db_path: str, tables: Dict[str, List[List[Any]]]) -> Optional[sqlite3.Connection]:
    """Open an external SQLite DB and expose safe table/column aliases.

    The PCFG compiler sanitizes table and column names with ``_safe_ident``.
    Raw Spider/TQA-Bench databases may use spaces, punctuation, or mixed-case
    identifiers.  To make compiled SQL executable without copying full tables
    into JSONL, we create TEMP VIEWs whose names/columns match the compiler's
    sanitized identifiers.
    """
    if not db_path:
        return None
    if not os.path.exists(db_path):
        return None
    try:
        conn = sqlite3.connect(db_path)
        conn.text_factory = lambda b: b.decode('utf-8', errors='replace')
        conn.create_function("REGEXP", 2, _regexp)
        for raw_name, table in (tables or {}).items():
            if not isinstance(table, list) or not table:
                continue
            safe_table = _safe_ident(raw_name)
            headers = [str(h) for h in table[0]]
            safe_cols = _make_unique_idents(headers)
            select_exprs = [f'{_quote_ident(h)} AS {_quote_ident(sc)}' for h, sc in zip(headers, safe_cols)]
            # TEMP objects shadow main objects; this lets sanitized SQL use
            # either renamed tables or renamed columns transparently.
            view_sql = f'CREATE TEMP VIEW IF NOT EXISTS {_quote_ident(safe_table)} AS SELECT {", ".join(select_exprs)} FROM main.{_quote_ident(raw_name)}'
            try:
                conn.execute(view_sql)
            except Exception:
                # Some SQLite files have table names already sanitized or views
                # that cannot be shadowed.  Failure to create one view should not
                # kill the whole sample; candidate execution will report errors.
                pass
        return conn
    except Exception:
        return None


def _db_path_from_sample(sample: Dict[str, Any]) -> Optional[str]:
    """Return an existing SQLite path from a sample if available."""
    for key in ("db_path", "sqlite_path", "database_path"):
        val = sample.get(key)
        if val and os.path.exists(str(val)):
            return str(val)
    return None


def get_sqlite_connection_for_sample(sample: Dict[str, Any], tables: Dict[str, List[List[Any]]]) -> Optional[sqlite3.Connection]:
    """Use an external DB when provided; otherwise build an in-memory DB.

    This is the key dataset-compatibility fix: converted Spider/TQA-Bench JSONL
    stores only schema + preview rows for prompting/candidate generation, while
    SQL execution runs on the real sqlite file via safe TEMP VIEW aliases.
    """
    db_path = _db_path_from_sample(sample)
    if db_path:
        conn = _connect_external_sqlite_with_safe_views(db_path, tables)
        if conn is not None:
            return conn
    return build_sqlite_db(tables)

# ============================================================
# SQLite DB builder
# ============================================================

def build_sqlite_db(tables: Dict[str, List[List[Any]]]) -> Optional[sqlite3.Connection]:
    if not tables:
        return None
    conn = sqlite3.connect(":memory:")
    conn.create_function("REGEXP", 2, _regexp)

    for raw_name, table in tables.items():
        if not isinstance(table, list) or not table:
            continue
        header = [str(h) for h in table[0]]
        rows = table[1:]
        safe_table = _safe_ident(raw_name)
        safe_cols = _make_unique_idents(header)
        col_types = [_infer_sql_type(table, i) for i in range(len(header))]
        col_defs = [f"{c} {t}" for c, t in zip(safe_cols, col_types)]
        try:
            conn.execute(f"CREATE TABLE {safe_table} ({', '.join(col_defs)})")
        except sqlite3.OperationalError:
            continue
        if not rows:
            continue
        placeholders = ", ".join(["?"] * len(safe_cols))
        insert_sql = f"INSERT INTO {safe_table} ({', '.join(safe_cols)}) VALUES ({placeholders})"
        norm_rows = []
        for row in rows:
            padded = list(row[:len(safe_cols)]) + [""] * max(0, len(safe_cols) - len(row))
            norm_rows.append(tuple(_normalize_cell(v, col_types[i]) for i, v in enumerate(padded)))
        try:
            conn.executemany(insert_sql, norm_rows)
        except sqlite3.OperationalError:
            # If some row fails due to type mismatch, insert rows one by one.
            for r in norm_rows:
                try:
                    conn.execute(insert_sql, r)
                except sqlite3.OperationalError:
                    pass
    conn.commit()
    return conn


def _regexp(pattern: str, value: Any) -> bool:
    if value is None:
        return False
    return bool(re.search(pattern, str(value)))


# ============================================================
# Parse tree -> SQL
# ============================================================

class _SqlContext:
    def __init__(self, tables: Dict[str, List[List[Any]]]):
        self.tables = tables
        self.from_table = list(tables.keys())[0] if tables else "t"
        self.select_exprs: List[str] = []
        self.where_conds: List[str] = []
        self.group_cols: List[str] = []
        self.order_cols: List[str] = []
        self.joins: List[str] = []
        self.limit_val: Optional[int] = None
        self.agg_expr: Optional[str] = None
        self.raw_sql: Optional[str] = None

    def assemble(self) -> str:
        if self.raw_sql:
            return self.raw_sql
        if self.agg_expr and self.group_cols:
            select_str = ", ".join(self.group_cols + [self.agg_expr])
        else:
            select_str = self.agg_expr or (", ".join(self.select_exprs) if self.select_exprs else "*")
        sql = f"SELECT {select_str} FROM {_safe_ident(self.from_table)}"
        if self.joins:
            sql += " " + " ".join(self.joins)
        if self.where_conds:
            sql += " WHERE " + " AND ".join(self.where_conds)
        if self.group_cols:
            sql += " GROUP BY " + ", ".join(self.group_cols)
        if self.order_cols:
            sql += " ORDER BY " + ", ".join(self.order_cols)
        if self.limit_val is not None:
            sql += f" LIMIT {int(self.limit_val)}"
        return sql


def compile_tree_to_sql(parse_tree: Dict[str, Any], tables: Dict[str, List[List[Any]]]) -> Tuple[Optional[str], Optional[str]]:
    ctx = _SqlContext(tables)
    try:
        _compile_node(parse_tree, ctx)
        return ctx.assemble(), None
    except Exception as e:
        return None, str(e)


def _compile_node(node: Dict[str, Any], ctx: _SqlContext) -> None:
    terminal = node.get("terminal", "")
    if terminal:
        _compile_terminal(terminal, node.get("params", {}), ctx)
    for child in node.get("children", []):
        _compile_node(child, ctx)


def _sql_literal(value: Any) -> str:
    num = _parse_number(value)
    if num is not None:
        return str(num)
    return "'" + str(value).replace("'", "''") + "'"


def _sql_col_or_expr(value: Any) -> str:
    """Convert a column name or a simple arithmetic SQL expression safely.

    Supports:
      - column names: price
      - qualified names: products.price
      - aggregate modifiers: DISTINCT price
      - expressions: price * qty, products.price * orders.qty
    """
    text = str(value or "").strip()
    if not text or text == "*":
        return "*"
    if text.upper().startswith("DISTINCT "):
        return "DISTINCT " + _sql_col_or_expr(text.split(None, 1)[1])
    if any(op in text for op in ["+", "-", "*", "/", "(", ")"]):
        return _safe_expr(text)
    if "." in text:
        parts = [p for p in text.split(".") if p]
        return ".".join(_safe_ident(p) for p in parts)
    return _safe_ident(text)


def _compile_terminal(terminal_type: str, params: Dict[str, Any], ctx: _SqlContext) -> None:
    if terminal_type == "SelectRows":
        col = params.get("column")
        val = params.get("value")
        if not col or val in (None, "", "value"):
            return
        op = str(params.get("operator", "=")).upper()
        safe_col = _sql_col_or_expr(col)
        if op in {"=", "!=", "<", ">", "<=", ">="}:
            ctx.where_conds.append(f"{safe_col} {op} {_sql_literal(val)}")
        elif op == "LIKE":
            _esc = str(val).replace("'", "''")
            ctx.where_conds.append(f"{safe_col} LIKE '%{_esc}%'")
        elif op == "IN":
            vals = val if isinstance(val, list) else str(val).split(",")
            ctx.where_conds.append(f"{safe_col} IN ({', '.join(_sql_literal(v.strip()) for v in vals)})")
        return

    if terminal_type == "SelectCols":
        cols = params.get("columns", [])
        if isinstance(cols, str):
            cols = [cols]
        for c in cols:
            if c:
                safe = _sql_col_or_expr(c)
                if safe not in ctx.select_exprs:
                    ctx.select_exprs.append(safe)
        return

    if terminal_type == "GroupBy":
        col = params.get("column")
        if col:
            safe = _sql_col_or_expr(col)
            ctx.group_cols.append(safe)
            if safe not in ctx.select_exprs:
                ctx.select_exprs.append(safe)
        return

    if terminal_type == "SortBy":
        col = params.get("column")
        if col:
            order = str(params.get("order", "ASC")).upper()
            if order not in {"ASC", "DESC"}:
                order = "ASC"
            ctx.order_cols.append(f"{_sql_col_or_expr(col)} {order}")
        return

    if terminal_type == "Aggregate":
        fn = str(params.get("function", "AVG")).upper()
        if fn not in {"COUNT", "SUM", "AVG", "MAX", "MIN"}:
            fn = "AVG"
        col = params.get("column", "*")
        ctx.agg_expr = f"{fn}(*)" if fn == "COUNT" or not col or col == "*" else f"{fn}({_sql_col_or_expr(col)})"
        return

    if terminal_type == "JoinTables":
        table_a = params.get("table_a", ctx.from_table)
        table_b = params.get("table_b")
        if not table_b:
            return
        ctx.from_table = table_a
        on_a = params.get("on_col_a", params.get("on_col", "id"))
        on_b = params.get("on_col_b", params.get("on_col", "id"))
        ctx.joins.append(
            f"JOIN {_safe_ident(table_b)} ON {_safe_ident(table_a)}.{_safe_ident(on_a)} = {_safe_ident(table_b)}.{_safe_ident(on_b)}"
        )
        return

    if terminal_type == "AddColumn":
        name = params.get("name", "computed")
        expr = _safe_expr(params.get("expr", "0"))
        ctx.select_exprs.append(f"({expr}) AS {_safe_ident(name)}")
        return

    if terminal_type == "RawSQL":
        sql = str(params.get("sql", "")).strip()
        if sql:
            ctx.raw_sql = sql
        return

    if terminal_type == "ComputeDiff":
        col_a = params.get("col_a")
        col_b = params.get("col_b")
        if col_a and col_b:
            ctx.select_exprs.append(f"({_sql_col_or_expr(col_a)} - {_sql_col_or_expr(col_b)}) AS diff")
        return

    if terminal_type == "FilterYear":
        year = params.get("year")
        if year:
            ctx.where_conds.append(f"year = {int(year)}")
        return

    if terminal_type == "Limit":
        try:
            ctx.limit_val = max(1, int(params.get("n", 1)))
        except Exception:
            ctx.limit_val = 1
        return


def _safe_expr(expr: Any) -> str:
    return re.sub(r"[^a-zA-Z0-9_+\-*/().\s]", "", str(expr))


def compile_chain_to_sql(program_sample: Dict[str, Any], tables: Optional[Dict[str, List[List[Any]]]] = None) -> Tuple[Optional[str], Optional[str]]:
    # Backward-compatible fallback: wrap flat chain as terminal parse tree.
    if tables is None:
        tables = program_sample.get("tables") or ({"t": program_sample.get("table_text", [])} if program_sample.get("table_text") else {})
    children = []
    for op in program_sample.get("chain", []):
        children.append({
            "nonterminal": op.get("operation_name", ""),
            "terminal": op.get("operation_name", ""),
            "expansion": [op.get("operation_name", "")],
            "children": [],
            "params": op.get("parameter_and_conf", {}),
        })
    tree = {"nonterminal": "FlatChain", "expansion": [], "children": children}
    return compile_tree_to_sql(tree, tables)


# ============================================================
# Execution and scoring
# ============================================================

def execute_sql(sql: str, db_conn: sqlite3.Connection) -> Tuple[Optional[List[Tuple[Any, ...]]], Optional[str]]:
    if not sql or db_conn is None:
        return None, "No SQL or no DB"
    try:
        cur = db_conn.execute(sql)
        return cur.fetchall(), None
    except Exception as e:
        return None, str(e)


def _get_tables(sample: Dict[str, Any]) -> Dict[str, List[List[Any]]]:
    tables = sample.get("tables") or {}
    if tables:
        return tables
    table_text = sample.get("table_text") or sample.get("table") or []
    return {"t": table_text} if table_text else {}


def _get_question(sample: Dict[str, Any]) -> str:
    return str(sample.get("question") or sample.get("statement") or sample.get("claim") or "")


def _get_gold(sample: Dict[str, Any]) -> Any:
    for k in ("answer", "gold_answer", "answers", "target"):
        if k in sample:
            return sample[k]
    return sample.get("label")


def _get_mc_gold_value(sample: Dict[str, Any]) -> Any:
    """Return the value behind a multiple-choice gold letter if available."""
    gold = str(sample.get("answer", "")).strip().upper()
    choices = sample.get("choices") or []
    if not gold or not choices:
        return None
    for c in choices:
        parts = str(c).split(")", 1)
        if len(parts) == 2 and parts[0].strip().upper() == gold:
            return parts[1].strip()
    return None


# ── Stopwords for token alignment ───────────────────────────────
# NOTE: "not", "no", "all", "every", "each", "any", "some", "but"
# are intentionally NOT in this set — they carry logical meaning in
# fact verification (negation, quantification).
_STOP = {
    "the", "a", "an", "of", "in", "on", "to", "for", "and", "or",
    "is", "are", "was", "were", "be", "by", "with", "from", "has",
    "have", "had", "that", "this", "it", "its", "their",
    "select", "where", "from", "group", "order", "limit", "having",
    "count", "sum", "avg", "max", "min", "as", "t", "distinct",
    "join", "on", "by", "desc", "asc", "between", "like", "null",
}


def _meaningful_tokens(text: str):
    """Tokenize and remove SQL/natural-language stopwords."""
    return {x for x in re.findall(r"[a-zA-Z0-9]+", text.lower())
            if x not in _STOP and len(x) >= 2}


def _is_decisive_boolean_sql(sql: str, rows) -> bool:
    """Check if SQL produces a clear True/False signal.

    Decisive patterns:
      - COUNT(*) / MAX(col) / MIN(col) / AVG(col) returning a scalar
      - WHERE col = specific_value returning a narrow filtered set
      - GROUP BY + COUNT showing a distribution
      - ORDER BY + LIMIT 1 for superlative queries
    """
    sql_upper = sql.upper().replace("  ", " ")

    has_filter = "WHERE" in sql_upper or "HAVING" in sql_upper
    has_aggregate = any(fn in sql_upper for fn in
                        ("COUNT(", "SUM(", "AVG(", "MAX(", "MIN("))
    has_group = "GROUP BY" in sql_upper
    has_limit = "LIMIT" in sql_upper

    if not (has_filter or has_aggregate or has_group or has_limit):
        return False

    if rows is None or len(rows) == 0:
        return has_filter  # empty WHERE result is a clear False signal

    # Scalar result (COUNT, MAX, AVG) → decisive
    if len(rows) == 1 and rows[0] and len(rows[0]) == 1:
        return True

    # Small filtered set relative to query output → decisive
    if has_filter and len(rows) <= 5:
        return True

    # Grouped distribution → decisive
    if has_group:
        return True

    # Superlative (ORDER + LIMIT 1) → decisive
    if has_limit and len(rows) == 1:
        return True

    return False


def _is_boolean_task(sample: Dict[str, Any]) -> bool:
    # Treat TabFact label-only 0/1 as boolean. Generic QA should use answer/gold_answer.
    return "answer" not in sample and "gold_answer" not in sample and isinstance(sample.get("label"), int) and sample.get("label") in (0, 1)


def compute_execution_likelihood(program_sample: Dict[str, Any], original_sample: Dict[str, Any],
                                  use_gold: bool = False) -> float:
    """Score a candidate program by executing its SQL on the actual table.

    Args:
        program_sample: candidate program with parse_tree or chain
        original_sample: input sample with tables, question/statement
        use_gold: if True, reward programs whose output matches the gold
                  answer/label.  **Only for oracle/ablation studies.**
                  Must be False in formal experiments to avoid label leakage.
    """
    tables = _get_tables(original_sample)
    if not tables:
        return 0.01
    conn = get_sqlite_connection_for_sample(original_sample, tables)
    if conn is None:
        return 0.05

    tree = program_sample.get("parse_tree")
    sql, err = compile_tree_to_sql(tree, tables) if tree else compile_chain_to_sql(program_sample, tables)
    if not sql:
        return 0.05
    rows, exec_err = execute_sql(sql, conn)
    if exec_err:
        return 0.15

    # ── Boolean tasks (e.g. TabFact) ────────────────────────────
    if _is_boolean_task(original_sample):
        statement = original_sample.get("cleaned_statement") or original_sample.get("statement") or original_sample.get("question") or ""
        answer, confidence = judge_claim_from_result(statement, rows, sql)
        complexity = _program_complexity_bonus(sql)

        if use_gold:
            matches = answer == (original_sample.get("label") == 1)
            base = 0.90 if matches else 0.10
            return min(0.98, base * confidence + complexity)

        # ── Formal mode — no label leakage ────────────────────
        # Score by SQL structure: predicate, aggregate, grouping,
        # semantic alignment with question.  No gold label used.
        question = _get_question(original_sample).lower()
        sql_upper = sql.upper()

        q_tokens = _meaningful_tokens(question)
        sql_tokens = _meaningful_tokens(sql.lower())
        alignment = len(q_tokens & sql_tokens)

        # Base: below any feature-enhanced program, above trivial
        score = 0.25

        # Decisive boolean SQL gets strong reward
        if _is_decisive_boolean_sql(sql, rows):
            score += 0.30

        # Predicate structure
        if "WHERE" in sql_upper or "HAVING" in sql_upper:
            score += 0.10

        # Aggregation
        if any(fn in sql_upper for fn in ("COUNT(", "SUM(", "AVG(", "MAX(", "MIN(")):
            score += 0.10

        # Grouping
        if "GROUP BY" in sql_upper:
            score += 0.05

        # Superlative
        if "ORDER BY" in sql_upper and "LIMIT" in sql_upper:
            score += 0.05

        # Semantic alignment with question
        score += min(alignment * 0.05, 0.20)

        # Empty filtered result — weak but meaningful negation signal
        if (not rows or len(rows) == 0) and ("WHERE" in sql_upper or "HAVING" in sql_upper):
            score += 0.03

        # Penalize trivial queries
        if _is_trivial_select(sql):
            score -= 0.35

        return round(min(0.92, max(0.08, score)), 4)

    # ── QA / value-extraction tasks ─────────────────────────────
    result = _extract_result(rows)

    if use_gold:
        gold = _get_gold(original_sample)
        mc_gold_value = _get_mc_gold_value(original_sample)
        if mc_gold_value is not None:
            gold = mc_gold_value
        if gold is not None:
            if _compare_answer(result, gold):
                return 0.95
            if _soft_contains(result, gold):
                return 0.80
            return 0.10 if result is not None else 0.05

    # Formal mode — score by result quality (no gold answer)
    if result is None:
        return 0.20
    expected = _infer_expected_result_type(_get_question(original_sample))
    got = _get_result_type(result)
    complexity = _program_complexity_bonus(sql)

    q_tokens = _meaningful_tokens(_get_question(original_sample))
    sql_tokens = _meaningful_tokens(sql)
    alignment = len(q_tokens & sql_tokens)

    base = 0.70 if expected == got else 0.50
    score = base + complexity + min(alignment * 0.05, 0.20)

    if _is_trivial_select(sql):
        score -= 0.35

    return round(min(0.92, max(0.08, score)), 4)



def _first_scalar(rows: Optional[List[Tuple[Any, ...]]]) -> Any:
    if not rows:
        return None
    if len(rows) == 1 and rows[0] and len(rows[0]) == 1:
        return rows[0][0]
    return None


def judge_claim_from_result(statement: str, rows: Optional[List[Tuple[Any, ...]]], sql: str = "") -> Tuple[bool, float]:
    """Claim-aware boolean judge without using the gold label.

    The old mapping treated any non-zero scalar as True.  That is unsafe for
    claims such as "there are exactly 3 ..." where COUNT(*)=2 should be False.
    This function reads comparison cues from the claim and compares them with
    the executed scalar result when possible.
    """
    s = str(statement or "").lower()
    scalar = _first_scalar(rows)

    # Empty filtered result is strong negative evidence, especially for
    # existential claims.  For negated claims it can support True.
    negated = any(x in s for x in [" no ", "none", "never", "not ", "neither", "without"])
    if not rows:
        return (True, 0.72) if negated else (False, 0.72)

    # Numeric comparisons: COUNT/SUM/AVG/MAX/MIN scalar against number in claim.
    nums = re.findall(r"(?<![A-Za-z])[-+]?\d+(?:\.\d+)?", s)
    scalar_num = _parse_number(scalar)
    if scalar_num is not None and nums:
        # Prefer the last number for claims like "in 2012 there were 3 ...".
        claim_num = float(nums[-1])
        if any(x in s for x in ["at least", "no fewer than", "not less than", "greater than or equal"]):
            return (scalar_num >= claim_num, 0.88)
        if any(x in s for x in ["more than", "greater than", "over", "above", "exceed"]):
            return (scalar_num > claim_num, 0.88)
        if any(x in s for x in ["at most", "no more than", "not more than", "less than or equal"]):
            return (scalar_num <= claim_num, 0.88)
        if any(x in s for x in ["less than", "fewer than", "under", "below"]):
            return (scalar_num < claim_num, 0.88)
        if any(x in s for x in ["exactly", "there are", "there were", "has", "have", "had", "is", "are", "was", "were"]):
            return (abs(scalar_num - claim_num) <= 1e-6, 0.88)

    # Negation over counts or existence.
    if negated:
        if scalar_num is not None:
            return (abs(scalar_num) <= 1e-9, 0.82)
        return (False, 0.60) if rows else (True, 0.72)

    # Fallback to the older existence/scalar interpretation.
    return _map_sql_result_to_bool(rows, sql)


def _choice_letter_from_result(result: Any, choices: List[str]) -> str:
    """Map an execution result to a multiple-choice letter using choices only."""
    if result is None or not choices:
        return "?"
    raw = result
    if isinstance(result, list) and result and isinstance(result[0], (list, tuple)):
        raw = result[0][0]
    val = str(raw).strip()
    if val.upper() in {"A", "B", "C", "D", "E", "F"}:
        return val.upper()
    for c in choices:
        parts = str(c).split(")", 1)
        if len(parts) != 2:
            continue
        letter, choice_val = parts[0].strip().upper(), parts[1].strip()
        if _compare_answer(val, choice_val) or _soft_contains(val, choice_val):
            return letter
    return "?"


def _map_sql_result_to_bool(rows: Optional[List[Tuple[Any, ...]]], sql: str = "") -> Tuple[bool, float]:
    """Map SQL result to a boolean answer with confidence.

    Returns (bool_answer, confidence) where confidence is 0.0–1.0.
    Programs that perform actual verification (WHERE/aggregate/grouping)
    produce higher-confidence answers than trivial SELECT-all queries.
    """
    if not rows:
        return (False, 0.7)
    # Trivial SELECT * FROM t without any logic → the result tells us
    # nothing about the claim.  Default toward True (some data exists)
    # but assign very low confidence so better programs win in posterior.
    if _is_trivial_select(sql):
        return (True, 0.15)
    if len(rows) == 1 and len(rows[0]) == 1:
        v = rows[0][0]
        if v is None:
            return (False, 0.7)
        if isinstance(v, (int, float)):
            return (float(v) != 0.0, 0.85)
        sv = str(v).strip().lower()
        if sv in {"true", "yes", "1", "t"}:
            return (True, 0.80)
        if sv in {"false", "no", "0", "f"}:
            return (False, 0.80)
        # Non-empty string result from a filtered query → True
        return (True, 0.60)
    # Multiple rows returned by a meaningful query → evidence exists
    return (True, 0.65)
    """Reward programs that do actual verification work.

    Programs that only SELECT columns without filtering, grouping, sorting,
    or aggregating cannot meaningfully verify a fact.  This bonus shifts
    posterior mass toward programs that perform genuine reasoning steps.
    """
    sql_upper = sql.upper().replace("  ", " ").replace("  ", " ")
    bonus = 0.0
    if " WHERE " in sql_upper:
        bonus += 0.15
    if any(kw in sql_upper for kw in ("GROUP BY", "ORDER BY", "LIMIT")):
        bonus += 0.05
    if any(kw in sql_upper for kw in ("COUNT(", "SUM(", "AVG(", "MAX(", "MIN(")):
        bonus += 0.10
    if any(kw in sql_upper for kw in ("JOIN", "UNION", "HAVING", "DISTINCT")):
        bonus += 0.10
    return bonus


def _program_complexity_bonus(sql: str) -> float:
    """Reward programs that do actual verification work.

    Programs that only SELECT columns without filtering, grouping, sorting,
    or aggregating cannot meaningfully verify a fact.  This bonus shifts
    posterior mass toward programs that perform genuine reasoning steps.
    """
    sql_upper = sql.upper().replace("  ", " ").replace("  ", " ")
    bonus = 0.0
    if " WHERE " in sql_upper:
        bonus += 0.15
    if any(kw in sql_upper for kw in ("GROUP BY", "ORDER BY", "LIMIT")):
        bonus += 0.05
    if any(kw in sql_upper for kw in ("COUNT(", "SUM(", "AVG(", "MAX(", "MIN(")):
        bonus += 0.10
    if any(kw in sql_upper for kw in ("JOIN", "UNION", "HAVING", "DISTINCT")):
        bonus += 0.10
    return bonus


def _is_trivial_select(sql: str) -> bool:
    """Return True if the SQL is just SELECT ... FROM t with no real logic."""
    sql_upper = sql.upper().replace("  ", " ").strip()
    has_filter = any(kw in sql_upper for kw in (
        "WHERE", "GROUP BY", "ORDER BY", "LIMIT", "HAVING",
        "COUNT(", "SUM(", "AVG(", "MAX(", "MIN(",
        "JOIN", "UNION", "DISTINCT"))
    return not has_filter


def score_execution_with_sql(program_sample: Dict[str, Any], original_sample: Dict[str, Any]) -> Dict[str, Any]:
    tables = _get_tables(original_sample)
    if not tables:
        return {"answer": None, "evidence_cells": [], "program": None, "execution_result": None, "likelihood": 0.01}
    conn = get_sqlite_connection_for_sample(original_sample, tables)
    if conn is None:
        return {"answer": None, "evidence_cells": [], "program": None, "execution_result": None, "likelihood": 0.05}
    tree = program_sample.get("parse_tree")
    sql, err = compile_tree_to_sql(tree, tables) if tree else compile_chain_to_sql(program_sample, tables)
    if not sql:
        return {"answer": None, "evidence_cells": [], "program": None, "execution_result": None, "likelihood": 0.05}
    rows, exec_err = execute_sql(sql, conn)
    likelihood = compute_execution_likelihood(program_sample, original_sample)
    if _is_boolean_task(original_sample):
        statement = original_sample.get("cleaned_statement") or original_sample.get("statement") or original_sample.get("question") or ""
        answer, _ = judge_claim_from_result(statement, rows, sql)
    else:
        answer = _extract_result(rows)
        if original_sample.get("choices"):
            mapped = _choice_letter_from_result(answer, original_sample.get("choices") or [])
            if mapped != "?":
                answer = mapped
    return {
        "answer": answer,
        "evidence_cells": _collect_evidence(tree, tables, conn) if tree else [],
        "program": sql,
        "execution_result": rows,
        "likelihood": likelihood,
    }


def _collect_evidence(parse_tree: Dict[str, Any], tables: Dict[str, List[List[Any]]], conn: sqlite3.Connection) -> List[str]:
    evidence: List[str] = []
    try:
        ctx = _SqlContext(tables)
        _collect_where_only(parse_tree, ctx)
        t = _safe_ident(ctx.from_table)
        where = " WHERE " + " AND ".join(ctx.where_conds) if ctx.where_conds else ""
        rows, err = execute_sql(f"SELECT * FROM {t}{where} LIMIT 5", conn)
        if not rows:
            rows, err = execute_sql(f"SELECT * FROM {t} LIMIT 5", conn)
        cur = conn.execute(f"SELECT * FROM {t} LIMIT 0")
        cols = [d[0] for d in cur.description]
        for r in rows or []:
            evidence.append("; ".join(f"{cols[i]}={r[i]}" for i in range(min(len(cols), len(r)))))
    except Exception:
        pass
    return evidence


def _collect_where_only(node: Dict[str, Any], ctx: _SqlContext) -> None:
    if node.get("terminal") in {"SelectRows", "FilterYear"}:
        _compile_terminal(node.get("terminal"), node.get("params", {}), ctx)
    for child in node.get("children", []):
        _collect_where_only(child, ctx)


def _extract_result(rows: Optional[List[Tuple[Any, ...]]]) -> Any:
    if not rows:
        return None
    if len(rows) == 1 and len(rows[0]) == 1:
        return rows[0][0]
    # Flatten one-column multi-row answers into a list.
    if all(len(r) == 1 for r in rows):
        vals = [r[0] for r in rows]
        return vals[0] if len(vals) == 1 else vals
    return [list(r) for r in rows[:20]]


def _norm_text(x: Any) -> str:
    return re.sub(r"\s+", " ", str(x).strip().lower())


def _compare_answer(pred: Any, gold: Any) -> bool:
    if isinstance(gold, list):
        return any(_compare_answer(pred, g) for g in gold)
    if isinstance(pred, list):
        return any(_compare_answer(p, gold) for p in pred)
    pn = _parse_number(pred)
    gn = _parse_number(gold)
    if pn is not None and gn is not None:
        if abs(gn) < 1e-12:
            return abs(pn - gn) < 1e-6
        return abs(pn - gn) / abs(gn) <= 5e-3
    return _norm_text(pred) == _norm_text(gold)


def _soft_contains(pred: Any, gold: Any) -> bool:
    if pred is None:
        return False
    if isinstance(gold, list):
        return any(_soft_contains(pred, g) for g in gold)
    if isinstance(pred, list):
        return any(_soft_contains(p, gold) for p in pred)
    return _norm_text(gold) in _norm_text(pred) or _norm_text(pred) in _norm_text(gold)


def _infer_expected_result_type(question: str) -> str:
    q = question.lower()
    if any(w in q for w in ["how many", "count", "number of"]):
        return "int"
    if any(w in q for w in ["average", "mean", "sum", "total", "difference", "increase", "decrease", "percentage", "ratio"]):
        return "float"
    if any(w in q for w in ["which", "who", "what", "name", "list"]):
        return "list"
    return "scalar"


def _get_result_type(result: Any) -> str:
    if isinstance(result, bool):
        return "bool"
    if isinstance(result, int):
        return "int"
    if isinstance(result, float):
        return "float"
    if isinstance(result, list):
        return "list"
    return "scalar"


def score_all_candidates(candidates: List[Tuple[Dict[str, Any], float]], original_sample: Dict[str, Any]) -> List[Tuple[Dict[str, Any], float, float]]:
    return [(prog, compute_execution_likelihood(prog, original_sample), score) for prog, score in candidates]
