from __future__ import annotations
"""TabFact unified candidate-ours adapter.

This module provides two TabFact paths:

1) schema_rule: a lightweight evidence-chain CandidateProgramEngine baseline.
2) all / agent90 / candidate_ours: the high-accuracy TabFact candidate-ours
   path.  It wraps Agent90 self-consistency, adjudication, and specialized
   verifiers as a candidate-program posterior framework:

   - LLM votes are semantic candidate programs / evidence hypotheses.
   - Vote aggregation is answer-level posterior marginalization.
   - Adjudication is low-confidence local repair.
   - Specialized verifier is execution/evidence-grounded risk correction.

The high-accuracy path intentionally avoids the earlier weak schema-rule-only
selector that achieved high oracle coverage but poor ranking accuracy.
"""

from typing import Any, Dict, List, Optional, Tuple
import os
import re
import json
import pickle
import copy
import pandas as pd

try:
    from tqdm import tqdm
except Exception:  # pragma: no cover
    def tqdm(x, **kwargs):
        return x

from candidate_framework import TaskContext, CandidateProgramEngine
from candidate_framework.core import CandidateProgram, CandidateGenerator
from adapters.fact_verify import EvidenceExecutor, EvidenceVerifier, EvidenceRepairer


# ---------------------------------------------------------------------------
# Common helpers
# ---------------------------------------------------------------------------

def _norm(x: Any) -> str:
    return re.sub(r"\s+", " ", str(x or "").replace("\n", " ").strip()).lower()


def _parse_num(x: Any) -> Optional[float]:
    m = re.search(r"[-+]?\d[\d,]*(?:\.\d+)?", str(x or ""))
    if not m:
        return None
    try:
        return float(m.group(0).replace(",", ""))
    except Exception:
        return None


def _label_to_bool(label: Any) -> Optional[bool]:
    if isinstance(label, bool):
        return bool(label)
    try:
        if int(label) == 1:
            return True
        if int(label) == 0:
            return False
    except Exception:
        pass
    s = str(label).strip().lower()
    if s in {"true", "1", "yes", "entailed", "supported"}:
        return True
    if s in {"false", "0", "no", "refuted", "unsupported"}:
        return False
    return None


def sample_to_dataframe(sample: Dict[str, Any]) -> pd.DataFrame:
    table = sample.get("table_text")
    if not table and isinstance(sample.get("tables"), dict):
        table = sample["tables"].get("t") or sample["tables"].get("main")
    if not isinstance(table, list) or not table:
        return pd.DataFrame()
    headers = [str(h) for h in table[0]]
    rows = table[1:]
    return pd.DataFrame(rows, columns=headers)


def _numeric_columns(df: pd.DataFrame) -> List[str]:
    out: List[str] = []
    for col in df.columns:
        vals = [_parse_num(v) for v in df[col].tolist()]
        if any(v is not None for v in vals):
            out.append(str(col))
    return out


# ---------------------------------------------------------------------------
# Conservative schema-rule baseline.  This is NOT the final high-accuracy Ours;
# it is useful for internal ablation only.
# ---------------------------------------------------------------------------

class TabFactHeuristicEvidenceGenerator(CandidateGenerator):
    """Generate conservative evidence-chain candidates for ablation."""

    def __init__(self, max_candidates: int = 16):
        self.max_candidates = max_candidates

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        df = ctx.data if isinstance(ctx.data, pd.DataFrame) else pd.DataFrame(ctx.data)
        claim = _norm(ctx.question)
        if df.empty:
            return []
        chains: List[List[Dict[str, Any]]] = []
        num_cols = _numeric_columns(df)
        text_cols = [str(c) for c in df.columns if str(c) not in set(num_cols)]

        if re.search(r"\bhighest\b|\bmaximum\b|\blargest\b|\bmost\b", claim):
            for ncol in num_cols[:4]:
                for tcol in text_cols[:4]:
                    for val in df[tcol].astype(str).head(100).tolist():
                        if len(_norm(val)) >= 3 and _norm(val) in claim:
                            chains.append([{"op": "argmax", "column": ncol}, {"op": "check", "column": tcol, "cmp": "==", "value": val}])
                            break
        if re.search(r"\blowest\b|\bminimum\b|\bsmallest\b|\bleast\b", claim):
            for ncol in num_cols[:4]:
                for tcol in text_cols[:4]:
                    for val in df[tcol].astype(str).head(100).tolist():
                        if len(_norm(val)) >= 3 and _norm(val) in claim:
                            chains.append([{"op": "argmin", "column": ncol}, {"op": "check", "column": tcol, "cmp": "==", "value": val}])
                            break

        added = 0
        for col in df.columns:
            for val in df[col].astype(str).head(200).tolist():
                v = _norm(val)
                if len(v) >= 3 and v in claim:
                    chains.append([{"op": "locate", "column": str(col), "contains": val}, {"op": "check_exists"}])
                    added += 1
                    if added >= 8:
                        break
            if added >= 8:
                break

        m = re.search(r"(?:greater than|more than|over|above)\s+([-+]?\d[\d,]*(?:\.\d+)?)", claim)
        if m:
            val = float(m.group(1).replace(",", ""))
            for col in num_cols[:4]:
                chains.append([{"op": "check", "column": col, "cmp": ">", "value": val}])
        m = re.search(r"(?:less than|under|below)\s+([-+]?\d[\d,]*(?:\.\d+)?)", claim)
        if m:
            val = float(m.group(1).replace(",", ""))
            for col in num_cols[:4]:
                chains.append([{"op": "check", "column": col, "cmp": "<", "value": val}])

        if not chains:
            chains.append([{"op": "check_exists"}])

        programs: List[CandidateProgram] = []
        seen = set()
        for i, chain in enumerate(chains):
            key = json.dumps(chain, sort_keys=True, default=str)
            if key in seen:
                continue
            seen.add(key)
            programs.append(CandidateProgram(chain, "evidence_chain", "schema_rule", f"tabfact_schema_rule:{i}"))
            if len(programs) >= self.max_candidates:
                break
        return programs


def _solve_schema_rule_sample(sample: Dict[str, Any], max_candidates: int = 16, max_repair_rounds: int = 0) -> Dict[str, Any]:
    df = sample_to_dataframe(sample)
    claim = sample.get("cleaned_statement") or sample.get("statement") or sample.get("question") or ""
    ctx = TaskContext(
        task_id=str(sample.get("id", "tabfact_sample")),
        question=claim,
        data=df,
        schema=list(df.columns),
        task_type="tabfact_schema_rule_evidence_chain",
        metadata={"table_caption": sample.get("table_caption")},
    )
    engine = CandidateProgramEngine(
        generators=[TabFactHeuristicEvidenceGenerator(max_candidates=max_candidates)],
        executor=EvidenceExecutor(),
        verifier=EvidenceVerifier(),
        repairers=[EvidenceRepairer()],
        max_repair_rounds=max_repair_rounds,
    )
    solved = engine.solve(ctx)
    selected = solved.get("selected_candidate")
    out = dict(sample)
    out.update({
        "answer": solved.get("answer"),
        "pred_answer": solved.get("answer"),
        "program": selected.program.content if selected else None,
        "program_type": selected.program.program_type if selected else "evidence_chain",
        "answer_mass": solved.get("answer_mass"),
        "answer_source": "schema_rule_candidate_program",
        "candidate_framework_engine_used": True,
        "candidate_ours_mode": "schema_rule_only",
        "chain": [{"operation_name": "candidate_framework_fact_verify", "parameter_and_conf": [["true" if bool(solved.get("answer")) else "false", 1.0]]}],
        "candidate_framework": {
            "engine_used": True,
            "task_type": "tabfact_schema_rule_evidence_chain",
            "num_initial_candidates": solved.get("num_initial_candidates"),
            "num_evaluated_candidates": solved.get("num_evaluated_candidates"),
            "selected_program_type": selected.program.program_type if selected else None,
            "selected_source": selected.program.source if selected else None,
            "selected_posterior": selected.posterior if selected else None,
            "ranked_candidates": [c.to_dict() for c in solved.get("ranked_candidates", [])[:20]],
        },
    })
    return out


# ---------------------------------------------------------------------------
# High-accuracy TabFact candidate_ours: Agent90 wrapped as candidate posterior.
# ---------------------------------------------------------------------------

def _agent90_to_candidate_framework_record(result: Dict[str, Any], report: Optional[Dict[str, Any]] = None, *, posterior_selection: str = "answer_marginal", adjudicate: bool = True, verifier: bool = True, false_rescue: bool = True, disable_structural_prior: bool = False) -> Dict[str, Any]:
    """Attach candidate-framework style diagnostics to an Agent90 result."""
    report = report or {}
    ag = result.get("agent90") or {}
    posterior_mode = str(posterior_selection or ag.get("posterior_selection") or report.get("posterior_selection") or "answer_marginal").lower().strip()
    vote_summary = ag.get("vote_summary") or report.get("vote_summary") or {}
    answer = result.get("answer")
    answer_key = "bool:true" if answer is True else "bool:false" if answer is False else "none"

    # Convert vote buckets into answer posterior-like mass.  This supports the
    # paper narrative: answer-level posterior marginalization over multiple
    # semantic evidence candidates.
    total_weight = 0.0
    answer_mass: Dict[str, float] = {}
    for k, v in vote_summary.items():
        try:
            w = float(v.get("weight", v.get("count", 0.0)) or 0.0)
        except Exception:
            w = 0.0
        total_weight += max(w, 0.0)
        kk = "bool:true" if str(k).lower() == "true" else "bool:false" if str(k).lower() == "false" else str(k)
        answer_mass[kk] = answer_mass.get(kk, 0.0) + max(w, 0.0)
    if total_weight > 0:
        answer_mass = {k: v / total_weight for k, v in answer_mass.items()}

    sorted_mass = sorted(answer_mass.items(), key=lambda kv: kv[1], reverse=True)
    second = sorted_mass[1][1] if len(sorted_mass) > 1 else 1e-12
    best = sorted_mass[0][1] if sorted_mass else 0.0
    bf = best / max(second, 1e-12)

    selected_source = result.get("answer_source") or report.get("answer_source") or "agent90_candidate_posterior"
    result["candidate_framework_engine_used"] = True
    result["candidate_ours_mode"] = "agent90_candidate_posterior"
    result["answer_mass"] = answer_mass
    result["answer_bayes_factor"] = bf
    result["program"] = {
        "type": "agent90_semantic_evidence_posterior",
        "votes": ag.get("votes"),
        "vote_summary": vote_summary,
        "adjudicated": ag.get("adjudicated"),
        "verifier": ag.get("v11_verifier"),
        "false_rescue": ag.get("tabfact_v30_false_rescue"),
        "risk_tags": ag.get("claim_risk_tags"),
    }
    result["program_type"] = "agent90_semantic_evidence_posterior"
    result["chain"] = [{
        "operation_name": "candidate_framework_fact_verify_agent90",
        "parameter_and_conf": [["true" if answer is True else "false" if answer is False else "invalid", float(best or 0.0)]],
    }]
    result["candidate_framework"] = {
        "engine_used": True,
        "task_type": "tabfact_agent90_candidate_posterior",
        "selected_source": selected_source,
        "selected_program_type": "agent90_semantic_evidence_posterior",
        "answer_key": answer_key,
        "answer_mass": answer_mass,
        "answer_bayes_factor": bf,
        "vote_summary": vote_summary,
        "vote_margin": ag.get("vote_margin") or report.get("vote_margin"),
        "posterior_selection": posterior_mode,
        "disable_structural_prior": bool(disable_structural_prior),
        "adjudicated": bool(ag.get("adjudicated")),
        "adjudication_enabled": bool(adjudicate),
        "verifier_enabled": bool(verifier),
        "verifier_result": ag.get("v11_verifier"),
        "false_rescue_enabled": bool(false_rescue),
        "false_rescue_result": ag.get("tabfact_v30_false_rescue"),
        "claim_risk_tags": ag.get("claim_risk_tags"),
        "innovation_mapping": {
            "structure_prior": "disabled_plain_table_prompt" if disable_structural_prior else "table rows/columns are formatted as evidence context and claim-risk tags guide verification",
            "candidate_generation": "multiple LLM semantic evidence votes plus optional adjudication candidate",
            "execution_feedback": "specialized verifier checks numeric, superlative, score, and multi-evidence risks",
            "local_repair": "disabled" if not (adjudicate or verifier or false_rescue) else "adjudication, deterministic verifier, and strict false-rescue audit override only bounded risky cases",
            "answer_posterior": "program_map_disabled" if posterior_mode == "program_map" else "vote-summary weights are marginalized at boolean answer level",
        },
    }
    return result


def solve_tabfact_dataset_agent90_candidate_ours(
    dataset: List[Dict[str, Any]],
    llm: Any,
    llm_options: Optional[Dict[str, Any]] = None,
    votes: int = 3,
    max_table_chars: int = 20000,
    adjudicate: bool = True,
    verifier: bool = True,
    false_rescue: bool = True,
    posterior_selection: str = "answer_marginal",
    disable_structural_prior: bool = False,
    cache_dir: str = "./results/agent90_cache_v19",
    debug: bool = False,
) -> Tuple[List[Dict[str, Any]], List[Optional[Dict[str, Any]]]]:
    from utils.agent_engine import execute_agent90_dataset

    results, reports = execute_agent90_dataset(
        all_samples=dataset,
        llm=llm,
        llm_options=llm_options or {},
        dataset_name="tabfact",
        votes=votes,
        max_table_chars=max_table_chars,
        adjudicate=adjudicate,
        verifier=verifier,
        false_rescue=false_rescue,
        posterior_selection=posterior_selection,
        disable_structural_prior=disable_structural_prior,
        debug=debug,
        cache_dir=cache_dir,
    )
    out: List[Dict[str, Any]] = []
    for i, sample in enumerate(dataset):
        r = results[i] if i < len(results) and results[i] is not None else None
        rep = reports[i] if i < len(reports) else None
        if r is None:
            r = copy.deepcopy(sample)
            r.update({"answer": None, "pred_answer": None, "answer_source": "agent90_missing"})
        out.append(_agent90_to_candidate_framework_record(r, rep, posterior_selection=posterior_selection, adjudicate=adjudicate, verifier=verifier, false_rescue=false_rescue, disable_structural_prior=disable_structural_prior))
    return out, reports


# ---------------------------------------------------------------------------
# Public API used by run_fact_verification.py
# ---------------------------------------------------------------------------

def solve_tabfact_sample_with_framework(
    sample: Dict[str, Any],
    max_candidates: int = 16,
    candidate_sources: str = "schema_rule",
    max_repair_rounds: int = 0,
) -> Dict[str, Any]:
    """Single-sample schema-rule baseline for backward compatibility.

    High-accuracy candidate_ours requires an LLM and is therefore exposed at the
    dataset level via solve_tabfact_dataset_with_framework(..., llm=...).
    """
    return _solve_schema_rule_sample(sample, max_candidates=max_candidates, max_repair_rounds=max_repair_rounds)


def solve_tabfact_dataset_with_framework(
    dataset: List[Dict[str, Any]],
    max_candidates: int = 16,
    candidate_sources: str = "all",
    max_repair_rounds: int = 1,
    llm: Any = None,
    llm_options: Optional[Dict[str, Any]] = None,
    result_dir: Optional[str] = None,
    votes: int = 3,
    max_table_chars: int = 20000,
    adjudicate: bool = True,
    verifier: bool = True,
    false_rescue: bool = True,
    posterior_selection: str = "answer_marginal",
    disable_safe_repairs: bool = False,
    disable_structural_prior: bool = False,
    debug: bool = False,
) -> Tuple[List[Dict[str, Any]], List[Optional[Dict[str, Any]]]]:
    """Solve TabFact under the unified candidate-ours protocol.

    candidate_sources:
      - schema_rule: internal ablation, no LLM, low accuracy expected.
      - all / agent90 / candidate_ours / llm: high-accuracy unified Ours.
    """
    src = str(candidate_sources or "all").lower().strip()
    if src in {"schema", "schema_rule", "schema-rule", "rule", "rules"}:
        solved = [_solve_schema_rule_sample(s, max_candidates=max_candidates, max_repair_rounds=0 if disable_safe_repairs else max_repair_rounds)
                  for s in tqdm(dataset, total=len(dataset), desc="Solving TabFact schema_rule")]
        return solved, [None] * len(solved)

    if llm is None:
        raise ValueError(
            "TabFact candidate_ours requires an LLM. Pass llm=... or run with --model_name and API key. "
            "Use --candidate_sources schema_rule for the no-LLM ablation."
        )
    if disable_safe_repairs:
        adjudicate = False
        verifier = False
        false_rescue = False
    posterior_mode = str(posterior_selection or "answer_marginal").lower().strip()
    cache_suffix = f"agent90_cache_votes{votes}_posterior-{posterior_mode}_adj-{int(bool(adjudicate))}_ver-{int(bool(verifier))}_falseaudit-{int(bool(false_rescue))}_struct-{int(not disable_structural_prior)}_chars{int(max_table_chars or 0)}"
    cache_dir = os.path.join(result_dir or "results/tabfact_candidate_ours", cache_suffix)
    print(
        f"[TabFact candidate_ours] agent90 posterior enabled; samples={len(dataset)}, "
        f"votes={votes}, adjudicate={adjudicate}, verifier={verifier}, false_rescue={false_rescue}, posterior={posterior_mode}, disable_safe_repairs={disable_safe_repairs}, disable_structural_prior={disable_structural_prior}",
        flush=True,
    )
    return solve_tabfact_dataset_agent90_candidate_ours(
        dataset=dataset,
        llm=llm,
        llm_options=llm_options,
        votes=votes,
        max_table_chars=max_table_chars,
        adjudicate=adjudicate,
        verifier=verifier,
        false_rescue=false_rescue,
        posterior_selection=posterior_mode,
        disable_structural_prior=disable_structural_prior,
        cache_dir=cache_dir,
        debug=debug,
    )


def compute_tabfact_metrics(result_samples: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = len(result_samples)
    correct = 0
    invalid = 0
    false_rescue_triggered = 0
    false_rescue_applied = 0
    false_rescue_correct_after_apply = 0
    rows = []
    for s in result_samples:
        pred = s.get("answer")
        label_bool = _label_to_bool(s.get("label"))
        valid = isinstance(pred, bool)
        if not valid:
            invalid += 1
        ok = valid and label_bool is not None and pred == label_bool
        if ok:
            correct += 1

        cf = s.get("candidate_framework") or {}
        false_rescue_result = cf.get("false_rescue_result")
        if not isinstance(false_rescue_result, dict):
            false_rescue_result = ((s.get("agent90") or {}).get("tabfact_v30_false_rescue"))
        rescue_triggered = bool(isinstance(false_rescue_result, dict) and false_rescue_result.get("triggered"))
        rescue_applied = bool(isinstance(false_rescue_result, dict) and false_rescue_result.get("applied"))
        false_rescue_triggered += int(rescue_triggered)
        false_rescue_applied += int(rescue_applied)
        false_rescue_correct_after_apply += int(rescue_applied and ok)

        rows.append({
            "id": s.get("id"),
            "statement": s.get("statement"),
            "prediction": pred,
            "label": s.get("label"),
            "correct": bool(ok),
            "answer_source": s.get("answer_source"),
            "candidate_ours_mode": s.get("candidate_ours_mode"),
            "answer_bayes_factor": s.get("answer_bayes_factor"),
            "false_rescue_triggered": rescue_triggered,
            "false_rescue_applied": rescue_applied,
            "false_rescue_result": false_rescue_result,
            "candidate_framework": s.get("candidate_framework"),
        })
    valid_total = max(total - invalid, 0)
    metrics = {
        "total": total,
        "correct": correct,
        "invalid": invalid,
        "accuracy": correct / max(total, 1),
        "invalid_rate": invalid / max(total, 1),
        "valid_total": valid_total,
        "valid_accuracy": correct / max(valid_total, 1) if valid_total else 0.0,
        "candidate_framework_engine_used": True,
        "framework_task_type": "tabfact_agent90_candidate_posterior",
        "false_rescue_triggered": false_rescue_triggered,
        "false_rescue_applied": false_rescue_applied,
        "false_rescue_trigger_rate": false_rescue_triggered / max(total, 1),
        "false_rescue_apply_rate": false_rescue_applied / max(total, 1),
        "false_rescue_accept_rate_given_trigger": false_rescue_applied / max(false_rescue_triggered, 1),
        "false_rescue_correct_after_apply": false_rescue_correct_after_apply,
    }
    return {"metrics": metrics, "rows": rows}
