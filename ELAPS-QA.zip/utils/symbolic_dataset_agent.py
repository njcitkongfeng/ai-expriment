from __future__ import annotations
"""TQA-Bench SymDataset direct SQL agent v40 leakage-safe semantic repair (additive module).

This module does NOT use data/tqa_bench/test.jsonl and does NOT assume a fixed
mapping between question choices and db_path.  It reads the existing TQA-Bench
resources directly:

    data/tableQA/task.json                 # questions + official Python code
    data/symDataset/<scale>/<domain>/*.sqlite  # actual SQLite databases

For each selected (task, scale, sqlite_db) pair, the official Python code is
executed on the selected SQLite database to obtain the gold denotation.  The
LLM is then asked to generate SQLite SELECT/WITH SQL over that exact database;
the SQL execution result is compared with the gold denotation.
"""

import ast
import contextlib
import copy
import csv
import io
import json
import math
import hashlib
import os
import pickle
import re
import time
from pathlib import Path
import sqlite3
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import pandas as pd
except Exception as exc:  # pragma: no cover
    raise ImportError("pandas is required for TQA-Bench gold-code execution. Install: pip install pandas") from exc

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

try:
    from tqdm import tqdm
except Exception:  # pragma: no cover
    def tqdm(x, **kwargs):
        return x

from utils.symbolic_dataset_safe_repairs import (
    leakage_audit_metadata,
    model_visible_sample,
    normalize_prediction_without_gold,
    result_shape_score,
    generate_adaptive_sql_repairs,
)

from utils.multitable_bayes import (
    build_schema_graph,
    schema_graph_summary,
    generate_schema_graph_rule_candidates,
    select_by_multitable_bayes,
    candidate_coverage_with_gold,
    allow_llm_referee_override,
)

from utils.multitable_program_framework import execute_tqa_sql_candidate_pool_via_framework


# ---------------------------------------------------------------------------
# General utilities
# ---------------------------------------------------------------------------

def _safe_filename(x: Any) -> str:
    s = str(x)
    s = re.sub(r"[^a-zA-Z0-9_.-]+", "_", s)
    return s[:180] or "case"


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _make_py_var(name: str) -> str:
    s = re.sub(r"\W+", "_", str(name)).strip("_")
    if not s:
        s = "table"
    if s[0].isdigit():
        s = "_" + s
    return s


def _json_dumps(obj: Any, max_chars: int = 12000) -> str:
    text = json.dumps(obj, ensure_ascii=False, default=str)
    return text if len(text) <= max_chars else text[:max_chars] + " ...[truncated]"


def _clean_sql(sql: str) -> str:
    """Clean SQL extracted from LLM output.

    DeepSeek sometimes returns SQL strings that still contain JSON-style escaped
    double quotes, for example ``N.\"iron\"``.  SQLite treats the backslash as
    a literal token and raises ``unrecognized token: "\"``.  We normalize those
    escapes before executing the query.
    """
    sql = str(sql or "").strip()
    sql = re.sub(r"^```(?:sql)?", "", sql, flags=re.I).strip()
    sql = re.sub(r"```$", "", sql).strip()
    sql = sql.replace('\\"', '"').replace("\\'", "'")
    sql = sql.replace('\\`', '`')
    # Remove trailing commentary after semicolon by keeping first statement only.
    parts = [p.strip() for p in sql.split(";") if p.strip()]
    if parts:
        sql = parts[0]
    return sql.strip()


def _is_safe_select_sql(sql: str) -> bool:
    """Allow read-only SQLite SELECT/WITH queries.

    v32 accidentally blocked the token ``REPLACE``.  That is too strict for
    TQA-Bench because several databases store numbers as strings such as
    ``$100,000,000``; correct SQL must often use SQLite's scalar
    ``REPLACE(...)`` function before ``CAST``.  We still block write/DDL/PRAGMA
    statements.
    """
    s = re.sub(r"--.*?$|/\*.*?\*/", "", str(sql), flags=re.S | re.M).strip().lower()
    if not (s.startswith("select") or s.startswith("with")):
        return False
    forbidden = [
        "insert", "update", "delete", "drop", "alter", "create", "attach",
        "detach", "pragma", "vacuum", "reindex"
    ]
    return not any(re.search(rf"\b{kw}\b", s) for kw in forbidden)


def _extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    s = str(text).strip()
    s = re.sub(r"^```(?:json)?\s*", "", s, flags=re.I).strip()
    s = re.sub(r"\s*```$", "", s).strip()
    try:
        obj = json.loads(s)
        return obj if isinstance(obj, dict) else None
    except Exception:
        pass
    m = re.search(r"\{.*\}", s, flags=re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            return obj if isinstance(obj, dict) else None
        except Exception:
            return None
    return None


def extract_sql_candidates(raw: str) -> List[Dict[str, Any]]:
    """Extract SQL candidates from JSON/fenced/raw LLM output."""
    if not raw:
        return []
    raw = str(raw).strip()
    obj = _extract_json_object(raw)
    items: List[Any] = []
    if isinstance(obj, dict):
        if isinstance(obj.get("queries"), list):
            items.extend(obj["queries"])
        elif isinstance(obj.get("candidates"), list):
            items.extend(obj["candidates"])
        elif isinstance(obj.get("sql"), str):
            items.append(obj)
        elif isinstance(obj.get("query"), str):
            items.append({"sql": obj.get("query"), "rationale": obj.get("rationale")})
    for block in re.findall(r"```(?:sql)?\s*(.*?)```", raw, flags=re.I | re.S):
        if re.search(r"\b(select|with)\b", block, flags=re.I):
            items.append({"sql": block.strip()})
    # Last-resort raw SELECT/WITH snippets.
    for m in re.finditer(r"(?is)\b(with\b.*?|select\b.*?)(?:;|$)", raw):
        sql = m.group(1).strip()
        if len(sql) >= 10:
            items.append({"sql": sql})
    out: List[Dict[str, Any]] = []
    seen = set()
    for item in items:
        if isinstance(item, str):
            d = {"sql": item}
        elif isinstance(item, dict):
            d = dict(item)
            d["sql"] = str(d.get("sql") or d.get("query") or "")
        else:
            continue
        sql = _clean_sql(d.get("sql") or "")
        if not sql or sql in seen:
            continue
        seen.add(sql)
        d["sql"] = sql
        out.append(d)
    return out[:8]


# ---------------------------------------------------------------------------
# Denotation normalization and comparison
# ---------------------------------------------------------------------------

def _is_nan(x: Any) -> bool:
    try:
        return bool(math.isnan(float(x)))
    except Exception:
        return False


def _num(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, bool):
        return float(int(x))
    if isinstance(x, (int, float)) and not _is_nan(x):
        return float(x)
    s = str(x).strip()
    if not s:
        return None
    # Remove common decorations.
    s = s.replace(",", "")
    if s.endswith("%"):
        s = s[:-1]
    m = re.search(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", s)
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None


def _norm_text(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, bytes):
        try:
            x = x.decode("utf-8", errors="ignore")
        except Exception:
            x = str(x)
    s = str(x)
    s = s.replace("\u00a0", " ")
    s = re.sub(r"\s+", " ", s).strip().lower()
    s = re.sub(r"^[\"']|[\"']$", "", s)
    return s


def _flatten_value(x: Any) -> Any:
    """Reduce common SQL/Pandas outputs to scalar/list forms."""
    if x is None:
        return None
    # pandas/numpy scalars.
    try:
        if hasattr(x, "item") and not isinstance(x, (list, tuple, dict, str, bytes)):
            return x.item()
    except Exception:
        pass
    # DataFrame/Series.
    if hasattr(x, "to_dict") and hasattr(x, "shape"):
        try:
            vals = x.values.flatten().tolist()
            return [_flatten_value(v) for v in vals]
        except Exception:
            pass
    if isinstance(x, dict):
        vals = list(x.values())
        if len(vals) == 1:
            return _flatten_value(vals[0])
        return [_flatten_value(v) for v in vals]
    if isinstance(x, (list, tuple, set)):
        vals = list(x)
        if len(vals) == 1:
            return _flatten_value(vals[0])
        return [_flatten_value(v) for v in vals]
    return x


def _sql_rows_to_value(rows: Any) -> Any:
    if not isinstance(rows, list) or not rows:
        return None
    vals = []
    for row in rows:
        if isinstance(row, dict):
            rv = list(row.values())
            if len(rv) == 1:
                vals.append(rv[0])
            else:
                vals.append(tuple(rv))
        elif isinstance(row, (list, tuple)):
            vals.append(row[0] if len(row) == 1 else tuple(row))
        else:
            vals.append(row)
    return _flatten_value(vals)


def _parse_printed_value(text: str) -> Any:
    s = str(text or "").strip()
    if not s:
        return None
    # Keep the last non-empty line. Most official code prints one value.
    lines = [ln.strip() for ln in s.splitlines() if ln.strip()]
    if lines:
        s = lines[-1]
    # Try Python literal for lists/tuples/dicts/strings/numbers.
    try:
        return ast.literal_eval(s)
    except Exception:
        pass
    n = _num(s)
    if n is not None and re.fullmatch(r"\s*[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?\s*%?\s*", s.replace(",", "")):
        return int(n) if abs(n - int(n)) < 1e-12 else n
    return s


def _postprocess_sql_value(sql: str, value: Any) -> Any:
    """Normalize a few SQL aggregate edge cases.

    SQLite returns NULL for SUM over an empty set, while many dataset scripts
    express the denotation as 0.  Treat this as 0 only for SUM-like aggregate
    queries.  AVG(NULL) remains invalid because 0 would be semantically wrong.
    """
    if value is None and re.search(r"\bsum\s*\(", str(sql), flags=re.I):
        return 0
    return value


def _string_literal_variants(lit: str) -> List[str]:
    """Generate safe singular/plural variants for common category values."""
    lit = str(lit)
    variants = []
    low = lit.lower()
    def add(x: str):
        if x and x != lit and x.lower() not in {v.lower() for v in variants}:
            variants.append(x)
    if not low.endswith("s"):
        add(lit + "s")
    else:
        add(lit[:-1])
    if low.endswith("y"):
        add(lit[:-1] + "ies")
    if low.endswith("ies"):
        add(lit[:-3] + "y")
    # Some questions use singular wording but cell values use plural labels.
    if " product" in low and not low.endswith("s"):
        add(lit + "s")
    return variants[:8]


def _replace_single_quoted_literal(sql: str, old: str, new: str) -> str:
    old_esc = old.replace("'", "''")
    new_esc = new.replace("'", "''")
    return sql.replace(f"'{old_esc}'", f"'{new_esc}'", 1)


def _extract_single_quoted_literals(sql: str) -> List[str]:
    # Handles normal SQLite single quoted literals with doubled quote escapes.
    lits = []
    for m in re.finditer(r"'((?:''|[^'])*)'", str(sql)):
        lit = m.group(1).replace("''", "'")
        if 1 <= len(lit) <= 80:
            lits.append(lit)
    return lits


def denotation_equal(pred: Any, gold: Any, rel_tol: float = 1e-3, abs_tol: float = 1e-6) -> bool:
    pred = _flatten_value(pred)
    gold = _flatten_value(gold)
    pn, gn = _num(pred), _num(gold)
    if pn is not None and gn is not None:
        return abs(pn - gn) <= max(abs_tol, rel_tol * max(abs(gn), 1.0))
    if isinstance(pred, (list, tuple)) or isinstance(gold, (list, tuple)):
        pl = list(pred) if isinstance(pred, (list, tuple)) else [pred]
        gl = list(gold) if isinstance(gold, (list, tuple)) else [gold]
        if len(pl) != len(gl):
            return False
        # Order-insensitive for multi-row denotations.
        pn_l = sorted(_norm_text(x) for x in pl)
        gn_l = sorted(_norm_text(x) for x in gl)
        return pn_l == gn_l
    return _norm_text(pred) == _norm_text(gold)


def denotation_key(x: Any) -> str:
    x = _flatten_value(x)
    n = _num(x)
    if n is not None:
        return f"NUM:{round(n, 8)}"
    if isinstance(x, (list, tuple)):
        return "LIST:" + "||".join(sorted(_norm_text(v) for v in x))
    return "TEXT:" + _norm_text(x)


# ---------------------------------------------------------------------------
# SQLite + official-code execution
# ---------------------------------------------------------------------------

class SQLiteDB:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, timeout=30)
        self.conn.row_factory = sqlite3.Row

    def close(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def table_names(self) -> List[str]:
        cur = self.conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
        return [r[0] for r in cur.fetchall()]

    def find_text_value_variants(self, literal: str, max_hits: int = 12) -> List[str]:
        """Find actual cell values that are likely variants of a literal.

        This is used only as a post-generation SQL repair step, not to expose
        gold answers.  It helps when the model writes a singular category value
        but the database stores the plural form, e.g. ``baking product`` vs
        ``baking products``.
        """
        literal = str(literal or "").strip()
        if not literal:
            return []
        wanted = {literal.lower()}
        for v in _string_literal_variants(literal):
            wanted.add(v.lower())
        hits: List[str] = []
        cur = self.conn.cursor()
        for tn in self.table_names():
            try:
                cols = cur.execute(f"PRAGMA table_info({_quote_ident(tn)})").fetchall()
            except Exception:
                continue
            for col in cols:
                cn = str(col[1])
                ctype = str(col[2] or "").lower()
                # Try text-like columns, plus loosely typed SQLite columns.
                if ctype and not any(t in ctype for t in ["char", "text", "clob", "varchar"]):
                    continue
                try:
                    q = f"SELECT DISTINCT {_quote_ident(cn)} AS v FROM {_quote_ident(tn)} WHERE {_quote_ident(cn)} IS NOT NULL LIMIT 2000"
                    for row in cur.execute(q).fetchall():
                        val = row[0]
                        if val is None:
                            continue
                        sv = str(val).strip()
                        if not sv:
                            continue
                        sl = sv.lower()
                        if sl in wanted or sl.rstrip('s') == literal.lower().rstrip('s'):
                            if sv != literal and sv not in hits:
                                hits.append(sv)
                                if len(hits) >= max_hits:
                                    return hits
                except Exception:
                    continue
        return hits


    def value_hints(self, question: str, max_chars: int = 4500, max_values_per_column: int = 10) -> str:
        """Return generic schema/value hints sampled from the database.

        This exposes only database values, never gold answers or official code.
        It improves schema linking for string filters by showing values that
        lexically overlap with the question.
        """
        stop = {
            "what", "which", "when", "where", "who", "how", "many", "much", "the", "and", "or", "with", "from", "that", "have", "has", "are", "was", "were", "for", "all", "any", "into", "over", "under", "than", "then", "after", "before", "average", "total", "number", "count", "rate", "percentage", "percent", "maximum", "minimum", "highest", "lowest", "most", "least",
        }
        q = str(question or "")
        toks = [t.lower() for t in re.findall(r"[A-Za-z][A-Za-z0-9_/$.-]{2,}", q)]
        toks = [t for t in toks if t not in stop]
        # Preserve quoted phrases and capitalized fragments as useful literals.
        phrases = re.findall(r"['\"]([^'\"]{2,80})['\"]", q)
        keys = set(toks + [p.lower() for p in phrases])
        if not keys:
            keys = set(toks[:8])
        cur = self.conn.cursor()
        chunks: List[str] = []
        for tn in self.table_names():
            try:
                cols = cur.execute(f"PRAGMA table_info({_quote_ident(tn)})").fetchall()
            except Exception:
                continue
            for col in cols:
                cn = str(col[1])
                ctype = str(col[2] or "").lower()
                is_text = (not ctype) or any(t in ctype for t in ["char", "text", "clob", "varchar"])
                # Column-name overlap is a useful schema hint even without value samples.
                name_hit = any(k in cn.lower() or cn.lower() in k for k in keys)
                if is_text:
                    vals = []
                    try:
                        qsql = f"SELECT DISTINCT {_quote_ident(cn)} AS v FROM {_quote_ident(tn)} WHERE {_quote_ident(cn)} IS NOT NULL LIMIT 1200"
                        for row in cur.execute(qsql).fetchall():
                            sv = str(row[0]).strip()
                            if not sv:
                                continue
                            sl = sv.lower()
                            hit = name_hit or any(k in sl or sl in k for k in keys if len(k) >= 3)
                            if hit:
                                vals.append(sv)
                            if len(vals) >= max_values_per_column:
                                break
                    except Exception:
                        vals = []
                    if vals:
                        chunks.append(f"{tn}.{cn} possible_values: {json.dumps(vals, ensure_ascii=False)}")
                else:
                    # Generic numeric range hints for columns mentioned by name.
                    if name_hit and any(t in ctype for t in ["int", "real", "num", "double", "float", "dec"]):
                        try:
                            row = cur.execute(f"SELECT MIN({_quote_ident(cn)}), MAX({_quote_ident(cn)}) FROM {_quote_ident(tn)} WHERE {_quote_ident(cn)} IS NOT NULL").fetchone()
                            chunks.append(f"{tn}.{cn} numeric_range: [{row[0]}, {row[1]}]")
                        except Exception:
                            pass
            text = "\n".join(chunks)
            if len(text) > max_chars:
                return text[:max_chars] + "\n...[value hints truncated]"
        return "\n".join(chunks)[:max_chars]

    def load_pandas_env(self) -> Dict[str, Any]:
        env: Dict[str, Any] = {}
        used = set()
        for tn in self.table_names():
            df = pd.read_sql_query(f"SELECT * FROM {_quote_ident(tn)}", self.conn)
            var = _make_py_var(tn)
            base = var
            k = 2
            while var in used:
                var = f"{base}_{k}"
                k += 1
            used.add(var)
            env[var] = df.copy()
            # Also expose exact table name if it is a valid Python identifier.
            if str(tn).isidentifier():
                env[str(tn)] = df.copy()
        return env

    def schema_summary(self, max_chars: int = 14000, sample_rows: int = 3) -> str:
        cur = self.conn.cursor()
        chunks: List[str] = []
        for tn in self.table_names():
            ddl = cur.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (tn,)).fetchone()[0]
            chunks.append(f"TABLE {tn}\nDDL: {ddl}")
            try:
                n = cur.execute(f"SELECT COUNT(*) FROM {_quote_ident(tn)}").fetchone()[0]
                chunks.append(f"row_count: {n}")
            except Exception:
                pass
            try:
                cols = cur.execute(f"PRAGMA table_info({_quote_ident(tn)})").fetchall()
                chunks.append("columns: " + ", ".join(str(c[1]) for c in cols))
            except Exception:
                pass
            try:
                rows = cur.execute(f"SELECT * FROM {_quote_ident(tn)} LIMIT {int(sample_rows)}").fetchall()
                sample = [{k: r[k] for k in r.keys()} for r in rows]
                chunks.append("sample_rows: " + _json_dumps(sample, max_chars=2500))
            except Exception as exc:
                chunks.append(f"sample_rows_error: {exc}")
            chunks.append("")
            if sum(len(x) for x in chunks) > max_chars:
                break
        text = "\n".join(chunks)
        return text if len(text) <= max_chars else text[:max_chars] + "\n...[schema truncated]"

    def execute_sql(self, sql: str, max_rows: int = 80) -> Tuple[bool, Any, Optional[str]]:
        sql = _clean_sql(sql)
        if not _is_safe_select_sql(sql):
            return False, None, "unsafe_or_not_select"
        try:
            cur = self.conn.cursor()
            cur.execute(sql)
            rows = cur.fetchmany(max_rows + 1)
            out: List[Dict[str, Any]] = []
            for r in rows[:max_rows]:
                if isinstance(r, sqlite3.Row):
                    out.append({k: r[k] for k in r.keys()})
                else:
                    cols = [d[0] for d in (cur.description or [])]
                    out.append({cols[i]: r[i] for i in range(len(cols))})
            return True, out, None
        except Exception as exc:
            return False, None, str(exc)


def execute_gold_code(db_path: str, code: str) -> Tuple[bool, Any, str, Optional[str]]:
    db = SQLiteDB(db_path)
    try:
        env = db.load_pandas_env()
        # Provide common libraries and safe builtins.  The official dataset code
        # uses pandas dataframe operations and print().
        safe_builtins = {
            "print": print, "len": len, "range": range, "sum": sum, "min": min,
            "max": max, "sorted": sorted, "round": round, "abs": abs, "float": float,
            "int": int, "str": str, "list": list, "dict": dict, "set": set, "tuple": tuple,
            "enumerate": enumerate, "zip": zip, "any": any, "all": all,
        }
        glob = {"__builtins__": safe_builtins, "pd": pd, "pandas": pd, "math": math}
        if np is not None:
            glob["np"] = np
            glob["numpy"] = np
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            exec(code, glob, env)
        stdout = buf.getvalue().strip()
        value = _parse_printed_value(stdout)
        return True, value, stdout, None
    except Exception as exc:
        return False, None, "", str(exc)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Dataset builder: task.json + symDataset
# ---------------------------------------------------------------------------

def _parse_csv_arg(x: Optional[str], default: Optional[List[str]] = None) -> List[str]:
    if x is None or str(x).strip() == "":
        return default or []
    if str(x).lower() in {"all", "*"}:
        return ["all"]
    return [p.strip() for p in str(x).split(",") if p.strip()]


def _available_scales(symdataset_dir: str) -> List[str]:
    if not os.path.isdir(symdataset_dir):
        return []
    scales = [d for d in os.listdir(symdataset_dir) if os.path.isdir(os.path.join(symdataset_dir, d))]
    def key(s):
        m = re.search(r"\d+", s)
        return int(m.group(0)) if m else 10**9
    return sorted(scales, key=key)


def _available_domains(symdataset_dir: str, scale: str) -> List[str]:
    p = os.path.join(symdataset_dir, scale)
    if not os.path.isdir(p):
        return []
    return sorted(d for d in os.listdir(p) if os.path.isdir(os.path.join(p, d)))


def _sqlite_files(symdataset_dir: str, scale: str, domain: str, db_ids: Optional[Sequence[str]] = None) -> List[str]:
    p = os.path.join(symdataset_dir, scale, domain)
    if not os.path.isdir(p):
        return []
    files = []
    want_all = not db_ids or "all" in db_ids or "*" in db_ids
    wanted = {str(x) for x in (db_ids or [])}
    for fn in os.listdir(p):
        if not fn.endswith(".sqlite"):
            continue
        stem = os.path.splitext(fn)[0]
        # Prefer numbered DB instances.  Some folders contain a zero-byte domain.sqlite.
        if stem.isdigit():
            if want_all or stem in wanted:
                full = os.path.join(p, fn)
                if os.path.getsize(full) > 0:
                    files.append(full)
    return sorted(files, key=lambda x: int(os.path.splitext(os.path.basename(x))[0]))


def build_symdataset_samples(
    task_path: str = "data/tableQA/task.json",
    symdataset_dir: str = "data/symDataset",
    scales: str = "16k",
    domains: str = "all",
    db_ids: str = "0",
    first_n: int = -1,
    skip_gold_errors: bool = True,
    cache_gold: bool = True,
    result_dir: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Build direct symDataset samples and compute gold by official code."""
    with open(task_path, "r", encoding="utf-8") as f:
        tasks = json.load(f)
    if not isinstance(tasks, list):
        raise ValueError(f"Expected list in {task_path}, got {type(tasks)}")

    scale_list = _parse_csv_arg(scales, default=["16k"])
    if "all" in scale_list:
        scale_list = _available_scales(symdataset_dir)
    domain_list_arg = _parse_csv_arg(domains, default=["all"])
    db_id_list = _parse_csv_arg(db_ids, default=["0"])

    # Optional persistent gold cache because executing official pandas code for
    # many DBs can be slower than loading task metadata.
    gold_cache_path = None
    gold_cache: Dict[str, Any] = {}
    if cache_gold and result_dir:
        os.makedirs(result_dir, exist_ok=True)
        gold_cache_path = os.path.join(result_dir, "symdataset_gold_cache.pkl")
        if os.path.exists(gold_cache_path):
            try:
                gold_cache = pickle.load(open(gold_cache_path, "rb"))
            except Exception:
                gold_cache = {}

    samples: List[Dict[str, Any]] = []
    stats = {
        "tasks_total": len(tasks),
        "scales": scale_list,
        "domains_arg": domain_list_arg,
        "db_ids_arg": db_id_list,
        "gold_errors": 0,
        "missing_db": 0,
        "built": 0,
        "by_domain": defaultdict(int),
    }

    # Pre-index tasks by domain.
    tasks_by_domain: Dict[str, List[Tuple[int, Dict[str, Any]]]] = defaultdict(list)
    for ti, task in enumerate(tasks):
        dom = str(task.get("database") or task.get("domain") or "").strip()
        if dom:
            tasks_by_domain[dom].append((ti, task))

    pbar_items: List[Tuple[str, str, str, int, Dict[str, Any]]] = []
    for scale in scale_list:
        available_domains = _available_domains(symdataset_dir, scale)
        if "all" in domain_list_arg:
            domain_list = [d for d in available_domains if d in tasks_by_domain]
        else:
            domain_list = [d for d in domain_list_arg if d in available_domains]
        for domain in domain_list:
            dbs = _sqlite_files(symdataset_dir, scale, domain, db_id_list)
            if not dbs:
                stats["missing_db"] += len(tasks_by_domain.get(domain, []))
                continue
            for db_path in dbs:
                db_id = os.path.splitext(os.path.basename(db_path))[0]
                for ti, task in tasks_by_domain.get(domain, []):
                    pbar_items.append((scale, domain, db_id, ti, task))

    if first_n is not None and first_n > 0:
        pbar_items = pbar_items[:first_n]

    for scale, domain, db_id, ti, task in tqdm(pbar_items, total=len(pbar_items), desc="Building symDataset samples"):
        db_path = os.path.join(symdataset_dir, scale, domain, f"{db_id}.sqlite")
        cache_key = f"{scale}/{domain}/{db_id}/task-{ti}"
        if cache_key in gold_cache:
            gold_info = gold_cache[cache_key]
        else:
            ok, gold_value, stdout, err = execute_gold_code(db_path, str(task.get("code") or ""))
            gold_info = {"ok": ok, "gold_value": gold_value, "stdout": stdout, "error": err}
            gold_cache[cache_key] = gold_info
        if not gold_info.get("ok"):
            stats["gold_errors"] += 1
            if skip_gold_errors:
                continue
        # Do not store official code, choices, rightIdx, or gold stdout in
        # samples passed to the solver.  Those fields are not needed after gold
        # construction and keeping them increases accidental leakage risk.
        sample = {
            "id": f"tqa-sym-{scale}-{domain}-{db_id}-task{ti}",
            "task_index": ti,
            "scale": scale,
            "database": domain,
            "db_id": db_id,
            "db_path": db_path,
            "question": str(task.get("question") or ""),
            "gold_value": gold_info.get("gold_value"),
            "gold_error": gold_info.get("error"),
        }
        samples.append(sample)
        stats["built"] += 1
        stats["by_domain"][domain] += 1

    if gold_cache_path:
        try:
            pickle.dump(gold_cache, open(gold_cache_path, "wb"))
        except Exception:
            pass
    stats["by_domain"] = dict(stats["by_domain"])
    return samples, stats


# ---------------------------------------------------------------------------
# LLM SQL agent
# ---------------------------------------------------------------------------

def build_sql_prompt(sample: Dict[str, Any], schema: str, value_hints: str = "", max_sql_candidates: int = 4) -> str:
    question = str(sample.get("question") or "")
    hints = f"\nRelevant database value hints sampled from SQLite:\n{value_hints}\n" if str(value_hints or "").strip() else ""
    return f"""You are solving a TQA-Bench question over a SQLite database.

Generate SQLite SQL to compute the answer from the FULL database, not just the sample rows.

Rules:
- Output JSON only.
- Use only SELECT or WITH queries.
- Use the exact table and column names shown in the schema.
- Quote table/column names with double quotes when they contain spaces or special characters.
- Do not use INSERT, UPDATE, DELETE, CREATE, DROP, PRAGMA, or multiple statements.
- Prefer SQL that returns the final denotation directly. If the question asks for an entity with the highest/lowest/most/fewest value, return only the entity column, not the ranking score.
- Do not use DISTINCT unless the question explicitly asks for unique/distinct items or de-duplication is required by the natural-language meaning.
- For percentages or rates, make the unit explicit in SQL: if returning a percentage, multiply the fraction by 100.
- For string filters, prefer exact values that actually occur in the database; use the value hints when relevant.
- If several SQL interpretations are plausible, return multiple candidates ordered from most likely to least likely.
- Do not output an explanation outside JSON.

Question:
{question}

SQLite schema and small row samples:
{schema}
{hints}
Return this JSON:
{{
  "queries": [
    {{"sql": "SELECT ...", "rationale": "brief"}}
  ]
}}
Return at most {max_sql_candidates} SQL candidates.
"""


def call_llm_text(llm: Any, prompt: str, max_tokens: int = 1200, temperature: float = 0.0) -> str:
    opts = llm.get_model_options(
        temperature=temperature,
        per_example_max_decode_steps=max_tokens,
        per_example_top_p=1.0,
        n_sample=1,
    )
    try:
        return llm.generate(prompt, opts)
    except AttributeError:
        return llm.generate_plus_with_score(prompt, opts)[0][0]




def _summarize_candidate_value(value: Any, max_chars: int = 800) -> str:
    text = json.dumps(value, ensure_ascii=False, default=str)
    return text if len(text) <= max_chars else text[:max_chars] + " ...[truncated]"


def build_result_selector_prompt(sample: Dict[str, Any], candidates: List[Dict[str, Any]]) -> str:
    """Build a leakage-safe prompt for selecting among executed SQL candidates.

    The selector sees only the question, SQL strings, and SQL execution outputs.
    It never sees gold values, official code, choices, or rightIdx.
    """
    question = str(sample.get("question") or "")
    rows = []
    for i, c in enumerate(candidates):
        rows.append({
            "index": i,
            "sql": c.get("sql"),
            "result": c.get("value"),
            "shape_score": c.get("shape_score", 0.0),
            "rationale": c.get("rationale"),
        })
    return f"""You are selecting the SQL result that best answers a database question.

You must choose from executed SQL candidates only. Do not solve from memory.
Prefer the candidate whose SQL logic and result directly match the wording of the question.
If the question asks for an entity, avoid candidates that return an extra score unless the entity is clearly identified.
If the question asks for a number/rate/average/count, prefer scalar numeric results.

Question:
{question}

Executed candidates:
{json.dumps(rows, ensure_ascii=False, default=str, indent=2)}

Return JSON only:
{{"choice": 0, "reason": "brief"}}
"""


def choose_candidate_with_llm(llm: Any, sample: Dict[str, Any], candidates: List[Dict[str, Any]]) -> Optional[int]:
    if not candidates:
        return None
    if len(candidates) == 1:
        return 0
    prompt = build_result_selector_prompt(sample, candidates[:10])
    try:
        raw = call_llm_text(llm, prompt, max_tokens=500, temperature=0.0)
        obj = _extract_json_object(raw)
        if isinstance(obj, dict):
            idx = obj.get("choice", obj.get("index"))
            try:
                idx = int(idx)
                if 0 <= idx < min(10, len(candidates)):
                    candidates[idx]["selector_reason"] = obj.get("reason")
                    return idx
            except Exception:
                pass
    except Exception:
        return None
    return None


def build_sql_repair_prompt(sample: Dict[str, Any], schema: str, value_hints: str, bad_sql: str, error: Optional[str], value: Any) -> str:
    question = str(sample.get("question") or "")
    hints = f"\nRelevant database value hints:\n{value_hints}\n" if str(value_hints or "").strip() else ""
    return f"""Repair a SQLite SELECT/WITH query for the given database question.

Use only the question, schema, value hints, the previous SQL, and the execution error/result.
Do not use any external knowledge. Return JSON only.

Question:
{question}

Schema:
{schema}
{hints}
Previous SQL:
{bad_sql}

Execution error:
{error}

Execution result:
{_summarize_candidate_value(value)}

Return JSON:
{{"queries": [{{"sql": "SELECT ...", "rationale": "what was fixed"}}]}}
"""


def _is_suspicious_result(question: str, value: Any) -> bool:
    if value is None:
        return True
    q = _norm_text(question)
    v = _flatten_value(value)
    if isinstance(v, (list, tuple)) and len(v) == 0:
        return True
    # Long multi-row outputs are suspicious for scalar/entity questions.
    if isinstance(v, (list, tuple)) and len(v) > 10 and not re.search(r"\b(list|all|which|what are)\b", q):
        return True
    return False

def _best_prediction_from_votes(values: List[Any]) -> Tuple[Any, float, Dict[str, int]]:
    if not values:
        return None, 0.0, {}
    keys = [denotation_key(v) for v in values]
    counts = Counter(keys)
    best_key, best_count = counts.most_common(1)[0]
    for v, k in zip(values, keys):
        if k == best_key:
            return v, best_count / max(1, len(values)), dict(counts)
    return values[0], best_count / max(1, len(values)), dict(counts)



def _count_like_zero(value: Any, sql: str) -> bool:
    """Whether value is a likely zero count/aggregate worth value-link repair."""
    n = _num(value)
    if n is None or abs(n) > 1e-12:
        return False
    return bool(re.search(r"\b(count|sum|avg|average)\s*\(", str(sql), flags=re.I))


def execute_sql_with_repairs(db: SQLiteDB, sql: str, visible_sample: Optional[Dict[str, Any]] = None, disable_safe_repairs: bool = False) -> Tuple[bool, Any, Optional[str], List[Dict[str, Any]], str]:
    """Execute SQL and apply leakage-safe generic repairs.

    v39 still does not use gold denotation or official code.  Repairs are only
    transformations of the LLM-generated SQL based on question wording, schema,
    database values, and SQL execution result.  Unlike v34, this function never
    creates a complete benchmark-task SQL template from scratch.
    """
    attempts: List[Dict[str, Any]] = []
    visible_sample = visible_sample or {}
    question = str(visible_sample.get("question") or "")

    def _run(one_sql: str, stage: str, repair_reason: Optional[str] = None) -> Tuple[bool, Any, Optional[str], str]:
        clean = _clean_sql(one_sql)
        ok, rows, err = db.execute_sql(clean)
        value = _sql_rows_to_value(rows) if ok else None
        value = _postprocess_sql_value(clean, value)
        attempts.append({"stage": stage, "repair_reason": repair_reason, "sql": clean, "ok": ok, "rows": rows, "value": value, "error": err})
        return ok, value, err, clean

    ok, value, err, used_sql = _run(sql, "sql_execution")
    base_sql = _clean_sql(sql)

    if disable_safe_repairs:
        attempts.append({"stage": "safe_repairs_disabled", "ok": True, "sql": base_sql, "value": value, "error": None})
        return ok, value, err, attempts, used_sql

    generated: List[Dict[str, Any]] = []
    seen = {base_sql}

    def add_candidate(csql: str, reason: str, prefer: bool = False):
        csql = _clean_sql(csql)
        if csql and csql not in seen:
            seen.add(csql)
            generated.append({"sql": csql, "reason": reason, "prefer_if_success": bool(prefer)})

    # Legacy v35/v37 literal repairs: singular/plural and actual DB variants.
    # v40 also allows this for zero aggregate results, because a zero count often
    # means the literal does not match the database value.
    if (not ok) or value is None or _count_like_zero(value, base_sql):
        for lit in _extract_single_quoted_literals(base_sql):
            cand_values = _string_literal_variants(lit)
            try:
                cand_values.extend(db.find_text_value_variants(lit))
            except Exception:
                pass
            for nv in cand_values:
                add_candidate(_replace_single_quoted_literal(base_sql, lit, nv), "generic_literal_variant_repair", prefer=(value is None or _count_like_zero(value, base_sql)))
                if len(generated) >= 10:
                    break
            if len(generated) >= 10:
                break

    # New v39 generic semantic/adaptive repairs. These are transformations of the LLM SQL.
    try:
        for cand in generate_adaptive_sql_repairs(db, visible_sample, base_sql, value=value, error=err):
            add_candidate(cand.get("sql") or "", cand.get("reason") or "adaptive_sql_repair", bool(cand.get("prefer_if_success", True)))
    except Exception as rex:
        attempts.append({"stage": "adaptive_repair_generation", "ok": False, "error": str(rex), "sql": base_sql})

    # If original execution is valid, keep it unless a generic repair is marked
    # semantically preferable and executes successfully.  This avoids v36's
    # candidate-majority regression while still fixing recurring generic errors.
    original_score = result_shape_score(question, value) if ok and value is not None else -100.0
    best = (ok, value, err, used_sql, original_score, False)

    for cand in generated[:18]:
        ok2, value2, err2, used_sql2 = _run(cand["sql"], "adaptive_sql_repair", cand.get("reason"))
        if not (ok2 and value2 is not None):
            continue
        score2 = result_shape_score(question, value2)
        prefer = bool(cand.get("prefer_if_success"))
        # Choose repair if original invalid/null, if it fixes a zero aggregate, or
        # if a generic semantic rewrite is explicitly preferred and shape is not
        # worse.  No gold is consulted.
        if (not ok or value is None) or (_count_like_zero(value, base_sql) and not _count_like_zero(value2, used_sql2)) or (prefer and score2 >= original_score - 0.25):
            return ok2, value2, err2, attempts, used_sql2
        if score2 > best[4] + 0.75:
            best = (ok2, value2, err2, used_sql2, score2, True)

    if best[5]:
        return best[0], best[1], best[2], attempts, best[3]
    return ok, value, err, attempts, used_sql


def _adaptive_value_hint_reasons(db: SQLiteDB, prediction: Any, vote_sqls: Sequence[str]) -> List[str]:
    """Return leakage-safe reasons for a second pass with database value hints.

    The decision uses only the predicted denotation, generated SQL, and database
    contents.  Gold values, official code, choices, task ids, and correctness
    flags are deliberately unavailable here.
    """
    reasons: List[str] = []
    sqls = [str(s or "") for s in vote_sqls if str(s or "").strip()]
    if prediction is None or not sqls:
        reasons.append("no_valid_prediction")
        return reasons

    # A zero aggregate is suspicious only when a generated string literal is
    # absent but a close singular/plural database value exists.  Zero alone is
    # a valid answer and must never trigger a retry.
    has_zero_aggregate = any(_count_like_zero(prediction, sql) for sql in sqls)
    if has_zero_aggregate:
        checked = set()
        for sql in sqls:
            for literal in _extract_single_quoted_literals(sql):
                key = literal.casefold().strip()
                if not key or key in checked:
                    continue
                checked.add(key)
                variants = db.find_text_value_variants(literal, max_hits=4)
                if variants:
                    reasons.append("zero_aggregate_with_unmatched_literal")
                    return reasons
    return reasons


def _adaptive_should_use_hinted(
    base_prediction: Any,
    base_confidence: float,
    hinted_prediction: Any,
    hinted_confidence: float,
    reasons: Sequence[str],
) -> bool:
    """Conservatively choose the hinted pass without consulting gold labels."""
    if hinted_prediction is None:
        return False
    if base_prediction is None:
        return True
    if "zero_aggregate_with_unmatched_literal" in reasons:
        base_num = _num(base_prediction)
        hinted_num = _num(hinted_prediction)
        if base_num is not None and abs(base_num) <= 1e-12:
            if hinted_num is not None and abs(hinted_num) > 1e-12:
                return True
            return float(hinted_confidence or 0.0) > float(base_confidence or 0.0)
    return False


def _parse_candidate_sources(candidate_sources: str) -> set:
    """Parse candidate-source ablation setting for paper experiments.

    Valid tokens: all, llm, schema_rule, schema, rule.  The repair source is
    controlled separately by --disable_safe_repairs because repairs happen during
    execution of each candidate program.
    """
    raw = str(candidate_sources or "all").lower().strip()
    if raw in {"", "all", "default"}:
        return {"llm", "schema_rule"}
    toks = {t.strip() for t in re.split(r"[,;+ ]+", raw) if t.strip()}
    out = set()
    for t in toks:
        if t in {"all", "default"}:
            out.update({"llm", "schema_rule"})
        elif t in {"llm", "model", "model_sql", "llm_sql"}:
            out.add("llm")
        elif t in {"schema", "schema_rule", "schema_graph", "rule", "rules", "pcfg", "symbolic"}:
            out.add("schema_rule")
        elif t in {"none", "empty"}:
            pass
        else:
            raise ValueError(f"Unknown candidate source token: {t!r}. Use all,llm,schema_rule,none.")
    return out

def solve_one_sample(
    sample: Dict[str, Any],
    llm: Any,
    votes: int = 1,
    parallel_votes: int = 1,
    max_schema_chars: int = 14000,
    max_sql_candidates: int = 2,
    enable_result_selector: bool = False,
    repair_rounds: int = 0,
    enable_value_hints: bool = False,
    value_hint_mode: str = "off",
    selection_policy: str = "primary_majority",
    candidate_sources: str = "all",
    disable_safe_repairs: bool = False,
    posterior_selection: str = "answer_marginal",
    bf_threshold: float = 3.0,
    schema_graph_ablation: str = "none",
    save_full_candidate_trace: bool = False,
    debug: bool = False,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    mode = str(value_hint_mode or "off").lower().strip()
    if enable_value_hints and mode == "off":
        mode = "always"  # compatibility with the old --enable_value_hints flag
    if mode not in {"off", "always", "adaptive"}:
        raise ValueError(f"Unknown value_hint_mode={value_hint_mode!r}; use off, always, or adaptive")
    policy = str(selection_policy or "primary_majority").lower().strip()
    source_set = _parse_candidate_sources(candidate_sources)

    # Adaptive mode is a conservative two-pass wrapper.  The ordinary pass is
    # returned unchanged unless generic execution diagnostics justify a hinted
    # retry and that retry resolves the diagnosed failure.  Selection never
    # reads gold_value or any correctness flag.
    if mode == "adaptive":
        base_result, base_report = solve_one_sample(
            sample, llm, votes=votes, parallel_votes=parallel_votes,
            max_schema_chars=max_schema_chars, max_sql_candidates=max_sql_candidates,
            enable_result_selector=enable_result_selector, repair_rounds=repair_rounds,
            enable_value_hints=False, value_hint_mode="off",
            selection_policy=selection_policy, candidate_sources=candidate_sources,
            disable_safe_repairs=disable_safe_repairs, posterior_selection=posterior_selection,
            bf_threshold=bf_threshold, schema_graph_ablation=schema_graph_ablation,
            save_full_candidate_trace=save_full_candidate_trace, debug=debug,
        )
        probe_db = SQLiteDB(str(model_visible_sample(sample)["db_path"]))
        try:
            reasons = _adaptive_value_hint_reasons(
                probe_db,
                base_report.get("pred"),
                base_report.get("vote_sqls") or [],
            )
        finally:
            probe_db.close()

        adaptive_meta: Dict[str, Any] = {
            "mode": "adaptive",
            "triggered": bool(reasons),
            "reasons": list(reasons),
            "selected_pass": "base",
            "base_prediction": base_report.get("pred"),
            "base_confidence": base_report.get("confidence"),
        }
        if not reasons:
            base_result.setdefault("tqabench_symdataset_sql", {})["adaptive_value_hints"] = adaptive_meta
            base_report["adaptive_value_hints"] = adaptive_meta
            return base_result, base_report

        hinted_result, hinted_report = solve_one_sample(
            sample, llm, votes=votes, parallel_votes=parallel_votes,
            max_schema_chars=max_schema_chars, max_sql_candidates=max_sql_candidates,
            enable_result_selector=enable_result_selector, repair_rounds=repair_rounds,
            enable_value_hints=True, value_hint_mode="always",
            selection_policy=selection_policy, candidate_sources=candidate_sources,
            disable_safe_repairs=disable_safe_repairs, posterior_selection=posterior_selection,
            bf_threshold=bf_threshold, schema_graph_ablation=schema_graph_ablation,
            save_full_candidate_trace=save_full_candidate_trace, debug=debug,
        )
        use_hinted = _adaptive_should_use_hinted(
            base_report.get("pred"), float(base_report.get("confidence") or 0.0),
            hinted_report.get("pred"), float(hinted_report.get("confidence") or 0.0),
            reasons,
        )
        adaptive_meta.update({
            "selected_pass": "hinted" if use_hinted else "base",
            "hinted_prediction": hinted_report.get("pred"),
            "hinted_confidence": hinted_report.get("confidence"),
        })
        chosen_result = hinted_result if use_hinted else base_result
        chosen_report = hinted_report if use_hinted else base_report
        chosen_result.setdefault("tqabench_symdataset_sql", {})["adaptive_value_hints"] = adaptive_meta
        chosen_result["answer_source"] = (
            "tqabench_symdataset_v41_adaptive_value_hints"
            if use_hinted else chosen_result.get("answer_source")
        )
        chosen_report["answer_source"] = chosen_result.get("answer_source")
        chosen_report["adaptive_value_hints"] = adaptive_meta
        return chosen_result, chosen_report

    # Use a restricted view for all model-facing and repair-facing code.
    # gold_value / official code / choices / rightIdx are intentionally excluded.
    visible_sample = model_visible_sample(sample)
    db = SQLiteDB(visible_sample["db_path"])
    try:
        schema_graph = build_schema_graph(db, ablation=schema_graph_ablation) if policy in {"multitable_bayes", "hybrid_multitable_bayes"} else {}
        schema = db.schema_summary(max_chars=max_schema_chars)
        if policy in {"multitable_bayes", "hybrid_multitable_bayes"}:
            schema = schema + "\n\n" + schema_graph_summary(schema_graph, max_chars=3500)
        value_hints = db.value_hints(visible_sample.get("question", ""), max_chars=4500) if mode == "always" else ""
        prompt = build_sql_prompt(visible_sample, schema, value_hints=value_hints, max_sql_candidates=max_sql_candidates)

        raw_outputs: List[str] = []
        n_votes = max(1, int(votes or 1))
        workers = max(1, min(int(parallel_votes or 1), n_votes))
        if "llm" in source_set:
            def _one(vi: int) -> str:
                # Keep first vote deterministic; diversify later votes mildly.
                vote_temp = float(os.environ.get("TQA_VOTE_TEMPERATURE", "0.25"))
                temp = 0.0 if vi == 0 else vote_temp
                return call_llm_text(llm, prompt, max_tokens=1600, temperature=temp)

            if workers == 1:
                for vi in range(n_votes):
                    raw_outputs.append(_one(vi))
            else:
                with ThreadPoolExecutor(max_workers=workers) as ex:
                    futs = [ex.submit(_one, vi) for vi in range(n_votes)]
                    for fut in as_completed(futs):
                        raw_outputs.append(fut.result())

        evidence: List[Dict[str, Any]] = []
        primary_values: List[Any] = []
        primary_sqls: List[str] = []
        executed_candidates: List[Dict[str, Any]] = []
        seen_sql = set()

        # v52: build the full visible SQL candidate pool first, then execute it
        # through CandidateProgramEngine once at sample level.  This makes TQA a
        # genuine SQL instance of the universal candidate-program framework, not
        # a bypass path with only per-candidate wrappers.
        candidate_specs: List[Dict[str, Any]] = []
        global_idx = 0
        for vi, raw in enumerate(raw_outputs):
            candidates = extract_sql_candidates(raw)
            if not candidates:
                evidence.append({"stage": "sql_generation", "raw": raw, "error": "no_sql_extracted"})
                continue
            for j, cand in enumerate(candidates[:max(1, int(max_sql_candidates or 1))]):
                sql = cand.get("sql") or ""
                if not sql:
                    continue
                candidate_specs.append({
                    "sql": sql,
                    "rationale": cand.get("rationale"),
                    "stage": "llm_sql_candidate",
                    "source": "llm_sql_candidate",
                    "vote_index": vi,
                    "candidate_index": j,
                    "global_index": global_idx,
                    "primary_eligible": True,
                })
                global_idx += 1

        if policy in {"multitable_bayes", "hybrid_multitable_bayes"} and "schema_rule" in source_set:
            # Multi-source candidate recall branch: add conservative schema-graph/rule candidates.
            # These are generated as CandidateProgram objects by the framework pool,
            # not executed through a separate task-specific bypass path.
            for k, sc in enumerate(generate_schema_graph_rule_candidates(visible_sample, schema_graph, max_candidates=max(4, int(max_sql_candidates or 2) * 2))):
                sql = sc.get("sql") or ""
                if not sql:
                    continue
                candidate_specs.append({
                    "sql": sql,
                    "rationale": sc.get("rationale"),
                    "stage": sc.get("stage") or "schema_graph_rule_candidate",
                    "source": sc.get("stage") or "schema_graph_rule_candidate",
                    "vote_index": None,
                    "candidate_index": k,
                    "global_index": global_idx,
                    "primary_eligible": False,
                })
                global_idx += 1

        if candidate_specs:
            def _execute_sql_with_current_repair_policy(db_obj, sql_text, vis_sample):
                return execute_sql_with_repairs(db_obj, sql_text, vis_sample, disable_safe_repairs=disable_safe_repairs)

            pool_eval = execute_tqa_sql_candidate_pool_via_framework(
                db=db,
                visible_sample=visible_sample,
                schema_graph=schema_graph,
                candidate_specs=candidate_specs,
                execute_sql_with_repairs_fn=_execute_sql_with_current_repair_policy,
                normalize_prediction_without_gold_fn=normalize_prediction_without_gold,
                result_shape_score_fn=result_shape_score,
                clean_sql_fn=_clean_sql,
            )
            evidence.extend(pool_eval.get("evidence") or [])
            executed_candidates.extend(pool_eval.get("executed_candidates") or [])

            # Reconstruct the v35/v39 primary-vote behavior from framework-evaluated
            # LLM candidates: for each vote, take the first valid candidate in the
            # model's own order.  This preserves the high-performing hybrid guard.
            chosen_votes = set()
            for rec in sorted(executed_candidates, key=lambda r: (
                10**9 if r.get("vote_index") is None else int(r.get("vote_index")),
                10**9 if r.get("candidate_index") is None else int(r.get("candidate_index")),
                10**9 if r.get("global_index") is None else int(r.get("global_index")),
            )):
                if not rec.get("primary_eligible"):
                    continue
                vi = rec.get("vote_index")
                if vi in chosen_votes:
                    continue
                chosen_votes.add(vi)
                primary_values.append(rec["value"])
                primary_sqls.append(rec["sql"])

            framework_pool_summary = pool_eval.get("framework_result") or {"engine_used": True, "engine_scope": "sample_candidate_pool"}
        else:
            framework_pool_summary = {"engine_used": True, "engine_scope": "sample_candidate_pool", "num_initial_candidates": 0, "num_evaluated_candidates": 0}

        # Choose final prediction.
        # - primary_majority: v35-compatible default, safest for reporting.
        # - selector: optional LLM selector over executed SQL candidates; leakage-safe
        #   but should be reported separately as an ablation.
        # - candidate_majority: kept only for ablation; not recommended because it
        #   caused the v36 accuracy drop.
        pred_value = None
        confidence = 0.0
        vote_summary: Dict[str, int] = {}
        vote_sqls: List[str] = []
        answer_source = "tqabench_symdataset_invalid"
        policy = str(selection_policy or "primary_majority").lower().strip()
        bayes_diagnostics: Dict[str, Any] = {}
        bayes_ranked_candidates: List[Dict[str, Any]] = []

        if policy in {"multitable_bayes", "hybrid_multitable_bayes"} and executed_candidates:
            chosen, bayes_diagnostics, bayes_ranked_candidates = select_by_multitable_bayes(
                executed_candidates, visible_sample.get("question", ""), schema_graph,
                posterior_selection=posterior_selection, bf_threshold=bf_threshold
            )
            # Optional low-confidence LLM referee.  It only sees executed candidates,
            # execution traces, and risk signals; it never sees gold or official code.
            if enable_result_selector and bayes_diagnostics.get("low_confidence") and len(bayes_ranked_candidates) > 1:
                idx = choose_candidate_with_llm(llm, visible_sample, bayes_ranked_candidates[:8])
                if idx is not None and 0 <= idx < min(8, len(bayes_ranked_candidates)):
                    referee_choice = bayes_ranked_candidates[idx]
                    allow_override, override_reason = allow_llm_referee_override(
                        visible_sample.get("question", ""), chosen, referee_choice, bayes_diagnostics
                    )
                    bayes_diagnostics["llm_referee_used"] = True
                    bayes_diagnostics["llm_referee_index"] = idx
                    bayes_diagnostics["llm_referee_override_allowed"] = bool(allow_override)
                    bayes_diagnostics["llm_referee_override_reason"] = override_reason
                    if allow_override:
                        chosen = referee_choice
                else:
                    bayes_diagnostics["llm_referee_used"] = False
                    bayes_diagnostics["llm_referee_override_allowed"] = False
            if chosen is not None:
                # Optional hybrid guard: keep primary-majority unless multitable evidence
                # indicates a generic high-risk situation where primary is likely wrong.
                # This keeps the four diagnostic modules active while avoiding unnecessary
                # regressions from noisy extra candidates.
                if policy == "hybrid_multitable_bayes":
                    primary_pred_tmp, primary_conf_tmp, primary_summary_tmp = _best_prediction_from_votes(primary_values)
                    q_tmp = str(visible_sample.get("question", "")).lower()
                    mt_val = chosen.get("value")
                    use_mt = primary_pred_tmp is None or denotation_key(primary_pred_tmp) == denotation_key(mt_val)
                    if not use_mt:
                        risk_terms = ["ratio", "percentage", "percent", "rate", "majority", "more than", "fraction", "share",
                                      "ranked", "ranking", "criterion", "criteria", "cwur", "based on the criterion"]
                        primary_zero = False
                        try:
                            primary_zero = abs(float(primary_pred_tmp)) <= 1e-12
                        except Exception:
                            primary_zero = False
                        mt_nonzero = False
                        try:
                            mt_nonzero = abs(float(mt_val)) > 1e-12
                        except Exception:
                            mt_nonzero = mt_val is not None
                        use_mt = (any(t in q_tmp for t in risk_terms) and (primary_zero or float(bayes_diagnostics.get("chosen_answer_mass") or 0.0) >= 0.75 or bayes_diagnostics.get("llm_referee_override_allowed")))
                        if primary_zero and mt_nonzero and any(t in q_tmp for t in ["ranked", "ranking", "criterion", "criteria", "cwur"]):
                            use_mt = True
                    bayes_diagnostics["hybrid_primary_prediction"] = primary_pred_tmp
                    bayes_diagnostics["hybrid_primary_confidence"] = primary_conf_tmp
                    bayes_diagnostics["hybrid_used_multitable"] = bool(use_mt)
                    if not use_mt:
                        pred_value = primary_pred_tmp
                        vote_sqls = primary_sqls
                        confidence = primary_conf_tmp
                        vote_summary = primary_summary_tmp
                        answer_source = "tqabench_symdataset_v52_hybrid_primary_guard"
                    else:
                        pred_value = mt_val
                        vote_sqls = [chosen.get("sql")]
                        confidence = float(bayes_diagnostics.get("chosen_answer_mass") or chosen.get("posterior") or 0.0)
                        vote_summary = dict(bayes_diagnostics.get("answer_posterior") or {})
                        answer_source = "tqabench_symdataset_v52_hybrid_multitable_bayes" + ("_llm_referee" if bayes_diagnostics.get("llm_referee_used") else "")
                else:
                    pred_value = chosen.get("value")
                    vote_sqls = [chosen.get("sql")]
                    confidence = float(bayes_diagnostics.get("chosen_answer_mass") or chosen.get("posterior") or 0.0)
                    vote_summary = dict(bayes_diagnostics.get("answer_posterior") or {})
                    answer_source = "tqabench_symdataset_v52_multitable_bayes" + ("_llm_referee" if bayes_diagnostics.get("llm_referee_used") else "")

        if policy == "selector" and enable_result_selector and executed_candidates:
            idx = choose_candidate_with_llm(llm, visible_sample, executed_candidates)
            if idx is not None:
                chosen = executed_candidates[idx]
                pred_value = chosen.get("value")
                vote_sqls = [chosen.get("sql")]
                confidence = 1.0
                answer_source = "tqabench_symdataset_v40_llm_result_selector"

        if pred_value is None and policy == "candidate_majority" and executed_candidates:
            values = [c["value"] for c in executed_candidates]
            keys = [denotation_key(v) for v in values]
            counts = Counter(keys)
            best_count = max(counts.values()) if counts else 0
            tied_keys = {k for k, c in counts.items() if c == best_count}
            best_i = None
            best_tuple = (-10**9, -1)
            for i, c in enumerate(executed_candidates):
                if keys[i] not in tied_keys:
                    continue
                tup = (float(c.get("shape_score", 0.0)), -i)
                if tup > best_tuple:
                    best_tuple = tup
                    best_i = i
            if best_i is None:
                best_i = 0
            chosen = executed_candidates[best_i]
            pred_value = chosen.get("value")
            vote_sqls = [c.get("sql") for c in executed_candidates]
            confidence = best_count / max(1, len(executed_candidates))
            vote_summary = dict(counts)
            answer_source = "tqabench_symdataset_v40_candidate_majority_ablation"

        if pred_value is None:
            pred_value, confidence, vote_summary = _best_prediction_from_votes(primary_values)
            vote_sqls = primary_sqls
            answer_source = "tqabench_symdataset_v40_primary_majority" if pred_value is not None else "tqabench_symdataset_invalid"

        gold = sample.get("gold_value")
        correct = pred_value is not None and denotation_equal(pred_value, gold)
        oracle_coverage = candidate_coverage_with_gold(
            (bayes_ranked_candidates if (policy in {"multitable_bayes", "hybrid_multitable_bayes"} and bayes_ranked_candidates) else executed_candidates),
            gold,
            denotation_equal,
        ) if policy in {"multitable_bayes", "hybrid_multitable_bayes"} else {}

        result = copy.deepcopy(visible_sample)
        result.update({
            "gold_value": gold,
            "answer": pred_value,
            "pred_answer": pred_value,
            "answer_source": answer_source,
            "correct": bool(correct),
            "tqabench_symdataset_sql": {
                "version": "v52_pooled_candidate_framework_guarded_multitable_candidate_bayes_leakage_safe",
                "candidate_framework_engine_used": True,
                "candidate_framework_engine_scope": "sample_candidate_pool",
                "candidate_framework_pool": framework_pool_summary,
                "votes": n_votes,
                "parallel_votes": workers,
                "max_sql_candidates": max_sql_candidates,
                "enable_result_selector": enable_result_selector,
                "repair_rounds": repair_rounds,
                "value_hint_mode": mode,
                "selection_policy": policy,
                "candidate_sources": sorted(source_set),
                "disable_safe_repairs": bool(disable_safe_repairs),
                "posterior_selection": posterior_selection,
                "bf_threshold": float(bf_threshold or 3.0),
                "schema_graph_ablation": schema_graph_ablation,
                "confidence": confidence,
                "vote_summary": vote_summary,
                "vote_sqls": vote_sqls,
                "executed_candidate_count": len(executed_candidates),
                "executed_candidates": (
                    (bayes_ranked_candidates if (policy in {"multitable_bayes", "hybrid_multitable_bayes"} and bayes_ranked_candidates) else executed_candidates)
                    if (debug or save_full_candidate_trace)
                    else ((bayes_ranked_candidates if (policy in {"multitable_bayes", "hybrid_multitable_bayes"} and bayes_ranked_candidates) else executed_candidates)[:12])
                ),
                "schema_graph_summary": schema_graph_summary(schema_graph, max_chars=5000) if policy in {"multitable_bayes", "hybrid_multitable_bayes"} else "",
                "multitable_bayes": bayes_diagnostics,
                "oracle_coverage": oracle_coverage,
                "evidence": evidence if debug else evidence[:60],
            },
        })
        report = {
            "id": result.get("id"),
            "scale": sample.get("scale"),
            "database": sample.get("database"),
            "db_id": sample.get("db_id"),
            "task_index": sample.get("task_index"),
            "question": sample.get("question"),
            "gold": gold,
            "pred": pred_value,
            "correct": bool(correct),
            "invalid": pred_value is None,
            "confidence": confidence,
            "answer_source": answer_source,
            "vote_sqls": vote_sqls,
            "oracle_covered": oracle_coverage.get("oracle_covered") if oracle_coverage else None,
            "valid_candidate_count": oracle_coverage.get("valid_candidate_count") if oracle_coverage else None,
        }
        return result, report
    finally:
        db.close()

def evaluate_results(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = correct = invalid = 0
    oracle_total = oracle_covered = oracle_candidate_count = 0
    by_domain = defaultdict(lambda: {"total": 0, "correct": 0, "invalid": 0})
    by_scale = defaultdict(lambda: {"total": 0, "correct": 0, "invalid": 0})
    for r in results:
        total += 1
        pred = r.get("pred_answer", r.get("answer"))
        gold = r.get("gold_value")
        is_invalid = pred is None
        is_correct = False if is_invalid else denotation_equal(pred, gold)
        if is_invalid:
            invalid += 1
        if is_correct:
            correct += 1
        oc = ((r.get("tqabench_symdataset_sql") or {}).get("oracle_coverage") or {})
        if oc:
            oracle_total += 1
            oracle_covered += int(bool(oc.get("oracle_covered")))
            oracle_candidate_count += int(oc.get("valid_candidate_count") or 0)
        dom = str(r.get("database"))
        sc = str(r.get("scale"))
        for stats in (by_domain[dom], by_scale[sc]):
            stats["total"] += 1
            stats["correct"] += int(is_correct)
            stats["invalid"] += int(is_invalid)
    def final_stats(d):
        return {k: {**v, "accuracy": round(v["correct"] / max(v["total"], 1), 4)} for k, v in d.items()}
    metrics = {
        "total": total,
        "correct": correct,
        "invalid": invalid,
        "accuracy": round(correct / max(total, 1), 4),
        "valid_accuracy": round(correct / max(total - invalid, 1), 4),
        "by_domain": final_stats(by_domain),
        "by_scale": final_stats(by_scale),
    }
    if oracle_total:
        metrics.update({
            "topk_oracle_coverage": round(oracle_covered / max(oracle_total, 1), 4),
            "generation_miss_rate": round(1.0 - oracle_covered / max(oracle_total, 1), 4),
            "ranking_error_rate": round(max(oracle_covered - correct, 0) / max(oracle_total, 1), 4),
            "avg_valid_candidate_count": round(oracle_candidate_count / max(oracle_total, 1), 3),
        })
    return metrics


def solve_dataset(
    samples: List[Dict[str, Any]],
    llm: Any,
    result_dir: str,
    votes: int = 1,
    parallel_votes: int = 1,
    max_schema_chars: int = 14000,
    max_sql_candidates: int = 2,
    enable_result_selector: bool = False,
    repair_rounds: int = 0,
    enable_value_hints: bool = False,
    value_hint_mode: str = "off",
    selection_policy: str = "primary_majority",
    candidate_sources: str = "all",
    disable_safe_repairs: bool = False,
    posterior_selection: str = "answer_marginal",
    bf_threshold: float = 3.0,
    schema_graph_ablation: str = "none",
    save_full_candidate_trace: bool = False,
    resume: bool = True,
    debug: bool = False,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    os.makedirs(result_dir, exist_ok=True)
    cache_config = {
        "votes": votes,
        "parallel_votes": parallel_votes,
        "max_schema_chars": max_schema_chars,
        "max_sql_candidates": max_sql_candidates,
        "enable_result_selector": enable_result_selector,
        "repair_rounds": repair_rounds,
        "enable_value_hints": enable_value_hints,
        "value_hint_mode": value_hint_mode,
        "selection_policy": selection_policy,
        "candidate_sources": candidate_sources,
        "disable_safe_repairs": disable_safe_repairs,
        "posterior_selection": posterior_selection,
        "bf_threshold": bf_threshold,
        "schema_graph_ablation": schema_graph_ablation,
        "save_full_candidate_trace": bool(save_full_candidate_trace),
        "TQA_VOTE_TEMPERATURE": os.environ.get("TQA_VOTE_TEMPERATURE", ""),
    }
    cache_key = hashlib.md5(json.dumps(cache_config, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:10]
    cache_dir = os.path.join(result_dir, f"tqabench_symdataset_cache_strict_{cache_key}")
    os.makedirs(cache_dir, exist_ok=True)
    results: List[Dict[str, Any]] = []
    reports: List[Dict[str, Any]] = []
    for idx, sample in enumerate(tqdm(samples, total=len(samples), desc="Solving symDataset")):
        cp = os.path.join(cache_dir, _safe_filename(sample.get("id", idx)) + ".pkl")
        if resume and os.path.exists(cp):
            try:
                r, rep = pickle.load(open(cp, "rb"))
                results.append(r)
                reports.append(rep)
                continue
            except Exception:
                pass
        try:
            r, rep = solve_one_sample(
                sample, llm, votes=votes, parallel_votes=parallel_votes,
                max_schema_chars=max_schema_chars, max_sql_candidates=max_sql_candidates,
                enable_result_selector=enable_result_selector, repair_rounds=repair_rounds,
                enable_value_hints=enable_value_hints, value_hint_mode=value_hint_mode,
                selection_policy=selection_policy,
                candidate_sources=candidate_sources,
                disable_safe_repairs=disable_safe_repairs,
                posterior_selection=posterior_selection,
                bf_threshold=bf_threshold,
                schema_graph_ablation=schema_graph_ablation,
                save_full_candidate_trace=save_full_candidate_trace,
                debug=debug,
            )
        except Exception as exc:
            r = copy.deepcopy(sample)
            r.update({
                "answer": None,
                "pred_answer": None,
                "answer_source": "tqabench_symdataset_error",
                "correct": False,
                "tqabench_symdataset_sql": {"error": str(exc), "version": "v43_guarded_multitable_candidate_bayes_leakage_safe"},
            })
            rep = {"id": sample.get("id"), "error": str(exc), "gold": sample.get("gold_value"), "pred": None, "correct": False, "invalid": True}
            if debug:
                print(f"[TQA-SymDataset] case {idx} failed: {exc}", flush=True)
        results.append(r)
        reports.append(rep)
        try:
            pickle.dump((r, rep), open(cp, "wb"))
        except Exception:
            pass
    metrics = evaluate_results(results)
    metrics["experiment_config"] = cache_config
    metrics["cache_key"] = cache_key
    return results, reports, metrics


def _output_path(path: str) -> Path:
    """Return a normalised absolute output path and create its parent directory."""
    target = Path(os.path.abspath(os.path.normpath(str(path)))).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    return target


def _replace_with_retry(tmp: Path, target: Path, retries: int = 4) -> None:
    """Atomically replace an output file, retrying transient Windows locks."""
    last_error: Optional[BaseException] = None
    for attempt in range(max(int(retries), 1)):
        try:
            os.replace(str(tmp), str(target))
            return
        except OSError as exc:
            last_error = exc
            if attempt + 1 < retries:
                time.sleep(0.25 * (attempt + 1))
    if last_error is not None:
        raise last_error


def write_json(path: str, payload: Any) -> None:
    """Write JSON through a temporary file so an interrupted run stays resumable."""
    target = _output_path(path)
    tmp = target.with_name(target.name + ".tmp")
    try:
        with tmp.open("w", encoding="utf-8", newline="\n") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2, default=str)
            f.write("\n")
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        _replace_with_retry(tmp, target)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def write_jsonl(path: str, rows: Iterable[Dict[str, Any]]) -> None:
    """Atomically write JSONL, avoiding direct overwrite failures on Windows."""
    target = _output_path(path)
    tmp = target.with_name(target.name + ".tmp")
    try:
        with tmp.open("w", encoding="utf-8", newline="\n") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        _replace_with_retry(tmp, target)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def write_report_csv(path: str, rows: Iterable[Dict[str, Any]]) -> None:
    """Atomically write the human-readable per-case CSV report."""
    rows = list(rows)
    fields = ["id", "scale", "database", "db_id", "task_index", "correct", "invalid", "gold", "pred", "confidence", "answer_source", "oracle_covered", "valid_candidate_count", "question", "vote_sqls"]
    target = _output_path(path)
    tmp = target.with_name(target.name + ".tmp")
    try:
        with tmp.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                cleaned = dict(row)
                cleaned["vote_sqls"] = json.dumps(cleaned.get("vote_sqls"), ensure_ascii=False, default=str)
                writer.writerow(cleaned)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        _replace_with_retry(tmp, target)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
