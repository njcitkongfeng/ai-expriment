from __future__ import annotations
"""
Chain-of-Table Operation Planner — Full TableMaster + Chain-of-Table Fusion.

Architecture:
  1. Table-of-Focus: schema linking → relevant rows & columns
  2. Rich Verbalization: table descriptions + FK relationships
  3. LLM plans operation sequence
  4. Ops executed on actual table → intermediate results
  5. Final answer from execution (deterministic) or LLM (semantic)
"""


import re
from typing import Any, Dict, List, Optional, Tuple


# ══════════════════════════════════════════════════════════════════════
# Table-of-Focus — row & column filtering via schema linking
# ══════════════════════════════════════════════════════════════════════

def _build_focused_tables(
    tables: Dict[str, List[List[Any]]],
    question: str,
    max_rows: int = 12,
) -> Dict[str, List[List[Any]]]:
    """Extract question-relevant rows and columns from all tables."""
    ql = question.lower()
    q_words = set(re.findall(r"[a-zA-Z0-9]+", ql))
    focused = {}

    for tn, table in tables.items():
        if not isinstance(table, list) or len(table) < 2:
            continue
        header = [str(h) for h in table[0]]
        hl = [h.lower() for h in header]

        # Column selection: keep cols with question-token overlap
        relevant_cols = set()
        for ci, h in enumerate(hl):
            if set(re.findall(r"[a-zA-Z0-9]+", h)) & q_words:
                relevant_cols.add(ci)
        # Always keep ID/FK columns
        for ci, h in enumerate(hl):
            if "id" in h or h.endswith("_id"):
                relevant_cols.add(ci)
        if len(relevant_cols) < 3:
            relevant_cols = set(range(min(3, len(header))))

        # Row selection: rows with value matches
        matched = set()
        for ri, row in enumerate(table[1:], start=1):
            for ci in relevant_cols:
                if ci < len(row) and len(str(row[ci]).strip()) >= 2:
                    if str(row[ci]).strip().lower() in ql:
                        matched.add(ri)
                        break
        # Also: rows with token overlap
        if len(matched) < 3:
            for ri, row in enumerate(table[1:], start=1):
                if ri in matched: continue
                rt = set()
                for ci in relevant_cols:
                    if ci < len(row):
                        rt |= set(re.findall(r"[a-zA-Z0-9]+", str(row[ci]).lower()))
                if len(rt & q_words) >= 2:
                    matched.add(ri)

        # Build focused table: relevant cols × matched rows
        sc = sorted(relevant_cols)
        if matched:
            focused[tn] = [[header[ci] for ci in sc]] + [
                [str(table[ri][ci]) if ci < len(table[ri]) else "" for ci in sc]
                for ri in sorted(matched)[:max_rows]
            ]
        else:
            focused[tn] = [[header[ci] for ci in sc]] + [
                [str(r[ci]) if ci < len(r) else "" for ci in sc]
                for r in table[1:max_rows]
            ]

    return focused


# ══════════════════════════════════════════════════════════════════════
# Rich Verbalization
# ══════════════════════════════════════════════════════════════════════

def _verbalize_rich(tables, focused_tables, question):
    """Generate natural-language description of tables and relationships."""
    lines = []
    tnames = list(focused_tables.keys())
    ql = question.lower()

    for tn in tnames:
        ft = focused_tables.get(tn)
        orig = tables.get(tn)
        if not ft or not orig:
            continue
        cols = ft[0]
        n_rows = len(ft) - 1
        orig_rows = len(orig) - 1 if isinstance(orig, list) and len(orig) > 1 else n_rows

        # Detect column types
        num_cols = []
        text_cols = []
        for ci, c in enumerate(cols):
            vals = [r[ci] for r in ft[1:] if ci < len(r) and str(r[ci]).strip()]
            if vals:
                numeric = sum(1 for v in vals if str(v).replace('.', '').replace('-', '').isdigit())
                if numeric / len(vals) >= 0.5:
                    num_cols.append(c)
                else:
                    text_cols.append(c)
            else:
                text_cols.append(c)

        lines.append(
            f"Table '{tn}': {len(cols)} columns, showing {n_rows} of {orig_rows} rows."
        )
        lines.append(f"  Columns: {cols}")
        if num_cols:
            lines.append(f"  Numeric: {num_cols}")
        if text_cols:
            lines.append(f"  Text: {text_cols}")

    # Detect FK relationships
    fks = _detect_fks(focused_tables)
    if fks:
        lines.append("\nTable relationships (foreign keys):")
        for ta, ca, tb, cb in fks[:10]:
            lines.append(f"  {ta}.{ca} ↔ {tb}.{cb}")

    # Question-relevant hints
    hints = []
    if any(w in ql for w in ["how many", "count", "number of"]):
        hints.append("Use COUNT after filtering")
    if any(w in ql for w in ["highest", "most", "maximum", "top"]):
        hints.append("Use sort DESC + limit 1")
    if any(w in ql for w in ["never", "none", "no"]):
        hints.append("A 'never' claim means ZERO matching rows")
    if any(w in ql for w in ["every", "all", "each"]):
        hints.append("Check ALL rows — one violation means FALSE")
    if hints:
        lines.append("\nReasoning hints: " + "; ".join(hints))

    return "\n".join(lines)


def _detect_fks(tables):
    """Detect FK pairs via column name patterns."""
    fks = []
    tnames = list(tables.keys())
    for i, ta in enumerate(tnames):
        A = tables[ta]
        if not isinstance(A, list) or len(A) < 2: continue
        ah = [str(h).lower() for h in A[0]]
        for j, tb in enumerate(tnames):
            if i >= j: continue
            B = tables[tb]
            if not isinstance(B, list) or len(B) < 2: continue
            bh = [str(h).lower() for h in B[0]]
            for ai, ac in enumerate(ah):
                for bi, bc in enumerate(bh):
                    if ac == bc and "id" in ac:
                        fks.append((ta, A[0][ai], tb, B[0][bi]))
                    elif ac == f"{tb}_id":
                        fks.append((ta, A[0][ai], tb, B[0][bi] if bi < len(B[0]) else bc))
                    elif bc == f"{ta}_id":
                        fks.append((tb, B[0][bi], ta, A[0][ai]))
    return fks


# ══════════════════════════════════════════════════════════════════════
# Operation execution engine — Chain-of-Table step-by-step
# ══════════════════════════════════════════════════════════════════════

def _parse_op(op_str):
    """Parse operation string: 'count', 'count()', 'filter(x,y)'."""
    op_text = op_str.strip().lower()
    m = re.match(r"(\w+)\((.*)\)", op_text)
    if m:
        op = m.group(1)
        args = [a.strip() for a in m.group(2).split(",")] if m.group(2).strip() else []
    else:
        op = op_text
        args = []
    return op, args


def _execute_chain_operations(tables, operations):
    """Execute operations step-by-step on actual table, updating intermediate
    table after each operation.  Returns human-readable execution trace."""
    results = []
    if not operations:
        return results

    current_table = None
    for t in tables.values():
        if isinstance(t, list) and len(t) >= 2:
            current_table = [list(r) for r in t]
            break
    if not current_table:
        return results

    for op_str in operations:
        before_rows = len(current_table) - 1
        op, args = _parse_op(op_str)
        current_table = _apply_op(current_table, op, args)
        after_rows = len(current_table) - 1

        preview = current_table[:4]
        preview_text = " | ".join(str(c) for c in preview[0]) + "\n" if preview else ""
        preview_text += "\n".join(
            " | ".join(str(c) for c in row) for row in preview[1:4]
        )
        results.append(
            f"{op_str}: rows {before_rows} → {after_rows}\n{preview_text}"
        )

    return results


def _exec_one_op(table, op_str):
    """Execute one operation string like 'filter(opponents, 0)'."""
    try:
        op, args = _parse_op(op_str)

        header = [str(h).lower() for h in table[0]]
        rows = table[1:]

        if op in ("filter", "select_row", "where"):
            if len(args) < 2:
                return "(need col, value)"
            ci = _find_col_idx(header, args[0])
            if ci is None:
                return f"(col '{args[0]}' not found)"
            val = args[1].strip().strip("'\"")
            matched = [r for r in rows if ci < len(r) and str(r[ci]).strip().lower() == val.lower()]
            return f"{len(matched)} rows match {args[0]}={val}"

        elif op in ("count",):
            return f"count = {len(rows)}"

        elif op in ("max", "min"):
            ci = _find_col_idx(header, args[0]) if args else 0
            if ci is None: return "(col not found)"
            vals = [float(str(r[ci]).replace(',', '')) for r in rows
                    if ci < len(r) and str(r[ci]).replace('.', '').replace('-', '').strip().isdigit()]
            if not vals: return f"(no numeric values in {args[0] if args else 'col'})"
            return f"{op}({args[0] if args else ''}) = {max(vals) if op == 'max' else min(vals)}"

        elif op in ("sum", "avg", "average"):
            ci = _find_col_idx(header, args[0]) if args else 0
            if ci is None: return "(col not found)"
            vals = [float(str(r[ci]).replace(',', '')) for r in rows
                    if ci < len(r) and str(r[ci]).replace('.', '').replace('-', '').strip().isdigit()]
            if not vals: return "(no numeric values)"
            if op in ("sum",):
                return f"sum = {sum(vals)}"
            return f"avg = {sum(vals)/len(vals):.1f}"

        elif op in ("sort", "order_by"):
            ci = _find_col_idx(header, args[0]) if args else 0
            if ci is None: return "(col not found)"
            order = args[1].upper() if len(args) > 1 else "ASC"
            return f"sorted by {args[0] if args else ''} {order}"

        elif op in ("project", "select_column"):
            indices = [_find_col_idx(header, a) for a in args if _find_col_idx(header, a) is not None]
            return f"kept {len(indices)} columns: {[table[0][i] for i in indices]}"

        elif op in ("group", "group_by"):
            ci = _find_col_idx(header, args[0]) if args else 0
            if ci is None: return "(col not found)"
            from collections import Counter
            counts = Counter(str(r[ci]).strip() if ci < len(r) else "" for r in rows)
            top = counts.most_common(3)
            return f"groups: {dict(top)}"

        else:
            return f"(unknown op: {op})"

    except Exception as e:
        return f"(error: {e})"


def _find_col_idx(header, name):
    nl = str(name).lower().strip()
    for i, h in enumerate(header):
        hl = str(h).lower().strip()
        if nl == hl or nl in hl or hl in nl:
            return i
    return None


# ══════════════════════════════════════════════════════════════════════
# Main prompt builder
# ══════════════════════════════════════════════════════════════════════

def _execute_chain_full(tables, operations, is_bool):
    """Execute operations step-by-step on real table, return SUMMARY values.

    Returns a dict with keys like 'count', 'max', 'min', 'sum', 'avg', 'rows'
    describing the final table state.  This is more informative than a bare
    True/False because it lets the LLM compare against the original claim.
    """
    if not operations:
        return None

    working = None
    for t in tables.values():
        if isinstance(t, list) and len(t) >= 2:
            working = [list(r) for r in t]
            break
    if not working:
        return None

    for op_str in operations:
        op, args = _parse_op(op_str)
        try:
            working = _apply_op(working, op, args)
        except Exception:
            continue

    if not working or len(working) < 2:
        return None

    rows = working[1:]
    summary = {"rows": len(rows)}

    if len(rows) == 1 and len(rows[0]) == 1:
        v = rows[0][0]
        if isinstance(v, (int, float)):
            # Detect which aggregate produced this
            header = str(working[0][0]).lower() if working[0] else ""
            for agg in ["count", "max", "min", "sum", "avg"]:
                if agg in header:
                    summary[agg] = v
                    break
            else:
                summary["value"] = v
    elif all(len(r) == 2 for r in rows):
        # Grouped result: first col = key, second = count
        summary["groups"] = {str(r[0]): int(r[1]) if isinstance(r[1], (int, float)) else str(r[1])
                             for r in rows[:5]}

    return summary


def _apply_op(table, op, args):
    """Apply one operation to the table, returning transformed table."""
    header = [str(h) for h in table[0]]
    rows = table[1:]

    if op in ("filter", "select_row", "where"):
        if len(args) < 2:
            return table
        ci = _find_col_idx(header, args[0])
        if ci is None:
            return table
        val = args[1].strip().strip("'\"")
        matched = [r for r in rows if ci < len(r) and str(r[ci]).strip().lower() == val.lower()]
        return [table[0]] + matched

    elif op in ("count",):
        return [["count"], [len(rows)]]

    elif op in ("max",):
        ci = _find_col_idx(header, args[0]) if args else 0
        if ci is None: return table
        vals = [float(str(r[ci]).replace(',', '')) for r in rows
                if ci < len(r) and str(r[ci]).replace('.', '').replace('-', '').strip().isdigit()]
        return [[f"max({table[0][ci] if ci < len(table[0]) else ''})"], [max(vals) if vals else 0]]

    elif op in ("min",):
        ci = _find_col_idx(header, args[0]) if args else 0
        if ci is None: return table
        vals = [float(str(r[ci]).replace(',', '')) for r in rows
                if ci < len(r) and str(r[ci]).replace('.', '').replace('-', '').strip().isdigit()]
        return [[f"min({table[0][ci] if ci < len(table[0]) else ''})"], [min(vals) if vals else 0]]

    elif op in ("sum",):
        ci = _find_col_idx(header, args[0]) if args else 0
        if ci is None: return table
        vals = [float(str(r[ci]).replace(',', '')) for r in rows
                if ci < len(r) and str(r[ci]).replace('.', '').replace('-', '').strip().isdigit()]
        return [[f"sum({table[0][ci] if ci < len(table[0]) else ''})"], [sum(vals) if vals else 0]]

    elif op in ("avg", "average"):
        ci = _find_col_idx(header, args[0]) if args else 0
        if ci is None: return table
        vals = [float(str(r[ci]).replace(',', '')) for r in rows
                if ci < len(r) and str(r[ci]).replace('.', '').replace('-', '').strip().isdigit()]
        return [[f"avg({table[0][ci] if ci < len(table[0]) else ''})"], [sum(vals)/len(vals) if vals else 0]]

    elif op in ("sort", "order_by"):
        ci = _find_col_idx(header, args[0]) if args else 0
        if ci is None: return table
        reverse = args[1].upper() == "DESC" if len(args) > 1 else False
        try:
            rows_sorted = sorted(rows, key=lambda r: float(str(r[ci]).replace(',', ''))
                                 if ci < len(r) and str(r[ci]).replace('.', '').replace('-', '').strip().isdigit() else 0,
                                 reverse=reverse)
        except Exception:
            rows_sorted = rows
        return [table[0]] + rows_sorted

    elif op in ("project", "select_column"):
        indices = [_find_col_idx(header, a) for a in args if _find_col_idx(header, a) is not None]
        if not indices: return table
        return [[table[0][i] for i in indices]] + [[r[i] for i in indices if i < len(r)] for r in rows]

    elif op in ("group", "group_by"):
        ci = _find_col_idx(header, args[0]) if args else 0
        if ci is None: return table
        from collections import Counter
        counts = Counter(str(r[ci]).strip() if ci < len(r) else "" for r in rows)
        return [[table[0][ci] if ci < len(table[0]) else "group", "count"]] + [[k, v] for k, v in counts.items()]

    return table


def build_cot_operation_prompt(
    sample: Dict[str, Any],
    bf_result: Optional[Dict[str, Any]] = None,
) -> str:
    """Build the full TableMaster + Chain-of-Table fusion prompt.

    Includes:
      - Table-of-Focus (filtered rows & columns)
      - Rich verbalization (column types, FK relationships)
      - Operation planning instructions
      - Execution results for LLM-planned operations
    """
    question = str(sample.get("question") or sample.get("statement") or "")
    tables = sample.get("tables") or (
        {"t": sample["table_text"]} if sample.get("table_text") else {})

    # Step 1: Table-of-Focus
    focused = _build_focused_tables(tables, question)

    # Step 2: Rich verbalization
    verbalization = _verbalize_rich(tables, focused, question)

    is_bool = "label" in sample and sample.get("label") in (0, 1)

    if is_bool:
        op_instructions = """
Operations you can use:
  filter(column, value)  — keep only rows where column equals value
  count()               — count remaining rows
  max(column) / min(column) — get max/min value
  sum(column) / avg(column) — aggregate
  sort(column, DESC/ASC) — sort rows
  project(col1, col2)    — keep only specified columns
  group(column)          — group by column and count
"""
    else:
        op_instructions = """
Operations you can use:
  filter(column, value)  — keep only rows where column equals value
  count(), max(column), min(column), sum(column), avg(column)
  sort(column, DESC/ASC) — sort rows
  project(col1, col2)    — keep only specified columns
  group(column)          — group by column
  join(table1.col, table2.col) — join two tables (for cross-table)

For multi-table questions, plan the join path first, then filter and aggregate."""

    prompt = f"""You are a table reasoning agent.

{op_instructions}

Table descriptions:
{verbalization}

Focused tables:
"""
    for tn, ft in focused.items():
        prompt += f"\nTable '{tn}':\n"
        for row in ft[:10]:
            prompt += "  " + " | ".join(str(c) for c in row) + "\n"

    prompt += f"""
Question/Statement: {question}

Step 1 — Parse: What does the question/statement ask for? What needs to be checked?

Step 2 — Plan: Write the sequence of operations to answer it.
  Example: filter(opponents, 0) → count()

Step 3 — Execute mentally: Run each operation on the table data above.
  Write the intermediate result of each step.

Step 4 — Decide the final answer based on the execution results.

Return ONLY valid JSON:
{{"answer": <true/false or value>, "confidence": 0.0-1.0,
  "operations": ["op1", "op2", ...], "reason": "evidence"}}
"""
    return prompt
