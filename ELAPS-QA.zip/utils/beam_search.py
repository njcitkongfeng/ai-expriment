"""
Beam Search + Posterior MCMC Sampling for Candidate Program Generation.

Beam search: samples multiple parse trees from the PCFG grammar, scores
each by prior, and keeps the top-b candidates.

MCMC (Metropolis-Hastings): samples from the POSTERIOR distribution
  p(R | Q, T) ∝ p(Q | R, T) · p(R | T)
where p(Q | R, T) is the execution likelihood (real SQLite execution)
and p(R | T) is the PCFG tree prior.

This is the key fix for "MCMC不够后验化" (MCMC not posterior enough).
Each MH step now computes execution likelihood, not just prior.
"""

import copy
import math
import random
import re
from collections import defaultdict
from utils.pcfg import (
    compute_tree_prior,
    expand_nonterminal,
    tree_to_operations,
    TERMINAL_TYPES,
    GRAMMAR,
    build_schema_graph,
    _get_column_names_from_schema,
)




# ============================================================
# Deterministic schema-aware candidate programs
# ============================================================

def deterministic_candidates(sample, debug=False):
    """Generate a small set of high-precision programs from question/schema cues.

    These candidates make the experiment runnable without relying on LLM-based
    operation parameter generation. They are merged with PCFG beam/MCMC samples.
    """
    tables = sample.get('tables') or ({'t': sample.get('table_text', [])} if sample.get('table_text') else {})
    if not tables:
        return []
    question = str(sample.get('question') or sample.get('statement') or '').lower()
    schema = build_schema_graph(tables)
    col_map = _get_column_names_from_schema(schema)
    table_name = next(iter(tables.keys()))
    cols = col_map.get(table_name, [])
    num_cols = [c for c, typ in cols if typ == 'numeric']
    text_cols = [c for c, typ in cols if typ != 'numeric']
    all_cols = [c for c, _ in cols]

    def rel_col(cands):
        if not cands:
            return ''
        q_tokens = set(_tokens(question))
        best = max(cands, key=lambda c: len(q_tokens & set(_tokens(c))))
        return best

    primary_num = rel_col(num_cols) or (num_cols[0] if num_cols else '')
    primary_text = rel_col(text_cols) or (text_cols[0] if text_cols else (all_cols[0] if all_cols else ''))
    candidates = []

    def add(terminals, score=-0.50):
        tree = _make_tree(terminals)
        candidates.append(({'parse_tree': tree, 'chain': tree_to_operations(tree), 'log_prior': score}, score))

    # Filter by ALL entity/value pairs mentioned in question.
    filter_terminals = _find_all_mentioned_values(tables[table_name], question, all_cols)
    primary_filter = filter_terminals[0] if filter_terminals else None

    # Aggregation questions.
    if any(x in question for x in ['how many', 'number of', 'count']):
        terms = []
        if filter_terminals:
            terms.append(filter_terminals[0])
        terms.append(('Aggregate', {'operation': 'Aggregate', 'function': 'COUNT', 'column': '*'}))
        add(terms, -0.10)

    if any(x in question for x in ['average', 'avg', 'mean']) and primary_num:
        terms = list(filter_terminals[:1])
        terms.append(('Aggregate', {'operation': 'Aggregate', 'function': 'AVG', 'column': primary_num}))
        add(terms, -0.10)

    if any(x in question for x in ['sum', 'total']) and primary_num:
        terms = list(filter_terminals[:1])
        terms.append(('Aggregate', {'operation': 'Aggregate', 'function': 'SUM', 'column': primary_num}))
        add(terms, -0.10)

    if any(x in question for x in ['highest', 'largest', 'most', 'maximum', 'max', 'top']) and primary_num:
        if any(x in question for x in ['which', 'who', 'name', 'what']):
            add([
                ('SelectCols', {'operation': 'SelectCols', 'columns': [primary_text, primary_num]}),
                ('SortBy', {'operation': 'SortBy', 'column': primary_num, 'order': 'DESC'}),
                ('Limit', {'operation': 'Limit', 'n': 1}),
            ], -0.05)
        add([('Aggregate', {'operation': 'Aggregate', 'function': 'MAX', 'column': primary_num})], -0.10)

    if any(x in question for x in ['lowest', 'smallest', 'least', 'minimum', 'min', 'bottom']) and primary_num:
        if any(x in question for x in ['which', 'who', 'name', 'what']):
            add([
                ('SelectCols', {'operation': 'SelectCols', 'columns': [primary_text, primary_num]}),
                ('SortBy', {'operation': 'SortBy', 'column': primary_num, 'order': 'ASC'}),
                ('Limit', {'operation': 'Limit', 'n': 1}),
            ], -0.05)
        add([('Aggregate', {'operation': 'Aggregate', 'function': 'MIN', 'column': primary_num})], -0.10)

    # Difference between two numeric columns.
    if any(x in question for x in ['difference', 'increase', 'decrease', 'change', 'gap']) and len(num_cols) >= 2:
        add([('ComputeDiff', {'operation': 'ComputeDiff', 'col_a': num_cols[-1], 'col_b': num_cols[0]})], -0.15)

    # Basic lookup: filter to mentioned row/entity then select relevant columns.
    if primary_filter:
        select_cols = [primary_text] if primary_text else []
        if primary_num:
            select_cols.append(primary_num)
        if select_cols:
            add([primary_filter, ('SelectCols', {'operation': 'SelectCols', 'columns': select_cols[:3]})], -0.20)

    # ── Pattern: Universal quantification ("every", "all", "never") ──
    if any(x in question for x in ['every', 'all', 'each', 'never', 'none']) and primary_num:
        numbers = re.findall(r'\d+', question)
        val = numbers[0] if numbers else '0'
        if any(x in question for x in ['never', 'none']):
            add([
                ('SelectRows', {'operation': 'SelectRows', 'column': primary_num,
                                'operator': '>', 'value': val}),
                ('SelectCols', {'operation': 'SelectCols', 'columns': [primary_text, primary_num]}),
            ], -0.05)
        if any(x in question for x in ['every', 'all', 'each']):
            add([
                ('SelectRows', {'operation': 'SelectRows', 'column': primary_num,
                                'operator': '=', 'value': '0'}),
                ('SelectCols', {'operation': 'SelectCols', 'columns': [primary_text, primary_num]}),
            ], -0.05)

    # ── Pattern: Multi-condition lookup ──
    if len(filter_terminals) >= 2:
        combined = list(filter_terminals[:2])
        combined.append(('SelectCols', {'operation': 'SelectCols', 'columns': all_cols[:3]}))
        add(combined, -0.08)

    # ── Pattern: GroupBy for distribution questions ──
    group_candidates = [c for c, _ in cols if c != primary_text]
    if any(x in question for x in ['in', 'on', 'during', 'by']) and group_candidates:
        group_col = rel_col(group_candidates) or group_candidates[0]
        if group_col and primary_filter:
            add([
                primary_filter,
                ('GroupBy', {'operation': 'GroupBy', 'column': group_col}),
                ('Aggregate', {'operation': 'Aggregate', 'function': 'COUNT', 'column': '*'}),
            ], -0.05)

    # ── Pattern: "outscored by" / comparison ──
    if any(x in question for x in ['outscored', 'more than', 'higher than',
                                     'greater than', 'less than', 'lower than']) and len(num_cols) >= 2:
        add([('ComputeDiff', {'operation': 'ComputeDiff', 'col_a': num_cols[-1], 'col_b': num_cols[0]})], -0.10)

    # Fallback select relevant columns.
    if not candidates and all_cols:
        ranked = sorted(all_cols, key=lambda c: len(set(_tokens(question)) & set(_tokens(c))), reverse=True)
        add([('SelectCols', {'operation': 'SelectCols', 'columns': ranked[:3]})], -0.50)

    # Deduplicate by chain signature.
    unique = []
    seen = set()
    for prog, score in candidates:
        sig = _chain_signature(prog)
        if sig not in seen:
            unique.append((prog, score))
            seen.add(sig)
    if debug:
        print(f"[Deterministic] Generated {len(unique)} schema-aware candidates")
    return unique


def _make_tree(terminals):
    return {
        'nonterminal': 'DeterministicProgram',
        'expansion': [t for t, _ in terminals],
        'children': [
            {
                'nonterminal': t,
                'expansion': [t],
                'children': [],
                'terminal': t,
                'params': params,
            }
            for t, params in terminals
        ],
    }


def _tokens(text):
    import re
    return re.findall(r'[a-zA-Z0-9]+', str(text).lower())


def _find_mentioned_value(table, question):
    if not isinstance(table, list) or len(table) < 2:
        return None
    q = str(question).lower()
    best = None
    best_len = 0
    for col_idx, h in enumerate(table[0]):
        for row in table[1:]:
            if col_idx >= len(row):
                continue
            v = str(row[col_idx]).strip()
            if not v:
                continue
            vl = v.lower()
            # Require reasonably specific string match; avoid matching single digits everywhere.
            if len(vl) >= 3 and vl in q and len(vl) > best_len:
                best = (str(h), v)
                best_len = len(vl)
    return best


def _find_all_mentioned_values(table, question, all_cols):
    """Find ALL column=value pairs where the value appears in the question.

    Returns a list of ('SelectRows', params) terminals sorted by match length.
    Unlike _find_mentioned_value which only returns the longest match,
    this returns ALL matches so multi-condition programs can be built.
    """
    if not isinstance(table, list) or len(table) < 2:
        return []
    q = str(question).lower()
    matches = []
    seen_values = set()
    for col_idx, h in enumerate(table[0]):
        for row in table[1:]:
            if col_idx >= len(row):
                continue
            v = str(row[col_idx]).strip()
            vl = v.lower()
            if not vl or len(vl) < 3 or vl in seen_values:
                continue
            if vl in q:
                matches.append((len(vl), str(h), v))
                seen_values.add(vl)
    matches.sort(key=lambda x: x[0], reverse=True)
    return [
        ("SelectRows", {"operation": "SelectRows", "column": col, "operator": "=", "value": val})
        for _, col, val in matches[:5]
    ]


# ============================================================
# Beam Search over PCFG Trees
# ============================================================

def beam_search_trees(sample, num_samples=30, beam_width=5, debug=False):
    """
    Generate multiple parse trees from PCFG, score by prior, keep top-b.

    Instead of step-by-step operation expansion, generates full trees
    from the grammar and scores them by structure-conditioned prior.

    Args:
        sample: input sample dict with tables, statement
        num_samples: number of random trees to generate
        beam_width: number of top candidates to keep
        debug: verbose output

    Returns:
        list of (program_sample, log_prior) tuples, sorted by score descending
    """
    from utils.pcfg import generate_grammar_tree

    candidates = []

    for i in range(num_samples):
        tree = generate_grammar_tree(sample, llm=None, max_depth=6)
        if tree is None:
            continue

        log_prior = compute_tree_prior(tree, sample)

        program_sample = {
            'parse_tree': tree,
            'chain': tree_to_operations(tree),
            'log_prior': log_prior,
        }
        candidates.append((program_sample, log_prior))

    # Deduplicate by chain structure
    unique = _deduplicate_by_chain(candidates)
    unique.sort(key=lambda x: x[1], reverse=True)

    if debug:
        print(f"[BeamSearch] Generated {len(candidates)} trees, "
              f"{len(unique)} unique, keeping top {beam_width}")

    return unique[:beam_width]


def _deduplicate_by_chain(candidates):
    """Deduplicate candidates by their operation chain signature."""
    seen = set()
    unique = []
    for prog, score in candidates:
        sig = _chain_signature(prog)
        if sig not in seen:
            seen.add(sig)
            unique.append((prog, score))
    return unique


def _chain_signature(program_sample):
    """Create a hashable signature of a program's operation chain."""
    chain = program_sample.get('chain', [])
    return tuple(
        (op.get('operation_name', '?'),
         _params_key(op.get('parameter_and_conf', {})))
        for op in chain
    )


def _params_key(params):
    """Stable hashable representation of params."""
    if isinstance(params, dict):
        return tuple(sorted((k, str(v)) for k, v in params.items()))
    return str(params)


# ============================================================
# Posterior MCMC Sampling (Metropolis-Hastings)
# ============================================================

def mcmc_sample_posterior(
    sample,
    n_iterations=100,
    burn_in=20,
    debug=False,
):
    """
    MCMC sampling from the POSTERIOR distribution over reasoning programs.

    Target distribution: p(R | Q, T) ∝ p(Q | R, T) · p(R | T)

    At each step:
      1. Propose a tree mutation (resample a subtree from grammar)
      2. Flatten tree to operations and compute execution likelihood via SQLite
      3. Compute tree prior from PCFG
      4. Posterior = likelihood × prior
      5. MH accept/reject using posterior ratio

    This fixes "MCMC不够后验化" — the chain now targets the true posterior,
    not just the prior.

    Args:
        sample: input sample with tables, statement
        n_iterations: total MCMC iterations
        burn_in: number of initial samples to discard
        debug: verbose output

    Returns:
        list of (program_sample, posterior_prob) tuples (unique, sorted)
    """
    from utils.pcfg import generate_grammar_tree
    from utils.execution_verifier import compute_execution_likelihood

    # Initialize from a random grammar tree
    current_tree = generate_grammar_tree(sample, llm=None, max_depth=6)
    if current_tree is None:
        return []

    current_log_prior = compute_tree_prior(current_tree, sample)
    current_prog = {
        'parse_tree': current_tree,
        'chain': tree_to_operations(current_tree),
    }
    current_likelihood = compute_execution_likelihood(current_prog, sample)
    current_log_post = math.log(max(current_likelihood, 1e-10)) + current_log_prior

    accepted = []
    all_samples = []

    for it in range(n_iterations):
        # Propose a new tree by mutating the current one
        proposed_tree = _propose_tree_mutation(current_tree, sample)
        if proposed_tree is None:
            continue

        proposed_log_prior = compute_tree_prior(proposed_tree, sample)
        proposed_prog = {
            'parse_tree': proposed_tree,
            'chain': tree_to_operations(proposed_tree),
        }
        proposed_likelihood = compute_execution_likelihood(proposed_prog, sample)
        proposed_log_post = math.log(max(proposed_likelihood, 1e-10)) + proposed_log_prior

        # Metropolis-Hastings: accept with probability min(1, posterior_ratio)
        # Using log scale: log_alpha = proposed_log_post - current_log_post
        log_alpha = proposed_log_post - current_log_post

        if math.log(random.random()) < log_alpha:
            current_tree = proposed_tree
            current_log_post = proposed_log_post
            current_log_prior = proposed_log_prior
            current_likelihood = proposed_likelihood
            current_prog = proposed_prog
            accepted.append(it)

        if it >= burn_in:
            all_samples.append({
                'parse_tree': copy.deepcopy(current_tree),
                'chain': copy.deepcopy(current_prog.get('chain', [])),
                'log_posterior': current_log_post,
                'likelihood': current_likelihood,
                'log_prior': current_log_prior,
            })

    if debug:
        acc_rate = len(accepted) / n_iterations if n_iterations > 0 else 0
        print(f"[MCMC] Acceptance rate: {acc_rate:.2%} ({len(accepted)}/{n_iterations})")
        print(f"[MCMC] Collected {len(all_samples)} post-burn-in samples")

    # Deduplicate and compute empirical probabilities
    return _deduplicate_posterior_samples(all_samples)


def _propose_tree_mutation(current_tree, sample):
    """
    Propose a new parse tree by mutating a random non-terminal node.

    The mutation picks a random non-terminal in the tree and resamples
    its expansion from the PCFG grammar. This ensures all proposals
    are grammatically valid.
    """
    if current_tree is None:
        from utils.pcfg import generate_grammar_tree
        return generate_grammar_tree(sample, llm=None, max_depth=6)

    # Collect all non-terminal nodes (internal nodes with children)
    internal_nodes = []
    _collect_internal_nodes(current_tree, internal_nodes)

    if not internal_nodes:
        return _resample_tree(sample)

    # Pick a random internal node to resample
    node = random.choice(internal_nodes)
    nt = node.get('nonterminal', '')

    if nt not in GRAMMAR:
        return _resample_tree(sample)

    # Resample this node's expansion from the grammar
    new_tree = copy.deepcopy(current_tree)

    # Find the corresponding node in the copy
    copied_nodes = []
    _collect_internal_nodes(new_tree, copied_nodes)
    for cn in copied_nodes:
        if cn.get('nonterminal', '') == nt and _node_path(cn) == _node_path(node):
            _resample_node(cn, nt, sample)
            break

    return new_tree


def _collect_internal_nodes(node, result):
    """Collect all non-terminal nodes that have children."""
    children = node.get('children', [])
    if children:
        # Is internal (has children that are non-terminals)
        for child in children:
            if child.get('children') or child.get('nonterminal', '') in GRAMMAR:
                result.append(child)
            _collect_internal_nodes(child, result)


def _node_path(node):
    """Create a path identifier for a node (approximate)."""
    parts = [node.get('nonterminal', '?')]
    terminal = node.get('terminal', '')
    if terminal:
        parts.append(terminal)
    params = node.get('params', {})
    if params:
        parts.append(str(sorted(params.items())))
    return tuple(parts)


def _resample_node(node, nonterminal, sample):
    """Resample the expansion of a specific node from the grammar."""
    rules = GRAMMAR.get(nonterminal, [])
    if not rules:
        return

    valid_rules, probs = expand_nonterminal(nonterminal, sample)
    if valid_rules is None or len(valid_rules) == 0:
        return

    # Sample a new expansion
    expansion_str, _ = random.choices(valid_rules, weights=probs, k=1)[0]
    tokens = expansion_str.split()

    node['expansion'] = tokens
    node['children'] = []

    for token in tokens:
        child = _build_child_node(token, sample, depth=0)
        node['children'].append(child)


def _build_child_node(token, sample, depth, max_depth=4):
    """Build a child node for a grammar token."""
    if depth > max_depth:
        return {
            'nonterminal': token, 'expansion': [token],
            'children': [], 'terminal': 'FinalAnswer', 'params': {}
        }

    if token in TERMINAL_TYPES:
        from utils.pcfg import _generate_llm_params
        return {
            'nonterminal': token,
            'expansion': [token],
            'children': [],
            'terminal': token,
            'params': _generate_llm_params(token, sample, None),
        }

    if token in GRAMMAR:
        rules = GRAMMAR.get(token, [])
        valid_rules, probs = expand_nonterminal(token, sample)
        if valid_rules:
            exp_str, _ = random.choices(valid_rules, weights=probs, k=1)[0]
            tokens = exp_str.split()
            child = {
                'nonterminal': token,
                'expansion': tokens,
                'children': [],
            }
            for t in tokens:
                child['children'].append(_build_child_node(t, sample, depth + 1, max_depth))
            return child

    return {
        'nonterminal': token, 'expansion': [token],
        'children': [], 'terminal': 'FinalAnswer', 'params': {}
    }


def _resample_tree(sample):
    """Generate a completely new random tree."""
    from utils.pcfg import generate_grammar_tree
    return generate_grammar_tree(sample, llm=None, max_depth=6)


def _deduplicate_posterior_samples(samples):
    """Deduplicate MCMC samples by chain signature, compute frequencies."""
    counts = defaultdict(int)
    sample_map = {}

    for s in samples:
        chain_tuple = _chain_signature(s)
        counts[chain_tuple] += 1
        if chain_tuple not in sample_map:
            sample_map[chain_tuple] = s

    total = sum(counts.values())
    result = []
    for sig, count in counts.items():
        prob = count / total if total > 0 else 0
        result.append((sample_map[sig], prob))

    result.sort(key=lambda x: x[1], reverse=True)
    return result


# ============================================================
# Combined Beam + Posterior MCMC Generator
# ============================================================

def generate_candidates(
    sample,
    beam_width=5,
    n_mcmc=80,
    debug=False,
):
    """
    Generate candidate reasoning programs via beam search + posterior MCMC.

    Beam search covers the high-prior region (doesn't miss obvious candidates).
    Posterior MCMC explores the full posterior landscape.

    Returns merged, deduplicated candidate set.

    Args:
        sample: input sample with tables, statement
        beam_width: number of beam candidates to keep
        n_mcmc: number of MCMC iterations
        debug: verbose output

    Returns:
        list of (program_sample, search_score) tuples
    """
    if debug:
        print(f"[CandidateGen] Deterministic schema-aware candidates...")

    det_candidates = deterministic_candidates(sample, debug=debug)

    if debug:
        print(f"[CandidateGen] Beam search over PCFG trees (b={beam_width})...")

    beam_candidates = beam_search_trees(
        sample, num_samples=beam_width * 6, beam_width=beam_width, debug=debug
    )

    if debug:
        print(f"[CandidateGen] Beam produced {len(beam_candidates)} candidates")
        print(f"[CandidateGen] Posterior MCMC sampling ({n_mcmc} iters)...")

    mcmc_candidates = mcmc_sample_posterior(
        sample, n_iterations=n_mcmc, burn_in=max(10, n_mcmc // 5), debug=debug
    )

    if debug:
        print(f"[CandidateGen] MCMC produced {len(mcmc_candidates)} unique candidates")

    # Merge: deterministic, beam and MCMC candidates
    all_candidates = []
    seen = set()

    for prog, det_score in det_candidates:
        sig = _chain_signature(prog)
        if sig not in seen:
            seen.add(sig)
            all_candidates.append((prog, det_score))

    for prog, log_prior in beam_candidates:
        sig = _chain_signature(prog)
        if sig not in seen:
            seen.add(sig)
            all_candidates.append((prog, log_prior))

    for prog, mcmc_prob in mcmc_candidates:
        sig = _chain_signature(prog)
        if sig not in seen:
            seen.add(sig)
            # Use MCMC posterior prob as score
            all_candidates.append((prog, math.log(max(mcmc_prob, 1e-10))))

    if debug:
        print(f"[CandidateGen] Total unique candidates: {len(all_candidates)}")

    return all_candidates
