from __future__ import annotations
"""WikiTQ-specific answer extraction, normalization, and denotation matching.

This module is additive: it does not change TabFact/Spider/TQA-Bench logic.
It is used only when dataset_name == "wikitq" or by the wikitq evaluation branch.
"""

import json
import math
import re
import unicodedata
from typing import Any, Iterable, List, Optional, Sequence, Tuple, Union

_PLACEHOLDER = {"", "none", "null", "n/a", "na", "unknown", "not found", "placeholder"}


def _strip_code_fences(text: str) -> str:
    s = str(text or "").strip()
    s = re.sub(r"^```(?:json)?\s*", "", s, flags=re.I).strip()
    s = re.sub(r"\s*```$", "", s).strip()
    return s


def _remove_thinking(text: str) -> str:
    s = str(text or "")
    s = re.sub(r"<think>.*?</think>", "", s, flags=re.I | re.S).strip()
    return s


def _json_load_maybe(text: str) -> Any:
    s = _strip_code_fences(_remove_thinking(text))
    if not s:
        return None
    try:
        return json.loads(s)
    except Exception:
        pass
    # Try to isolate an outermost complete object.  Only parse arrays when the
    # response itself starts as an array; otherwise an evidence_rows array inside
    # a truncated JSON object may be mistaken for the final answer.
    start = s.find("{")
    end = s.rfind("}")
    if start >= 0 and end > start:
        frag = s[start:end + 1]
        try:
            return json.loads(frag)
        except Exception:
            pass
    if s.lstrip().startswith("["):
        start = s.find("[")
        end = s.rfind("]")
        if start >= 0 and end > start:
            frag = s[start:end + 1]
            try:
                return json.loads(frag)
            except Exception:
                pass
    return None


def _partial_answer_value(text: str) -> Optional[Any]:
    """Extract `answer` from malformed/truncated JSON-like responses.

    DeepSeek sometimes returns a long JSON object that is truncated before the
    closing brace.  The ordinary json parser fails, but the answer value is often
    already present near the front, e.g. `{ "answer": "4", "confidence": ...`.
    """
    s = _strip_code_fences(_remove_thinking(text))
    if not s:
        return None

    # answer: ["A", "B"] or answer: [A, B]
    m = re.search(r'(?is)["\']?answer["\']?\s*:\s*(\[[^\]]*)', s)
    if m:
        frag = m.group(1)
        if not frag.endswith("]"):
            frag = frag + "]"
        try:
            return json.loads(frag)
        except Exception:
            inside = frag.strip()[1:-1]
            vals = re.findall(r'"([^"]+)"|\'([^\']+)\'', inside)
            if vals:
                return [a or b for a, b in vals]
            return [x.strip().strip('"\'') for x in re.split(r"\s*[|;]\s*|\s*,\s*", inside) if x.strip()]

    # answer: "..." with possible missing closing quote. Stop before a known next key.
    m = re.search(r'(?is)["\']?answer["\']?\s*:\s*["\']([^"\'\n\r}]*)', s)
    if m:
        val = m.group(1).strip()
        val = re.split(r'(?i)\s*,\s*"(?:confidence|evidence_rows|reason|claim_type)"\s*:', val)[0].strip()
        return val

    # answer: 123 / answer: true / answer: bare phrase until comma/newline/brace.
    m = re.search(r'(?is)["\']?answer["\']?\s*:\s*([^,}\n\r]+)', s)
    if m:
        val = m.group(1).strip().strip('"\'')
        if val:
            return val

    # Fallback for plain text forms: Answer: X / Final answer: X
    m = re.search(r'(?im)^\s*(?:final\s+answer|answer)\s*[:=]\s*(.+?)\s*$', s)
    if m:
        return m.group(1).strip()
    return None


def _clean_scalar_answer(x: Any) -> Optional[str]:
    if x is None:
        return None
    if isinstance(x, bool):
        return "true" if x else "false"
    if isinstance(x, (int, float)) and not isinstance(x, bool):
        if isinstance(x, float) and x.is_integer():
            return str(int(x))
        return str(x)
    s = str(x).strip()
    s = _strip_code_fences(_remove_thinking(s))
    # If a whole JSON object/array was accidentally passed as a string, recurse.
    obj = _json_load_maybe(s)
    if isinstance(obj, dict) and "answer" in obj:
        return _clean_scalar_answer(obj.get("answer"))
    if isinstance(obj, list) and len(obj) == 1:
        return _clean_scalar_answer(obj[0])
    s = s.strip().strip('"\'')
    s = re.sub(r"\s+", " ", s).strip()
    if s.lower() in _PLACEHOLDER:
        return None
    return s


def extract_wikitq_answer(value: Any) -> Any:
    """Return a compact answer value from raw LLM output or parsed objects.

    Output is either None, a string, or a list of strings.  It deliberately keeps
    display text (e.g. `New Delhi, India`) intact; splitting into denotation sets
    is handled by the evaluator because it depends on the gold answer cardinality.
    """
    if value is None:
        return None
    if isinstance(value, dict):
        if "answer" in value:
            return extract_wikitq_answer(value.get("answer"))
        return None
    if isinstance(value, (list, tuple, set)):
        out: List[str] = []
        for item in value:
            ans = extract_wikitq_answer(item)
            if isinstance(ans, list):
                out.extend(ans)
            elif ans is not None:
                out.append(str(ans))
        out = [x for x in (_clean_scalar_answer(x) for x in out) if x is not None]
        if not out:
            return None
        return out if len(out) > 1 else out[0]
    if isinstance(value, str):
        s = _strip_code_fences(_remove_thinking(value))
        if not s or s.lower() in _PLACEHOLDER:
            return None
        obj = _json_load_maybe(s)
        if isinstance(obj, dict) and "answer" in obj:
            return extract_wikitq_answer(obj.get("answer"))
        if isinstance(obj, list):
            return extract_wikitq_answer(obj)
        partial = _partial_answer_value(s)
        if partial is not None:
            return extract_wikitq_answer(partial)
        return _clean_scalar_answer(s)
    return _clean_scalar_answer(value)


def _unicode_norm(s: str) -> str:
    s = unicodedata.normalize("NFKC", str(s or ""))
    s = s.replace("–", "-").replace("—", "-").replace("−", "-")
    s = s.replace("“", '"').replace("”", '"').replace("’", "'")
    return s


def canonical_text(x: Any) -> str:
    s = _clean_scalar_answer(x)
    if s is None:
        return ""
    s = _unicode_norm(s).lower().strip()
    s = re.sub(r"\[[^\]]*\]", "", s)  # remove citation brackets
    s = re.sub(r"\s+", " ", s).strip()
    # Remove articles only when they are standalone words.
    s = re.sub(r"\b(the|a|an)\b", " ", s)
    # Keep decimal points, minus signs, percent signs and internal commas for numbers.
    s = re.sub(r"[^0-9a-z%.,'\- /]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip(" ,.;:'\"")
    return s


def _number_from_text(x: Any) -> Optional[float]:
    s = canonical_text(x)
    if not s:
        return None
    # Prefer the first explicit number.  Remove thousands separators first.
    s2 = re.sub(r"(?<=\d),(?=\d{3}(\D|$))", "", s)
    m = re.search(r"[-+]?\d+(?:\.\d+)?", s2)
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None


def _numbers_equiv(a: Any, b: Any) -> bool:
    na, nb = _number_from_text(a), _number_from_text(b)
    if na is None or nb is None:
        return False
    if abs(nb) < 1e-12:
        return abs(na - nb) < 1e-6
    return abs(na - nb) / abs(nb) <= 1e-6


def _scalar_equiv(pred: Any, gold: Any) -> bool:
    ps, gs = canonical_text(pred), canonical_text(gold)
    if not ps or not gs:
        return False
    if ps == gs:
        return True
    # Numeric/unit tolerant match: 33 == 33 years, 12467 == 12,467.
    if _numbers_equiv(ps, gs):
        # Avoid declaring "2010" equal to "2010 season champion" unless one side
        # is primarily numeric/unit text.  This is intentionally permissive for
        # WikiTQ count/sum/difference answers.
        return True
    # Country-code equivalence seen in WikiTQ sports/location tables.
    country_codes = {"irl": "ireland", "ire": "ireland", "usa": "united states", "us": "united states", "u.s.": "united states", "uk": "united kingdom"}
    if country_codes.get(ps) == gs or country_codes.get(gs) == ps:
        return True

    # Mild text containment for answers with parenthetical/disambiguating suffixes.
    # Only allow prefix containment to avoid incorrectly accepting long
    # "cannot be determined ... X ..." sentences.
    if len(ps) >= 4 and len(gs) >= 4:
        p_no_paren = re.sub(r"\([^)]*\)", "", ps).strip()
        g_no_paren = re.sub(r"\([^)]*\)", "", gs).strip()
        if p_no_paren and g_no_paren and p_no_paren == g_no_paren:
            return True
        if ps.startswith(gs + " ") or ps.startswith(gs + ",") or ps.startswith(gs + "("):
            return True
    return False


def _as_list_raw(x: Any) -> List[str]:
    ans = extract_wikitq_answer(x)
    if ans is None:
        return []
    if isinstance(ans, list):
        return [str(v) for v in ans if _clean_scalar_answer(v) is not None]
    return [str(ans)]


def _split_pred_for_gold(pred: Any, gold_items: Sequence[str]) -> List[str]:
    items = _as_list_raw(pred)
    if len(items) != 1:
        return items
    s = items[0]
    # Only split commas when gold has multiple answers.  This avoids breaking
    # single-cell locations such as "New Delhi, India".
    if len(gold_items) > 1:
        if "|" in s:
            return [p.strip() for p in s.split("|") if p.strip()]
        if ";" in s:
            return [p.strip() for p in s.split(";") if p.strip()]
        if "\n" in s:
            return [p.strip(" -•\t") for p in s.splitlines() if p.strip(" -•\t")]
        # Split comma-separated names only when not a thousands number.
        if "," in s and not re.search(r"\d,\d{3}", s):
            return [p.strip() for p in s.split(",") if p.strip()]
        if re.search(r"\s+and\s+", s, flags=re.I):
            return [p.strip() for p in re.split(r"\s+and\s+", s, flags=re.I) if p.strip()]
    return items


def compare_wikitq_answer(pred: Any, gold: Any) -> bool:
    """WikiTQ-style denotation comparison with practical normalization.

    - single gold: any predicted scalar equivalent to gold is correct;
    - multiple golds: prediction must cover every gold item, allowing comma/and/|
      separated model answers.
    """
    gold_items = _as_list_raw(gold)
    if not gold_items:
        return False
    pred_items = _split_pred_for_gold(pred, gold_items)
    if not pred_items:
        return False
    if len(gold_items) == 1:
        return any(_scalar_equiv(p, gold_items[0]) for p in pred_items)

    matched = [False] * len(gold_items)
    used_pred = [False] * len(pred_items)
    for gi, g in enumerate(gold_items):
        for pi, p in enumerate(pred_items):
            if used_pred[pi]:
                continue
            if _scalar_equiv(p, g):
                matched[gi] = True
                used_pred[pi] = True
                break
    return all(matched)


def wikitq_answer_key(answer: Any) -> str:
    items = _as_list_raw(answer)
    if not items:
        return "invalid"
    cans = [canonical_text(x) for x in items]
    cans = [x for x in cans if x]
    if not cans:
        return "invalid"
    # Sort multi-answer keys so equivalent ordering votes aggregate together.
    return " | ".join(sorted(cans))


def postprocess_wikitq_prediction(pred: Any) -> Any:
    ans = extract_wikitq_answer(pred)
    if isinstance(ans, list):
        cleaned = [x for x in (_clean_scalar_answer(v) for v in ans) if x is not None]
        return cleaned if len(cleaned) != 1 else cleaned[0]
    return _clean_scalar_answer(ans)
