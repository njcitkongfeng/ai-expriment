from __future__ import annotations
"""
Claim-to-Predicate Parser for TabFact fact verification.

Converts natural language claims into structured SQL predicates.
This addresses a key failure mode: PCFG generates executable but
semantically-wrong SQL (e.g. ``SELECT AVG(points) WHERE points=7``
for "kept the opponent scoreless").

The parser extracts:
  - subject: what the claim is about (team, player, event, ...)
  - condition: the logical condition to check
  - aggregation: COUNT, SUM, AVG, MAX, MIN, or None
  - comparison: how to compare the result (=, <, >, etc.)
  - target_value: the expected value for comparison
"""


import re
from typing import Any, Dict, List, Optional, Tuple


# ── Negation patterns ─────────────────────────────────────────────
NEGATION = [
    "never", "none", "no ", "not ", "without", "neither",
    "nobody", "nothing", "nowhere", "failed to", "did not",
    "does not", "do not", "was not", "were not", "is not", "are not",
]

# ── Comparison keywords ──────────────────────────────────────────
COMPARISON_PATTERNS = [
    # (regex, comparison_op, aggregation)
    (r"more than (\d+)", ">", None),
    (r"less than (\d+)", "<", None),
    (r"at least (\d+)", ">=", None),
    (r"at most (\d+)", "<=", None),
    (r"exactly (\d+)", "=", None),
    (r"over (\d+)", ">", None),
    (r"under (\d+)", "<", None),
    (r"greater than (\d+)", ">", None),
    (r"fewer than (\d+)", "<", None),
    (r"higher than (\d+)", ">", None),
    (r"lower than (\d+)", "<", None),
    (r"equal to (\d+)", "=", None),
    (r"totaling (\d+)", "=", "SUM"),
    (r"total of (\d+)", "=", "SUM"),
    (r"average of (\d+)", "=", "AVG"),
    (r"averaging (\d+)", "=", "AVG"),
]

# ── Count-based patterns ─────────────────────────────────────────
COUNT_PATTERNS = [
    r"(\w+ )?(\d+) times",
    r"(\d+) (games|matches|seasons|years|occasions|instances)",
    r"in (\d+) (games|matches|seasons)",
    r"(\d+) different",
    r"only (\w+ )?(\d+)",
]

# ── Score-related patterns ───────────────────────────────────────
SCORE_PATTERNS = [
    (r"scoreless", "=", "0"),
    (r"shut ?out", "=", "0"),
    (r"blanked", "=", "0"),
    (r"kept .* scoreless", "=", "0"),
    (r"outscored .* by (\d+)", "-", None),  # difference comparison
]


def parse_claim(statement: str, table_headers: List[str]) -> Dict[str, Any]:
    """Parse a natural language claim into a structured predicate.

    Args:
        statement: natural language claim (e.g. "the wildcats kept the
                   opposing team scoreless in ten games")
        table_headers: column names from the table

    Returns:
        dict with keys: subject, condition, aggregation, comparison,
        target_value, sql_suggestion, is_negated
    """
    stmt_lower = statement.lower().strip()
    result: Dict[str, Any] = {
        "subject": None,
        "condition": None,
        "aggregation": None,
        "comparison": "=",
        "target_value": None,
        "sql_suggestion": None,
        "is_negated": False,
    }

    # ── Detect negation ────────────────────────────────────────
    for neg in NEGATION:
        if neg in stmt_lower:
            result["is_negated"] = True
            break

    # ── Extract entity/value mentions from statement ───────────
    # Match words in the statement against table column values
    mentioned_entities: List[Tuple[str, str]] = []  # (column, value)
    # This will be filled by the caller with actual table data

    # ── Detect "every" / "all" (universal quantification) ─────
    if any(w in stmt_lower for w in ["every", "all", "each"]):
        result["aggregation"] = "COUNT"
        result["comparison"] = "="
        # "every team had several wins" → check COUNT(teams WHERE wins=0) = 0

    # ── Detect "never" / "none" patterns ──────────────────────
    if any(w in stmt_lower for w in ["never", "none", "no "]):
        result["aggregation"] = "COUNT"
        result["comparison"] = "="
        result["target_value"] = "0"
        # "never scored more than 7" → COUNT(rows WHERE points > 7) = 0

    # ── Detect scoreless / shutout patterns ────────────────────
    for pattern, comp, val in SCORE_PATTERNS:
        if re.search(pattern, stmt_lower):
            if comp == "-":
                result["aggregation"] = "MAX"
                result["comparison"] = "-"
                m = re.search(pattern, stmt_lower)
                if m:
                    result["target_value"] = m.group(1)
            else:
                result["condition"] = "opponent_score = 0"
                result["aggregation"] = "COUNT"
                result["comparison"] = "="
                result["target_value"] = "0"
            break

    # ── Detect comparison patterns ────────────────────────────
    for pattern, comp, agg in COMPARISON_PATTERNS:
        m = re.search(pattern, stmt_lower)
        if m:
            result["comparison"] = comp
            result["target_value"] = m.group(1)
            if agg:
                result["aggregation"] = agg
            break

    # ── Detect count patterns ─────────────────────────────────
    for pattern in COUNT_PATTERNS:
        m = re.search(pattern, stmt_lower)
        if m:
            # Extract the number
            nums = re.findall(r"\d+", m.group(0))
            if nums:
                if result["target_value"] is None:
                    result["target_value"] = nums[0]
                if result["aggregation"] is None:
                    result["aggregation"] = "COUNT"
            break

    # ── Detect "most" / "highest" / "largest" ─────────────────
    if any(w in stmt_lower for w in ["most", "highest", "largest", "greatest",
                                       "maximum", "top"]):
        if result["aggregation"] is None:
            result["aggregation"] = "MAX"

    # ── Detect "least" / "lowest" / "smallest" ────────────────
    if any(w in stmt_lower for w in ["least", "lowest", "smallest", "minimum",
                                       "bottom"]):
        if result["aggregation"] is None:
            result["aggregation"] = "MIN"

    # ── Detect "average" / "mean" ─────────────────────────────
    if any(w in stmt_lower for w in ["average", "avg", "mean"]):
        if result["aggregation"] is None:
            result["aggregation"] = "AVG"

    # ── Generate SQL suggestion ───────────────────────────────
    result["sql_suggestion"] = _build_sql_suggestion(result, table_headers)

    return result


def _build_sql_suggestion(parsed: Dict[str, Any],
                          headers: List[str]) -> Optional[str]:
    """Build a suggested SQL query from the parsed claim."""
    agg = parsed.get("aggregation")
    comp = parsed.get("comparison", "=")
    target = parsed.get("target_value")
    condition = parsed.get("condition")

    if agg is None and condition is None:
        return None

    # Find numeric columns for aggregation
    num_cols = [h for h in headers
                if any(kw in h.lower() for kw in
                       ["score", "points", "wins", "losses", "goals",
                        "attendance", "population", "revenue", "profit",
                        "age", "year", "capacity", "price", "salary"])]
    primary_col = num_cols[0] if num_cols else (headers[0] if headers else "*")

    if agg:
        select = f"SELECT {agg}({primary_col})"
        if condition:
            return f"{select} FROM t WHERE {condition}"
        elif target and comp == "=" and target == "0" and parsed.get("is_negated"):
            return f"SELECT COUNT(*) FROM t WHERE {primary_col} > 0"
        else:
            return f"{select} FROM t"

    if condition:
        return f"SELECT COUNT(*) FROM t WHERE {condition}"

    return None


def apply_claim_predicate(
    statement: str,
    table_headers: List[str],
) -> Dict[str, Any]:
    """Public API: parse a claim and return structured predicate.

    This should be called during candidate generation for TabFact
    to produce semantically-meaningful SQL suggestions.
    """
    return parse_claim(statement, table_headers)
