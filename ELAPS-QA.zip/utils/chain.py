# Copyright 2024 The Chain-of-Table authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from multiprocessing.dummy import Pool as ThreadPool
import copy
import math
import re
from tqdm import tqdm
import numpy as np
from utils.helper import table2string
from collections import defaultdict
import pickle
import os

import multiprocessing as mp

from operations import *


def fixed_chain_exec_mp(llm, init_samples, fixed_op_list, n_proc=10, chunk_size=50):
    history = {}
    final_result = None

    chain_header = copy.deepcopy(init_samples)
    chain_key = ""

    for i, (op_name, solver_func, kargs, llm_kargs) in enumerate(fixed_op_list):
        chain_key += f"->{op_name}" if i > 0 else op_name
        chain_header = conduct_single_solver_mp(
            llm=llm,
            all_samples=chain_header,
            solver_func=solver_func,
            tqdm_tag=op_name,
            n_proc=n_proc,
            chunk_size=chunk_size,
            llm_options=llm.get_model_options(
                **llm_kargs,
            ),
            **kargs,
        )

        history[f"({i}) {chain_key}"] = chain_header
        if i == len(fixed_op_list) - 1:
            final_result = chain_header

    return final_result, history


def conduct_single_solver(llm, all_samples, solver_func, tqdm_tag=None, **kwargs):
    result_samples = [None for _ in range(len(all_samples))]

    for idx in tqdm(range(len(all_samples)), desc=tqdm_tag):
        try:
            sample = all_samples[idx]
            table_info = get_table_info(
                sample,
                skip_op=kwargs.get("skip_op", []),
                first_n_op=kwargs.get("first_n_op", None),
            )
            proc_sample = solver_func(sample, table_info, llm, **kwargs)
            result_samples[idx] = proc_sample
        except Exception as e:
            print(f"Error in {idx}th sample: {e}")
            continue
    return result_samples


def _conduct_single_solver_mp_core(arg):
    idx, sample, llm, solver_func, kwargs = arg
    try:
        table_info = get_table_info(
            sample,
            skip_op=kwargs.get("skip_op", []),
            first_n_op=kwargs.get("first_n_op", None),
        )
        proc_sample = solver_func(sample, table_info, llm, **kwargs)
        return idx, proc_sample
    except Exception as e:
        print(f"Error in {idx}-th sample: {e}")
        return idx, None


def conduct_single_solver_mp(
    llm, all_samples, solver_func, tqdm_tag=None, n_proc=10, chunk_size=50, **kwargs
):
    result_samples = [None for _ in range(len(all_samples))]

    args = [
        (idx, sample, llm, solver_func, kwargs)
        for idx, sample in enumerate(all_samples)
    ]

    if n_proc <= 1:
        iterator = map(_conduct_single_solver_mp_core, args)
        for idx, proc_sample in tqdm(iterator, total=len(all_samples), desc=tqdm_tag):
            result_samples[idx] = proc_sample
    else:
        # OpenAI-compatible clients can contain locks that cannot be pickled on
        # Windows. Threads avoid serializing the shared LLM client.
        pool_cls = ThreadPool if os.name == "nt" else mp.Pool
        with pool_cls(processes=n_proc) as p:
            for idx, proc_sample in tqdm(
                p.imap_unordered(_conduct_single_solver_mp_core, args, chunksize=chunk_size),
                total=len(all_samples),
                desc=tqdm_tag,
            ):
                result_samples[idx] = proc_sample

    return result_samples


def get_act_func(name):
    try:
        return eval(f"{name}_act")
    except:

        def _default_act(table_text, *args, **kwargs):
            return copy.deepcopy(table_text)

        if "query" not in name:
            print("Unknown operation: ", name)
        return _default_act


def get_table_info(sample, skip_op=[], first_n_op=None):
    table_text = sample["table_text"]
    chain = sample["chain"]

    if first_n_op is not None:
        chain = chain[:first_n_op]

    table_info = {
        "table_text": table_text,
        "act_chain": [],
    }

    for operation in chain:
        operation_name = operation["operation_name"]
        act_func = get_act_func(operation_name)
        table_info = act_func(table_info, operation, skip_op=skip_op)

    return table_info


def get_table_log(sample, skip_op=[], first_n_op=None):
    table_text = sample["table_text"]
    chain = sample["chain"]

    if first_n_op is not None:
        chain = chain[:first_n_op]

    table_log = []

    table_info = {
        "table_text": table_text,
        "act_chain": [],
    }
    table_log.append(table_info)

    for operation in chain:
        operation_name = operation["operation_name"]    
        act_func = get_act_func(operation_name)
        table_info = act_func(table_info, operation, skip_op=skip_op)
        if 'row' in operation_name:
            table_info['act_chain'][-1] = table_info['_real_select_rows']
        if 'query' in operation_name:
            table_info['act_chain'].append(f'{operation_name}()')
            table_info['cotable_result'] = operation['parameter_and_conf'][0][0]
        table_log.append(table_info)

    return table_log


# Dynmiac Chain Func


plan_add_column_demo = """If the table does not have the needed column to tell whether the statement is True or False, we use f_add_column() to add a new column for it. For example,
/*
col : rank | lane | player | time
row 1 :  | 5 | olga tereshkova (kaz) | 51.86
row 2 :  | 6 | manjeet kaur (ind) | 52.17
row 3 :  | 3 | asami tanno (jpn) | 53.04
*/
Statement: there are one athlete from japan.
Function: f_add_column(country of athlete)
Explanation: The statement is about the number of athletes from japan. We need to known the country of each athlete. There is no column of the country of athletes. We add a column "country of athlete"."""

plan_select_column_demo = """If the table only needs a few columns to tell whether the statement is True or False, we use f_select_column() to select these columns for it. For example,
/*
col : code | county | former province | area (km2) | population | capital
row 1 : 1 | mombasa | coast | 212.5 | 939,370 | mombasa (city)
row 2 : 2 | kwale | coast | 8,270.3 | 649,931 | kwale
row 3 : 3 | kilifi | coast | 12,245.9 | 1,109,735 | kilifi
*/
Statement: momasa is a county with population higher than 500000.
Function: f_select_column(county, population)
Explanation: The statement wants to check momasa county with population higher than 500000. We need to know the county and its population. We select the column "county" and column "population"."""

plan_select_row_demo = """If the table only needs a few rows to tell whether the statement is True or False, we use f_select_row() to select these rows for it. For example,
/*
table caption : jeep grand cherokee.
col : years | displacement | engine | power | torque
row 1 : 1999 - 2004 | 4.0l (242cid) | power tech i6 | - | 3000 rpm
row 2 : 1999 - 2004 | 4.7l (287cid) | powertech v8 | - | 3200 rpm
row 3 : 2002 - 2004 | 4.7l (287cid) | high output powertech v8 | - | -
row 4 : 1999 - 2001 | 3.1l diesel | 531 ohv diesel i5 | - | -
row 5 : 2002 - 2004 | 2.7l diesel | om647 diesel i5 | - | -
*/
Statement: the jeep grand cherokee with the om647 diesel i5 had the third lowest numbered displacement.
Function: f_select_row(row 1, row 4, row 5)
Explanation: The statement wants to check the om647 diesel i5 had third lowest numbered displacement. We need to know the first three low numbered displacement and all rows that power is om647 diesel i5. We select the row 1, row 4, row 5."""

plan_group_column_demo = """If the statement is about items with the same value and the number of these items, we use f_group_column() to group the items. For example,
/*
col : district | name | party | residence | first served
row 1 : district 1 | nelson albano | dem | vineland | 2006
row 2 : district 1 | robert andrzejczak | dem | middle twp. | 2013†
row 3 : district 2 | john f. amodeo | rep | margate | 2008
*/
Statement: there are 5 districts are democratic
Function: f_group_column(party)
Explanation: The statement wants to check 5 districts are democratic. We need to know the number of dem in the table. We group the rows according to column "party"."""

plan_sort_column_demo = """If the statement is about the order of items in a column, we use f_sort_column() to sort the items. For example,
/*
col : position | club | played | points
row 1 : 1 | malaga cf | 42 | 79
row 10 : 10 | cp merida | 42 | 59
row 3 : 3 | cd numancia | 42 | 73
*/
Statement: cd numancia placed in the last position.
Function: f_sort_column(position)
Explanation: The statement wants to check about cd numancia in the last position. We need to know the order of position from last to front. We sort the rows according to column "position"."""

plan_full_demo_simple = """Here are examples of using the operations to tell whether the statement is True or False.

/*
col : date | division | league | regular season | playoffs | open cup | avg. attendance
row 1 : 2001/01/02 | 2 | usl a-league | 4th, western | quarterfinals | did not qualify | 7,169
row 2 : 2002/08/06 | 2 | usl a-league | 2nd, pacific | 1st round | did not qualify | 6,260
row 5 : 2005/03/24 | 2 | usl first division | 5th | quarterfinals | 4th round | 6,028
*/
Statement: 2005 is the last year where this team was a part of the usl a-league?
Function Chain: f_add_column(year) -> f_select_row(row 1, row 2) -> f_select_column(year, league) -> f_sort_column(year) -> <END>

*/
col : rank | lane | athlete | time
row 1 : 1 | 6 | manjeet kaur (ind) | 52.17
row 2 : 2 | 5 | olga tereshkova (kaz) | 51.86
row 3 : 3 | 4 | pinki pramanik (ind) | 53.06
*/
Statement: There are 10 athletes from India.
Function Chain: f_add_column(country of athletes) -> f_select_row(row 1, row 3) -> f_select_column(athlete, country of athletes) -> f_group_column(country of athletes) -> <END>

/*
col : week | when | kickoff | opponent | results; final score | results; team record | game site | attendance
row 1 : 1 | saturday, april 13 | 7:00 p.m. | at rhein fire | w 27–21 | 1–0 | rheinstadion | 32,092
row 2 : 2 | saturday, april 20 | 7:00 p.m. | london monarchs | w 37–3 | 2–0 | waldstadion | 34,186
row 3 : 3 | sunday, april 28 | 6:00 p.m. | at barcelona dragons | w 33–29 | 3–0 | estadi olímpic de montjuïc | 17,503
*/
Statement: the competition with highest points scored is played on April 20.
Function Chain: f_add_column(points scored) -> f_select_row(*) -> f_select_column(when, points scored) -> f_sort_column(points scored) -> <END>

/*
col : iso/iec standard | status | wg
row 1 : iso/iec tr 19759 | published (2005) | 20
row 2 : iso/iec 15288 | published (2008) | 7
row 3 : iso/iec 12207 | published (2011) | 7
*/
Statement: 2 standards are published in 2011
Function Chain: f_add_column(year) -> f_select_row(row 3) -> f_select_column(year) -> f_group_column(year) -> <END>

Here are examples of using the operations to tell whether the statement is True or False."""

possible_next_operation_dict = {
    "<init>": [
        "add_column", 
        "select_row", 
        "select_column",
        "group_column",
        "sort_column",
    ],
    "add_column": [
        "select_row",
        "select_column", 
        "group_column", 
        "sort_column",
        "<END>",
    ],
    "select_row": [
        "select_column",
        "group_column",
        "sort_column",
        "<END>",
    ],
    "select_column": [
        "group_column",
        "sort_column",
        "<END>",
    ],
    "group_column": [
        "sort_column",
        "<END>",
    ],
    "sort_column": [
        "<END>",
    ],
}


def get_operation_name(string):
    # f_xxxx(...)
    res = re.findall(r"f_(.*?)\(.*\)", string)[0]
    return res


def get_all_operation_names(string):
    operation_names = []
    parts = string.split("->")
    for part in parts:
        part = part.strip()
        if part == "<END>":
            operation_names.append("<END>")
        else:
            res = re.findall(r"f_(.*?)\(.*\)", part)
            if res:
                operation_names.append(res[0])
    return operation_names


def generate_prompt_for_next_step(
    sample,
    debug=False,
    llm=None,
    llm_options=None,
    strategy="top",
):
    table_info = get_table_info(sample)
    act_chain = table_info["act_chain"]

    if debug:
        print("Act Chain: ", act_chain, flush=True)

    kept_act_chain = [x for x in act_chain if not x.startswith("skip")]
    kept_act_chain_str = " -> ".join(kept_act_chain)
    if kept_act_chain_str:
        kept_act_chain_str += " ->"

    skip_act_chain = [x for x in act_chain if x.startswith("skip")]
    skip_act_chain_op_names = []
    for op in skip_act_chain:
        op = op[len("skip ") :]
        op_name = get_operation_name(op)
        skip_act_chain_op_names.append(op_name)

    if debug:
        print("Kept Act Chain: ", kept_act_chain, flush=True)
        print("Skip Act Chain: ", skip_act_chain, flush=True)

    last_operation = (
        "<init>" if not kept_act_chain else get_operation_name(kept_act_chain[-1])
    )
    possible_next_operations = possible_next_operation_dict[last_operation]
    possible_next_operations = [
        x for x in possible_next_operations if x not in skip_act_chain_op_names
    ]

    if debug:
        print("Last Operation: ", last_operation, flush=True)
        print("Possible Next Operations: ", possible_next_operations, flush=True)

    if len(possible_next_operations) == 1:
        log = {
            "act_chain": act_chain,
            "last_operation": last_operation,
            "possible_next_operations": possible_next_operations,
            "prompt": None,
            "response": None,
            "generate_operations": None,
            "next_operation": possible_next_operations[0],
        }
        return possible_next_operations[0], log

    prompt = ""
    for operation in possible_next_operations:
        if operation == "<END>":
            continue
        prompt += eval(f"plan_{operation}_demo") + "\n\n"

    prompt += plan_full_demo_simple + "\n\n"

    prompt += "/*\n" + table2string(table_info["table_text"]) + "\n*/\n"
    prompt += "Statement: " + sample["statement"] + "\n"

    _possible_next_operations_str = " or ".join(
        [f"f_{op}()" if op != "<END>" else op for op in possible_next_operations]
    )

    if len(possible_next_operations) > 1:
        prompt += (
            f"The next operation must be one of {_possible_next_operations_str}.\n"
        )
    else:
        prompt += f"The next operation must be {_possible_next_operations_str}.\n"

    prompt += "Function Chain: " + kept_act_chain_str

    responses = llm.generate_plus_with_score(
        prompt, options=llm_options, end_str="\n\n"
    )

    if strategy == "top":
        response = responses[0][0]
        generate_operations = get_all_operation_names(response)
        if debug:
            print('Prompt:', prompt.split("\n\n")[-1])
            print('Response:', response)
            print("Generated Operations: ", generate_operations)
        next_operation = "<END>"
        for operation in generate_operations:
            if operation in possible_next_operations:
                next_operation = operation
                break
    elif strategy == "voting":
        next_operation_conf_dict = defaultdict(float)
        for response, score in responses:
            generate_operations = get_all_operation_names(response)
            next_operation = None
            for operation in generate_operations:
                if operation in possible_next_operations:
                    next_operation = operation
                    break
            if next_operation:
                next_operation_conf_dict[next_operation] += np.exp(score)
        if len(next_operation_conf_dict) != 0:
            next_operation_conf_pairs = sorted(
                next_operation_conf_dict.items(), key=lambda x: x[1], reverse=True
            )
            next_operation = next_operation_conf_pairs[0][0]
        else:
            next_operation = "<END>"

    log = {
        "act_chain": act_chain,
        "last_operation": last_operation,
        "possible_next_operations": possible_next_operations,
        "prompt": prompt,
        "response": response,
        "generate_operations": generate_operations,
        "next_operation": next_operation,
    }

    return next_operation, log


def default_operation_parameter_dict(llm):
    """Shared default operation parameter dict used by chain, beam_search, etc."""
    return {
        "add_column": (
            "addColumn",
            add_column_func,
            {},
            llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=150,
                per_example_top_p=1.0,
            ),
        ),
        "select_row": (
            "selectRow",
            select_row_func,
            {},
            llm.get_model_options(
                temperature=0.5,
                per_example_max_decode_steps=150,
                per_example_top_p=1.0,
                n_sample=8,
            ),
        ),
        "select_column": (
            "selectColumn",
            select_column_func,
            {},
            llm.get_model_options(
                temperature=0.5,
                per_example_max_decode_steps=150,
                per_example_top_p=1.0,
                n_sample=8,
            ),
        ),
        "group_column": (
            "groupColumn",
            group_column_func,
            dict(skip_op=[]),
            llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=150,
                per_example_top_p=1.0,
            ),
        ),
        "sort_column": (
            "sortColumn",
            sort_column_func,
            dict(skip_op=[]),
            llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=150,
                per_example_top_p=1.0,
            ),
        ),
        "join": (
            "join",
            select_row_func,  # placeholder: reuse select_row as join approximation
            {},
            llm.get_model_options(
                temperature=0.3,
                per_example_max_decode_steps=150,
                per_example_top_p=1.0,
                n_sample=4,
            ),
        ),
        "aggregate": (
            "aggregate",
            group_column_func,  # placeholder: reuse group as agg approximation
            {},
            llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=200,
                per_example_top_p=1.0,
            ),
        ),
        "compare": (
            "compare",
            simple_query,  # placeholder: reuse final query as comparison
            {},
            llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=200,
                per_example_top_p=1.0,
            ),
        ),
    }


def dynamic_chain_exec_one_sample(
    sample,
    llm,
    llm_options=None,
    strategy="top",
    debug=False,
    operation_parameter_dict=None,
):
    if operation_parameter_dict is None:
        operation_parameter_dict = default_operation_parameter_dict(llm)

    dynamic_chain_log = []

    current_sample = copy.deepcopy(sample)
    while True:
        # generate next operation
        next_operation, log = generate_prompt_for_next_step(
            current_sample,
            llm=llm,
            llm_options=llm_options,
            strategy=strategy,
            debug=debug,
        )
        dynamic_chain_log.append(log)

        if debug:
            print(next_operation)

        if next_operation == "<END>":
            break

        param = operation_parameter_dict[next_operation]
        op_name, solver_func, kargs, op_llm_options = param

        table_info = get_table_info(current_sample)

        current_sample = solver_func(
            current_sample, table_info, llm=llm, llm_options=op_llm_options, **kargs
        )
    return current_sample, dynamic_chain_log


def dynamic_chain_exec_with_cache_for_loop(
    all_samples,
    llm,
    llm_options=None,
    strategy="voting",
    cache_dir="./cache/debug",
):
    os.makedirs(cache_dir, exist_ok=True)
    result_samples = [None for _ in range(len(all_samples))]
    dynamic_chain_log_list = [None for _ in range(len(all_samples))]

    cache_filename = "case-{}.pkl"

    def _func(idx):
        sample = all_samples[idx]
        sample_id = sample["id"]
        cache_path = os.path.join(cache_dir, cache_filename.format(sample_id))
        if os.path.exists(cache_path):
            _, proc_sample, log = pickle.load(open(cache_path, "rb"))
        else:
            proc_sample, log = dynamic_chain_exec_one_sample(
                sample, llm=llm, llm_options=llm_options, strategy=strategy
            )
            pickle.dump((sample, proc_sample, log), open(cache_path, "wb"))
        result_samples[idx] = proc_sample
        dynamic_chain_log_list[idx] = log

    for idx in tqdm(range(len(all_samples)), total=len(all_samples)):
        try:
            _func(idx)
        except Exception as e:
            print(f"IDX={idx}: {e}", flush=True)

    return result_samples, dynamic_chain_log_list


def _dynamic_chain_exec_with_cache_mp_core(arg):
    idx, sample, llm, llm_options, strategy, cache_dir = arg

    cache_filename = "case-{}.pkl"
    try:
        sample_id = sample["id"]
        cache_path = os.path.join(cache_dir, cache_filename.format(idx))
        if os.path.exists(cache_path):
            _, proc_sample, log = pickle.load(open(cache_path, "rb"))
        else:
            proc_sample, log = dynamic_chain_exec_one_sample(
                sample, llm=llm, llm_options=llm_options, strategy=strategy
            )
            pickle.dump((sample, proc_sample, log), open(cache_path, "wb"))
        return idx, proc_sample, log
    except Exception as e:
        print(f"Error in {sample_id}: {e}", flush=True)
        return idx, None, None


def dynamic_chain_exec_with_cache_mp(
    all_samples,
    llm,
    llm_options=None,
    strategy="voting",
    cache_dir="./results/debug",
    n_proc=10,
    chunk_size=50,
):
    os.makedirs(cache_dir, exist_ok=True)
    result_samples = [None for _ in range(len(all_samples))]
    dynamic_chain_log_list = [None for _ in range(len(all_samples))]

    args = [
        (idx, sample, llm, llm_options, strategy, cache_dir)
        for idx, sample in enumerate(all_samples)
    ]

    if n_proc <= 1:
        # 单进程直接执行，避免Windows创建子进程以及pickle LLM客户端。
        iterator = map(_dynamic_chain_exec_with_cache_mp_core, args)

        for idx, proc_sample, log in tqdm(
            iterator,
            total=len(all_samples),
        ):
            result_samples[idx] = proc_sample
            dynamic_chain_log_list[idx] = log
    else:
        # Windows使用线程池，避免pickle包含RLock的LLM客户端；
        # Linux/macOS保留原来的多进程执行方式。
        pool_cls = ThreadPool if os.name == "nt" else mp.Pool

        with pool_cls(processes=n_proc) as p:
            for idx, proc_sample, log in tqdm(
                p.imap_unordered(
                    _dynamic_chain_exec_with_cache_mp_core,
                    args,
                    chunksize=chunk_size,
                ),
                total=len(all_samples),
            ):
                result_samples[idx] = proc_sample
                dynamic_chain_log_list[idx] = log

    return result_samples, dynamic_chain_log_list


# ============================================================
# PCFG + Bayes Factor Pipeline (New)
# ============================================================

def _is_tabfact_sample(sample):
    """Detect TabFact-style boolean verification samples."""
    return (isinstance(sample.get("label"), int)
            and sample.get("label") in (0, 1)
            and "answer" not in sample)


def _score_evidence(evidence_list, table_text):
    """Score LLM evidence quality for analysis (not a decision gate).

    Returns (matched_columns, matched_cell_values, evidence_score)
    where evidence_score is 0.0~1.0.
    """
    if not evidence_list or not isinstance(table_text, list) or len(table_text) < 2:
        return 0, 0, 0.0

    headers = [str(h).lower().strip() for h in table_text[0]]
    matched_cols = 0
    matched_cells = 0

    for e in evidence_list:
        if not isinstance(e, dict):
            continue
        col = str(e.get("column", "")).lower().strip()
        cell = str(e.get("cell_value", "")).strip()
        if not col:
            continue
        # Column match
        col_matched = any(col == h or col in h or h in col for h in headers)
        if col_matched:
            matched_cols += 1
            # Cell match — check if value exists in matched column
            for ci, h in enumerate(headers):
                if col == h or col in h or h in col:
                    for r in table_text[1:]:
                        if ci < len(r) and str(r[ci]).strip() == cell:
                            matched_cells += 1
                            break
                    break

    n = len(evidence_list)
    score = (0.5 * matched_cols / n + 0.5 * matched_cells / n) if n > 0 else 0.0
    return matched_cols, matched_cells, round(score, 3)


def _build_execution_visible_prompt(sample, exec_log, exec_summary, sym_ans, llm_ans):
    """Dedicated two-pass prompt: LLM sees actual execution trace, not re-planning."""
    statement = str(sample.get("statement") or sample.get("question") or "")
    return f"""You are verifying a table fact.

Original statement: {statement}

First-pass symbolic answer: {sym_ans}
First-pass LLM answer: {llm_ans}
They disagree.

The first-pass operations were executed on the actual table.
Execution trace (each step shows the intermediate table):
{chr(10).join(exec_log)}

Execution summary: {exec_summary}

Important:
- The operations may be incomplete or semantically wrong.
- Do NOT blindly trust the execution result.
- Compare the execution summary with the original statement.
- The execution summary shows computed values (count/max/min etc.),
  NOT the final TRUE/FALSE answer. You must decide if the computed
  values support or contradict the statement.

Return ONLY valid JSON:
{{"answer": true or false, "reason": "comparing statement with execution result"}}"""


def _llm_verify_with_execution(llm, sample, operations, sym_ans, llm_ans, bf_result, llm_options):
    """Execute LLM-planned operations on real table, then ask LLM to re-judge
    with actual intermediate results visible.  Dedicated two-pass prompt.

    Returns dict with answer, exec_log, exec_summary for later analysis."""
    from utils.llm_refinement import _extract_json_object
    from utils.cot_planner import _execute_chain_operations, _execute_chain_full

    tables = sample.get("tables") or (
        {"t": sample["table_text"]} if sample.get("table_text") else {})
    is_bool = isinstance(sym_ans, bool)

    exec_log = []
    exec_summary = None
    if operations:
        try:
            exec_log = _execute_chain_operations(tables, operations)
            exec_summary = _execute_chain_full(tables, operations, is_bool)
        except Exception:
            pass

    prompt = _build_execution_visible_prompt(
        sample, exec_log, exec_summary, sym_ans, llm_ans)

    try:
        raw = llm.generate(prompt, options=llm_options)
        parsed = _extract_json_object(raw)
        ans = None
        if parsed:
            ans = parsed.get("answer")
            if isinstance(ans, str):
                ans = ans.strip().upper()
                if ans in ("TRUE", "YES", "1", "T"): ans = True
                elif ans in ("FALSE", "NO", "0", "F"): ans = False
        return {"success": True, "answer": ans,
                "exec_log": exec_log, "exec_summary": exec_summary,
                "raw_response": raw}
    except Exception as e:
        return {"success": False, "error": str(e),
                "exec_log": exec_log, "exec_summary": exec_summary}


def _llm_self_consistency(llm, sample, sym_ans, llm_ans, bf_result, llm_options, n=3):
    """Run LLM n times with temp=0.3. Return majority answer or None."""
    from utils.llm_refinement import build_llm_refinement_prompt
    question = str(sample.get('question') or sample.get('statement') or '')
    extra = (
        f"Symbolic: {sym_ans}. LLM: {llm_ans}. "
        f"They disagree. Re-examine the table and decide."
    )
    prompt = build_llm_refinement_prompt(sample, bf_result, failure_context=extra)
    votes = []
    for _ in range(n):
        try:
            opts = dict(llm_options or {}); opts["temperature"] = 0.3
            raw = llm.generate(prompt, options=opts)
            from utils.llm_refinement import _extract_json_object
            parsed = _extract_json_object(raw)
            if parsed:
                ans = parsed.get("answer")
                if isinstance(ans, str):
                    ans = ans.strip().upper()
                    if ans in ("TRUE", "YES", "1", "T"): ans = True
                    elif ans in ("FALSE", "NO", "0", "F"): ans = False
                if isinstance(ans, bool): votes.append(ans)
        except Exception: pass
    if not votes: return None
    t, f = sum(1 for v in votes if v is True), sum(1 for v in votes if v is False)
    return True if t > f else (False if f > t else None)


def _flat_chain_to_tree(chain):
    """Convert a flat operation chain into a parse tree for BF scoring.

    Chain-of-Table LLM generates flat operation sequences like
    ``[f_select_row, f_select_column, f_group_by, f_aggregate]``.
    This wraps them in a minimal parse tree so they can be scored
    alongside PCFG grammar candidates.
    """
    children = []
    for op in chain:
        op_name = op.get("operation_name", "")
        params = op.get("parameter_and_conf", op.get("params", {}))
        children.append({
            "nonterminal": op_name,
            "expansion": [op_name],
            "children": [],
            "terminal": op_name,
            "params": params,
        })
    return {
        "nonterminal": "CoTChain",
        "expansion": [child["nonterminal"] for child in children],
        "children": children,
    }



def _risk_reasons_for_llm(bf_result, best_sample, sample, min_bf=3.0):
    """Return symbolic-risk reasons that should trigger LLM review.

    BF alone can be high even when the whole candidate pool is semantically
    wrong.  This gate catches high-confidence-but-risky cases.
    """
    reasons = []
    bf = float(bf_result.get('bf_value', 0.0) or 0.0)
    if bf < float(min_bf):
        reasons.append(f"low_bayes_factor<{min_bf}")

    sql = str(best_sample.get('program') or best_sample.get('representative_program') or '').upper()
    answer = best_sample.get('answer')
    question = str(sample.get('question') or sample.get('statement') or sample.get('cleaned_statement') or '').lower()
    tables = sample.get('tables') or ({'t': sample.get('table_text', [])} if sample.get('table_text') else {})

    if answer is None:
        reasons.append('empty_answer')

    logic_keywords = [
        ' WHERE ', ' GROUP BY ', ' ORDER BY ', ' LIMIT ', ' HAVING ',
        'COUNT(', 'SUM(', 'AVG(', 'MAX(', 'MIN(', ' JOIN ', ' DISTINCT '
    ]
    if sql and not any(k in f' {sql} ' for k in logic_keywords):
        reasons.append('trivial_sql')

    if len(tables) >= 2 and any(w in question for w in [' join ', ' with ', ' whose ', ' by ', ' per ', ' each ', ' for ']):
        if ' JOIN ' not in f' {sql} ':
            reasons.append('multi_table_question_without_join')

    if any(w in question for w in ['how many', 'number of', 'count', 'total', 'sum', 'average', 'mean']):
        if not any(fn in sql for fn in ['COUNT(', 'SUM(', 'AVG(']):
            reasons.append('aggregation_question_without_aggregate')

    if any(w in question for w in ['highest', 'lowest', 'largest', 'smallest', 'most', 'least', 'top', 'earliest', 'latest']):
        if 'ORDER BY' not in sql:
            reasons.append('superlative_question_without_order')

    aggr = bf_result.get('answer_aggregation') or {}
    if aggr:
        margin = float(aggr.get('answer_margin', 1.0) or 0.0)
        mass = float(aggr.get('posterior_mass', 0.0) or 0.0)
        if aggr.get('n_answer_groups', 0) >= 2 and margin < 0.10:
            reasons.append('answer_posterior_margin_low')
        if mass < 0.45:
            reasons.append('answer_posterior_mass_low')

    return reasons


def pcfg_bf_chain_exec_one_sample(
    sample,
    llm,
    llm_options=None,
    beam_width=5,
    n_mcmc=80,
    max_refinement_rounds=3,
    debug=False,
    llm_refine_mode="never",
    llm_refine_min_bf=3.0,
    llm_refine_top_k=3,
):
    """Execute the five-step executable table reasoning pipeline.

    Step 1 — Generate Reasoning Plans:
      PCFG grammar tree sampling + schema-aware deterministic patterns
      + claim-to-predicate parser + heuristic RawSQL candidates.

    Step 2 — Execute Plans:
      Compile each plan to SQL → execute on in-memory SQLite database.

    Step 3 — Verify (Bayes Factor):
      Formal execution likelihood (no gold labels) × PCFG structural prior
      + semantic prior bonus → posterior ranking → Bayes Factor.

    Step 4 — Decide:
      BF ≥ 3 → accept.  BF < 3 → grammar-guided local repair.

    Step 5 — LLM Verification (optional):
      LLM reviews table, question, and candidate evidence → final answer.

    Returns:
        (result_sample, pipeline_report)
    """
    from utils.beam_search import generate_candidates
    from utils.execution_verifier import score_all_candidates, compute_execution_likelihood
    from utils.bayes_factor import rank_and_verify, get_confidence_report
    from utils.refinement import targeted_refinement
    from utils.llm_refinement import llm_refine_answer

    # Step 1-3: Generate candidates via beam search + posterior MCMC
    # (v2: tree-based generation, no external LLM calls needed per op)
    candidates = generate_candidates(
        sample,
        beam_width=beam_width,
        n_mcmc=n_mcmc,
        debug=debug,
    )

    if not candidates:
        if debug:
            print("[PCFG-BF] No valid candidates generated, falling back to original CoT")
        if llm is None:
            empty = copy.deepcopy(sample)
            empty.update({'answer': None, 'evidence_cells': [], 'program': None,
                          'execution_result': None, 'likelihood': 0.0, 'bayes_factor': 0.0})
            return empty, {'method': 'fallback_empty', 'log': 'no candidates and no llm'}
        if str(llm_refine_mode).lower() in {"always", "fallback", "low_confidence"}:
            empty = copy.deepcopy(sample)
            llm_result = llm_refine_answer(
                llm, sample, bf_result=None, llm_options=llm_options,
                failure_context="No valid PCFG candidates were generated. Use direct table reasoning.",
                top_k=llm_refine_top_k, debug=debug,
            )
            if llm_result.get('success'):
                empty.update({'answer': llm_result.get('answer'), 'evidence_cells': [], 'program': None,
                              'execution_result': None, 'likelihood': llm_result.get('confidence', 0.0),
                              'bayes_factor': 0.0, 'llm_refinement': llm_result,
                              'answer_source': 'llm_refinement_no_candidates'})
                return empty, {'method': 'llm_refinement_no_candidates', 'log': llm_result}
        result_sample, chain_log = dynamic_chain_exec_one_sample(
            sample, llm, llm_options=llm_options, strategy="top", debug=debug,
        )
        return result_sample, {'method': 'fallback_cot', 'log': chain_log}

    # ── Claim-parser candidates (TabFact) ───────────────────────
    # Converts NL claims to structured SQL predicates for semantically
    # meaningful candidate generation.
    if _is_tabfact_sample(sample):
        try:
            from utils.claim_parser import apply_claim_predicate
            table_data = sample.get("table_text") or (
                list(sample.get("tables", {}).values())[0]
                if sample.get("tables") else [])
            headers = table_data[0] if table_data else []
            claim = apply_claim_predicate(
                str(sample.get("statement", sample.get("question", ""))),
                headers)
            sql = claim.get("sql_suggestion")
            if sql:
                claim_candidate = {
                    "parse_tree": {
                        "nonterminal": "ClaimPredicate",
                        "expansion": ["RawSQL"],
                        "children": [{
                            "nonterminal": "RawSQL",
                            "expansion": ["RawSQL"],
                            "children": [],
                            "terminal": "RawSQL",
                            "params": {"operation": "RawSQL", "sql": sql},
                        }],
                    },
                    "chain": [{"operation_name": "RawSQL",
                               "parameter_and_conf": {"sql": sql}}],
                    "log_prior": math.log(0.08),  # moderate prior
                }
                candidates.append((claim_candidate, math.log(0.08)))
                if debug:
                    print(f"[ClaimParser] Added: {sql}")
        except Exception as exc:
            if debug:
                print(f"[ClaimParser] Failed: {exc}")

    # ── Chain-of-Table LLM candidates (inject into BF pool) ─────
    # When an LLM is available, generate additional candidates via the
    # LLM refinement prompt (which has full table context) rather than
    # the original dynamic chain (which requires specific sample format).
    # The LLM refinement already provides answer-level correction; the
    # key addition is claim-parser and heuristic RawSQL candidates above.
    #
    # To add true CoT chain candidates, uncomment and adapt:
    # if llm is not None and debug:
    #     try:
    #         cot_result, _ = dynamic_chain_exec_one_sample(
    #             copy.deepcopy(sample), llm, llm_options=llm_options,
    #             strategy="top", debug=debug)
    #         ...
    #     except Exception: pass

    # Step 4: Execution likelihood via real SQLite execution
    scored = score_all_candidates(candidates, sample)

    # Step 5-6: Rank by posterior + compute Bayes Factor
    bf_result = rank_and_verify(scored, sample, debug=debug)

    # Step 7: Targeted refinement at tree-node level if BF < 3.
    # If the best program already has a near-perfect execution likelihood,
    # do not resample it away merely because the Bayes Factor is small;
    # MC-style answer matching can produce several plausible programs with
    # close posterior scores.
    best_entry_for_refine = bf_result.get('best_program')
    best_like_for_refine = best_entry_for_refine[2] if best_entry_for_refine else 0.0
    if not bf_result.get('accept', False) and best_like_for_refine < 0.95:
        if debug:
            print(f"[PCFG-BF] BF={bf_result['bf_value']:.2f} — entering refinement loop")

        bf_result = targeted_refinement(
            bf_result, sample,
            max_refinement_rounds=max_refinement_rounds,
            debug=debug,
        )
    elif not bf_result.get('accept', False) and best_like_for_refine >= 0.95:
        bf_result['accept'] = True
        bf_result['interpretation'] = (
            bf_result.get('interpretation', '') +
            ' | accepted because execution likelihood is near-perfect'
        )

    # Build output — merge original fields + enriched execution data
    confidence_report = get_confidence_report(bf_result)

    # Answer-level posterior aggregation: choose the answer with the largest
    # marginalized posterior mass, not necessarily the single best program.
    answer_group = None
    try:
        from utils.answer_aggregation import aggregate_by_answer
        answer_group = aggregate_by_answer(bf_result, sample)
        if answer_group is not None:
            bf_result['answer_aggregation'] = {
                'answer': str(answer_group.get('answer')),
                'posterior_mass': round(float(answer_group.get('posterior_mass', 0.0)), 6),
                'group_size': int(answer_group.get('group_size', 0)),
                'answer_bayes_factor': answer_group.get('answer_bayes_factor'),
                'answer_margin': round(float(answer_group.get('answer_margin', 0.0)), 6),
                'n_answer_groups': int(answer_group.get('n_answer_groups', 0)),
                'summary': answer_group.get('summary', []),
            }
    except Exception as exc:
        if debug:
            print(f"[AnswerAggregation] skipped: {exc}")

    best_entry = answer_group.get('representative_entry') if answer_group else bf_result.get('best_program')
    if best_entry is None:
        if debug:
            print("[PCFG-BF] No best program — falling back")
        if llm is None:
            empty = copy.deepcopy(sample)
            empty.update({'answer': None, 'evidence_cells': [], 'program': None,
                          'execution_result': None, 'likelihood': 0.0, 'bayes_factor': 0.0})
            return empty, {'method': 'fallback_empty', 'log': 'no best program and no llm'}
        if str(llm_refine_mode).lower() in {"always", "fallback", "low_confidence"}:
            empty = copy.deepcopy(sample)
            llm_result = llm_refine_answer(
                llm, sample, bf_result=bf_result, llm_options=llm_options,
                failure_context="No best symbolic program survived posterior ranking.",
                top_k=llm_refine_top_k, debug=debug,
            )
            if llm_result.get('success'):
                empty.update({'answer': llm_result.get('answer'), 'evidence_cells': [], 'program': None,
                              'execution_result': None, 'likelihood': llm_result.get('confidence', 0.0),
                              'bayes_factor': bf_result.get('bf_value', 0.0),
                              'llm_refinement': llm_result,
                              'answer_source': 'llm_refinement_no_best_program'})
                return empty, {'method': 'llm_refinement_no_best_program', 'log': llm_result}
        result_sample, chain_log = dynamic_chain_exec_one_sample(
            sample, llm, llm_options=llm_options, strategy="top", debug=debug,
        )
        return result_sample, {'method': 'fallback_cot', 'log': chain_log}

    best_sample = best_entry[0]
    best_posterior = best_entry[1]
    best_likelihood = best_entry[2]

    # Preserve original sample fields — including ALL gold-related keys
    # so evaluation never confuses predicted answer with gold answer.
    for key in ['table_text', 'statement', 'question',
                'answers', 'gold_answer', 'target', 'answer_gold',
                'choices', 'sql', 'database', 'label', 'id',
                'tables', 'table_caption', 'cleaned_statement']:
        if key in sample:
            best_sample[key] = sample[key]

    # Enrich with SQL execution results.
    # The predicted answer is stored separately as 'pred_answer' to avoid
    # overwriting any gold answer fields.
    from utils.execution_verifier import score_execution_with_sql
    enriched = score_execution_with_sql(best_sample, sample)
    for key in ['evidence_cells', 'program', 'execution_result', 'likelihood']:
        if key in enriched:
            best_sample[key] = enriched[key]
    # Predicted answer.  When answer aggregation is available, use the
    # marginalized answer and keep the representative program for evidence.
    best_sample['answer'] = answer_group.get('answer') if answer_group else enriched.get('answer')
    best_sample['pred_answer'] = best_sample['answer']

    best_sample['posterior_score'] = best_posterior
    best_sample['bayes_factor'] = bf_result['bf_value']
    if answer_group:
        best_sample['answer_posterior_mass'] = answer_group.get('posterior_mass')
        best_sample['answer_bayes_factor'] = answer_group.get('answer_bayes_factor')
        best_sample['answer_group_size'] = answer_group.get('group_size')
        best_sample['answer_aggregation_summary'] = answer_group.get('summary', [])
    best_sample['answer_source'] = 'pcfg_bayes_factor_answer_marginal' if answer_group else 'pcfg_bayes_factor'

    # Optional real-LLM refinement.  This is backend agnostic: the LLM may be
    # a Hugging Face online 7B model, a local vLLM server, or any
    # OpenAI-compatible endpoint.  Use --llm_refine_mode always to force a
    # true LLM call for every case, or low_confidence to call it only when BF
    # remains weak after symbolic local refinement.
    llm_mode = str(llm_refine_mode or 'never').lower()
    risk_reasons = _risk_reasons_for_llm(bf_result, best_sample, sample, llm_refine_min_bf)
    best_sample['llm_risk_reasons'] = risk_reasons
    should_llm_refine = (
        llm is not None
        and llm_mode != 'never'
        and (
            llm_mode == 'always'
            or (llm_mode == 'low_confidence' and bool(risk_reasons))
        )
    )
    llm_refinement_result = None
    if should_llm_refine:
        llm_refinement_result = llm_refine_answer(
            llm, sample, bf_result=bf_result, llm_options=llm_options,
            failure_context=(
                'Forced LLM refinement.' if llm_mode == 'always'
                else 'Risk-aware symbolic verifier triggered LLM review: ' + ', '.join(risk_reasons)
            ),
            top_k=llm_refine_top_k, debug=debug,
        )

        best_sample['llm_refinement'] = llm_refinement_result
        if llm_refinement_result.get('success'):
            symbolic_answer = best_sample.get('answer')
            llm_answer = llm_refinement_result.get('answer')
            llm_conf = float(llm_refinement_result.get('confidence', 0.0))

            best_sample['symbolic_answer_before_llm'] = symbolic_answer

            # ── Decision ───────────────────────────────────────
            if symbolic_answer is None:
                best_sample['answer'] = llm_answer
                best_sample['answer_source'] = 'llm_refinement'

            elif symbolic_answer == llm_answer:
                best_sample['answer_source'] = 'llm_confirmed'

            else:
                # Disagreement.  Boolean: execute operations on table,
                # let LLM see actual intermediate results, then re-judge.
                # Value extraction: LLM already selected from candidates.
                if isinstance(symbolic_answer, bool) and isinstance(llm_answer, bool):
                    ops = llm_refinement_result.get('operations', [])
                    second = _llm_verify_with_execution(
                        llm, sample, ops, symbolic_answer, llm_answer,
                        bf_result, llm_options)
                    best_sample['second_pass'] = second
                    if second and second.get('answer') is not None:
                        best_sample['answer'] = second['answer']
                        best_sample['answer_source'] = 'llm_verified_exec'
                    else:
                        best_sample['answer'] = llm_answer
                        best_sample['answer_source'] = 'llm_corrected'
                else:
                    best_sample['answer'] = llm_answer
                    best_sample['answer_source'] = 'llm_corrected'
                best_sample['symbolic_answer_overridden'] = symbolic_answer

            best_sample['llm_confidence'] = llm_conf

    # ── Pipeline metrics ─────────────────────────────────────
    pipeline_report = {
        'method': 'pcfg_bayes_factor_v2',
        'n_candidates': len(candidates),
        'bayes_factor': bf_result['bf_value'],
        'log_bf': bf_result.get('log_bf', float('inf')),
        'interpretation': bf_result['interpretation'],
        'accepted': bf_result['accept'],
        'confidence': confidence_report,
        'best_program_summary': _program_summary(best_sample),
        'best_execution_likelihood': best_likelihood,
        'refinement_rounds': len(bf_result.get('refinement_history', [])),
        'all_candidate_count': len(scored),
        'llm_refine_mode': llm_mode,
        'llm_risk_reasons': risk_reasons,
        'answer_aggregation': bf_result.get('answer_aggregation'),
        'llm_refinement_used': bool(llm_refinement_result and llm_refinement_result.get('used')),
        'llm_refinement_success': bool(llm_refinement_result and llm_refinement_result.get('success')),
        'answer_source': best_sample.get('answer_source'),
        # Evidence-gate metrics
        'llm_override_proposed': llm_refinement_result.get('repair_type') == 'override_with_evidence' if llm_refinement_result else False,
        'llm_override_accepted': best_sample.get('answer_source') == 'llm_corrected',
        'llm_override_rejected': best_sample.get('answer_source') == 'symbolic_kept_llm_disagreed',
        'llm_evidence_count': len(best_sample.get('verified_evidence', [])),
    }

    return best_sample, pipeline_report


def pcfg_bf_chain_exec_dataset(
    all_samples,
    llm,
    llm_options=None,
    beam_width=5,
    n_mcmc=30,
    max_refinement_rounds=3,
    debug=False,
    cache_dir="./results/pcfg_bf_cache",
    llm_refine_mode="never",
    llm_refine_min_bf=3.0,
    llm_refine_top_k=3,
):
    """Run the PCFG+BF pipeline over an entire dataset."""
    os.makedirs(cache_dir, exist_ok=True)
    result_samples = [None for _ in range(len(all_samples))]
    pipeline_reports = [None for _ in range(len(all_samples))]

    for idx in tqdm(range(len(all_samples)), total=len(all_samples)):
        try:
            sample = all_samples[idx]
            sample_id = sample.get("id", idx)
            # LLM-refinement runs must not reuse symbolic-only cache files;
            # otherwise --llm_refine_mode always could silently skip the real
            # 7B call.
            cache_suffix = "symbolic" if str(llm_refine_mode).lower() == "never" else f"llm-{str(llm_refine_mode).lower()}"
            cache_path = os.path.join(cache_dir, f"case-{sample_id}-{cache_suffix}.pkl")

            if os.path.exists(cache_path):
                result_samples[idx], pipeline_reports[idx] = pickle.load(
                    open(cache_path, "rb")
                )
            else:
                result_samples[idx], pipeline_reports[idx] = pcfg_bf_chain_exec_one_sample(
                    sample, llm,
                    llm_options=llm_options,
                    beam_width=beam_width,
                    n_mcmc=n_mcmc,
                    max_refinement_rounds=max_refinement_rounds,
                    debug=debug,
                    llm_refine_mode=llm_refine_mode,
                    llm_refine_min_bf=llm_refine_min_bf,
                    llm_refine_top_k=llm_refine_top_k,
                )
                pickle.dump(
                    (result_samples[idx], pipeline_reports[idx]),
                    open(cache_path, "wb"),
                )

        except Exception as e:
            print(f"[PCFG-BF] Error on sample {idx}: {e}", flush=True)

    return result_samples, pipeline_reports


def _program_summary(sample):
    """Human-readable program operation chain."""
    chain = sample.get('chain', [])
    if not chain:
        return "<empty>"
    return " -> ".join(
        op.get('operation_name', '?') for op in chain
    )
