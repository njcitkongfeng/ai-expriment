# Copyright 2024 The Chain-of-Table authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import pandas as pd
import json
import re
from _ctypes import PyObj_FromPtr


def _as_list(row):
    if isinstance(row, list):
        return row
    if isinstance(row, tuple):
        return list(row)
    if isinstance(row, dict):
        return list(row.values())
    return [row]


def _split_known_merged_cells(header, row):
    """Fix a few common WikiTQ CSV artifacts before padding short rows."""
    if len(row) >= len(header):
        return row

    vals = list(row)
    while len(vals) < len(header):
        changed = False
        for idx in range(min(len(vals), len(header) - 1)):
            h = str(header[idx]).lower()
            h_next = str(header[idx + 1]).lower()
            cell = str(vals[idx])
            if "height" in h and ("weight" in h_next or "lbs" in h_next) and "," in cell:
                left, right = re.split(r"\s*,\s*", cell, maxsplit=1)
                if left and right:
                    vals = vals[:idx] + [left, right] + vals[idx + 1 :]
                    changed = True
                    break
        if not changed:
            break
    return vals


def rectangularize_table_text(table_text):
    """Return a table whose rows all match the header width.

    Some WikiTQ JSONL rows contain delimiter artifacts.  Pandas refuses these
    ragged rows, so prompt-only baselines should normalize them instead of
    dropping the whole sample.
    """
    if not isinstance(table_text, list) or not table_text:
        return table_text

    header = [str(x) for x in _as_list(table_text[0])]
    width = len(header)
    if width == 0:
        return [header]

    rect_rows = []
    for raw_row in table_text[1:]:
        row = _split_known_merged_cells(header, _as_list(raw_row))
        if len(row) < width:
            row = row + [""] * (width - len(row))
        elif len(row) > width:
            row = row[: width - 1] + [" | ".join(str(x) for x in row[width - 1 :])]
        rect_rows.append(row)
    return [header] + rect_rows


def table2df(table_text, num_rows=100):
    table_text = rectangularize_table_text(table_text)
    header, rows = table_text[0], table_text[1:]
    rows = rows[:num_rows]
    df = pd.DataFrame(data=rows, columns=header)
    return df


def table2string(
    table_text,
    num_rows=100,
    caption=None,
):
    df = table2df(table_text, num_rows)
    linear_table = ""
    if caption is not None:
        linear_table += "table caption : " + caption + "\n"

    header = "col : " + " | ".join(df.columns) + "\n"
    linear_table += header
    rows = df.values.tolist()
    for row_idx, row in enumerate(rows):
        row = [str(x) for x in row]
        line = "row {} : ".format(row_idx + 1) + " | ".join(row)
        if row_idx != len(rows) - 1:
            line += "\n"
        linear_table += line
    return linear_table


class NoIndent(object):
    """Value wrapper."""

    def __init__(self, value):
        self.value = value


class MyEncoder(json.JSONEncoder):
    FORMAT_SPEC = "@@{}@@"
    regex = re.compile(FORMAT_SPEC.format(r"(\d+)"))

    def __init__(self, **kwargs):
        # Save copy of any keyword argument values needed for use here.
        self.__sort_keys = kwargs.get("sort_keys", None)
        super(MyEncoder, self).__init__(**kwargs)

    def default(self, obj):
        return (
            self.FORMAT_SPEC.format(id(obj))
            if isinstance(obj, NoIndent)
            else super(MyEncoder, self).default(obj)
        )

    def encode(self, obj):
        format_spec = self.FORMAT_SPEC  # Local var to expedite access.
        json_repr = super(MyEncoder, self).encode(obj)  # Default JSON.

        # Replace any marked-up object ids in the JSON repr with the
        # value returned from the json.dumps() of the corresponding
        # wrapped Python object.
        for match in self.regex.finditer(json_repr):
            # see https://stackoverflow.com/a/15012814/355230
            id = int(match.group(1))
            no_indent = PyObj_FromPtr(id)
            json_obj_repr = json.dumps(no_indent.value, sort_keys=self.__sort_keys)

            # Replace the matched id string with json formatted representation
            # of the corresponding Python object.
            json_repr = json_repr.replace(
                '"{}"'.format(format_spec.format(id)), json_obj_repr
            )

        return json_repr
