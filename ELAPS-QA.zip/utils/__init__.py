"""Utilities for the full Chain-of-Table experimental framework."""
