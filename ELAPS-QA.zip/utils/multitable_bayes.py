from __future__ import annotations
"""Multi-table candidate recall, verification, and Bayesian-style ranking for TQA-Bench SymDataset.

This module is leakage-safe by construction: it only consumes the visible question,
SQLite schema/values exposed through the database connection, candidate SQL strings,
and execution outputs.  It never reads gold denotations, official code, choices, or
rightIdx.
"""

import json
import math
import re
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Sequence, Tuple


def _norm(x: Any) -> str:
    return re.sub(r"\s+", " ", str(x or "").strip().lower())


def _compact(x: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", _norm(x))


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _num(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, bool):
        return float(int(x))
    if isinstance(x, (int, float)):
        if isinstance(x, float) and math.isnan(x):
            return None
        return float(x)
    s = str(x).strip().replace(',', '')
    if not s:
        return None
    if s.endswith('%'):
        s = s[:-1]
    m = re.search(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", s)
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None


def _unwrap(v: Any) -> Any:
    while isinstance(v, (list, tuple)) and len(v) == 1:
        v = v[0]
    return v


def _value_key(v: Any) -> str:
    """Stable answer key for posterior aggregation; no gold information used."""
    v = _unwrap(v)
    if isinstance(v, float):
        return f"num:{round(v, 6)}"
    if isinstance(v, int):
        return f"num:{v}"
    n = _num(v)
    if n is not None and not isinstance(v, str):
        return f"num:{round(n, 6)}"
    try:
        return json.dumps(v, ensure_ascii=False, sort_keys=True, default=str).lower()
    except Exception:
        return str(v).lower()


def build_schema_graph(db: Any, ablation: str = "none") -> Dict[str, Any]:
    """Extract a lightweight schema graph from SQLite.

    Nodes are tables and columns. Edges use declared foreign keys when present,
    and conservative name-based inferred joins when FK metadata is absent.
    """
    ablation = str(ablation or "none").lower().strip()
    cur = db.conn.cursor()
    tables = db.table_names()
    columns: Dict[str, List[Dict[str, Any]]] = {}
    pk_cols: Dict[str, List[str]] = defaultdict(list)
    edges: List[Dict[str, Any]] = []

    for t in tables:
        try:
            info = cur.execute(f"PRAGMA table_info({_quote_ident(t)})").fetchall()
        except Exception:
            info = []
        columns[t] = []
        for c in info:
            name = str(c[1])
            ctype = str(c[2] or "")
            is_pk = bool(c[5])
            columns[t].append({"name": name, "type": ctype, "pk": is_pk})
            if is_pk:
                pk_cols[t].append(name)
        try:
            fks = cur.execute(f"PRAGMA foreign_key_list({_quote_ident(t)})").fetchall()
        except Exception:
            fks = []
        if ablation not in {"no_edges", "no_foreign_keys", "no_fk"}:
            for fk in fks:
                # sqlite columns: id,seq,table,from,to,on_update,on_delete,match
                ref_t = str(fk[2])
                from_c = str(fk[3])
                to_c = str(fk[4])
                edges.append({
                    "left_table": t, "left_col": from_c,
                    "right_table": ref_t, "right_col": to_c,
                    "kind": "foreign_key",
                })

    # Conservative inferred edges: x_id -> x.id, table_id -> table.id, exact shared *_id.
    existing = {(e["left_table"], e["left_col"], e["right_table"], e["right_col"]) for e in edges}
    col_lookup = {t: [c["name"] for c in cols] for t, cols in columns.items()}
    if ablation not in {"no_edges", "no_inferred_edges", "no_inferred"}:
        for t1 in tables:
            for c1 in col_lookup.get(t1, []):
                c1n = c1.lower()
                for t2 in tables:
                    if t1 == t2:
                        continue
                    t2n = t2.lower()
                    for c2 in col_lookup.get(t2, []):
                        c2n = c2.lower()
                        match = False
                        if c1n == c2n and (c1n == "id" or c1n.endswith("_id") or c1n.endswith("id")):
                            match = True
                        if c1n in {f"{t2n}_id", f"{t2n}id"} and c2n in {"id", f"{t2n}_id", f"{t2n}id"}:
                            match = True
                        if c2n in {f"{t1.lower()}_id", f"{t1.lower()}id"} and c1n in {"id", f"{t1.lower()}_id", f"{t1.lower()}id"}:
                            match = True
                        key = (t1, c1, t2, c2)
                        if match and key not in existing:
                            existing.add(key)
                            edges.append({
                                "left_table": t1, "left_col": c1,
                                "right_table": t2, "right_col": c2,
                                "kind": "inferred_name_match",
                            })

    adjacency: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for e in edges:
        adjacency[e["left_table"]].append(e)
        rev = {
            "left_table": e["right_table"], "left_col": e["right_col"],
            "right_table": e["left_table"], "right_col": e["left_col"],
            "kind": e["kind"],
        }
        adjacency[e["right_table"]].append(rev)

    return {
        "tables": tables,
        "columns": columns,
        "primary_keys": dict(pk_cols),
        "edges": edges,
        "adjacency": dict(adjacency),
        "ablation": ablation,
        "disable_column_linking": ablation in {"no_column_links", "no_column_linking"},
        "disable_table_linking": ablation in {"no_table_links", "no_table_linking"},
    }


def schema_graph_summary(graph: Dict[str, Any], max_chars: int = 3500) -> str:
    lines: List[str] = ["SCHEMA GRAPH:"]
    for t in graph.get("tables", []):
        cols = [c["name"] + ("[PK]" if c.get("pk") else "") for c in graph.get("columns", {}).get(t, [])]
        lines.append(f"- {t}: {', '.join(cols[:30])}")
    lines.append("JOIN EDGES:")
    for e in graph.get("edges", [])[:120]:
        lines.append(f"- {e['left_table']}.{e['left_col']} = {e['right_table']}.{e['right_col']} ({e.get('kind')})")
    txt = "\n".join(lines)
    return txt if len(txt) <= max_chars else txt[:max_chars] + "\n...[schema graph truncated]"


def linked_tables_and_columns(question: str, graph: Dict[str, Any]) -> Dict[str, Any]:
    q = _norm(question)
    qc = _compact(question)
    linked_tables: List[str] = []
    linked_columns: List[Tuple[str, str]] = []
    for t in graph.get("tables", []):
        tn = _norm(t).replace("_", " ")
        if not graph.get("disable_table_linking") and tn and (tn in q or _compact(t) in qc):
            linked_tables.append(t)
        if graph.get("disable_column_linking"):
            continue
        for c in graph.get("columns", {}).get(t, []):
            cn = _norm(c["name"]).replace("_", " ")
            if len(cn) >= 3 and (cn in q or _compact(c["name"]) in qc):
                linked_columns.append((t, c["name"]))
                if t not in linked_tables:
                    linked_tables.append(t)
    return {"tables": linked_tables, "columns": linked_columns}


def _extract_sql_identifiers(sql: str) -> List[str]:
    return re.findall(r'"([^"]+)"|\b([A-Za-z_][A-Za-z0-9_]*)\b', str(sql or ""))


def sql_tables(sql: str, graph: Dict[str, Any]) -> List[str]:
    s = str(sql or "")
    tables = set()
    # Prefer FROM/JOIN positions.
    for m in re.finditer(r"\b(?:from|join)\s+([\"`\[]?)([A-Za-z_][A-Za-z0-9_ .-]*)([\"`\]]?)", s, flags=re.I):
        raw = m.group(2).strip().split()[0].strip('"`[]')
        for t in graph.get("tables", []):
            if raw.lower() == t.lower():
                tables.add(t)
    # Fallback: any exact table token.
    low = s.lower()
    for t in graph.get("tables", []):
        if re.search(rf"(?<![A-Za-z0-9_]){re.escape(t.lower())}(?![A-Za-z0-9_])", low):
            tables.add(t)
    return sorted(tables)


def _graph_connected(tables: Sequence[str], graph: Dict[str, Any]) -> bool:
    tables = list(dict.fromkeys(tables))
    if len(tables) <= 1:
        return True
    want = set(tables)
    adj = graph.get("adjacency", {})
    seen = {tables[0]}
    stack = [tables[0]]
    while stack:
        t = stack.pop()
        for e in adj.get(t, []):
            nt = e.get("right_table")
            if nt in want and nt not in seen:
                seen.add(nt)
                stack.append(nt)
    return want.issubset(seen)


def multitable_static_verify(sql: str, question: str, graph: Dict[str, Any]) -> Dict[str, Any]:
    q = _norm(question)
    s = _norm(sql)
    tables = sql_tables(sql, graph)
    risks: List[str] = []
    score = 0.0

    if not s.startswith("select") and not s.startswith("with"):
        risks.append("not_select_or_with")
        score -= 6.0
    if len(tables) >= 2 and not _graph_connected(tables, graph):
        risks.append("schema_graph_disconnected_join_path")
        score -= 2.5
    if len(tables) >= 2:
        score += 0.6
        if " join " not in f" {s} ":
            risks.append("multi_table_without_explicit_join")
            score -= 1.5
    if re.search(r"\b(how many|number of|count)\b", q):
        if "count" in s:
            score += 0.7
        else:
            risks.append("count_question_without_count")
            score -= 1.2
    if re.search(r"\b(highest|maximum|max|largest|most)\b", q):
        if re.search(r"\b(max\s*\(|order\s+by\b.*\bdesc\b|desc\b.*\blimit\b)", s):
            score += 0.8
        else:
            risks.append("superlative_without_max_or_order")
            score -= 1.2
    if re.search(r"\b(lowest|minimum|min|smallest|least)\b", q):
        if re.search(r"\b(min\s*\(|order\s+by\b.*\basc\b|asc\b.*\blimit\b)", s):
            score += 0.8
        else:
            risks.append("minimum_without_min_or_order")
            score -= 1.2
    if re.search(r"\b(average|mean)\b", q):
        if re.search(r"\bavg\s*\(", s):
            score += 0.7
        else:
            risks.append("average_question_without_avg")
            score -= 1.0
    if re.search(r"\b(ratio|rate|percent|percentage)\b", q):
        if "/" in s or re.search(r"\b(avg|sum|count)\s*\(", s):
            score += 0.5
        else:
            risks.append("ratio_question_without_ratio_logic")
            score -= 1.0
    if re.search(r"\bboth\b|\brespectively\b|\bat least one\b", q):
        if "exists" in s or "intersect" in s or s.count(" join ") >= 2:
            score += 0.5
        else:
            risks.append("multi_condition_question_without_entity_level_binding")
            score -= 0.8
    if len(tables) > 4:
        risks.append("very_long_join_path")
        score -= 0.25 * (len(tables) - 4)
    # Mild complexity prior: avoid over-penalizing necessary multi-table SQL.
    score -= 0.03 * min(80, len(re.findall(r"\b(select|join|where|group\s+by|order\s+by|exists|intersect)\b", s)))
    return {"static_prior": score, "tables": tables, "static_risks": risks, "is_multitable": len(tables) >= 2}


def _value_shape_score(question: str, value: Any) -> float:
    q = _norm(question)
    v = _unwrap(value)
    score = 0.0
    if value is None:
        return -8.0
    n = _num(v)
    if re.search(r"\b(how many|number of|count|average|mean|total|sum|ratio|rate|percent|percentage|maximum|minimum|highest|lowest)\b", q):
        score += 0.9 if n is not None else -1.2
    if re.search(r"\b(which|who|name|title|what\s+(?:city|airport|business|recipe|movie|film|artist|album|university))\b", q):
        score += 0.6 if n is None else -0.6
    if isinstance(v, (list, tuple)) and len(v) > 10 and not re.search(r"\b(list|all|what are|which are)\b", q):
        score -= 1.5
    return score


def multitable_dynamic_verify(sql: str, question: str, value: Any, attempts: Sequence[Dict[str, Any]], graph: Dict[str, Any]) -> Dict[str, Any]:
    risks: List[str] = []
    score = 0.0
    ok_attempts = [a for a in attempts if a.get("ok")]
    if ok_attempts:
        score += 0.8
    else:
        risks.append("execution_failed")
        score -= 3.0
    if value is None:
        risks.append("null_result")
        score -= 2.0
    else:
        score += _value_shape_score(question, value)
    # Detect whether repair was needed and succeeded; repair is evidence but also risk.
    repair_reasons = [str(a.get("repair_reason") or "") for a in attempts if a.get("stage") == "adaptive_sql_repair"]
    if repair_reasons:
        score += 0.25
        risks.extend([f"repair:{r}" for r in repair_reasons if r][:4])
    # Join cardinality risk: if final value is a suspiciously huge count for a multi-table SQL.
    st = multitable_static_verify(sql, question, graph)
    n = _num(_unwrap(value))
    if st.get("is_multitable") and n is not None and re.search(r"\b(how many|number of|count)\b", _norm(question)):
        if "distinct" in _norm(sql):
            score += 0.4
        else:
            risks.append("multi_table_count_without_distinct_risk")
            score -= 0.35
    return {"execution_likelihood": score, "dynamic_risks": risks}


def semantic_alignment_score(sql: str, question: str, graph: Dict[str, Any]) -> Dict[str, Any]:
    q = _norm(question)
    s = _norm(sql)
    linked = linked_tables_and_columns(question, graph)
    score = 0.0
    signals: List[str] = []
    for t in linked.get("tables", []):
        if t.lower() in s:
            score += 0.25
            signals.append(f"linked_table:{t}")
    for t, c in linked.get("columns", []):
        if c.lower() in s:
            score += 0.2
            signals.append(f"linked_column:{t}.{c}")
    # Aggregation/condition lexical alignment.
    pairs = [
        (r"\bhow many|number of|count\b", r"\bcount\s*\(", "count_alignment"),
        (r"\baverage|mean\b", r"\bavg\s*\(", "avg_alignment"),
        (r"\btotal|sum\b", r"\bsum\s*\(", "sum_alignment"),
        (r"\bhighest|maximum|largest|most\b", r"\bmax\s*\(|order\s+by|desc\b", "max_order_alignment"),
        (r"\blowest|minimum|smallest|least\b", r"\bmin\s*\(|order\s+by|asc\b", "min_order_alignment"),
        (r"\bboth\b", r"\bexists\b|\bintersect\b|\band\b", "both_condition_alignment"),
        (r"\bratio|rate|percent|percentage\b", r"/|\bavg\s*\(|\bsum\s*\(|\bcount\s*\(", "ratio_alignment"),
    ]
    for qpat, spat, name in pairs:
        if re.search(qpat, q):
            if re.search(spat, s):
                score += 0.55
                signals.append(name)
            else:
                score -= 0.8
                signals.append(f"missing_{name}")
    return {"semantic_score": score, "semantic_signals": signals}


def annotate_executed_candidate(candidate: Dict[str, Any], question: str, graph: Dict[str, Any]) -> Dict[str, Any]:
    c = dict(candidate)
    sql = str(c.get("sql") or "")
    static = multitable_static_verify(sql, question, graph)
    dynamic = multitable_dynamic_verify(sql, question, c.get("value"), c.get("attempts", []), graph)
    semantic = semantic_alignment_score(sql, question, graph)
    score = float(static.get("static_prior", 0.0)) + float(dynamic.get("execution_likelihood", 0.0)) + float(semantic.get("semantic_score", 0.0))
    # Small source priors.  These are deliberately mild so evidence dominates.
    stage = str(c.get("stage") or "")
    if "llm" in stage:
        score += 0.15
    if "schema_graph" in stage:
        score += 0.10
    if "repair" in stage:
        score += 0.05
    c.update(static)
    c.update(dynamic)
    c.update(semantic)
    c["bayes_score"] = score
    c["posterior"] = 0.0
    c["answer_key"] = _value_key(c.get("value"))
    return c


def softmax_scores(scores: Sequence[float]) -> List[float]:
    if not scores:
        return []
    m = max(scores)
    exps = [math.exp(max(-60.0, min(60.0, s - m))) for s in scores]
    z = sum(exps) or 1.0
    return [e / z for e in exps]



def _is_numeric_answer_key(k: str) -> bool:
    return str(k or "").startswith("num:")

def _is_zeroish_value(v: Any) -> bool:
    try:
        return abs(float(v)) <= 1e-12
    except Exception:
        return False

def _question_wants_entity(q: str) -> bool:
    q = _norm(q)
    return (
        q.startswith("which ")
        or " which " in f" {q} "
        or "which business" in q
        or "which recipe" in q
        or "which movie" in q
        or "which actor" in q
        or "what is the name" in q
        or "what business" in q
        or "what recipe" in q
    )

def allow_llm_referee_override(question: str, current: Optional[Dict[str, Any]], referee: Optional[Dict[str, Any]], diag: Dict[str, Any]) -> Tuple[bool, str]:
    """Guard LLM referee overrides.

    v42 let the referee freely replace the answer whenever program BF was low.
    In practice, duplicate programs with the same answer often make program BF low,
    causing unnecessary overrides even when answer-level posterior is strong.
    This guard keeps the referee useful for low-confidence or known multi-table
    risk cases while preventing it from overturning a confident answer group.
    It uses only question text, candidate values, and diagnostics; no gold access.
    """
    if current is None or referee is None:
        return False, "missing_current_or_referee"
    cur_key = str(current.get("answer_key") or _value_key(current.get("value")))
    ref_key = str(referee.get("answer_key") or _value_key(referee.get("value")))
    if cur_key == ref_key:
        return True, "same_answer_group"
    q = _norm(question)
    try:
        answer_bf = float(diag.get("answer_bayes_factor") or 0.0)
    except Exception:
        answer_bf = 0.0
    try:
        mass = float(diag.get("chosen_answer_mass") or 0.0)
    except Exception:
        mass = 0.0

    # Entity questions: numeric top answer is often an intermediate value (score/fat/zip-as-number),
    # while a string candidate may be the actual entity requested.
    if _question_wants_entity(q) and _is_numeric_answer_key(cur_key) and not _is_numeric_answer_key(ref_key):
        return True, "entity_question_numeric_top_string_referee"

    # Generic high-risk zero-result pattern for ranking/criterion questions.  This captures
    # value-linking / criterion-name failures without hard-coding task IDs or gold answers.
    ranking_terms = ["ranked", "ranking", "criterion", "criteria", "cwur", "based on the criterion"]
    if _is_zeroish_value(current.get("value")) and not _is_zeroish_value(referee.get("value")) and any(t in q for t in ranking_terms):
        return True, "zero_top_ranking_or_criterion_risk"

    # True close race: let the referee arbitrate.
    if answer_bf < 1.35 or mass < 0.55:
        return True, "low_answer_margin"

    # Ratio/percent questions frequently need semantic unit interpretation.
    ratio_terms = ["ratio", "percentage", "percent", "rate", "majority", "more than", "fraction", "share"]
    if any(t in q for t in ratio_terms) and answer_bf < 5.0:
        return True, "ratio_percent_semantic_risk"

    return False, "confident_answer_posterior_veto"

def select_by_multitable_bayes(candidates: Sequence[Dict[str, Any]], question: str, graph: Dict[str, Any], posterior_selection: str = "answer_marginal", bf_threshold: float = 3.0) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any], List[Dict[str, Any]]]:
    annotated = [annotate_executed_candidate(c, question, graph) for c in candidates if c.get("value") is not None]
    if not annotated:
        return None, {"reason": "no_valid_candidates"}, []
    post = softmax_scores([float(c.get("bayes_score", 0.0)) for c in annotated])
    for c, p in zip(annotated, post):
        c["posterior"] = p
    # Program-level best and runner-up.
    ranked = sorted(annotated, key=lambda x: (float(x.get("posterior", 0.0)), float(x.get("bayes_score", 0.0))), reverse=True)
    best_program = ranked[0]
    runner = ranked[1] if len(ranked) > 1 else None
    bf = (best_program.get("posterior", 0.0) + 1e-12) / ((runner or {}).get("posterior", 0.0) + 1e-12)
    # Answer-level posterior aggregation.
    mass: Dict[str, float] = defaultdict(float)
    first: Dict[str, Dict[str, Any]] = {}
    sources: Dict[str, List[str]] = defaultdict(list)
    for c in annotated:
        k = c["answer_key"]
        mass[k] += float(c.get("posterior", 0.0))
        first.setdefault(k, c)
        sources[k].append(str(c.get("stage") or "unknown"))
    best_key = max(mass.keys(), key=lambda k: mass[k])
    answer_sorted = sorted(mass.items(), key=lambda kv: kv[1], reverse=True)
    answer_bf = (answer_sorted[0][1] + 1e-12) / ((answer_sorted[1][1] if len(answer_sorted) > 1 else 0.0) + 1e-12)
    posterior_selection = str(posterior_selection or "answer_marginal").lower().strip()
    if posterior_selection in {"program_map", "map", "program"}:
        chosen = best_program
        chosen_answer_key = chosen.get("answer_key")
        chosen_answer_mass = mass.get(chosen_answer_key, float(chosen.get("posterior", 0.0)))
    else:
        posterior_selection = "answer_marginal"
        chosen = first[best_key]
        chosen_answer_key = best_key
        chosen_answer_mass = mass[best_key]
    diag = {
        "policy": "multitable_bayes",
        "posterior_selection": posterior_selection,
        "bf_threshold": float(bf_threshold or 3.0),
        "program_bayes_factor": bf,
        "answer_bayes_factor": answer_bf,
        "best_program_posterior": best_program.get("posterior"),
        "chosen_answer_mass": chosen_answer_mass,
        "answer_posterior": {k: v for k, v in answer_sorted[:20]},
        "answer_sources": {k: sources[k] for k, _ in answer_sorted[:8]},
        "low_confidence": bool(bf < float(bf_threshold or 3.0) or answer_bf < float(bf_threshold or 3.0)),
        "answer_level_low_confidence": bool(answer_bf < float(bf_threshold or 3.0) or chosen_answer_mass < 0.60),
        "best_program_stage": best_program.get("stage"),
        "chosen_program_stage": chosen.get("stage"),
    }
    return chosen, diag, ranked


def _choose_entity_table(question: str, graph: Dict[str, Any]) -> Optional[str]:
    linked = linked_tables_and_columns(question, graph).get("tables", [])
    if linked:
        return linked[0]
    tables = graph.get("tables", [])
    # Prefer non-bridge tables by row name heuristic.
    for t in tables:
        tn = t.lower()
        if not any(x in tn for x in ["_", "year", "map", "link", "detail", "details"]):
            return t
    return tables[0] if tables else None


def _primary_key_for_table(t: str, graph: Dict[str, Any]) -> Optional[str]:
    pks = graph.get("primary_keys", {}).get(t) or []
    if pks:
        return pks[0]
    cols = [c["name"] for c in graph.get("columns", {}).get(t, [])]
    for c in cols:
        if c.lower() in {"id", f"{t.lower()}_id", f"{t.lower()}id"} or c.lower().endswith("_id"):
            return c
    return cols[0] if cols else None


def generate_schema_graph_rule_candidates(sample: Dict[str, Any], graph: Dict[str, Any], max_candidates: int = 8) -> List[Dict[str, Any]]:
    """Generate conservative schema/rule candidates for candidate-recall ablations.

    These are intentionally generic and safe.  They should not be expected to solve
    all questions; their role is to provide a measurable schema/rule branch so the
    TQA experiment can report candidate-source coverage.
    """
    q = _norm(sample.get("question", ""))
    out: List[Dict[str, Any]] = []
    table = _choose_entity_table(q, graph)
    if not table:
        return out
    pk = _primary_key_for_table(table, graph)
    qt = _quote_ident(table)
    if re.search(r"\b(how many|number of|count)\b", q):
        out.append({"sql": f"SELECT COUNT(*) AS answer FROM {qt}", "rationale": "schema_graph_rule_count_table", "stage": "schema_graph_rule_candidate"})
        if pk:
            out.append({"sql": f"SELECT COUNT(DISTINCT {_quote_ident(pk)}) AS answer FROM {qt}", "rationale": "schema_graph_rule_count_distinct_entity", "stage": "schema_graph_rule_candidate"})
    # Single-table superlative fallback over linked numeric columns.
    linked_cols = linked_tables_and_columns(sample.get("question", ""), graph).get("columns", [])
    numeric_like = []
    for t, c in linked_cols:
        for col in graph.get("columns", {}).get(t, []):
            if col["name"] == c and re.search(r"int|real|num|float|double|dec", str(col.get("type") or ""), re.I):
                numeric_like.append((t, c))
    for t, c in numeric_like[:3]:
        qt2, qc2 = _quote_ident(t), _quote_ident(c)
        if re.search(r"\b(highest|maximum|max|largest|most)\b", q):
            out.append({"sql": f"SELECT MAX({qc2}) AS answer FROM {qt2}", "rationale": "schema_graph_rule_max", "stage": "schema_graph_rule_candidate"})
        if re.search(r"\b(lowest|minimum|min|smallest|least)\b", q):
            out.append({"sql": f"SELECT MIN({qc2}) AS answer FROM {qt2}", "rationale": "schema_graph_rule_min", "stage": "schema_graph_rule_candidate"})
        if re.search(r"\b(average|mean)\b", q):
            out.append({"sql": f"SELECT AVG({qc2}) AS answer FROM {qt2}", "rationale": "schema_graph_rule_avg", "stage": "schema_graph_rule_candidate"})
    # Remove duplicates.
    seen = set()
    dedup = []
    for c in out:
        if c["sql"] not in seen:
            seen.add(c["sql"])
            dedup.append(c)
        if len(dedup) >= max_candidates:
            break
    return dedup


def candidate_coverage_with_gold(candidates: Sequence[Dict[str, Any]], gold: Any, denotation_equal_fn: Any) -> Dict[str, Any]:
    """Evaluation-only oracle coverage. Gold is used only after prediction."""
    covered = False
    by_stage: Dict[str, int] = defaultdict(int)
    valid = 0
    for c in candidates:
        if c.get("value") is None:
            continue
        valid += 1
        ok = bool(denotation_equal_fn(c.get("value"), gold))
        if ok:
            covered = True
            by_stage[str(c.get("stage") or "unknown")] += 1
    return {"oracle_covered": covered, "oracle_covered_by_stage": dict(by_stage), "valid_candidate_count": valid}
