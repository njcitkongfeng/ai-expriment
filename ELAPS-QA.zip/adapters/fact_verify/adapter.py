from __future__ import annotations
from typing import Any, Dict, List
import operator
import re
import pandas as pd
from candidate_framework.core import TaskContext, CandidateProgram, ExecutionTrace, VerificationResult, CandidateGenerator, ProgramExecutor, ProgramVerifier, ProgramRepairer

OPS = {
    "==": operator.eq, "=": operator.eq, "!=": operator.ne,
    ">": operator.gt, ">=": operator.ge, "<": operator.lt, "<=": operator.le,
}


def _coerce(x: Any) -> Any:
    try:
        return float(str(x).replace(",", ""))
    except Exception:
        return str(x).strip().lower()


def _safe_contains(series: pd.Series, text: Any) -> pd.Series:
    return series.astype(str).str.contains(re.escape(str(text)), case=False, na=False, regex=True)


class EvidenceChainGenerator(CandidateGenerator):
    """Provided evidence verification chains for TabFact-style tasks."""
    def __init__(self, chains: List[List[Dict[str, Any]]], source: str = "provided_evidence"):
        self.chains = chains
        self.source = source

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        return [CandidateProgram(chain, "evidence_chain", self.source, f"{self.source}:{i}") for i, chain in enumerate(self.chains)]


class EvidenceExecutor(ProgramExecutor):
    def execute(self, ctx: TaskContext, program: CandidateProgram) -> ExecutionTrace:
        if program.program_type != "evidence_chain":
            return ExecutionTrace(False, None, None, "not_evidence_chain")
        df = ctx.data.copy() if isinstance(ctx.data, pd.DataFrame) else pd.DataFrame(ctx.data)
        cur = df
        checks: List[Dict[str, Any]] = []
        try:
            verdict = True
            count_value = None
            for step in program.content:
                op = step.get("op")
                if op == "final_verdict":
                    verdict = bool(step.get("verdict"))
                    checks.append({"op": "final_verdict", "verdict": verdict})
                elif op == "locate":
                    col = step["column"]
                    if "eq" in step:
                        cur = cur[cur[col].astype(str).str.strip().str.lower() == str(step["eq"]).strip().lower()]
                    elif "contains" in step:
                        cur = cur[_safe_contains(cur[col], step["contains"])]
                    checks.append({"op": "locate", "column": col, "rows": len(cur)})
                elif op == "filter":
                    col = step["column"]
                    if "contains" in step:
                        cur = cur[_safe_contains(cur[col], step["contains"])]
                    elif "cmp" in step:
                        cmp = step.get("cmp", "=="); val = step.get("value")
                        fn = OPS.get(str(cmp), operator.eq)
                        cur = cur[cur[col].map(lambda x: bool(fn(_coerce(x), _coerce(val))))]
                    elif "eq" in step:
                        cur = cur[cur[col].astype(str).str.strip().str.lower() == str(step["eq"]).strip().lower()]
                    checks.append({"op": "filter", "column": col, "rows": len(cur)})
                elif op == "argmax":
                    col = step["column"]
                    series = pd.to_numeric(cur[col].astype(str).str.replace(",", "", regex=False).str.extract(r"([-+]?\d+(?:\.\d+)?)", expand=False), errors="coerce")
                    if series.notna().any():
                        target = series.max(); cur = cur[series == target]
                    else:
                        cur = cur[cur[col] == cur[col].max()]
                    checks.append({"op": "argmax", "column": col, "rows": len(cur)})
                elif op == "argmin":
                    col = step["column"]
                    series = pd.to_numeric(cur[col].astype(str).str.replace(",", "", regex=False).str.extract(r"([-+]?\d+(?:\.\d+)?)", expand=False), errors="coerce")
                    if series.notna().any():
                        target = series.min(); cur = cur[series == target]
                    else:
                        cur = cur[cur[col] == cur[col].min()]
                    checks.append({"op": "argmin", "column": col, "rows": len(cur)})
                elif op == "count":
                    col = step.get("distinct_column")
                    count_value = int(cur[col].nunique()) if col else int(len(cur))
                    checks.append({"op": "count", "count": count_value})
                elif op == "check_count":
                    if count_value is None:
                        count_value = int(len(cur))
                    cmp = step.get("cmp", "=="); val = step.get("value")
                    fn = OPS.get(str(cmp), operator.eq)
                    result = bool(fn(float(count_value), float(str(val).replace(",", ""))))
                    verdict = verdict and result
                    checks.append({"op": "check_count", "cmp": cmp, "value": val, "count": count_value, "result": result})
                elif op == "check":
                    col = step["column"]; cmp = step.get("cmp", "=="); val = step.get("value")
                    fn = OPS.get(str(cmp), operator.eq)
                    result = bool(cur[col].map(lambda x: fn(_coerce(x), _coerce(val))).any())
                    verdict = verdict and result
                    checks.append({"op": "check", "column": col, "cmp": cmp, "value": val, "result": result})
                elif op == "check_exists":
                    result = len(cur) > 0
                    verdict = verdict and result
                    checks.append({"op": "check_exists", "rows": len(cur), "result": result})
                elif op == "final":
                    expected = step.get("expected")
                    if expected is not None:
                        verdict = verdict == bool(expected)
                else:
                    raise ValueError(f"unsupported_evidence_op:{op}")
            return ExecutionTrace(True, bool(verdict), {"checks": checks, "evidence_rows": cur.head(20).to_dict(orient="records")})
        except Exception as exc:
            return ExecutionTrace(False, None, {"checks": checks}, str(exc))


class EvidenceVerifier(ProgramVerifier):
    def verify(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace) -> VerificationResult:
        claim = ctx.question.lower()
        ops = [s.get("op") for s in (program.content if isinstance(program.content, list) else [])]
        source = str(program.source or "")
        risks: List[str] = []
        static = 1.0 if program.program_type == "evidence_chain" else -5.0
        if "schema_rule" in source:
            static += 0.7
        if "llm_evidence" in source:
            static += 0.3
        if "llm_verdict" in source:
            static -= 0.5; risks.append("direct_verdict_low_structural_support")
        dynamic = 1.0 if execution.ok else -3.0
        semantic = 0.0
        if any(w in claim for w in ["highest", "maximum", "largest", "most"]):
            if "argmax" in ops: semantic += 0.8
            else: semantic -= 0.8; risks.append("claim_superlative_without_argmax")
        if any(w in claim for w in ["lowest", "minimum", "smallest", "least"]):
            if "argmin" in ops: semantic += 0.8
            else: semantic -= 0.8; risks.append("claim_minimum_without_argmin")
        if re.search(r"\bhow many\b|\bnumber of\b|\bcount\b|\b\d+\b", claim):
            if "count" in ops or "check_count" in ops: semantic += 0.4
        if "check" in ops or "check_exists" in ops or "check_count" in ops or "final_verdict" in ops:
            semantic += 0.4
        else:
            semantic -= 0.5; risks.append("claim_without_check_op")
        if execution.ok and execution.answer is None:
            dynamic -= 1.0; risks.append("null_verdict")
        return VerificationResult(static, dynamic, semantic, risks)


class EvidenceRepairer(ProgramRepairer):
    """Conservative local repair for invalid evidence chains."""
    def repair(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace, verification: VerificationResult) -> List[CandidateProgram]:
        if program.program_type != "evidence_chain" or not isinstance(program.content, list):
            return []
        out: List[CandidateProgram] = []
        if execution.error and "missing_column" in str(execution.error):
            return out
        # Empty locate with exact equality can be relaxed to contains.
        if execution.ok and execution.trace:
            checks = execution.trace.get("checks", []) if isinstance(execution.trace, dict) else []
            if any(c.get("rows") == 0 for c in checks):
                for i, s in enumerate(program.content):
                    if s.get("op") in {"locate", "filter"} and "eq" in s:
                        new_ops = [dict(x) for x in program.content]
                        val = new_ops[i].pop("eq")
                        new_ops[i]["contains"] = val
                        out.append(CandidateProgram(new_ops, "evidence_chain", f"repair:{program.source}", metadata={"repair_type": "eq_to_contains"}))
                        break
        return out
