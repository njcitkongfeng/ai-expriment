from __future__ import annotations
import ast
import re
from typing import Any, Dict, List
import pandas as pd
from candidate_framework.core import TaskContext, CandidateProgram, ExecutionTrace, VerificationResult, CandidateGenerator, ProgramExecutor, ProgramVerifier, ProgramRepairer


class PandasCodeGenerator(CandidateGenerator):
    def __init__(self, codes: List[str], source: str = "provided_pandas"):
        self.codes = codes
        self.source = source

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        return [CandidateProgram(c, "pandas", self.source, f"{self.source}:{i}") for i, c in enumerate(self.codes)]


class SafePandasExecutor(ProgramExecutor):
    """Safe-ish pandas executor for CSV/Excel multi-table tasks.

    Candidate code must assign final result to variable `answer`.
    This executor is intentionally restrictive; extend its AST whitelist only after
    reviewing safety implications.
    """
    ALLOWED_NODES = (
        ast.Module, ast.Assign, ast.Expr, ast.Load, ast.Store, ast.Name, ast.Constant,
        ast.Subscript, ast.Call, ast.Attribute, ast.keyword, ast.Compare,
        ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.BoolOp, ast.And, ast.Or,
        ast.BinOp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.BitAnd, ast.BitOr, ast.List, ast.Tuple, ast.Dict,
        ast.UnaryOp, ast.USub, ast.Index, ast.Slice
    )
    FORBIDDEN_NAMES = {"open", "exec", "eval", "__import__", "compile", "input", "globals", "locals", "os", "sys", "subprocess"}

    def _safe_ast(self, code: str) -> bool:
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return False
        for node in ast.walk(tree):
            if not isinstance(node, self.ALLOWED_NODES):
                return False
            if isinstance(node, ast.Name) and node.id in self.FORBIDDEN_NAMES:
                return False
            if isinstance(node, ast.Attribute) and node.attr.startswith("__"):
                return False
        return True

    def execute(self, ctx: TaskContext, program: CandidateProgram) -> ExecutionTrace:
        if program.program_type != "pandas":
            return ExecutionTrace(False, None, None, "not_pandas_program")
        code = str(program.content)
        if not self._safe_ast(code):
            return ExecutionTrace(False, None, {"code": code}, "unsafe_pandas_code")
        env: Dict[str, Any] = {"pd": pd, "answer": None}
        # ctx.data is expected as dict[str, DataFrame]
        env.update(ctx.data or {})
        try:
            exec(compile(ast.parse(code), "<candidate_pandas>", "exec"), {"__builtins__": {}}, env)
            ans = env.get("answer")
            if isinstance(ans, (pd.Series, pd.DataFrame)):
                preview = ans.head(20).to_dict() if hasattr(ans, "head") else str(ans)
                # keep scalar-ish series as list
                ans_out = ans.tolist() if isinstance(ans, pd.Series) else preview
            else:
                ans_out = ans
            return ExecutionTrace(True, ans_out, {"locals": sorted(k for k in env if k not in {"pd"})})
        except Exception as exc:
            return ExecutionTrace(False, None, {"code": code}, str(exc))


class PandasVerifier(ProgramVerifier):
    def verify(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace) -> VerificationResult:
        q = ctx.question.lower()
        code = str(program.content).lower()
        risks: List[str] = []
        static = 1.0 if program.program_type == "pandas" else -5.0
        dynamic = 1.0 if execution.ok else -3.0
        semantic = 0.0
        if ".merge" in code or "merge(" in code:
            static += 0.5
        if re.search(r"\bhow many|number of|count\b", q):
            if ".nunique" in code or ".count" in code or "len(" in code:
                semantic += 0.8
            else:
                semantic -= 0.8; risks.append("count_question_without_count_operation")
            if "student" in q or "entity" in q or "business" in q:
                if ".nunique" in code: semantic += 0.3
                elif ".count" in code or "len(" in code: risks.append("possible_row_vs_entity_count")
        if re.search(r"\baverage|mean\b", q):
            if ".mean" in code: semantic += 0.8
            else: semantic -= 0.8; risks.append("average_question_without_mean")
        if re.search(r"\bhighest|maximum|largest|most\b", q):
            if ".max" in code or "sort_values" in code: semantic += 0.8
            else: semantic -= 0.7; risks.append("superlative_without_max_or_sort")
        if execution.ok and execution.answer is None:
            dynamic -= 1.0; risks.append("null_answer")
        return VerificationResult(static, dynamic, semantic, risks, {"code": code})


class PandasRepairer(ProgramRepairer):
    def repair(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace, verification: VerificationResult) -> List[CandidateProgram]:
        code = str(program.content)
        out: List[CandidateProgram] = []
        entity_col = ctx.metadata.get("entity_id_column")
        if entity_col and ".count()" in code and ".nunique()" not in code:
            fixed = code.replace(f"['{entity_col}'].count()", f"['{entity_col}'].nunique()")
            fixed = fixed.replace(f'["{entity_col}"].count()', f'["{entity_col}"].nunique()')
            if fixed != code:
                out.append(CandidateProgram(fixed, "pandas", "repair", f"{program.program_id}:nunique", {"repair_type": "count_to_nunique"}))
        # common percent threshold repair in pandas code
        fixed = re.sub(r"(pct|percent|ratio)([^\n<>]*[<>]=?\s*)50\b", r"\g<1>\g<2>0.5", code, flags=re.I)
        if fixed != code:
            out.append(CandidateProgram(fixed, "pandas", "repair", f"{program.program_id}:percent_scale", {"repair_type": "percent_scale"}))
        return out


def load_table_files(paths: Dict[str, str]) -> Dict[str, pd.DataFrame]:
    """Load CSV/XLSX files into a DataFrame dictionary."""
    out: Dict[str, pd.DataFrame] = {}
    for name, path in paths.items():
        if path.lower().endswith(('.xlsx', '.xls')):
            out[name] = pd.read_excel(path)
        else:
            out[name] = pd.read_csv(path)
    return out
