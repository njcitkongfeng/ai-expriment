from __future__ import annotations
from typing import Any, Dict, List
import re
import pandas as pd
from candidate_framework.core import TaskContext, CandidateProgram, ExecutionTrace, VerificationResult, CandidateGenerator, ProgramExecutor, ProgramVerifier, ProgramRepairer


def _coerce_num(x: Any):
    s = str(x or "").replace(",", "")
    m = re.search(r"[-+]?\d+(?:\.\d+)?", s)
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None


def _safe_contains(series: pd.Series, text: Any) -> pd.Series:
    pattern = re.escape(str(text))
    return series.astype(str).str.contains(pattern, case=False, na=False, regex=True)


class TableOpsGenerator(CandidateGenerator):
    """Generates provided table-operation chains."""
    def __init__(self, chains: List[List[Dict[str, Any]]], source: str = "provided_table_ops"):
        self.chains = chains
        self.source = source

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        return [CandidateProgram(chain, "table_ops", self.source, f"{self.source}:{i}") for i, chain in enumerate(self.chains)]


class TableOpsExecutor(ProgramExecutor):
    def execute(self, ctx: TaskContext, program: CandidateProgram) -> ExecutionTrace:
        if program.program_type != "table_ops":
            return ExecutionTrace(False, None, None, "not_table_ops_program")
        df = ctx.data.copy() if isinstance(ctx.data, pd.DataFrame) else pd.DataFrame(ctx.data)
        trace: List[Dict[str, Any]] = []
        try:
            cur = df
            answer: Any = None
            for step in program.content:
                op = step.get("op")
                if op == "direct_answer":
                    answer = step.get("answer")
                elif op == "filter":
                    col = step["column"]
                    if col not in cur.columns:
                        raise KeyError(f"missing_column:{col}")
                    if "eq" in step:
                        cur = cur[cur[col].astype(str).str.strip().str.lower() == str(step["eq"]).strip().lower()]
                    elif "contains" in step:
                        cur = cur[_safe_contains(cur[col], step["contains"])]
                    elif "cmp" in step:
                        cmp = str(step.get("cmp", "=="))
                        val = step.get("value")
                        nums = pd.to_numeric(cur[col].astype(str).str.replace(",", "", regex=False).str.extract(r"([-+]?\d+(?:\.\d+)?)", expand=False), errors="coerce")
                        vnum = _coerce_num(val)
                        if vnum is not None and nums.notna().any():
                            if cmp in {">", "gt"}: cur = cur[nums > vnum]
                            elif cmp in {">=", "ge"}: cur = cur[nums >= vnum]
                            elif cmp in {"<", "lt"}: cur = cur[nums < vnum]
                            elif cmp in {"<=", "le"}: cur = cur[nums <= vnum]
                            elif cmp in {"==", "="}: cur = cur[nums == vnum]
                            elif cmp in {"!=", "<>"}: cur = cur[nums != vnum]
                            else: raise ValueError(f"unsupported_cmp:{cmp}")
                        else:
                            sval = str(val).strip().lower()
                            ser = cur[col].astype(str).str.strip().str.lower()
                            if cmp in {"==", "="}: cur = cur[ser == sval]
                            elif cmp in {"!=", "<>"}: cur = cur[ser != sval]
                            else: raise ValueError(f"non_numeric_cmp:{cmp}")
                    else:
                        raise ValueError("filter_requires_eq_contains_or_cmp")
                elif op == "select":
                    cols = step.get("columns") or [step.get("column")]
                    cur = cur[cols]
                elif op == "sort":
                    col = step["column"]
                    if col not in cur.columns:
                        raise KeyError(f"missing_column:{col}")
                    key_series = pd.to_numeric(cur[col].astype(str).str.replace(",", "", regex=False).str.extract(r"([-+]?\d+(?:\.\d+)?)", expand=False), errors="coerce")
                    if key_series.notna().any():
                        cur = cur.assign(__sort_key=key_series).sort_values("__sort_key", ascending=bool(step.get("ascending", True)), na_position="last").drop(columns=["__sort_key"])
                    else:
                        cur = cur.sort_values(col, ascending=bool(step.get("ascending", True)))
                elif op == "first":
                    cur = cur.head(int(step.get("n", 1) or 1))
                elif op == "last":
                    cur = cur.tail(int(step.get("n", 1) or 1))
                elif op == "count":
                    col = step.get("distinct_column")
                    answer = int(cur[col].nunique()) if col else int(len(cur))
                elif op == "aggregate":
                    col = step["column"]; func = step.get("func", "max")
                    if col not in cur.columns:
                        raise KeyError(f"missing_column:{col}")
                    series = pd.to_numeric(cur[col].astype(str).str.replace(",", "", regex=False).str.extract(r"([-+]?\d+(?:\.\d+)?)", expand=False), errors="coerce")
                    src = series.dropna() if series.notna().any() else cur[col]
                    if len(src) == 0:
                        answer = None
                    elif func == "max": answer = src.max()
                    elif func == "min": answer = src.min()
                    elif func == "avg": answer = float(src.mean())
                    elif func == "sum": answer = src.sum()
                    else: raise ValueError(f"unsupported_aggregate:{func}")
                elif op == "span":
                    # Generic duration/range operation: max(column)-min(column).
                    # This is used for WikiTQ questions such as "how long did X serve"
                    # or "what is the difference between the first and last year".
                    col = step["column"]
                    if col not in cur.columns:
                        raise KeyError(f"missing_column:{col}")
                    series = pd.to_numeric(cur[col].astype(str).str.replace(",", "", regex=False).str.extract(r"([-+]?\d+(?:\.\d+)?)", expand=False), errors="coerce").dropna()
                    if len(series) == 0:
                        answer = None
                    else:
                        diff = float(series.max() - series.min())
                        if abs(diff - round(diff)) < 1e-9:
                            diff = int(round(diff))
                        suffix = str(step.get("suffix") or "").strip()
                        answer = f"{diff} {suffix}".strip() if suffix else diff
                elif op == "return":
                    col = step.get("column")
                    if col:
                        if col not in cur.columns:
                            raise KeyError(f"missing_column:{col}")
                        vals = cur[col].tolist()
                        answer = vals[0] if len(vals) == 1 else vals
                    else:
                        answer = cur.to_dict(orient="records")
                else:
                    raise ValueError(f"unsupported_op:{op}")
                trace.append({"op": op, "shape": getattr(cur, "shape", None), "answer": answer})
            return ExecutionTrace(True, answer, trace={"steps": trace})
        except Exception as exc:
            return ExecutionTrace(False, None, {"steps": trace}, str(exc))


class TableOpsVerifier(ProgramVerifier):
    def verify(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace) -> VerificationResult:
        q = ctx.question.lower()
        ops = [s.get("op") for s in (program.content if isinstance(program.content, list) else [])]
        risks: List[str] = []
        source = str(program.source or "")
        static = 1.0 if program.program_type == "table_ops" else -5.0
        if "schema_rule" in source:
            static += 0.7
        if "llm_ops" in source:
            static += 0.3
        if "direct_answer" in source:
            static -= 0.5; risks.append("direct_answer_low_structural_support")
        dynamic = 1.0 if execution.ok else -3.0
        semantic = 0.0
        if re.search(r"\bhow many|number of|count\b", q):
            if "count" in ops: semantic += 0.8
            else: semantic -= 0.8; risks.append("count_question_without_count_op")
        if re.search(r"\bhighest|maximum|largest|most|top\b", q):
            if "sort" in ops or any(s.get("func") == "max" for s in program.content): semantic += 0.8
            else: semantic -= 0.8; risks.append("superlative_without_sort_or_max")
        if re.search(r"\blowest|minimum|smallest|least\b", q):
            if "sort" in ops or any(s.get("func") == "min" for s in program.content): semantic += 0.8
            else: semantic -= 0.8; risks.append("minimum_without_sort_or_min")
        if re.search(r"\baverage|mean\b", q):
            if any(s.get("func") == "avg" for s in program.content): semantic += 0.8
            else: semantic -= 0.8; risks.append("average_without_avg")
        if re.search(r"\b(how long|duration|span|difference between|how many years)\b", q):
            if "span" in ops: semantic += 0.8
        if execution.ok and execution.answer is None:
            dynamic -= 0.8; risks.append("null_answer")
        if execution.ok and isinstance(execution.answer, list) and len(execution.answer) == 0:
            dynamic -= 0.4; risks.append("empty_list_answer")
        return VerificationResult(static, dynamic, semantic, risks)


class TableOpsRepairer(ProgramRepairer):
    """Local repairer for high-risk table-operation programs."""
    def repair(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace, verification: VerificationResult) -> List[CandidateProgram]:
        if program.program_type != "table_ops" or not isinstance(program.content, list):
            return []
        out: List[CandidateProgram] = []
        # If a return column is missing, try a column whose normalized name matches.
        if execution.error and "missing_column" in str(execution.error):
            m = re.search(r"missing_column:([^'\"]+)", str(execution.error))
            missing = m.group(1).strip() if m else ""
            df = ctx.data if isinstance(ctx.data, pd.DataFrame) else pd.DataFrame(ctx.data)
            norm_map = {re.sub(r"\W+", "", str(c).lower()): str(c) for c in df.columns}
            repl = norm_map.get(re.sub(r"\W+", "", missing.lower()))
            if repl:
                new_ops = []
                for s in program.content:
                    ss = dict(s)
                    if ss.get("column") == missing:
                        ss["column"] = repl
                    new_ops.append(ss)
                out.append(CandidateProgram(new_ops, "table_ops", f"repair:{program.source}", metadata={"repair_type": "column_alias"}))
        # For empty filter results, try contains instead of exact equality.
        if execution.ok and isinstance(execution.answer, list) and len(execution.answer) == 0:
            for i, s in enumerate(program.content):
                if s.get("op") == "filter" and "eq" in s:
                    new_ops = [dict(x) for x in program.content]
                    val = new_ops[i].pop("eq")
                    new_ops[i]["contains"] = val
                    out.append(CandidateProgram(new_ops, "table_ops", f"repair:{program.source}", metadata={"repair_type": "eq_to_contains"}))
                    break
        return out
