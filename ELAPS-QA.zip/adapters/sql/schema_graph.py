from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Any
import sqlite3
import re


@dataclass
class SchemaGraph:
    tables: Dict[str, List[str]] = field(default_factory=dict)
    primary_keys: Dict[str, Set[str]] = field(default_factory=dict)
    foreign_keys: List[Tuple[str, str, str, str, str]] = field(default_factory=list)  # src_t,src_c,dst_t,dst_c,kind
    edges: Dict[str, Set[str]] = field(default_factory=dict)

    def add_edge(self, a: str, b: str) -> None:
        self.edges.setdefault(a, set()).add(b)
        self.edges.setdefault(b, set()).add(a)

    def connected(self, table_names: List[str]) -> bool:
        names = [t for t in table_names if t in self.tables]
        if len(names) <= 1:
            return True
        start = names[0]
        todo = [start]
        seen = {start}
        target = set(names)
        while todo:
            u = todo.pop()
            for v in self.edges.get(u, set()):
                if v not in seen:
                    seen.add(v)
                    todo.append(v)
        return target.issubset(seen)

    def summary(self, max_cols: int = 12) -> str:
        lines = []
        for t, cols in sorted(self.tables.items()):
            pk = sorted(self.primary_keys.get(t, set()))
            lines.append(f"TABLE {t}({', '.join(cols[:max_cols])}) PK={pk}")
        for a, ac, b, bc, kind in self.foreign_keys[:80]:
            lines.append(f"EDGE {a}.{ac} -> {b}.{bc} [{kind}]")
        return "\n".join(lines)


def build_sqlite_schema_graph(db_path: str, infer_id_edges: bool = True) -> SchemaGraph:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    g = SchemaGraph()
    tables = [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    for t in tables:
        rows = cur.execute(f"PRAGMA table_info('{t}')").fetchall()
        cols = [r[1] for r in rows]
        g.tables[t] = cols
        g.primary_keys[t] = {r[1] for r in rows if r[5]}
    for t in tables:
        try:
            fks = cur.execute(f"PRAGMA foreign_key_list('{t}')").fetchall()
        except Exception:
            fks = []
        for fk in fks:
            _, _, ref_t, from_col, to_col, *_ = fk
            if ref_t in g.tables:
                g.foreign_keys.append((t, from_col, ref_t, to_col, "fk"))
                g.add_edge(t, ref_t)
    conn.close()

    if infer_id_edges:
        # Conservative inferred join edges: same column name ending in _id or table_id -> table primary/id.
        col_to_tables: Dict[str, List[str]] = {}
        for t, cols in g.tables.items():
            for c in cols:
                col_to_tables.setdefault(c.lower(), []).append(t)
        for col, ts in col_to_tables.items():
            if len(ts) > 1 and (col == "id" or col.endswith("_id")):
                for i in range(len(ts)):
                    for j in range(i + 1, len(ts)):
                        a, b = ts[i], ts[j]
                        g.foreign_keys.append((a, col, b, col, "inferred_same_id"))
                        g.add_edge(a, b)
        for t, cols in g.tables.items():
            singular = re.sub(r"s$", "", t.lower())
            candidates = {f"{singular}_id", f"{t.lower()}_id"}
            for other, other_cols in g.tables.items():
                if other == t:
                    continue
                for c in other_cols:
                    if c.lower() in candidates:
                        target_col = next((x for x in cols if x.lower() in {"id", c.lower()}), None)
                        if target_col:
                            g.foreign_keys.append((other, c, t, target_col, "inferred_table_id"))
                            g.add_edge(other, t)
    return g


def extract_sql_tables(sql: str, known_tables: List[str]) -> List[str]:
    s = str(sql or "").lower()
    found = []
    for t in known_tables:
        if re.search(rf"\b{re.escape(t.lower())}\b", s):
            found.append(t)
    return found
