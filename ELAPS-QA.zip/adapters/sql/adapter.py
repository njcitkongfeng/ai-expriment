from __future__ import annotations
import re
import sqlite3
from typing import Any, Dict, List, Optional
from candidate_framework.core import (
    TaskContext, CandidateProgram, ExecutionTrace, VerificationResult,
    ProgramExecutor, ProgramVerifier, ProgramRepairer, CandidateGenerator
)
from .schema_graph import build_sqlite_schema_graph, extract_sql_tables, SchemaGraph


def clean_sql(sql: str) -> str:
    sql = str(sql or "").strip()
    sql = re.sub(r"^```(?:sql)?", "", sql, flags=re.I).strip()
    sql = re.sub(r"```$", "", sql).strip()
    return sql.rstrip(";")


def is_safe_select_sql(sql: str) -> bool:
    s = clean_sql(sql).lower().strip()
    if not (s.startswith("select") or s.startswith("with")):
        return False
    forbidden = ["insert ", "update ", "delete ", "drop ", "alter ", "create ", "pragma ", "attach ", "detach "]
    if any(tok in f" {s} " for tok in forbidden):
        return False
    # avoid semicolon-separated multi statements after clean
    return ";" not in s


class SQLListGenerator(CandidateGenerator):
    def __init__(self, sqls: List[str], source: str = "provided_sql"):
        self.sqls = list(sqls)
        self.source = source

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        return [CandidateProgram(clean_sql(s), "sql", self.source, f"{self.source}:{i}") for i, s in enumerate(self.sqls)]


class SQLiteExecutor(ProgramExecutor):
    def __init__(self, db_path_key: str = "db_path", max_rows: int = 1000):
        self.db_path_key = db_path_key
        self.max_rows = max_rows

    def execute(self, ctx: TaskContext, program: CandidateProgram) -> ExecutionTrace:
        if program.program_type != "sql":
            return ExecutionTrace(False, None, None, "not_sql_program")
        sql = clean_sql(program.content)
        if not is_safe_select_sql(sql):
            return ExecutionTrace(False, None, None, "unsafe_or_not_select")
        db_path = ctx.metadata.get(self.db_path_key)
        if not db_path:
            return ExecutionTrace(False, None, None, "missing_db_path")
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            cur.execute(sql)
            rows = cur.fetchmany(self.max_rows + 1)
            cols = [d[0] for d in cur.description] if cur.description else []
            conn.close()
            tuples = [tuple(r) for r in rows[: self.max_rows]]
            # For Spider/Text-to-SQL, an empty denotation is a valid answer,
            # not an invalid prediction.  Use [] to distinguish it from
            # execution failure / no-answer (None).
            if len(rows) == 0:
                answer: Any = []
            elif len(rows) == 1 and len(rows[0]) == 1:
                answer = rows[0][0]
            else:
                answer = tuples
            return ExecutionTrace(True, answer, {"sql": sql, "columns": cols, "rows_preview": tuples[:20], "num_rows": len(rows)})
        except Exception as exc:
            return ExecutionTrace(False, None, {"sql": sql}, str(exc))


class SQLSchemaRuleGenerator(CandidateGenerator):
    """Small schema/rule branch for multi-table candidate recall.

    It is intentionally conservative. It supplements LLM SQL candidates instead of
    attempting complete SQL enumeration.
    """
    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        graph: Optional[SchemaGraph] = ctx.metadata.get("schema_graph")
        if graph is None and ctx.metadata.get("db_path"):
            graph = build_sqlite_schema_graph(ctx.metadata["db_path"])
            ctx.metadata["schema_graph"] = graph
        if graph is None:
            return []
        q = ctx.question.lower()
        out: List[CandidateProgram] = []
        # Very conservative single-table count candidates from linked table names.
        for t in graph.tables:
            if re.search(rf"\b{re.escape(t.lower())}\b", q) or re.search(rf"\b{re.escape(t.lower().rstrip('s'))}\b", q):
                if re.search(r"\bhow many|number of|count\b", q):
                    pk = next(iter(graph.primary_keys.get(t, [])), None)
                    if pk:
                        sql = f"SELECT COUNT(DISTINCT {t}.{pk}) FROM {t}"
                    else:
                        sql = f"SELECT COUNT(*) FROM {t}"
                    out.append(CandidateProgram(sql, "sql", "schema_rule", f"schema_rule:count:{t}"))
        return out[:8]


class SQLVerifier(ProgramVerifier):
    def verify(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace) -> VerificationResult:
        q = (ctx.question or "").lower()
        sql = clean_sql(program.content).lower()
        risks: List[str] = []
        static = 0.0
        dynamic = 0.0
        semantic = 0.0

        if is_safe_select_sql(sql):
            static += 1.0
        else:
            static -= 6.0; risks.append("unsafe_or_not_select")

        graph: Optional[SchemaGraph] = ctx.metadata.get("schema_graph")
        if graph is None and ctx.metadata.get("db_path"):
            try:
                graph = build_sqlite_schema_graph(ctx.metadata["db_path"])
                ctx.metadata["schema_graph"] = graph
            except Exception:
                graph = None
        if graph:
            tables = extract_sql_tables(sql, list(graph.tables.keys()))
            if len(tables) >= 2:
                static += 0.4
                if " join " not in f" {sql} ":
                    static -= 1.5; risks.append("multi_table_without_explicit_join")
                if not graph.connected(tables):
                    static -= 2.0; risks.append("schema_graph_disconnected_join_path")
            for t in tables:
                static += 0.05

        # Question-SQL semantic alignment.
        if re.search(r"\b(how many|number of|count)\b", q):
            if re.search(r"\bcount\s*\(", sql): semantic += 0.8
            else: semantic -= 1.0; risks.append("count_question_without_count")
        if re.search(r"\b(average|mean)\b", q):
            if re.search(r"\bavg\s*\(", sql): semantic += 0.8
            else: semantic -= 0.8; risks.append("average_question_without_avg")
        if re.search(r"\b(highest|maximum|max|largest|most)\b", q):
            if re.search(r"\bmax\s*\(|order\s+by|desc\b", sql): semantic += 0.8
            else: semantic -= 0.8; risks.append("superlative_without_max_or_order")
        if re.search(r"\b(ratio|rate|percent|percentage)\b", q):
            if "/" in sql or re.search(r"\b(avg|sum|count)\s*\(", sql): semantic += 0.5
            else: semantic -= 0.8; risks.append("ratio_question_without_ratio_logic")
        if "both" in q:
            if "exists" in sql or "intersect" in sql or sql.count(" join ") >= 2: semantic += 0.4
            else: semantic -= 0.5; risks.append("both_condition_without_entity_binding")

        if execution.ok:
            dynamic += 1.0
            if execution.answer is None:
                dynamic -= 1.0; risks.append("null_or_empty_result")
        else:
            dynamic -= 3.0; risks.append("execution_failed")

        # Result shape.
        ans = execution.answer
        if re.search(r"\b(how many|number of|count|average|mean|ratio|percent|maximum|minimum|highest|lowest)\b", q):
            try:
                float(str(ans).replace(",", "").replace("%", "")); dynamic += 0.4
            except Exception:
                dynamic -= 0.5; risks.append("numeric_question_non_numeric_answer")
        if len(extract_sql_tables(sql, list(graph.tables.keys())) if graph else []) >= 2 and re.search(r"\b(how many|number of|count)\b", q):
            if "distinct" in sql: dynamic += 0.3
            else: dynamic -= 0.25; risks.append("multi_table_count_without_distinct_risk")

        return VerificationResult(static, dynamic, semantic, risks, {"sql": sql})


class SQLRepairer(ProgramRepairer):
    def repair(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace, verification: VerificationResult) -> List[CandidateProgram]:
        sql = clean_sql(program.content)
        out: List[CandidateProgram] = []
        lower = sql.lower()
        entity_id = ctx.metadata.get("entity_id_column")
        if entity_id and "count(" in lower and "distinct" not in lower:
            fixed = re.sub(r"count\s*\(\s*\*\s*\)", f"COUNT(DISTINCT {entity_id})", sql, flags=re.I)
            if fixed != sql:
                out.append(CandidateProgram(fixed, "sql", "repair", f"{program.program_id}:count_distinct", {"repair_type": "count_distinct"}))
        fixed = re.sub(r"(\b(?:pct|percent|ratio)[a-zA-Z0-9_\.]*\b\s*[<>=]+\s*)50\b", r"\g<1>0.5", sql, flags=re.I)
        if fixed != sql:
            out.append(CandidateProgram(fixed, "sql", "repair", f"{program.program_id}:percent_scale", {"repair_type": "percent_scale"}))
        return out
