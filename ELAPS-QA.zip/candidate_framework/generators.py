from __future__ import annotations
from typing import Any, Callable, Iterable, List
from .core import CandidateGenerator, CandidateProgram, TaskContext


class ProvidedProgramGenerator(CandidateGenerator):
    """Generator for precomputed candidates, useful for tests and demos."""
    def __init__(self, programs: Iterable[Any], program_type: str, source: str = "provided"):
        self.programs = list(programs)
        self.program_type = program_type
        self.source = source

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        return [CandidateProgram(p, self.program_type, self.source, f"{self.source}:{i}") for i, p in enumerate(self.programs)]


class CallableGenerator(CandidateGenerator):
    """Wraps an arbitrary function(ctx)->list[CandidateProgram|raw_program]."""
    def __init__(self, fn: Callable[[TaskContext], List[Any]], program_type: str, source: str):
        self.fn = fn
        self.program_type = program_type
        self.source = source

    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        out: List[CandidateProgram] = []
        for i, item in enumerate(self.fn(ctx)):
            if isinstance(item, CandidateProgram):
                out.append(item)
            else:
                out.append(CandidateProgram(item, self.program_type, self.source, f"{self.source}:{i}"))
        return out
