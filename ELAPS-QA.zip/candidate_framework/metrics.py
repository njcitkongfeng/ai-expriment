from __future__ import annotations
from typing import Any, Callable, Dict, Iterable, List
from .core import EvaluatedCandidate, AnswerNormalizer


def default_equal(a: Any, b: Any) -> bool:
    norm = AnswerNormalizer()
    return norm.key(a) == norm.key(b)


def oracle_coverage(evaluated: Iterable[EvaluatedCandidate], gold: Any, equal_fn: Callable[[Any, Any], bool] = default_equal) -> Dict[str, Any]:
    valid = 0
    covered = False
    by_source: Dict[str, int] = {}
    for c in evaluated:
        if not c.execution.ok or c.execution.answer is None:
            continue
        valid += 1
        if equal_fn(c.execution.answer, gold):
            covered = True
            by_source[c.program.source] = by_source.get(c.program.source, 0) + 1
    return {"oracle_covered": covered, "valid_candidate_count": valid, "oracle_covered_by_source": by_source}
