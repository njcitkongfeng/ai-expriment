from __future__ import annotations
"""
Universal executable candidate-program framework.

The core layer is task-agnostic. It never assumes SQL, pandas, WikiTQ,
TabFact, or any specific dataset. A task is integrated by providing adapters:

- CandidateGenerator: produces candidate programs.
- ProgramExecutor: executes a candidate program and returns trace/evidence.
- ProgramVerifier: scores static, execution, and semantic reliability.
- ProgramRepairer: produces repaired candidate programs from risk signals.
- CandidateRanker: converts verifier scores into posterior-like scores.
- AnswerAggregator: aggregates multiple candidates that support the same answer.

TQA/Spider = SQL adapter; CSV/Excel = pandas adapter; WikiTQ = table-op adapter;
TabFact = fact-verification adapter.
"""

from abc import ABC, abstractmethod
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import math
import uuid
import numbers


@dataclass
class TaskContext:
    """Prediction-visible task context.

    IMPORTANT: Do not put gold answers, official code, rightIdx, or evaluation-only
    data in this object during prediction. Use EvaluationRecord after prediction.
    """
    task_id: str
    question: str
    data: Any
    schema: Any = None
    task_type: str = "generic"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CandidateProgram:
    """A candidate executable reasoning path.

    content examples:
    - SQL string
    - pandas code
    - table operation list
    - evidence verification plan
    - graph query / API plan / any executable program representation
    """
    content: Any
    program_type: str
    source: str = "unknown"      # llm / schema_graph / rule / repair / referee / provided
    program_id: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.program_id:
            self.program_id = f"{self.source}:{self.program_type}:{uuid.uuid4().hex[:8]}"


@dataclass
class ExecutionTrace:
    ok: bool
    answer: Any = None
    trace: Any = None
    error: Optional[str] = None
    evidence: Dict[str, Any] = field(default_factory=dict)


@dataclass
class VerificationResult:
    static_score: float = 0.0
    execution_score: float = 0.0
    semantic_score: float = 0.0
    risk_signals: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def total_score(self) -> float:
        return float(self.static_score + self.execution_score + self.semantic_score)


@dataclass
class EvaluatedCandidate:
    program: CandidateProgram
    execution: ExecutionTrace
    verification: VerificationResult
    bayes_score: float = 0.0
    posterior: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "program": asdict(self.program),
            "execution": asdict(self.execution),
            "verification": asdict(self.verification),
            "bayes_score": self.bayes_score,
            "posterior": self.posterior,
        }


class CandidateGenerator(ABC):
    @abstractmethod
    def generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        raise NotImplementedError


class ProgramExecutor(ABC):
    @abstractmethod
    def execute(self, ctx: TaskContext, program: CandidateProgram) -> ExecutionTrace:
        raise NotImplementedError


class ProgramVerifier(ABC):
    @abstractmethod
    def verify(self, ctx: TaskContext, program: CandidateProgram, execution: ExecutionTrace) -> VerificationResult:
        raise NotImplementedError


class ProgramRepairer(ABC):
    def repair(
        self,
        ctx: TaskContext,
        program: CandidateProgram,
        execution: ExecutionTrace,
        verification: VerificationResult,
    ) -> List[CandidateProgram]:
        return []


class CandidateRanker:
    """Bayesian-form posterior scorer.

    This is Bayesian-form rather than a strictly calibrated probability model:
        score = structural_prior + execution_likelihood + semantic_evidence
        posterior = softmax(score over candidate set)
    """
    def rank(self, evaluated: Sequence[EvaluatedCandidate]) -> List[EvaluatedCandidate]:
        scores = [c.verification.total_score for c in evaluated]
        posteriors = self.softmax(scores)
        ranked: List[EvaluatedCandidate] = []
        for c, s, p in zip(evaluated, scores, posteriors):
            c.bayes_score = float(s)
            c.posterior = float(p)
            ranked.append(c)
        return sorted(ranked, key=lambda x: x.posterior, reverse=True)

    @staticmethod
    def softmax(scores: Sequence[float]) -> List[float]:
        if not scores:
            return []
        m = max(scores)
        exps = [math.exp(max(min(s - m, 60.0), -60.0)) for s in scores]
        z = sum(exps) or 1.0
        return [e / z for e in exps]


class AnswerNormalizer:
    def key(self, answer: Any) -> str:
        if answer is None:
            return "none"
        if isinstance(answer, bool):
            return f"bool:{answer}"
        if isinstance(answer, numbers.Integral):
            return f"num:{int(answer)}"
        if isinstance(answer, numbers.Real):
            return f"num:{round(float(answer), 6)}"
        if isinstance(answer, (list, tuple)):
            return "seq:" + "|".join(self.key(x) for x in answer)
        s = str(answer).strip().lower()
        s = " ".join(s.split())
        return s


class AnswerAggregator:
    """Answer-level posterior aggregation.

    Multiple different candidate programs may support the same denotation. Their
    posterior masses are summed, then the answer with maximum mass is selected.
    """
    def __init__(self, normalizer: Optional[AnswerNormalizer] = None):
        self.normalizer = normalizer or AnswerNormalizer()

    def aggregate(self, ranked: Sequence[EvaluatedCandidate]) -> Dict[str, Any]:
        mass: Dict[str, float] = defaultdict(float)
        first: Dict[str, EvaluatedCandidate] = {}
        supporters: Dict[str, List[str]] = defaultdict(list)
        for cand in ranked:
            if not cand.execution.ok or cand.execution.answer is None:
                continue
            k = self.normalizer.key(cand.execution.answer)
            mass[k] += float(cand.posterior)
            first.setdefault(k, cand)
            supporters[k].append(cand.program.program_id)
        if not mass:
            return {
                "answer": None,
                "answer_key": None,
                "answer_mass": {},
                "selected_candidate": None,
                "supporters": {},
                "answer_bayes_factor": 0.0,
            }
        sorted_keys = sorted(mass, key=lambda k: mass[k], reverse=True)
        best_key = sorted_keys[0]
        second_mass = mass[sorted_keys[1]] if len(sorted_keys) > 1 else 1e-12
        answer_bf = mass[best_key] / max(second_mass, 1e-12)
        return {
            "answer": first[best_key].execution.answer,
            "answer_key": best_key,
            "answer_mass": dict(mass),
            "selected_candidate": first[best_key],
            "supporters": dict(supporters),
            "answer_bayes_factor": answer_bf,
        }


class CandidateProgramEngine:
    """Task-agnostic executable candidate-program engine."""

    def __init__(
        self,
        generators: Sequence[CandidateGenerator],
        executor: ProgramExecutor,
        verifier: ProgramVerifier,
        repairers: Optional[Sequence[ProgramRepairer]] = None,
        ranker: Optional[CandidateRanker] = None,
        aggregator: Optional[AnswerAggregator] = None,
        max_repair_rounds: int = 1,
        keep_failed_candidates: bool = True,
    ):
        self.generators = list(generators)
        self.executor = executor
        self.verifier = verifier
        self.repairers = list(repairers or [])
        self.ranker = ranker or CandidateRanker()
        self.aggregator = aggregator or AnswerAggregator()
        self.max_repair_rounds = max_repair_rounds
        self.keep_failed_candidates = keep_failed_candidates

    def solve(self, ctx: TaskContext) -> Dict[str, Any]:
        candidates = self._generate(ctx)
        evaluated = self._execute_verify_repair(ctx, candidates)
        ranked = self.ranker.rank(evaluated)
        aggregated = self.aggregator.aggregate(ranked)
        solved = {
            "task_id": ctx.task_id,
            "task_type": ctx.task_type,
            "answer": aggregated["answer"],
            "answer_key": aggregated["answer_key"],
            "answer_mass": aggregated["answer_mass"],
            "answer_bayes_factor": aggregated["answer_bayes_factor"],
            "selected_candidate": aggregated["selected_candidate"],
            "supporters": aggregated["supporters"],
            "ranked_candidates": ranked,
            "num_initial_candidates": len(candidates),
            "num_evaluated_candidates": len(evaluated),
        }
        # Preserve optional task-specific diagnostics returned by custom
        # aggregators, e.g., source-weighted answer mass for TabFact.
        for k, v in aggregated.items():
            if k not in solved:
                solved[k] = v
        return solved

    def _generate(self, ctx: TaskContext) -> List[CandidateProgram]:
        candidates: List[CandidateProgram] = []
        for generator in self.generators:
            candidates.extend(generator.generate(ctx))
        return self._dedupe(candidates)

    def _execute_verify_repair(self, ctx: TaskContext, initial: Sequence[CandidateProgram]) -> List[EvaluatedCandidate]:
        queue: List[Tuple[CandidateProgram, int]] = [(p, 0) for p in initial]
        seen = {(p.program_type, str(p.content)) for p in initial}
        evaluated: List[EvaluatedCandidate] = []
        while queue:
            program, depth = queue.pop(0)
            execution = self.executor.execute(ctx, program)
            verification = self.verifier.verify(ctx, program, execution)
            if self.keep_failed_candidates or execution.ok:
                evaluated.append(EvaluatedCandidate(program, execution, verification))
            if depth < self.max_repair_rounds:
                for repairer in self.repairers:
                    for repaired in repairer.repair(ctx, program, execution, verification):
                        key = (repaired.program_type, str(repaired.content))
                        if key not in seen:
                            seen.add(key)
                            queue.append((repaired, depth + 1))
        return evaluated

    @staticmethod
    def _dedupe(candidates: Sequence[CandidateProgram]) -> List[CandidateProgram]:
        seen = set()
        out: List[CandidateProgram] = []
        for p in candidates:
            key = (p.program_type, str(p.content))
            if key not in seen:
                seen.add(key)
                out.append(p)
        return out
