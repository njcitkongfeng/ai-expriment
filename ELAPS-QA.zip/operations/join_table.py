from __future__ import annotations
"""
Chain-of-Table operation: f_join_table()

Joins two tables on a specified column, producing a merged table.
This is the key cross-table operation that Chain-of-Table lacks
for multi-table reasoning.

Supports both rule-based (schema linking) and LLM-based column selection.
"""


import copy
import re
from typing import Any, Dict, List, Optional, Tuple


def _find_join_column(
    table_a: List[List[Any]], table_b: List[List[Any]],
    ta_name: str = "A", tb_name: str = "B",
) -> Optional[Tuple[str, str, float]]:
    """Find the best join column pair between two tables.

    Returns (col_a, col_b, confidence) or None.
    Uses FK naming patterns and value overlap.
    """
    if not table_a or not table_b:
        return None
    a_headers = [str(h).lower() for h in table_a[0]]
    b_headers = [str(h).lower() for h in table_b[0]]
    a_rows = table_a[1:]
    b_rows = table_b[1:]

    best = None
    best_conf = 0.0

    for ai, ah in enumerate(a_headers):
        for bi, bh in enumerate(b_headers):
            conf = 0.0

            # FK naming patterns
            if ah == f"{tb_name}_id" or ah == f"{tb_name} id":
                conf = 0.95
            elif bh == f"{ta_name}_id" or bh == f"{ta_name} id":
                conf = 0.95
            elif ah == bh and "id" in ah:
                conf = 0.90
            elif ah == bh:
                conf = 0.70
            elif ah.endswith("_id") and bh == "id":
                conf = 0.65
            elif bh.endswith("_id") and ah == "id":
                conf = 0.65

            # Value overlap for non-obvious matches
            if conf < 0.50:
                a_vals = set()
                for r in a_rows:
                    if ai < len(r):
                        v = str(r[ai]).strip().lower()
                        if v and v != "none":
                            a_vals.add(v)
                b_vals = set()
                for r in b_rows:
                    if bi < len(r):
                        v = str(r[bi]).strip().lower()
                        if v and v != "none":
                            b_vals.add(v)
                if a_vals and b_vals:
                    overlap = len(a_vals & b_vals)
                    ratio = overlap / min(len(a_vals), len(b_vals))
                    if ratio >= 0.50:
                        conf = max(0.60, ratio * 0.85)

            if conf > best_conf:
                best_conf = conf
                best = (table_a[0][ai], table_b[0][bi], conf)

    return best


def join_table_build_prompt(
    table_a_info: Dict[str, Any],
    table_b_info: Dict[str, Any],
    statement: str,
) -> str:
    """Build prompt for LLM-based join column selection."""
    def desc(tbl, name):
        if not tbl or len(tbl) < 2:
            return f"Table {name}: (empty)"
        cols = ", ".join(str(h) for h in tbl[0])
        return f"Table {name}: columns [{cols}]  ({len(tbl)-1} rows)"

    return (
        desc(table_a_info.get("table_text", []), "A") + "\n"
        + desc(table_b_info.get("table_text", []), "B") + "\n\n"
        + f"Statement: {statement}\n"
        + "Which column should be used to join these tables?\n"
        + "Output: f_join_table(A.column_name, B.column_name)"
    )


def join_table_func(
    sample: Dict[str, Any],
    table_info: Dict[str, Any],
    llm: Any,
    llm_options: Optional[Dict[str, Any]] = None,
    debug: bool = False,
) -> Dict[str, Any]:
    """Join two tables on the best matching column."""
    tables = table_info.get("tables", sample.get("tables", {}))
    tnames = list(tables.keys())

    if len(tnames) < 2:
        return sample

    # Pick the two most relevant tables via schema linking scores
    from utils.schema_linking import link_schema
    question = str(sample.get("question") or sample.get("statement") or "")
    links = link_schema(question, tables)
    relevant = sorted(tnames, key=lambda tn: sum(
        c["score"] for c in links.get(tn, [])), reverse=True)

    ta_name = relevant[0]
    tb_name = relevant[1] if len(relevant) > 1 else relevant[0]

    table_a = tables.get(ta_name)
    table_b = tables.get(tb_name)
    if not table_a or not table_b or ta_name == tb_name:
        return sample

    # Find join column
    result = _find_join_column(table_a, table_b, ta_name, tb_name)
    if not result:
        return sample

    col_a, col_b, conf = result

    # Execute join: merge tables on the join column
    a_header = [str(h) for h in table_a[0]]
    b_header = [str(h) for h in table_b[0]]
    ai = a_header.index(col_a) if col_a in a_header else 0
    bi = b_header.index(col_b) if col_b in b_header else 0

    # Build merged table: all A columns + all B columns (except join column)
    merged_header = a_header + [h for h in b_header if h != col_b]
    merged_rows = []
    for ra in table_a[1:]:
        a_key = str(ra[ai]).strip() if ai < len(ra) else ""
        for rb in table_b[1:]:
            b_key = str(rb[bi]).strip() if bi < len(rb) else ""
            if a_key == b_key and a_key:
                merged_row = list(ra) + [
                    rb[ci] for ci in range(len(b_header)) if ci != bi
                ]
                merged_rows.append(merged_row)

    if not merged_rows:
        return sample  # No matching rows found

    operation = {
        "operation_name": "join_table",
        "parameter_and_conf": [
            ((ta_name, col_a, tb_name, col_b), conf)
        ],
    }

    sample_copy = copy.deepcopy(sample)
    sample_copy["chain"] = sample_copy.get("chain", []) + [operation]
    sample_copy["joined_table"] = [merged_header] + merged_rows
    return sample_copy


def join_table_act(
    table_info: Dict[str, Any],
    operation: Dict[str, Any],
) -> Dict[str, Any]:
    """Execute join on the actual table data."""
    table_info = copy.deepcopy(table_info)
    params = operation.get("parameter_and_conf", [((), 0)])[0]
    if not params or not params[0]:
        return table_info

    ta_name, col_a, tb_name, col_b = params[0]
    tables = table_info.get("tables", {})
    table_a = tables.get(ta_name)
    table_b = tables.get(tb_name)
    if not table_a or not table_b:
        return table_info

    a_header = [str(h) for h in table_a[0]]
    b_header = [str(h) for h in table_b[0]]
    ai = a_header.index(col_a) if col_a in a_header else 0
    bi = b_header.index(col_b) if col_b in b_header else 0

    merged_header = a_header + [h for h in b_header if h != col_b]
    merged_rows = []
    for ra in table_a[1:]:
        a_key = str(ra[ai]).strip() if ai < len(ra) else ""
        for rb in table_b[1:]:
            b_key = str(rb[bi]).strip() if bi < len(rb) else ""
            if a_key == b_key and a_key:
                merged_row = list(ra) + [
                    rb[ci] for ci in range(len(b_header)) if ci != bi
                ]
                merged_rows.append(merged_row)

    if merged_rows:
        new_name = f"{ta_name}_{tb_name}_joined"
        table_info["tables"][new_name] = [merged_header] + merged_rows
        table_info["table_text"] = [merged_header] + merged_rows
        table_info["act_chain"] = table_info.get("act_chain", []) + [
            f"f_join_table({ta_name}.{col_a} = {tb_name}.{col_b})"
        ]
        if "selected_tables" not in table_info:
            table_info["selected_tables"] = []
        table_info["selected_tables"].append(new_name)

    return table_info
