from __future__ import annotations
"""
Chain-of-Table operation: f_select_table()

Selects relevant tables from a multi-table collection based on
schema linking scores.  This is the first cross-table operation
in the Chain-of-Table pipeline.
"""


import copy
import re
from typing import Any, Dict, List, Optional


def _score_table_relevance(
    table: List[List[Any]], question: str
) -> float:
    """Score how relevant a single table is to the question."""
    if not isinstance(table, list) or len(table) < 2:
        return 0.0
    ql = question.lower()
    q_tokens = set(re.findall(r"[a-zA-Z0-9]+", ql))
    q_numbers = set(re.findall(r"\d+", ql))
    header = [str(h).lower() for h in table[0]]
    rows = table[1:]
    score = 0.0

    # Column name matches
    for h in header:
        h_tokens = set(re.findall(r"[a-zA-Z0-9]+", h))
        score += len(h_tokens & q_tokens) * 0.25
        if h in ql:
            score += 0.50

    # Value matches
    for row in rows:
        for cell in row:
            cs = str(cell).strip().lower()
            if len(cs) >= 2 and cs in ql:
                score += 0.20
            elif cs in q_numbers:
                score += 0.10

    return min(score, 3.0)


def select_table_build_prompt(
    tables: Dict[str, List[List[Any]]], statement: str
) -> str:
    """Build prompt for LLM-based table selection."""
    table_list = []
    for tn, table in tables.items():
        if not isinstance(table, list) or len(table) < 2:
            continue
        cols = ", ".join(str(h) for h in table[0])
        n_rows = len(table) - 1
        table_list.append(f"  {tn}: {cols}  ({n_rows} rows)")
    return (
        "Available tables:\n" + "\n".join(table_list)
        + f"\n\nStatement: {statement}\n"
        + "Select the tables needed to verify this statement.\n"
        + "Output: f_select_table([table1, table2, ...])"
    )


def select_table_func(
    sample: Dict[str, Any],
    table_info: Dict[str, Any],
    llm: Any,
    llm_options: Optional[Dict[str, Any]] = None,
    debug: bool = False,
) -> Dict[str, Any]:
    """Select relevant tables using schema linking or LLM."""
    tables = sample.get("tables", {})
    if not tables:
        return sample

    question = str(sample.get("question") or sample.get("statement") or "")

    # Rule-based selection (no LLM)
    scores = {}
    for tn, table in tables.items():
        scores[tn] = _score_table_relevance(table, question)

    # Select tables with score > threshold, min 1, max 5
    threshold = 0.3
    selected = sorted(
        [tn for tn, s in scores.items() if s >= threshold],
        key=lambda x: scores[x], reverse=True
    )[:5]
    if not selected:
        selected = [max(scores, key=scores.get)]

    operation = {
        "operation_name": "select_table",
        "parameter_and_conf": [(selected, 1.0)],
    }

    sample_copy = copy.deepcopy(sample)
    sample_copy["chain"] = sample_copy.get("chain", []) + [operation]
    sample_copy["selected_tables"] = selected
    return sample_copy


def select_table_act(
    table_info: Dict[str, Any],
    operation: Dict[str, Any],
) -> Dict[str, Any]:
    """Execute table selection: filter tables dict to selected ones."""
    table_info = copy.deepcopy(table_info)
    selected = operation.get("parameter_and_conf", [([], 0)])[0][0]
    if not selected:
        return table_info

    # Keep only selected tables
    all_tables = table_info.get("tables", {})
    table_info["tables"] = {tn: all_tables[tn] for tn in selected if tn in all_tables}
    table_info["act_chain"] = table_info.get("act_chain", []) + [
        f"f_select_table({', '.join(selected)})"
    ]
    return table_info
