#!/usr/bin/env python
"""Compatibility launcher for the WikiTQ table-operation experiment."""
import runpy
if __name__ == "__main__":
    runpy.run_module("experiments.wikitq.run_wikitq", run_name="__main__")
