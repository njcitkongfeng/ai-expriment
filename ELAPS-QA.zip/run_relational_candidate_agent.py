#!/usr/bin/env python
from __future__ import annotations
"""TQA-style command-line runner for Spider CandidateProgram experiments."""

from utils.relational_candidate_agent import run_spider_candidate_agent


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Spider multi-database CandidateProgramEngine agent")
    parser.add_argument("--spider_root", default="data/spider_data", help="Spider official data root containing dev.json/tables.json/database/")
    parser.add_argument("--split", default="dev", choices=["dev", "test", "train", "train_spider", "train_others"])
    parser.add_argument("--db_ids", default="all", help="all or comma-separated Spider db_id names")
    parser.add_argument("--model_name", default="gpt-4o-mini")
    parser.add_argument("--openai_api_key", default=None)
    parser.add_argument("--openai_api_base", default=None)
    parser.add_argument("--votes", type=int, default=1)
    parser.add_argument("--parallel_votes", type=int, default=1)
    parser.add_argument("--max_schema_chars", type=int, default=12000)
    parser.add_argument("--max_sql_candidates", type=int, default=3)
    parser.add_argument("--selection_policy", default="hybrid_multitable_bayes", choices=["primary_majority", "multitable_bayes", "hybrid_multitable_bayes"])
    parser.add_argument("--candidate_sources", default="all", help="all,llm,schema_rule or comma-separated")
    parser.add_argument("--disable_safe_repairs", action="store_true")
    parser.add_argument("--disable_local_bucket_verifier", action="store_true",
                        help="Deprecated compatibility flag; v33 no longer runs the v32 generative repair")
    parser.add_argument("--posterior_selection", default="answer_marginal", choices=["answer_marginal", "program_map"])
    parser.add_argument("--bf_threshold", type=float, default=3.0)
    parser.add_argument("--max_repair_rounds", type=int, default=1)
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--max_per_db", type=int, default=0, help="balanced subset: max examples per db_id; 0 means no limit")
    parser.add_argument("--result_dir", default="results/spider_candidate_framework")
    parser.add_argument("--no_resume", action="store_true", help="Start a clean Spider run and ignore existing results.jsonl.")
    parser.add_argument("--save_full_candidate_trace", action="store_true", help="Store the full ranked candidate trace in results.jsonl for offline analysis.")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    run_spider_candidate_agent(**vars(args))


if __name__ == "__main__":
    main()
