#!/usr/bin/env python
"""Compatibility launcher for the TabFact fact-verification experiment."""
import runpy
if __name__ == "__main__":
    runpy.run_module("experiments.tabfact.run_tabfact", run_name="__main__")
