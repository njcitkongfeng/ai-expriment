#!/usr/bin/env python
"""Compatibility launcher for the TQA-Bench/SymDataset SQL instance."""
import runpy
if __name__ == "__main__":
    runpy.run_module("experiments.tqabench_sql.run_tqabench_symdataset_agent", run_name="__main__")
