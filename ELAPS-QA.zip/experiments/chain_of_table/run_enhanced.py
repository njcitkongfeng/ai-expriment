#!/usr/bin/env python
# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""
PCFG-BF Enhanced Chain-of-Table — Unified Experiment Runner
============================================================

One runner for all datasets.  The architecture::

   Chain-of-Table (LLM plans operations)
        +
   PCFG Structural Prior (constrains operation space)
        +
   Bayes Factor Verification (executes & ranks candidates)
        =
   Enhanced Chain-of-Table with confidence scores

Supports three operating modes:
  --mode symbolic    PCFG-BF only (zero LLM cost)
  --mode enhanced    PCFG-BF + LLM refinement on low-confidence (hybrid)
  --mode llm         Full Chain-of-Table with LLM (paper baseline)

Datasets (auto-detected or specify --dataset):
  tabfact    Fact verification (YES/NO)
  wikitq     Table QA (value extraction)
  finqa      Financial numerical reasoning
  fetaqa     Free-form text generation (LLM required)
  spider     Text-to-SQL (multi-table)
  tqabench   Multi-table QA (multi-table)

Examples:
  # Pure symbolic on TabFact
  python run_reasoning_pipeline.py --dataset tabfact --mode symbolic --first_n 50

  # Enhanced (PCFG-BF + LLM) on WikiTQ
  python run_reasoning_pipeline.py --dataset wikitq --mode enhanced --first_n 50

  # Full LLM on FeTaQA
  python run_reasoning_pipeline.py --dataset fetaqa --mode llm --first_n 20
  python run_reasoning_pipeline.py --dataset tabfact --mode agent90 --model_name gpt-4o --first_n 200
"""

import json
import os
import pickle
import sys
import re
from typing import Any, Dict, List, Optional


# ══════════════════════════════════════════════════════════════════════
# Dataset registry
# ══════════════════════════════════════════════════════════════════════

DATASET_CONFIG = {
    "tabfact": {
        "default_path": "data/tabfact/test.jsonl",
        "task": "fact_verification",
        "load_fn": "load_tabfact_dataset",
        "loader_module": "utils.load_data",
        "loader_kwargs": {"raw2clean_path": "data/tabfact/raw2clean.jsonl"},
    },
    "wikitq": {
        "default_path": "data/wikitq/test.jsonl",
        "task": "value_extraction",
        "load_fn": "load_wikitablequestions_dataset",
        "loader_module": "utils.load_data",
        "loader_kwargs": {},
    },
    "finqa": {
        "default_path": "data/finqa/test.jsonl",
        "task": "numerical_reasoning",
        "load_fn": "load_wikitablequestions_dataset",
        "loader_module": "utils.load_data",
        "loader_kwargs": {},
    },
    "fetaqa": {
        "default_path": "data/fetaqa/test.jsonl",
        "task": "free_form_generation",
        "load_fn": "load_wikitablequestions_dataset",
        "loader_module": "utils.load_data",
        "loader_kwargs": {},
        "requires_llm": True,
    },
    "spider": {
        "default_path": "data/spider_data/dev.json",
        "task": "text_to_sql",
        "load_fn": "load_spider_dataset",
        "loader_module": "run_spider",
        "loader_kwargs": {},
    },
    "tqabench": {
        "default_path": "data/tqa_bench/test.jsonl",
        "task": "multi_table_qa",
        "load_fn": "load_tqabench_dataset",
        "loader_module": "run_tqabench",
        "loader_kwargs": {},
    },
    "multitable_fv": {
        "default_path": "data/multitable_fv/test.jsonl",
        "task": "multi_table_fact_verification",
        "load_fn": "load_tqabench_dataset",
        "loader_module": "run_tqabench",
        "loader_kwargs": {},
    },
}


# ══════════════════════════════════════════════════════════════════════
# Evaluation
# ══════════════════════════════════════════════════════════════════════

def _compare_answer(pred, gold):
    if isinstance(gold, list):
        return any(_compare_answer(pred, g) for g in gold)
    if isinstance(pred, list):
        return any(_compare_answer(p, gold) for p in pred)
    if pred is None and gold is None:
        return True
    if pred is None or gold is None:
        return False
    ps, gs = str(pred).strip().lower(), str(gold).strip().lower()
    if ps == gs:
        return True
    try:
        pn, gn = float(str(pred).replace(",", "")), float(str(gold).replace(",", ""))
        if abs(gn) < 1e-12:
            return abs(pn - gn) < 1e-6
        return abs(pn - gn) / abs(gn) <= 1e-3
    except (ValueError, ZeroDivisionError, TypeError):
        pass
    return False


def _get_gold_from_result_or_dataset(result_item, dataset_item=None, allow_dataset_answer=False):
    """Return gold answer without falling back to the prediction field.

    ``result_item['answer']`` is the prediction in this project, so it must not
    be used as gold.  For original dataset items, ``answer`` may still be a
    gold field, so it is allowed only when ``allow_dataset_answer=True``.
    """
    for key in ("answers", "gold_answer", "target", "answer_gold"):
        if key in result_item and result_item[key] is not None:
            return result_item[key]
    if dataset_item:
        keys = ["answers", "gold_answer", "target", "answer_gold"]
        if allow_dataset_answer:
            keys.append("answer")
        for key in keys:
            if key in dataset_item and dataset_item[key] is not None:
                return dataset_item[key]
    return None


def evaluate_results(results, dataset_name, dataset=None):
    if dataset_name == "tabfact":
        return _eval_tabfact(results)
    elif dataset_name == "multitable_fv":
        return _eval_tabfact(results)
    elif dataset_name == "wikitq":
        return _eval_wikitq(results, dataset)
    elif dataset_name == "finqa":
        return _eval_numerical(results, dataset)
    elif dataset_name == "spider":
        return _eval_denotation(results, dataset)
    elif dataset_name == "tqabench":
        return _eval_multichoice(results, dataset)
    elif dataset_name == "fetaqa":
        return _eval_fetaqa(results, dataset)
    return _eval_generic(results, dataset)


def _eval_tabfact(results):
    total = 0
    correct = 0
    invalid = 0
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("answer")
        label = s.get("label")
        if label not in (0, 1, True, False):
            invalid += 1
            continue
        gold = bool(label == 1 or label is True)
        if isinstance(pred, bool):
            pred_bool = pred
        elif pred is not None and str(pred).strip().lower() in ("true", "yes", "supported", "entailed", "1", "t"):
            pred_bool = True
        elif pred is not None and str(pred).strip().lower() in ("false", "no", "refuted", "unsupported", "0", "f"):
            pred_bool = False
        else:
            invalid += 1
            continue
        if pred_bool == gold:
            correct += 1
    return {"total": total, "correct": correct, "invalid": invalid,
            "accuracy": round(correct / max(total, 1), 4)}


def _eval_wikitq(results, dataset=None):
    """WikiTQ-compatible denotation evaluation.

    Additive branch: TabFact/Spider/TQA-Bench still use their old evaluators.
    This branch tolerates numeric commas/units and parses JSON-like model outputs
    before comparison.
    """
    try:
        from utils.table_answer_utils import compare_wikitq_answer, postprocess_wikitq_prediction
    except Exception:
        compare_wikitq_answer = None
        postprocess_wikitq_prediction = None

    total = 0
    correct = 0
    invalid = 0
    dataset_map = {str(s.get("id", "")): s for s in (dataset or [])}
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("pred_answer", s.get("answer"))
        if postprocess_wikitq_prediction is not None:
            pred = postprocess_wikitq_prediction(pred)
        original = dataset_map.get(str(s.get("id", "")), None)
        gold = _get_gold_from_result_or_dataset(s, original, allow_dataset_answer=True)
        if gold is None:
            invalid += 1
            continue
        ok = compare_wikitq_answer(pred, gold) if compare_wikitq_answer is not None else _compare_answer(pred, gold)
        if ok:
            correct += 1
    return {"total": total, "correct": correct, "invalid": invalid,
            "accuracy": round(correct / max(total, 1), 4)}


def _eval_denotation(results, dataset=None):
    total = 0
    correct = 0
    invalid = 0
    dataset_map = {str(s.get("id", "")): s for s in (dataset or [])}
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("pred_answer", s.get("answer"))
        original = dataset_map.get(str(s.get("id", "")), None)
        gold = _get_gold_from_result_or_dataset(s, original, allow_dataset_answer=True)
        if gold is None:
            invalid += 1
            continue
        if isinstance(gold, list) and len(gold) == 1:
            gold = gold[0]
        if _compare_answer(pred, gold):
            correct += 1
    return {"total": total, "correct": correct, "invalid": invalid,
            "accuracy": round(correct / max(total, 1), 4)}


def _eval_numerical(results, dataset=None):
    return _eval_denotation(results, dataset)


def _eval_multichoice(results, dataset=None):
    total = 0
    correct = 0
    invalid = 0
    dataset_map = {str(s.get("id", "")): s for s in (dataset or [])}
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("pred_answer", s.get("answer"))
        original = dataset_map.get(str(s.get("id", "")), {})
        gold = s.get("answer_gold", original.get("answer_gold", original.get("answer", "")))
        choices = s.get("choices", original.get("choices", []))
        if not gold:
            invalid += 1
            continue
        pred_letter = _map_result_to_choice(pred, choices)
        if pred_letter == str(gold).strip().upper():
            correct += 1
    return {"total": total, "correct": correct, "invalid": invalid,
            "accuracy": round(correct / max(total, 1), 4)}


def _map_result_to_choice(exec_result, choices):
    """Map a model answer to an option letter for TQA-Bench-style multiple choice.

    v29: robust against empty strings, fenced JSON, JSON snippets, XML-style tags,
    and raw option text. This function must never crash during evaluation.
    """
    if exec_result is None:
        return "?"

    raw = exec_result
    if isinstance(raw, dict):
        for k in ("answer", "choice", "option", "final_answer", "final"):
            if raw.get(k) is not None:
                raw = raw.get(k)
                break

    if isinstance(raw, list) and raw:
        if isinstance(raw[0], (list, tuple)) and raw[0]:
            raw = raw[0][0]
        else:
            raw = raw[0]

    txt = str(raw).strip()
    if not txt:
        return "?"

    txt2 = re.sub(r"^```(?:json)?\s*", "", txt.strip(), flags=re.I)
    txt2 = re.sub(r"\s*```$", "", txt2.strip())

    m = re.search(r"<\s*(?:answer|choice|option|final)\s*>\s*([A-F])\s*<\s*/\s*(?:answer|choice|option|final)\s*>", txt2, flags=re.I)
    if m:
        return m.group(1).upper()

    try:
        obj = json.loads(txt2)
        if isinstance(obj, dict):
            for k in ("answer", "choice", "option", "final_answer", "final"):
                if obj.get(k) is not None:
                    return _map_result_to_choice(obj.get(k), choices)
    except Exception:
        pass

    m = re.search(r"\{.*?\}", txt2, flags=re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            if isinstance(obj, dict):
                for k in ("answer", "choice", "option", "final_answer", "final"):
                    if obj.get(k) is not None:
                        return _map_result_to_choice(obj.get(k), choices)
        except Exception:
            pass

    m = re.search(r"\b(?:answer|choice|option|final(?: answer)?)\s*(?:is|=|:)?\s*\(?\s*([A-F])\s*\)?\b", txt2, flags=re.I)
    if m:
        return m.group(1).upper()
    m = re.match(r"^\s*\(?\s*([A-F])\s*\)?\s*(?:\)|\.|:|$)", txt2, flags=re.I)
    if m:
        return m.group(1).upper()
    if txt2.upper() in {"A", "B", "C", "D", "E", "F"}:
        return txt2.upper()

    val = txt2.strip()
    val_norm = re.sub(r"\s+", " ", val.lower()).strip()
    val_num = re.sub(r"[^0-9.\-]", "", val)

    for c in (choices or []):
        cs = str(c).strip()
        m = re.match(r"^\s*\(?\s*([A-F])\s*\)?\s*(?:\)|\.|:)?\s*(.*)$", cs, flags=re.I)
        if not m:
            continue
        letter, choice_val = m.group(1).upper(), m.group(2).strip()
        cv_norm = re.sub(r"\s+", " ", choice_val.lower()).strip()
        if val_norm == cv_norm:
            return letter
        try:
            pn = float(val.replace(",", ""))
            cn = float(choice_val.replace(",", ""))
            if abs(pn - cn) / max(abs(cn), 1e-9) < 1e-3:
                return letter
        except Exception:
            pass
        try:
            cn2 = re.sub(r"[^0-9.\-]", "", choice_val)
            if val_num and cn2 and abs(float(val_num) - float(cn2)) / max(abs(float(cn2)), 1e-9) < 1e-3:
                return letter
        except Exception:
            pass
        if val_norm and cv_norm and (val_norm in cv_norm or cv_norm in val_norm):
            return letter
    return "?"


def _eval_fetaqa(results, dataset=None):
    total = 0
    bleu_sum = 0.0
    invalid = 0
    import re
    dataset_map = {str(s.get("id", "")): s for s in (dataset or [])}
    for s in results:
        if s is None:
            continue
        total += 1
        pred = str(s.get("pred_answer", s.get("answer", "")))
        original = dataset_map.get(str(s.get("id", "")), None)
        gold = _get_gold_from_result_or_dataset(s, original, allow_dataset_answer=True)
        if gold is None:
            invalid += 1
            continue
        if isinstance(gold, str):
            gold = [gold]
        ref_tokens = [set(re.findall(r'\w+', str(g).lower())) for g in gold]
        cand_tokens = set(re.findall(r'\w+', pred.lower()))
        best = max((len(cand_tokens & r)) / max(len(cand_tokens), 1) for r in ref_tokens) if ref_tokens and cand_tokens else 0.0
        bleu_sum += best * 0.25
    return {"total": total, "invalid": invalid, "avg_bleu_approx": round(bleu_sum / max(total, 1), 4)}


def _eval_generic(results, dataset=None):
    return _eval_denotation(results, dataset)


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main(
    dataset: str = "tabfact",
    dataset_path: str = None,
    mode: str = "symbolic",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    openai_api_key: str = None,
    openai_api_base: str = None,
    llm_backend: str = None,
    first_n: int = -1,
    beam_width: int = 8,
    n_mcmc: int = 40,
    max_refinement: int = 3,
    result_dir: str = None,
    debug: bool = False,
    agent90_votes: int = 7,
    agent90_max_table_chars: int = 20000,
    agent90_no_adjudicate: bool = False,
    agent90_no_verifier: bool = False,
    agent90_temperature: float = 0.35,
    openai_tpm_limit: int = 0,
    openai_min_interval: float = 0.0,
    openai_max_retries: int = 8,
    deepseek_parallel_votes: int = 3,
    use_candidate_framework: bool = False,
    candidate_sources: str = "all",
    max_sql_candidates: int = 3,
):
    # ── Validate ──────────────────────────────────────────────────
    if dataset not in DATASET_CONFIG:
        print(f"Unknown dataset: {dataset}")
        print(f"  Choices: {list(DATASET_CONFIG.keys())}")
        sys.exit(1)
    if mode not in ("symbolic", "enhanced", "llm", "agent90"):
        print(f"Unknown mode: {mode}. Choices: symbolic, enhanced, llm, agent90")
        sys.exit(1)

    cfg = DATASET_CONFIG[dataset]
    dataset_path = dataset_path or cfg["default_path"]
    result_dir = result_dir or f"results/enhanced_{dataset}_{mode}"
    os.makedirs(result_dir, exist_ok=True)

    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base
    # Local OpenAI request throttling. These values are read by utils.llm.ChatGPT.
    # They reduce 429 errors from OpenAI TPM/RPM limits during Agent90 multi-vote runs.
    if openai_tpm_limit is not None:
        os.environ["OPENAI_TPM_LIMIT"] = str(openai_tpm_limit)
    if openai_min_interval is not None:
        os.environ["OPENAI_MIN_INTERVAL_SECONDS"] = str(openai_min_interval)
    if openai_max_retries is not None:
        os.environ["OPENAI_MAX_RETRIES"] = str(openai_max_retries)
    if deepseek_parallel_votes is not None:
        os.environ["DEEPSEEK_PARALLEL_VOTES"] = str(deepseek_parallel_votes)

    print(f"{'='*60}")
    print(f"  Enhanced Chain-of-Table Experiment")
    print(f"{'='*60}")
    print(f"  Dataset:  {dataset} ({cfg['task']})")
    print(f"  Mode:     {mode}")
    print(f"  Model:    {model_name}")
    print(f"  Path:     {dataset_path}")
    print(f"  First N:  {first_n}")
    print(f"  Result:   {result_dir}")
    print(f"{'='*60}")
    print()

    # ── Load dataset ──────────────────────────────────────────────
    loader_module = cfg["loader_module"]
    loader_fn = cfg["load_fn"]
    loader_kwargs = dict(cfg.get("loader_kwargs", {}))

    if loader_module == "utils.load_data":
        from utils.load_data import load_tabfact_dataset, load_wikitablequestions_dataset
        load_fn = load_tabfact_dataset if loader_fn == "load_tabfact_dataset" else load_wikitablequestions_dataset

        if dataset == "tabfact":
            dataset_data = load_tabfact_dataset(
                dataset_path, loader_kwargs.get("raw2clean_path", ""),
                first_n=first_n)
        else:
            dataset_data = load_wikitablequestions_dataset(
                dataset_path, first_n=first_n, tag=dataset)
    elif loader_module == "run_spider":
        from run_spider import load_spider_dataset
        dataset_data = load_spider_dataset(dataset_path, first_n=first_n, tag="spider")
    elif loader_module == "run_tqabench":
        from run_tqabench import load_tqabench_dataset
        dataset_data = load_tqabench_dataset(dataset_path, first_n=first_n, tag="tqa")
    else:
        from utils.load_data import load_wikitablequestions_dataset
        dataset_data = load_wikitablequestions_dataset(dataset_path, first_n=first_n, tag=dataset)

    print(f"Loaded {len(dataset_data)} samples\n")

    # ── Setup LLM if needed ───────────────────────────────────────
    llm = None
    llm_options = None
    llm_refine_mode = "never"

    if mode in ("enhanced", "llm", "agent90"):
        from utils.llm import create_llm
        # Local transformers doesn't need any token for public models.
        # HF online needs HF_TOKEN. OpenAI-compatible needs OPENAI_API_KEY.
        api_key = openai_api_key or os.environ.get("HF_TOKEN") or os.environ.get("OPENAI_API_KEY") or None
        llm = create_llm(model_name=model_name, key=api_key, backend=llm_backend)
        llm_options = llm.get_model_options(
            temperature=0.0, per_example_max_decode_steps=700,
            per_example_top_p=1.0, n_sample=1)
        if mode == "agent90":
            llm_options["agent90_temperature"] = agent90_temperature
        if mode == "enhanced":
            llm_refine_mode = "low_confidence"
        elif mode == "llm":
            llm_refine_mode = "always"
        elif mode == "agent90":
            llm_refine_mode = "agent90"

    if cfg.get("requires_llm") and llm is None:
        print(f"ERROR: {dataset} requires LLM. Use --mode enhanced or --mode llm.")
        sys.exit(1)

    # Active universal framework path for Spider.  This is separate from
    # --mode symbolic, which is only the PCFG-BF lower-bound baseline.
    if dataset == "spider" and use_candidate_framework:
        from run_spider import main as spider_main
        print("[Spider] Routing through CandidateProgramEngine (SQL candidate-program framework).", flush=True)
        spider_main(
            dataset_path=dataset_path,
            result_dir=result_dir,
            model_name=model_name,
            openai_api_key=openai_api_key,
            openai_api_base=openai_api_base,
            llm_backend=llm_backend,
            first_n=first_n,
            n_proc=1,
            use_pcfg_bf=False,
            use_candidate_framework=True,
            candidate_sources=candidate_sources,
            max_sql_candidates=max_sql_candidates,
            max_repair_rounds=max_refinement,
            pcfg_beam_width=beam_width,
            pcfg_n_mcmc=n_mcmc,
            pcfg_max_refinement=max_refinement,
            debug=debug,
        )
        return

    # ── Run ────────────────────────────────────────────────────────
    if mode == "agent90":
        from utils.agent_engine import execute_agent90_dataset

        _inject_multitable_candidates(dataset)
        # Additive cache namespace: WikiTQ uses the v24 parser/prompt/evaluator,
        # so keep its cache separate from old TabFact/Agent90 caches.
        if dataset == "wikitq":
            agent90_cache_name = "agent90_cache_v25_wikitq"
        elif dataset == "tqabench":
            agent90_cache_name = "agent90_cache_v29_tqabench"
        else:
            agent90_cache_name = "agent90_cache_v19"
        result_samples, pipeline_reports = execute_agent90_dataset(
            dataset_data,
            llm=llm,
            llm_options=llm_options,
            dataset_name=dataset,
            beam_width=beam_width,
            n_mcmc=n_mcmc,
            max_refinement=max_refinement,
            votes=agent90_votes,
            max_table_chars=agent90_max_table_chars,
            adjudicate=not agent90_no_adjudicate,
            verifier=not agent90_no_verifier,
            debug=debug,
            cache_dir=os.path.join(result_dir, agent90_cache_name),
        )
        metrics = evaluate_results(result_samples, dataset, dataset_data)

    elif mode == "llm" and dataset != "fetaqa":
        # Full Chain-of-Table LLM pipeline
        from utils.chain import dynamic_chain_exec_with_cache_mp, fixed_chain_exec_mp
        from operations.final_query import simple_query

        # Inject multi-table candidates for Spider/TQA-Bench
        _inject_multitable_candidates(dataset)

        proc_samples, _ = dynamic_chain_exec_with_cache_mp(
            dataset_data, llm=llm, llm_options=llm.get_model_options(
                temperature=0.0, per_example_max_decode_steps=200,
                per_example_top_p=1.0),
            strategy="top", cache_dir=os.path.join(result_dir, "llm_cache"),
            n_proc=1, chunk_size=1)
        final_result, _ = fixed_chain_exec_mp(
            llm, proc_samples,
            [("simpleQuery", simple_query, dict(use_demo=True),
              dict(temperature=0, per_example_max_decode_steps=200,
                   per_example_top_p=1.0))])
        metrics = evaluate_results(final_result, dataset, dataset_data)
    else:
        # Enhanced / Symbolic: PCFG-BF core
        from utils.cot_enhanced import execute_dataset

        _inject_multitable_candidates(dataset)

        result_samples, pipeline_reports = execute_dataset(
            dataset_data,
            llm=llm,
            llm_options=llm_options,
            beam_width=beam_width,
            n_mcmc=n_mcmc,
            max_repair_rounds=max_refinement,
            llm_refine_mode=llm_refine_mode,
            llm_refine_min_bf=3.0,
            debug=debug,
            cache_dir=os.path.join(result_dir, "pcfg_bf_cache"),
        )
        metrics = evaluate_results(result_samples, dataset, dataset_data)

    # ── Report ────────────────────────────────────────────────────
    acc_key = "avg_bleu_approx" if dataset == "fetaqa" else (
        "accuracy" if "accuracy" in metrics else "denotation_accuracy")
    acc = metrics.get(acc_key, metrics.get("accuracy", 0))
    total = metrics.get("total", 0)
    correct = metrics.get("correct", 0)
    print(f"\n{'='*60}")
    print(f"  Result: {acc_key.replace('_', ' ').title()}: {acc:.4f}")
    print(f"  ({correct}/{total})")
    print(f"{'='*60}")

    # ── Save ──────────────────────────────────────────────────────
    # Some interrupted or copied Windows runs may lose the result directory;
    # recreate it immediately before writing metrics to avoid FileNotFoundError.
    os.makedirs(result_dir, exist_ok=True)
    report = {k: v for k, v in metrics.items()}
    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(f"Results saved to {result_dir}/metrics.json")


def _inject_multitable_candidates(dataset_name: str):
    """Inject multi-table candidate generation for Spider/TQA-Bench."""
    if dataset_name in ("spider", "tqabench", "multitable_fv"):
        try:
            import utils.beam_search as bs_mod
            from run_tqabench import multi_table_candidates
            bs_mod._saved_deterministic = bs_mod.deterministic_candidates

            def _mt_wrapper(sample, debug=False):
                tables = sample.get("tables", {})
                if len(tables) >= 2:
                    return multi_table_candidates(sample, debug)
                return bs_mod._saved_deterministic(sample, debug)

            bs_mod.deterministic_candidates = _mt_wrapper
        except Exception:
            pass


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description="PCFG-BF Enhanced Chain-of-Table — Unified Experiment Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run_reasoning_pipeline.py --dataset tabfact --mode symbolic --first_n 50
  python run_reasoning_pipeline.py --dataset wikitq --mode enhanced --first_n 50
  python run_reasoning_pipeline.py --dataset spider --mode symbolic --first_n 30
  python run_reasoning_pipeline.py --dataset fetaqa --mode llm --first_n 20
  python run_reasoning_pipeline.py --dataset tabfact --mode agent90 --model_name gpt-4o --first_n 200
        """)
    parser.add_argument("--dataset", default="tabfact",
                        choices=list(DATASET_CONFIG.keys()))
    parser.add_argument("--dataset_path", default=None)
    parser.add_argument("--mode", default="symbolic",
                        choices=["symbolic", "enhanced", "llm", "agent90"])
    parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct")
    parser.add_argument("--openai_api_key", default=None)
    parser.add_argument("--openai_api_base", default=None)
    parser.add_argument("--llm_backend", default=None,
                        help="local_hf (no token needed), hf_api (needs HF_TOKEN), openai")
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--beam_width", type=int, default=8)
    parser.add_argument("--n_mcmc", type=int, default=40)
    parser.add_argument("--max_refinement", type=int, default=3)
    parser.add_argument("--agent90_votes", type=int, default=7,
                        help="Number of self-consistency LLM votes in --mode agent90; v11 default is 7")
    parser.add_argument("--agent90_max_table_chars", type=int, default=20000,
                        help="Maximum serialized table chars in Agent90 prompt; v11 default is 20000")
    parser.add_argument("--agent90_no_adjudicate", action="store_true",
                        help="Disable second-pass adjudication inside Agent90")
    parser.add_argument("--agent90_no_verifier", action="store_true",
                        help="Disable v11 deterministic TabFact specialized verifiers")
    parser.add_argument("--agent90_temperature", type=float, default=0.35,
                        help="Sampling temperature for Agent90 multi-vote self-consistency")
    parser.add_argument("--deepseek_parallel_votes", type=int, default=3,
                        help="For DeepSeek/OpenAI-compatible endpoints that only support n=1: emulate Agent90 votes with this many parallel n=1 requests. Use 1 for serial, 3 recommended, 5 fastest but more likely rate-limited.")
    parser.add_argument("--openai_tpm_limit", type=int, default=0,
                        help="Local OpenAI TPM budget used for preflight throttling. Set 0 to disable. Default 24000 for a 30000 TPM org limit.")
    parser.add_argument("--openai_min_interval", type=float, default=0.0,
                        help="Minimum seconds between OpenAI requests in this process. Set 0 to disable.")
    parser.add_argument("--openai_max_retries", type=int, default=8,
                        help="Maximum OpenAI retry attempts after 429 or transient errors.")
    parser.add_argument("--use_candidate_framework", action="store_true",
                        help="For Spider, route samples through CandidateProgramEngine as SQL candidate programs")
    parser.add_argument("--candidate_sources", default="all",
                        choices=["all", "llm", "schema_rule", "llm,schema_rule", "schema_rule,llm"],
                        help="Candidate sources for Spider framework mode")
    parser.add_argument("--max_sql_candidates", type=int, default=3,
                        help="Max LLM SQL candidates for Spider framework mode")
    parser.add_argument("--result_dir", default=None)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    main(**vars(args))
