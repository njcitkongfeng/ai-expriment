# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""
Runnable StructQA/TableQA experiment for the PCFG-BF framework.

Expected JSONL input, one sample per line. Supported fields:
  - table_text or table: list of rows, where first row is the header
  - question or statement: natural-language query
  - answer or gold_answer or answers: gold answer

Example:
  python run_structqa.py --dataset_path data/structqa_demo.jsonl --result_dir results/structqa_demo --first_n -1

This runner does not require an OpenAI key. It evaluates the PCFG structured
prior + Bayesian evidence verifier + grammar-guided refinement pipeline.
"""

import json
import os
import pickle
from typing import Any, Dict, List

from utils.chain import pcfg_bf_chain_exec_dataset
from utils.execution_verifier import _compare_answer


def _load_jsonl_dataset(path: str, first_n: int = -1) -> List[Dict[str, Any]]:
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for idx, line in enumerate(f):
            if first_n != -1 and idx >= first_n:
                break
            if not line.strip():
                continue
            raw = json.loads(line)
            table = raw.get("table_text", raw.get("table", raw.get("table_data", [])))
            question = raw.get("question", raw.get("statement", raw.get("claim", "")))
            answer = raw.get("answer", raw.get("gold_answer", raw.get("answers", raw.get("target", None))))
            sample = dict(raw)
            sample["id"] = raw.get("id", f"structqa-{idx}")
            sample["table_text"] = table
            sample["tables"] = raw.get("tables", {"t": table} if table else {})
            sample["statement"] = question
            sample["question"] = question
            sample["answer"] = answer
            sample["chain"] = []
            data.append(sample)
    return data


def _evaluate(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = 0
    correct = 0
    exec_ok = 0
    with_program = 0
    bf_values = []
    rows = []
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("answer")
        gold = s.get("answer", None)
        # The output sample preserves original answer, so read gold from a shadow field if present.
        gold = s.get("gold_answer", s.get("answers", s.get("target", s.get("answer_gold", s.get("_gold_answer", None)))))
        if gold is None:
            gold = s.get("answer_ref", None)
        # Fallback: run_structqa stores original answer under original_answer before execution.
        if gold is None:
            gold = s.get("original_answer", None)
        is_correct = _compare_answer(pred, gold) if gold is not None else False
        if is_correct:
            correct += 1
        if s.get("program"):
            with_program += 1
        if s.get("execution_result") is not None:
            exec_ok += 1
        if isinstance(s.get("bayes_factor"), (int, float)):
            bf_values.append(float(s.get("bayes_factor")))
        rows.append({
            "id": s.get("id"),
            "question": s.get("question", s.get("statement")),
            "gold": gold,
            "prediction": pred,
            "correct": is_correct,
            "program": s.get("program"),
            "likelihood": s.get("likelihood"),
            "bayes_factor": s.get("bayes_factor"),
        })
    avg_bf = sum(bf_values) / len(bf_values) if bf_values else 0.0
    return {
        "total": total,
        "accuracy": correct / total if total else 0.0,
        "execution_success_rate": exec_ok / total if total else 0.0,
        "program_rate": with_program / total if total else 0.0,
        "avg_bayes_factor": avg_bf,
        "rows": rows,
    }


def main(
    dataset_path: str = "data/structqa_demo.jsonl",
    result_dir: str = "results/structqa_demo",
    first_n: int = -1,
    beam_width: int = 8,
    n_mcmc: int = 80,
    max_refinement_rounds: int = 3,
    debug: bool = False,
    llm_refine_mode: str = "never",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    openai_api_key: str = None,
    openai_api_base: str = None,
    llm_refine_min_bf: float = 3.0,
    llm_refine_top_k: int = 3,
    llm_max_tokens: int = 256,
    write_failure_analysis: bool = True,
):
    os.makedirs(result_dir, exist_ok=True)
    dataset = _load_jsonl_dataset(dataset_path, first_n=first_n)

    llm = None
    llm_options = None
    if str(llm_refine_mode).lower() != "never":
        if openai_api_base:
            os.environ["OPENAI_API_BASE"] = openai_api_base
        from utils.llm import create_llm
        api_key = openai_api_key or os.environ.get("HF_TOKEN") or os.environ.get("OPENAI_API_KEY") or "vllm"
        llm = create_llm(model_name=model_name, key=api_key)
        llm_options = llm.get_model_options(
            temperature=0.0,
            per_example_max_decode_steps=llm_max_tokens,
            per_example_top_p=1.0,
            n_sample=1,
        )

    # Preserve gold answer under a non-conflicting key because the pipeline writes prediction to 'answer'.
    for s in dataset:
        s["original_answer"] = s.get("answer")

    results, reports = pcfg_bf_chain_exec_dataset(
        dataset,
        llm=llm,
        llm_options=llm_options,
        beam_width=beam_width,
        n_mcmc=n_mcmc,
        max_refinement_rounds=max_refinement_rounds,
        debug=debug,
        cache_dir=os.path.join(result_dir, "cache"),
        llm_refine_mode=llm_refine_mode,
        llm_refine_min_bf=llm_refine_min_bf,
        llm_refine_top_k=llm_refine_top_k,
    )

    # restore original gold answer field for evaluation clarity
    for r, orig in zip(results, dataset):
        if r is not None:
            r["original_answer"] = orig.get("original_answer")
            r["question"] = orig.get("question")

    metrics = _evaluate(results)
    report = {k: v for k, v in metrics.items() if k != "rows"}
    print(json.dumps(report, indent=2, ensure_ascii=False))

    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    with open(os.path.join(result_dir, "predictions.jsonl"), "w", encoding="utf-8") as f:
        for row in metrics["rows"]:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    with open(os.path.join(result_dir, "results.pkl"), "wb") as f:
        pickle.dump(results, f)
    with open(os.path.join(result_dir, "reports.pkl"), "wb") as f:
        pickle.dump(reports, f)

    if write_failure_analysis:
        from utils.failure_analysis import analyze_failures
        failure_summary = analyze_failures(
            results, reports,
            output_dir=os.path.join(result_dir, "failure_analysis"),
            dataset_type="structqa",
        )
        print("Failure analysis:", json.dumps(failure_summary, ensure_ascii=False))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_path", default="data/structqa_demo.jsonl")
    parser.add_argument("--result_dir", default="results/structqa_demo")
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--beam_width", type=int, default=8)
    parser.add_argument("--n_mcmc", type=int, default=80)
    parser.add_argument("--max_refinement_rounds", type=int, default=3)
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--llm_refine_mode", default="never", choices=["never", "low_confidence", "always", "fallback"],
                        help="Use a real LLM for refinement. 'always' forces a 7B call on every case; 'low_confidence' calls it only when BF is weak.")
    parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct",
                        help="HF online model ID or OpenAI-compatible model name.")
    parser.add_argument("--openai_api_key", default=None)
    parser.add_argument("--openai_api_base", default=None)
    parser.add_argument("--llm_refine_min_bf", type=float, default=3.0)
    parser.add_argument("--llm_refine_top_k", type=int, default=3)
    parser.add_argument("--llm_max_tokens", type=int, default=256)
    parser.add_argument("--no_failure_analysis", dest="write_failure_analysis", action="store_false")
    args = parser.parse_args()
    main(**vars(args))
