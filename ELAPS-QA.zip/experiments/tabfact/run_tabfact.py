# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

# Copyright 2024 The Chain-of-Table authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Modifications for open-source 7B/8B models:
#   - Default 7B model updated to Qwen/Qwen2.5-Coder-14B-Instruct.
#   - Hugging Face online inference is supported via HF_TOKEN.
#   - OpenAI-compatible endpoints such as vLLM/Ollama are also supported.
#   - PCFG-BF is symbolic by default; add --llm_refine_mode to run real LLM repair.

import os
import sys

from utils.load_data import load_tabfact_dataset
from utils.helper import *
from utils.evaluate import *
from utils.chain import *
from operations import *


def main(
    dataset_path: str = "data/tabfact/test.jsonl",
    raw2clean_path: str = "data/tabfact/raw2clean.jsonl",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    result_dir: str = "results/tabfact",
    openai_api_key: str = None,
    openai_api_base: str = None,
    first_n: int = -1,
    n_proc: int = 1,
    chunk_size: int = 1,
    use_pcfg_bf: bool = False,
    pcfg_beam_width: int = 5,
    pcfg_n_mcmc: int = 30,
    pcfg_max_refinement: int = 3,
    llm_refine_mode: str = "never",
    llm_refine_min_bf: float = 3.0,
    llm_refine_top_k: int = 3,
    llm_max_tokens: int = 256,
    write_failure_analysis: bool = True,
    use_candidate_framework: bool = False,
    framework_max_candidates: int = 16,
    candidate_sources: str = "all",
    max_repair_rounds: int = 1,
    agent90_votes: int = 3,
    agent90_max_table_chars: int = 20000,
    agent90_no_adjudicate: bool = False,
    agent90_no_verifier: bool = False,
    agent90_no_false_rescue: bool = False,
    agent90_temperature: float = 0.35,
    posterior_selection: str = "answer_marginal",
    disable_safe_repairs: bool = False,
    disable_structural_prior: bool = False,
):
    # ── vLLM / custom endpoint ──────────────────────────────────────
    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base

    dataset = load_tabfact_dataset(dataset_path, raw2clean_path, first_n=first_n)
    os.makedirs(result_dir, exist_ok=True)

    if use_candidate_framework:
        # ---- Unified TabFact candidate_ours path --------------------
        # This is the paper Ours path for TabFact.  It wraps Agent90
        # self-consistency/adjudication/verifier into the candidate-program
        # posterior framework, while keeping schema_rule as an explicit ablation.
        from utils.fact_program_framework import (
            solve_tabfact_dataset_with_framework,
            compute_tabfact_metrics,
        )
        from utils.llm import create_llm, configure_llm_usage_logger, write_llm_usage_summary
        import json
        import pickle

        configure_llm_usage_logger(result_dir, enabled=True)
        llm = None
        llm_options = None
        if str(candidate_sources or "all").lower() not in {"schema", "schema_rule", "schema-rule", "rule", "rules"}:
            api_key = openai_api_key or os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("OPENAI_API_KEY") or "vllm"
            llm = create_llm(model_name=model_name, key=api_key)
            llm_options = llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=max(int(llm_max_tokens or 700), 700),
                per_example_top_p=1.0,
                n_sample=1,
            )
            llm_options["agent90_temperature"] = agent90_temperature

        effective_adjudicate = (not agent90_no_adjudicate) and (not disable_safe_repairs)
        effective_verifier = (not agent90_no_verifier) and (not disable_safe_repairs)
        effective_false_rescue = (not agent90_no_false_rescue) and (not disable_safe_repairs)
        result_samples, pipeline_reports = solve_tabfact_dataset_with_framework(
            dataset=dataset,
            max_candidates=framework_max_candidates,
            candidate_sources=candidate_sources,
            max_repair_rounds=max_repair_rounds,
            llm=llm,
            llm_options=llm_options,
            result_dir=result_dir,
            votes=agent90_votes,
            max_table_chars=agent90_max_table_chars,
            adjudicate=effective_adjudicate,
            verifier=effective_verifier,
            false_rescue=effective_false_rescue,
            posterior_selection=posterior_selection,
            disable_safe_repairs=disable_safe_repairs,
            disable_structural_prior=disable_structural_prior,
            debug=False,
        )
        eval_pack = compute_tabfact_metrics(result_samples)
        metrics = eval_pack["metrics"]
        metrics.update({
            "candidate_sources": candidate_sources,
            "framework_max_candidates": framework_max_candidates,
            "max_repair_rounds": max_repair_rounds,
            "agent90_votes": agent90_votes,
            "agent90_max_table_chars": agent90_max_table_chars,
            "agent90_temperature": agent90_temperature,
            "agent90_adjudicate": effective_adjudicate,
            "agent90_verifier": effective_verifier,
            "agent90_false_rescue": effective_false_rescue,
            "tabfact_false_rescue_min_conf": float(os.environ.get("TABFACT_FALSE_RESCUE_MIN_CONF", "0.92") or 0.92),
            "posterior_selection": posterior_selection,
            "disable_safe_repairs": bool(disable_safe_repairs),
            "disable_structural_prior": bool(disable_structural_prior),
            "temperature_settings": {"agent90_temperature": agent90_temperature},
            "experiment_config": {
                "dataset_path": dataset_path,
                "raw2clean_path": raw2clean_path,
                "model_name": model_name,
                "first_n": first_n,
                "framework_max_candidates": framework_max_candidates,
                "candidate_sources": candidate_sources,
                "max_repair_rounds": max_repair_rounds,
                "agent90_votes": agent90_votes,
                "agent90_max_table_chars": agent90_max_table_chars,
                "agent90_temperature": agent90_temperature,
                "agent90_false_rescue": effective_false_rescue,
                "tabfact_false_rescue_min_conf": float(os.environ.get("TABFACT_FALSE_RESCUE_MIN_CONF", "0.92") or 0.92),
                "posterior_selection": posterior_selection,
                "disable_safe_repairs": bool(disable_safe_repairs),
                "disable_structural_prior": bool(disable_structural_prior),
                "openai_api_base": openai_api_base or os.environ.get("OPENAI_API_BASE", ""),
            },
        })
        print(f"Accuracy (CandidateProgramEngine): {metrics['accuracy']}")
        print(f"Valid accuracy: {metrics['valid_accuracy']}  invalid_rate={metrics['invalid_rate']}")
        with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
            json.dump(metrics, f, ensure_ascii=False, indent=2)
        with open(os.path.join(result_dir, "predictions.jsonl"), "w", encoding="utf-8") as f:
            for row in eval_pack["rows"]:
                f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
        with open(os.path.join(result_dir, "framework_result.pkl"), "wb") as f:
            pickle.dump(result_samples, f)
        with open(os.path.join(result_dir, "pipeline_reports.pkl"), "wb") as f:
            pickle.dump(pipeline_reports, f)
        write_llm_usage_summary(result_dir)

    elif use_pcfg_bf:
        # ---- PCFG + Bayes Factor pipeline.  By default this path is symbolic
        # and does not require an LLM.  Set --llm_refine_mode always or
        # low_confidence to run a real 7B LLM refinement call through Hugging
        # Face online inference or an OpenAI-compatible backend.
        print(f"[PCFG-BF] beam_width={pcfg_beam_width}, "
              f"n_mcmc={pcfg_n_mcmc}, max_refinement={pcfg_max_refinement}, "
              f"llm_refine_mode={llm_refine_mode}")

        llm = None
        llm_options = None
        if str(llm_refine_mode).lower() != "never":
            from utils.llm import create_llm
            api_key = openai_api_key or os.environ.get("HF_TOKEN") or os.environ.get("OPENAI_API_KEY") or "vllm"
            llm = create_llm(model_name=model_name, key=api_key)
            llm_options = llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=llm_max_tokens,
                per_example_top_p=1.0,
                n_sample=1,
            )

        result_samples, pipeline_reports = pcfg_bf_chain_exec_dataset(
            dataset,
            llm=llm,
            llm_options=llm_options,
            beam_width=pcfg_beam_width,
            n_mcmc=pcfg_n_mcmc,
            max_refinement_rounds=pcfg_max_refinement,
            debug=False,
            cache_dir=os.path.join(result_dir, "pcfg_bf_cache"),
            llm_refine_mode=llm_refine_mode,
            llm_refine_min_bf=llm_refine_min_bf,
            llm_refine_top_k=llm_refine_top_k,
        )

        correct = 0
        total = 0
        for s in result_samples:
            if s is None:
                continue
            if tabfact_match_from_pcfg_result(s):
                correct += 1
            total += 1
        acc = correct / max(total, 1)
        print(f"Accuracy (PCFG-BF): {acc}")

        print(
            f'Accuracy (PCFG-BF): {acc}',
            file=open(os.path.join(result_dir, "result_pcfg_bf.txt"), "w")
        )
        pickle.dump(
            result_samples,
            open(os.path.join(result_dir, "pcfg_bf_result.pkl"), "wb")
        )
        pickle.dump(
            pipeline_reports,
            open(os.path.join(result_dir, "pcfg_bf_reports.pkl"), "wb")
        )

        metrics = {
            "total": total,
            "correct": correct,
            "accuracy": acc,
            "llm_refine_mode": llm_refine_mode,
            "llm_refinement_used": sum(
                1 for s in result_samples
                if isinstance(s, dict) and isinstance(s.get("llm_refinement"), dict)
                and s["llm_refinement"].get("used")
            ),
        }
        with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
            import json
            json.dump(metrics, f, ensure_ascii=False, indent=2)

        if write_failure_analysis:
            from utils.failure_analysis import analyze_failures
            import json
            failure_summary = analyze_failures(
                result_samples, pipeline_reports,
                output_dir=os.path.join(result_dir, "failure_analysis"),
                dataset_type="tabfact",
            )
            print("Failure analysis:", json.dumps(failure_summary, ensure_ascii=False))

    else:
        # ---- Original Chain-of-Table pipeline (LLM required) --------
        from utils.llm import create_llm

        # Auto-detect backend:
        #   HF_TOKEN set + model "org/model" → HuggingFace serverless
        #   OPENAI_API_BASE set → OpenAI-compatible (vLLM/Ollama/DeepSeek)
        #   Otherwise → OpenAI official
        api_key = openai_api_key or os.environ.get("OPENAI_API_KEY", "vllm")
        gpt_llm = create_llm(model_name=model_name, key=api_key)

        proc_samples, dynamic_chain_log_list = dynamic_chain_exec_with_cache_mp(
            dataset,
            llm=gpt_llm,
            llm_options=gpt_llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=200,
                per_example_top_p=1.0,
            ),
            strategy="top",
            cache_dir=os.path.join(result_dir, "cache"),
            n_proc=n_proc,
            chunk_size=chunk_size,
        )
        fixed_chain = [
            (
                "simpleQuery_fewshot",
                simple_query,
                dict(use_demo=True),
                dict(
                    temperature=0,
                    per_example_max_decode_steps=200,
                    per_example_top_p=1.0,
                ),
            ),
        ]
        final_result, _ = fixed_chain_exec_mp(
            gpt_llm,
            proc_samples,
            fixed_chain,
            n_proc=n_proc,
            chunk_size=chunk_size,
        )
        acc = tabfact_match_func_for_samples(final_result)
        print("Accuracy:", acc)

        print(
            f'Accuracy: {acc}',
            file=open(os.path.join(result_dir, "result.txt"), "w")
        )
        pickle.dump(
            final_result,
            open(os.path.join(result_dir, "final_result.pkl"), "wb")
        )
        pickle.dump(
            dynamic_chain_log_list,
            open(os.path.join(result_dir, "dynamic_chain_log_list.pkl"), "wb")
        )


if __name__ == "__main__":
    try:
        import fire
        fire.Fire(main)
    except ModuleNotFoundError:
        import argparse
        parser = argparse.ArgumentParser(
            description="Chain-of-Table TabFact experiment runner"
        )
        parser.add_argument("--dataset_path", default="data/tabfact/test.jsonl")
        parser.add_argument("--raw2clean_path", default="data/tabfact/raw2clean.jsonl")
        parser.add_argument(
            "--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct",
            help="Model name served by the OpenAI-compatible endpoint "
                 "(e.g. Qwen/Qwen2.5-Coder-14B-Instruct, qwen2.5:7b, deepseek-chat)"
        )
        parser.add_argument("--result_dir", default="results/tabfact")
        parser.add_argument(
            "--openai_api_key", default=None,
            help="API key (optional for local vLLM; defaults to 'vllm')"
        )
        parser.add_argument(
            "--openai_api_base", default=None,
            help="OpenAI-compatible API base URL "
                 "(default: http://localhost:8000/v1). "
                 "Also settable via OPENAI_API_BASE env var."
        )
        parser.add_argument("--first_n", type=int, default=-1)
        parser.add_argument("--n_proc", type=int, default=1)
        parser.add_argument("--chunk_size", type=int, default=1)

        # PCFG-BF options (no LLM required)
        parser.add_argument("--use_pcfg_bf", action="store_true")
        parser.add_argument("--pcfg_beam_width", type=int, default=5)
        parser.add_argument("--pcfg_n_mcmc", type=int, default=30)
        parser.add_argument("--pcfg_max_refinement", type=int, default=3)
        parser.add_argument("--llm_refine_mode", default="never", choices=["never", "low_confidence", "always", "fallback"],
                            help="Use a real LLM in PCFG-BF mode. 'always' forces a 7B call on every case; 'low_confidence' calls it only when BF is weak.")
        parser.add_argument("--llm_refine_min_bf", type=float, default=3.0)
        parser.add_argument("--llm_refine_top_k", type=int, default=3)
        parser.add_argument("--llm_max_tokens", type=int, default=256)
        parser.add_argument("--no_failure_analysis", dest="write_failure_analysis", action="store_false")
        parser.add_argument("--use_candidate_framework", action="store_true",
                            help="Route TabFact samples through unified candidate-ours framework")
        parser.add_argument("--framework_max_candidates", type=int, default=16)
        parser.add_argument("--candidate_sources", default="all",
                            help="all/agent90/candidate_ours for high-accuracy Ours; schema_rule for no-LLM ablation")
        parser.add_argument("--max_repair_rounds", type=int, default=1)
        parser.add_argument("--agent90_votes", type=int, default=3,
                            help="Self-consistency votes for TabFact candidate_ours. Use 3 for the high-score v19 setting; use 7 for stronger but costlier runs.")
        parser.add_argument("--agent90_max_table_chars", type=int, default=20000)
        parser.add_argument("--agent90_no_adjudicate", action="store_true")
        parser.add_argument("--agent90_no_verifier", action="store_true")
        parser.add_argument("--agent90_no_false_rescue", action="store_true",
                            help="Disable the strict unanimous-FALSE evidence audit added for TabFact v30")
        parser.add_argument("--agent90_temperature", type=float, default=0.35)
        parser.add_argument("--posterior_selection", default="answer_marginal", choices=["answer_marginal", "program_map"],
                            help="answer_marginal = vote-bucket posterior; program_map = highest-confidence single vote ablation")
        parser.add_argument("--disable_safe_repairs", action="store_true",
                            help="Disable TabFact local repair/correction modules: adjudication, specialized verifier, and false-rescue audit")
        parser.add_argument("--disable_structural_prior", action="store_true",
                            help="Use a plain table-verification prompt without the structured TabFact reasoning rules")

        args = parser.parse_args()
        main(**vars(args))
