# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""
FinQA experiment runner — numerical reasoning over financial tables.

FinQA requires multi-step arithmetic reasoning (sum, average, difference,
percentage change, etc.) over financial report tables.  This makes it an
excellent benchmark for PCFG-BF: SQL execution is naturally strong at
numerical computation.

Both Pipelines are supported:
  --use_pcfg_bf     symbolic PCFG + SQLite (free, fast)
  (default)         LLM Chain-of-Table pipeline

Input format (JSONL, convert with scripts/convert_datasets.py):
  {
    "id": "finqa-0",
    "table_text": [["year","revenue","profit"], ["2020","100","10"], ...],
    "question": "What was the revenue growth from 2020 to 2021?",
    "answers": ["50"],
    "table_caption": "Apple Inc. Q4 2020 Earnings",
    "finqa_program": [...],
    "finqa_pre_text": [...],
    "finqa_post_text": [...]
  }

Evaluation: numerical denotation accuracy with tolerance.

Example:
  python run_finqa.py --dataset_path data/finqa/test.jsonl --first_n 20 --use_pcfg_bf
"""

import json
import math
import os
import pickle
import sys
from typing import Any, Dict, List, Optional


# ══════════════════════════════════════════════════════════════════════
# FinQA-specific evaluation — numerical tolerance
# ══════════════════════════════════════════════════════════════════════

def _parse_numeric(val: Any) -> Optional[float]:
    """Parse common financial number formats: $1,234M, (35.2)%, 1.5B, etc."""
    if val is None:
        return None
    if isinstance(val, (int, float)) and not isinstance(val, bool):
        return float(val)
    s = str(val).strip().lower().replace(",", "").replace(" ", "")
    if not s:
        return None
    # Handle parentheses for negatives: (35.2) → -35.2
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1]
    # Handle scale suffixes
    scale = 1.0
    for suffix, mult in [("billion", 1e9), ("million", 1e6),
                          ("thousand", 1e3), ("b", 1e9), ("m", 1e6),
                          ("k", 1e3), ("%", 0.01)]:
        if s.endswith(suffix):
            s = s[:-len(suffix)]
            scale = mult
            break
    # Remove currency symbols
    s = s.replace("$", "").replace("€", "").replace("£", "").replace("¥", "")
    try:
        val = float(s)
        if neg:
            val = -val
        return val * scale
    except ValueError:
        return None


def _numbers_match(pred: Any, gold: Any, rel_tol: float = 1e-3) -> bool:
    """Compare two values numerically with relative tolerance."""
    pn = _parse_numeric(pred)
    gn = _parse_numeric(gold)
    if pn is not None and gn is not None:
        if abs(gn) < 1e-12:
            return abs(pn - gn) < 1e-6
        return abs(pn - gn) / abs(gn) <= rel_tol
    # Fallback: string comparison
    return str(pred).strip().lower() == str(gold).strip().lower()


def evaluate_finqa(results: List[Optional[Dict[str, Any]]]) -> Dict[str, Any]:
    """Evaluate FinQA results — numerical denotation accuracy."""
    total = 0
    correct = 0
    rows = []
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("answer")
        gold_list = s.get("answers", s.get("answer", []))

        if isinstance(gold_list, str):
            gold_list = [gold_list]
        if not isinstance(gold_list, list):
            gold_list = [str(gold_list)]

        is_correct = any(_numbers_match(pred, g) for g in gold_list)
        if is_correct:
            correct += 1

        rows.append({
            "id": s.get("id"),
            "question": s.get("question"),
            "gold": gold_list,
            "prediction": pred,
            "correct": is_correct,
            "program": s.get("program"),
        })

    n = max(total, 1)
    return {
        "total": total,
        "correct": correct,
        "accuracy": round(correct / n, 4),
        "rows": rows,
    }


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main(
    dataset_path: str = "data/finqa/test.jsonl",
    result_dir: str = "results/finqa",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    openai_api_key: str = None,
    openai_api_base: str = None,
    first_n: int = -1,
    n_proc: int = 1,
    chunk_size: int = 1,
    use_pcfg_bf: bool = False,
    pcfg_beam_width: int = 8,
    pcfg_n_mcmc: int = 40,
    pcfg_max_refinement: int = 3,
    llm_refine_mode: str = "never",
):
    os.makedirs(result_dir, exist_ok=True)

    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base

    # ── Load dataset ─────────────────────────────────────────────
    from utils.load_data import load_wikitablequestions_dataset
    dataset = load_wikitablequestions_dataset(
        dataset_path, first_n=first_n, tag="finqa"
    )
    print(f"Loaded {len(dataset)} FinQA samples", flush=True)

    if use_pcfg_bf:
        # ── PCFG + Bayes Factor pipeline ─────────────────────────
        from utils.chain import pcfg_bf_chain_exec_dataset

        llm = None
        llm_options = None
        if str(llm_refine_mode).lower() != "never":
            from utils.llm import create_llm
            api_key = openai_api_key or os.environ.get("HF_TOKEN") or os.environ.get("OPENAI_API_KEY") or "vllm"
            llm = create_llm(model_name=model_name, key=api_key)
            llm_options = llm.get_model_options(
                temperature=0.0, per_example_max_decode_steps=150,
                per_example_top_p=1.0, n_sample=1,
            )

        result_samples, pipeline_reports = pcfg_bf_chain_exec_dataset(
            dataset,
            llm=llm,
            llm_options=llm_options,
            beam_width=pcfg_beam_width,
            n_mcmc=pcfg_n_mcmc,
            max_refinement_rounds=pcfg_max_refinement,
            debug=False,
            cache_dir=os.path.join(result_dir, "pcfg_bf_cache"),
            llm_refine_mode=llm_refine_mode,
        )

        metrics = evaluate_finqa(result_samples)
        print(f"FinQA Accuracy (PCFG-BF): {metrics['accuracy']:.4f} "
              f"({metrics['correct']}/{metrics['total']})")

    else:
        # ── LLM Chain-of-Table pipeline ──────────────────────────
        from utils.llm import create_llm
        from utils.chain import dynamic_chain_exec_with_cache_mp, fixed_chain_exec_mp
        from operations.final_query import simple_query

        api_key = openai_api_key or os.environ.get("OPENAI_API_KEY", "vllm")
        gpt_llm = create_llm(model_name=model_name, key=api_key)

        proc_samples, dynamic_chain_log_list = dynamic_chain_exec_with_cache_mp(
            dataset,
            llm=gpt_llm,
            llm_options=gpt_llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=200,
                per_example_top_p=1.0,
            ),
            strategy="top",
            cache_dir=os.path.join(result_dir, "cache"),
            n_proc=n_proc,
            chunk_size=chunk_size,
        )

        fixed_chain = [
            (
                "simpleQuery",
                simple_query,
                dict(use_demo=True),
                dict(temperature=0, per_example_max_decode_steps=200,
                     per_example_top_p=1.0),
            ),
        ]
        final_result, _ = fixed_chain_exec_mp(gpt_llm, proc_samples, fixed_chain)

        metrics = evaluate_finqa(final_result)
        print(f"FinQA Accuracy (LLM): {metrics['accuracy']:.4f} "
              f"({metrics['correct']}/{metrics['total']})")

    # ── Save ─────────────────────────────────────────────────────
    report = {k: v for k, v in metrics.items() if k != "rows"}
    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    with open(os.path.join(result_dir, "predictions.jsonl"), "w", encoding="utf-8") as f:
        for row in metrics["rows"]:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    pickle.dump(
        final_result if not use_pcfg_bf else result_samples,
        open(os.path.join(result_dir, "results.pkl"), "wb")
    )


if __name__ == "__main__":
    try:
        import fire
        fire.Fire(main)
    except ModuleNotFoundError:
        import argparse
        parser = argparse.ArgumentParser(
            description="Chain-of-Table FinQA experiment runner"
        )
        parser.add_argument("--dataset_path", default="data/finqa/test.jsonl")
        parser.add_argument("--result_dir", default="results/finqa")
        parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct")
        parser.add_argument("--openai_api_key", default=None)
        parser.add_argument("--openai_api_base", default=None)
        parser.add_argument("--first_n", type=int, default=-1)
        parser.add_argument("--n_proc", type=int, default=1)
        parser.add_argument("--chunk_size", type=int, default=1)
        parser.add_argument("--use_pcfg_bf", action="store_true")
        parser.add_argument("--pcfg_beam_width", type=int, default=8)
        parser.add_argument("--pcfg_n_mcmc", type=int, default=40)
        parser.add_argument("--pcfg_max_refinement", type=int, default=3)
        parser.add_argument("--llm_refine_mode", default="never",
                            choices=["never", "low_confidence", "always"])
        args = parser.parse_args()
        main(**vars(args))
