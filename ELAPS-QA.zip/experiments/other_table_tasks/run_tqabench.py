# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""
TQA-Bench Multi-Table QA experiment runner.

TQA-Bench evaluates multi-table reasoning over relational databases.
Each sample contains MULTIPLE tables with foreign-key relationships,
and the question requires JOINs, aggregation, and/or filtering across tables.

This runner uses the PCFG-BF pipeline (symbolic grammar + SQL execution)
with the JoinTables grammar terminal enabled for multi-table reasoning.

Input format (JSONL, converted by scripts/convert_tqabench.py):
  {
    "id": "tqa-0",
    "database": "address",
    "tables": {
      "table1": [["h1","h2"], ["v1","v2"], ...],
      "table2": [["h1","h2"], ["v1","v2"], ...]
    },
    "question": "How many zip codes...?",
    "choices": ["A) 52", "B) 29", "C) 14", "D) 12"],
    "answer": "A",
    "scale": "16k"
  }

Evaluation: multiple-choice accuracy.

Example:
  python run_tqabench.py --dataset_path data/tqa_bench/test.jsonl --first_n 20 --use_pcfg_bf
"""

import json
import os
import pickle
import re
import sys
from typing import Any, Dict, List, Optional


# ══════════════════════════════════════════════════════════════════════
# Multi-table data loading
# ══════════════════════════════════════════════════════════════════════

def load_tqabench_dataset(
    dataset_path: str,
    first_n: int = -1,
    tag: str = "tqa",
) -> List[Dict[str, Any]]:
    """Load TQA-Bench JSONL dataset."""
    from tqdm import tqdm

    dataset = []
    all_lines = []
    with open(dataset_path, "r", encoding="utf-8") as f:
        for line in f:
            all_lines.append(line)
            if first_n != -1 and len(all_lines) >= first_n:
                break

    for i, line in tqdm(enumerate(all_lines), total=len(all_lines),
                        desc=f"Loading {tag} dataset"):
        info = json.loads(line)
        info["id"] = info.get("id", f"{tag}-{i}")

        # Normalize question/statement names.  MultiTable-FV uses
        # ``statement`` while TQA-Bench uses ``question``; candidate generation
        # should see the same text under both fields.
        if "question" not in info and "statement" in info:
            info["question"] = info["statement"]
        if "statement" not in info and "question" in info:
            info["statement"] = info["question"]

        # Preserve multiple-choice gold before downstream prediction code may
        # overwrite ``answer``.  This prevents pred==gold evaluation leakage.
        if "choices" in info and "answer" in info and "answer_gold" not in info:
            info["answer_gold"] = info["answer"]

        # Ensure 'tables' field exists
        if "tables" not in info and "table_text" in info:
            info["tables"] = {"t": info["table_text"]}
        elif "tables" not in info:
            info["tables"] = {}

        # For multi-table, also keep the original tables key
        info["chain"] = info.get("chain", [])
        dataset.append(info)
    return dataset


# ══════════════════════════════════════════════════════════════════════
# Multi-table candidate generation
# ══════════════════════════════════════════════════════════════════════

def _make_join_tree(terminals):
    """Build a parse tree with JoinTables support."""
    children = []
    for t, params in terminals:
        children.append({
            "nonterminal": t,
            "expansion": [t],
            "children": [],
            "terminal": t,
            "params": params,
        })
    return {
        "nonterminal": "MultiTableProgram",
        "expansion": [t for t, _ in terminals],
        "children": children,
    }


def _get_table_names(tables: Dict[str, List[List[Any]]]) -> List[str]:
    """Return sorted list of table names from the tables dict."""
    return sorted(tables.keys())


def _find_join_column(
    table_a: str, table_b: str,
    tables: Dict[str, List[List[Any]]],
) -> Optional[str]:
    """Heuristically find a join column between two tables.

    Looks for columns that share a name or have foreign-key naming patterns
    (e.g., table_b has a column named table_a + '_id').
    """
    if table_a not in tables or table_b not in tables:
        return None

    cols_a = set(tables[table_a][0])
    cols_b = set(tables[table_b][0])

    # Exact match
    common = cols_a & cols_b
    if common:
        return list(common)[0]

    # Foreign-key pattern: table_a has 'id', table_b has 'table_a_id'
    for col in cols_b:
        col_lower = str(col).lower().replace(" ", "_")
        a_lower = table_a.lower().replace(" ", "_")
        if a_lower in col_lower or col_lower.startswith(a_lower):
            return col

    # Reverse: table_b has 'id', table_a has 'table_b_id'
    for col in cols_a:
        col_lower = str(col).lower().replace(" ", "_")
        b_lower = table_b.lower().replace(" ", "_")
        if b_lower in col_lower or col_lower.startswith(b_lower):
            return col

    return None


# ─────────────────────────────────────────────────────────────
# Strong deterministic SQL candidates for small multi-table QA tests
# ─────────────────────────────────────────────────────────────

def _safe_ident_local(name: Any) -> str:
    ident = re.sub(r"[^a-zA-Z0-9_]", "_", str(name).strip())
    ident = re.sub(r"_+", "_", ident).strip("_")
    if ident and ident[0].isdigit():
        ident = "_" + ident
    return ident or "col"


def _q(value: Any) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _headers(table: List[List[Any]]) -> List[str]:
    return [str(h) for h in table[0]] if isinstance(table, list) and table else []


def _find_col(table: List[List[Any]], names: List[str]) -> Optional[str]:
    hs = _headers(table)
    name_lows = [n.lower() for n in names]
    for h in hs:
        hl = h.lower()
        if any(n == hl or n in hl for n in name_lows):
            return h
    return None


def _mentioned_values_in_table(table: List[List[Any]], question: str):
    """Return (column, value) pairs whose cell value appears in the question."""
    if not isinstance(table, list) or len(table) < 2:
        return []
    q = question.lower()
    out = []
    seen = set()
    for ci, h in enumerate(table[0]):
        for row in table[1:]:
            if ci >= len(row):
                continue
            v = str(row[ci]).strip()
            if not v:
                continue
            vl = v.lower()
            # Allow one-letter grade values only when the column is semantically present.
            ok_short = len(vl) == 1 and (str(h).lower() in q or f"grade {vl}" in q)
            if (len(vl) >= 2 or ok_short) and vl in q and (h, v) not in seen:
                out.append((str(h), v))
                seen.add((h, v))
    out.sort(key=lambda x: len(str(x[1])), reverse=True)
    return out


def _find_join_pairs(tables: Dict[str, List[List[Any]]]):
    """Find likely FK pairs by value overlap, not only identical column names."""
    pairs = []
    names = list(tables.keys())
    for i, ta in enumerate(names):
        for j, tb in enumerate(names):
            if i >= j:
                continue
            A, B = tables.get(ta, []), tables.get(tb, [])
            if not (isinstance(A, list) and isinstance(B, list) and A and B):
                continue
            best = None
            for ia, ca in enumerate(A[0]):
                vals_a = {str(r[ia]).strip() for r in A[1:] if len(r) > ia and str(r[ia]).strip()}
                if not vals_a:
                    continue
                for ib, cb in enumerate(B[0]):
                    vals_b = {str(r[ib]).strip() for r in B[1:] if len(r) > ib and str(r[ib]).strip()}
                    if not vals_b:
                        continue
                    overlap = len(vals_a & vals_b)
                    ratio = overlap / max(1, min(len(vals_a), len(vals_b)))
                    name_bonus = 0.2 if str(ca).lower() == str(cb).lower() else 0.0
                    score = ratio + name_bonus
                    if overlap > 0 and (best is None or score > best[0]):
                        best = (score, str(ca), str(cb))
            if best and best[0] >= 0.5:
                pairs.append((ta, tb, best[1], best[2], best[0]))
    pairs.sort(key=lambda x: x[4], reverse=True)
    return pairs


def _choice_has_all_same(sample: Dict[str, Any]) -> bool:
    return any("all have same" in str(c).lower() or "all tied" in str(c).lower() for c in sample.get("choices", []))


def _add_heuristic_sql_candidates(sample, tables, question, add):
    """Generate RawSQL candidates from REAL database schema + question.

    Systematically inspects every table's actual column names, finds
    which columns are most relevant to the question, and generates SQL
    patterns that use the real column names.  No keyword-guessing.
    """
    import re
    ql = question.lower()
    q_tokens = set(re.findall(r"[a-zA-Z0-9]+", ql))
    table_names = list(tables.keys())

    def raw(sql, score=-0.01):
        add([("RawSQL", {"operation": "RawSQL", "sql": sql})], score)

    # ── Schema analysis: compute column relevance from question ──
    all_cols = {}      # {(tn, col_name): relevance_score}
    numeric_cols = {}
    text_cols = {}

    for tn in table_names:
        t = tables.get(tn)
        if not isinstance(t, list) or len(t) < 2:
            continue
        hs = [str(h) for h in t[0]]
        for ci, h in enumerate(hs):
            hl = h.lower()
            h_tokens = set(re.findall(r"[a-zA-Z0-9]+", hl.replace("_", " ")))
            relevance = len(q_tokens & h_tokens)
            if hl in ql:
                relevance += 3
            for kw_map in [
                (["how many", "count", "number of"], ["count", "id", "name"]),
                (["oldest", "youngest", "age"], ["age", "birth", "year"]),
                (["name", "show", "list"], ["name", "title"]),
                (["country", "nation"], ["country", "nation"]),
                (["capacity", "stadium"], ["capacity", "average"]),
                (["song", "album"], ["song", "album", "release"]),
                (["highest", "most", "maximum", "top"], ["count", "amount", "total", "score"]),
                (["average", "avg", "mean"], ["age", "capacity", "price", "score"]),
                (["minimum", "maximum"], ["age", "capacity", "price", "score"]),
            ]:
                if any(kw in ql for kw in kw_map[0]):
                    if any(kw in hl for kw in kw_map[1]):
                        relevance += 2
            all_cols[(tn, h)] = max(all_cols.get((tn, h), 0), relevance)
            try:
                from utils.pcfg import _is_numeric_column
                if _is_numeric_column(t, ci):
                    numeric_cols[(tn, h)] = True
                else:
                    text_cols[(tn, h)] = True
            except Exception:
                text_cols[(tn, h)] = True

    ranked_cols = sorted(all_cols.items(), key=lambda x: x[1], reverse=True)
    ranked_num = [(k, v) for k, v in ranked_cols if k in numeric_cols]
    ranked_text = [(k, v) for k, v in ranked_cols if k in text_cols]

    def top_num(n=2):
        return [(tn, c) for (tn, c), _ in ranked_num[:n]]
    def top_text(n=2):
        return [(tn, c) for (tn, c), _ in ranked_text[:n]]

    # ── Find join pairs ──
    joins = _find_join_pairs(tables)

    # ── Find mentioned values ──
    all_mentioned = {}
    for tn in table_names:
        t = tables.get(tn)
        if t:
            for col, val in _mentioned_values_in_table(t, question):
                all_mentioned[(tn, col, val)] = True

    stn = lambda tn: _safe_ident_local(tn)
    sc = lambda col: _safe_ident_local(col) if col else "*"

    # ══════════════════════════════════════════════════════════════
    # PATTERN 1: Single-table queries
    # ══════════════════════════════════════════════════════════════

    for tn in table_names:
        t = tables.get(tn)
        if not t:
            continue
        s = stn(tn)
        hs = [str(h) for h in t[0]]

        def _col(hints, by_relevance=True):
            """Find column matching hints.  When by_relevance=False, returns
            the FIRST match (hint order = semantic priority).  When True,
            returns the column with highest question-token overlap."""
            best, best_score = None, -99
            for h in hs:
                hl = h.lower()
                for hint in hints:
                    if hint.lower() in hl or hl in hint.lower():
                        if by_relevance:
                            score = all_cols.get((tn, h), 0)
                        else:
                            # Lower hint index = higher semantic priority
                            score = 100 - hints.index(hint)
                        if score > best_score:
                            best_score, best = score, h
            return best

        # -- COUNT --
        if any(w in ql for w in ["how many", "number of", "count", "total number"]):
            for col, val in _mentioned_values_in_table(t, question):
                raw(f"SELECT COUNT(*) FROM {s} WHERE {sc(col)} = {_q(val)}", -0.02)
            raw(f"SELECT COUNT(*) FROM {s}", -0.06)

        # -- ORDER BY + LIMIT --
        order_map = [
            (["youngest", "earliest", "lowest", "smallest", "least"], "ASC"),
            (["oldest", "latest", "highest", "largest", "most", "top"], "DESC"),
        ]
        for keywords, direction in order_map:
            if not any(kw in ql for kw in keywords):
                continue
            # "youngest/oldest" → prefer age over year; "highest/lowest" → prefer capacity/score
            if any(w in ql for w in ["youngest", "oldest"]):
                hint_order = ["age", "birth", "song_release_year", "year", "release", "date",
                              "capacity", "score", "average", "attendance", "time"]
            elif any(w in ql for w in ["highest", "largest", "lowest", "smallest"]):
                hint_order = ["capacity", "score", "average", "highest", "lowest", "age",
                              "attendance", "price", "salary", "points", "weight", "height"]
            else:
                hint_order = ["age", "capacity", "score", "year", "date", "average",
                              "attendance", "price", "salary", "points", "weight", "height", "time"]
            oc = _col(hint_order, by_relevance=False)
            if not oc:
                nums = top_num(5)
                oc = nums[0][1] if nums else hs[0]
            # Include both text AND numeric columns that are question-relevant
            display_text = [c for (tn2, c), _ in ranked_text if tn2 == tn and c != oc]
            display_num = [c for (tn2, c), _ in ranked_num if tn2 == tn and c != oc]
            # Prioritize: text columns first, then numeric columns relevant to question
            display = display_text[:3] + [c for c in display_num if c not in display_text[:3]]
            # Reorder display columns: question-mentioned concepts first
            boost_keywords = []
            for kw in ["song_name", "song", "release_year", "release", "name",
                        "country", "capacity", "location", "age"]:
                if kw in ql:
                    boost_keywords.append(kw)
            if boost_keywords:
                def _display_score(c):
                    cl = c.lower()
                    return sum(2 for kw in boost_keywords if kw in cl)
                display = sorted(display, key=_display_score, reverse=True)
            sel = ", ".join(sc(c) for c in (display[:3] or hs[:3]))
            limit = "" if any(w in ql for w in ["all singers", "all stadiums",
                                                     "every singer", "every stadium",
                                                     "list all", "show all",
                                                     "each singer", "each stadium"]) else " LIMIT 1"
            raw(f"SELECT {sel} FROM {s} ORDER BY {sc(oc)} {direction}{limit}", -0.02)

        # -- "ordered by" / "descending order" --
        if any(w in ql for w in ["order", "descending", "ascending"]):
            for oh in ["age", "year", "date", "capacity", "score", "name",
                        "country", "song_release_year", "average", "weight", "height"]:
                oc = _col([oh], by_relevance=False)
                if oc:
                    direction = "DESC" if any(w in ql for w in ["descending", "oldest", "highest"]) else "ASC"
                    display = [c for (tn2, c), _ in ranked_text[:4] if tn2 == tn]
                    sel = ", ".join(sc(c) for c in (display[:4] or hs[:3]))
                    raw(f"SELECT {sel} FROM {s} ORDER BY {sc(oc)} {direction}", -0.02)
                    break

        # -- DISTINCT --
        if any(w in ql for w in ["distinct", "different"]):
            for (tn2, c), _ in ranked_text[:3]:
                if tn2 != tn:
                    continue
                for (mtn, mcol, mval) in [k for k in all_mentioned if k[0] == tn][:2]:
                    op = ">" if any(w in ql for w in ["above", "over", "more than", "greater", "older", "higher"]) else                          "<" if any(w in ql for w in ["below", "under", "less than", "younger", "lower"]) else "="
                    raw(f"SELECT DISTINCT {sc(c)} FROM {s} WHERE {sc(mcol)} {op} {_q(mval)}", -0.02)
                raw(f"SELECT DISTINCT {sc(c)} FROM {s}", -0.04)

        # -- GROUP BY + COUNT --
        if any(w in ql for w in ["each", "per", "every"]) and any(
                w in ql for w in ["how many", "number of", "count", "many"]):
            for (tn2, gc), _ in ranked_text[:3]:
                if tn2 != tn:
                    continue
                raw(f"SELECT {sc(gc)}, COUNT(*) FROM {s} GROUP BY {sc(gc)}", -0.02)

        # -- Multi-column aggregate --
        has_avg = any(w in ql for w in ["average", "avg"])
        has_min = any(w in ql for w in ["minimum", "min"])
        has_max = any(w in ql for w in ["maximum", "max"])
        if (has_avg and has_min and has_max) or (has_min and has_max):
            nums = [c for (tn2, c), _ in ranked_num[:5] if tn2 == tn]
            if nums:
                nc = sc(nums[0])
                raw(f"SELECT AVG({nc}), MIN({nc}), MAX({nc}) FROM {s}", -0.01)
        elif has_avg and has_max:
            nums = [c for (tn2, c), _ in ranked_num[:5] if tn2 == tn]
            if nums:
                nc = sc(nums[0])
                raw(f"SELECT AVG({nc}), MAX({nc}) FROM {s}", -0.02)
        elif has_max and has_avg:
            nums = [c for (tn2, c), _ in ranked_num[:5] if tn2 == tn]
            if nums:
                nc = sc(nums[0])
                raw(f"SELECT MAX({nc}), AVG({nc}) FROM {s}", -0.02)

        # -- BETWEEN --
        if "between" in ql:
            numbers = re.findall(r"\d+", ql)
            for (tn2, c), _ in ranked_num[:3]:
                if tn2 == tn and len(numbers) >= 2:
                    display = [dc for (tn3, dc), _ in ranked_text[:3] if tn3 == tn]
                    sel = ", ".join(sc(d) for d in (display[:2] or ["*"]))
                    raw(f"SELECT {sel} FROM {s} WHERE {sc(c)} BETWEEN {numbers[0]} AND {numbers[1]}", -0.01)

        # -- Simple WHERE filter --
        for (mtn, mcol, mval) in [k for k in all_mentioned if k[0] == tn][:3]:
            display = [sc(c) for (tn2, c), _ in ranked_text[:4] if tn2 == tn]
            if display:
                sel = ", ".join(display[:4])
                raw(f"SELECT {sel} FROM {s} WHERE {sc(mcol)} = {_q(mval)}", -0.04)
            oc = _col(["age", "year", "date", "capacity", "average", "score", "release"])
            if oc and display:
                sel = ", ".join(display[:4])
                raw(f"SELECT {sel} FROM {s} WHERE {sc(mcol)} = {_q(mval)} ORDER BY {sc(oc)} DESC", -0.02)
                raw(f"SELECT {sel} FROM {s} WHERE {sc(mcol)} = {_q(mval)} ORDER BY {sc(oc)} ASC", -0.03)

    # ══════════════════════════════════════════════════════════════
    # PATTERN 2: Multi-table JOIN queries
    # ══════════════════════════════════════════════════════════════

    for ta, tb, ca, cb, _score in joins:
        A, B = tables.get(ta), tables.get(tb)
        if not A or not B:
            continue
        sta, stb = stn(ta), stn(tb)
        sca, scb = _safe_ident_local(ca), _safe_ident_local(cb)
        joined = f"{sta} JOIN {stb} ON {sta}.{sca} = {stb}.{scb}"

        jvalues = []
        for parent_tn, T in [(ta, A), (tb, B)]:
            for col, val in _mentioned_values_in_table(T, question):
                jvalues.append((parent_tn, col, val))

        # COUNT with JOIN + filter
        if any(w in ql for w in ["how many", "number of", "count"]):
            for tv, c, v in jvalues:
                raw(f"SELECT COUNT(*) FROM {joined} WHERE {stn(tv)}.{sc(c)} = {_q(v)}", -0.01)
            raw(f"SELECT COUNT(*) FROM {joined}", -0.05)

        # JOIN + GROUP BY + ORDER BY LIMIT
        if any(w in ql for w in ["highest", "most", "maximum", "top", "largest"]):
            gc = None
            gtn = None
            for (tn2, c), _ in ranked_text[:5]:
                if tn2 in (ta, tb):
                    gc, gtn = c, tn2
                    break
            if gc:
                metric = "COUNT(*)"
                nums = [c for (tn2, c), _ in ranked_num[:5] if tn2 in (ta, tb)]
                if nums and any(w in ql for w in ["total", "sum", "salary"]):
                    metric = f"SUM({sc(nums[0])})"
                raw(f"SELECT {stn(gtn)}.{sc(gc)} FROM {joined} GROUP BY {stn(gtn)}.{sc(gc)} ORDER BY {metric} DESC LIMIT 1", -0.02)

        # JOIN + AVG/SUM with filter
        if any(w in ql for w in ["average", "avg", "mean", "total", "sum"]):
            nums = [c for (tn2, c), _ in ranked_num[:5] if tn2 in (ta, tb)]
            if nums:
                fn = "AVG" if any(w in ql for w in ["average", "avg", "mean"]) else "SUM"
                nc = sc(nums[0])
                ntn = stn([tn2 for (tn2, c), _ in ranked_num[:5] if tn2 in (ta, tb)][0])
                for tv, c, v in (jvalues or [(None, None, None)]):
                    where = f" WHERE {stn(tv)}.{sc(c)} = {_q(v)}" if tv else ""
                    raw(f"SELECT {fn}({ntn}.{nc}) FROM {joined}{where}", -0.01)

    # ══════════════════════════════════════════════════════════════
    # PATTERN 3: Special patterns
    # ══════════════════════════════════════════════════════════════

    # -- Subquery: WHERE col > (SELECT AVG(col)) --
    if any(w in ql for w in ["above average", "older than average",
                               "greater than average", "higher than average"]):
        for tn in table_names:
            t = tables.get(tn)
            if not t:
                continue
            s = stn(tn)
            for (tn2, nc), _ in ranked_num[:3]:
                if tn2 != tn:
                    continue
                display = [sc(c) for (tn3, c), _ in ranked_text[:3] if tn3 == tn]
                sel = ", ".join(display[:3] or ["*"])
                raw(f"SELECT {sel} FROM {s} WHERE {sc(nc)} > (SELECT AVG({sc(nc)}) FROM {s})", -0.01)
                break

    # -- Tie detection --
    if _choice_has_all_same(sample):
        tie_text = next((str(c).split(")", 1)[1].strip() for c in sample.get("choices", [])
                         if "all have same" in str(c).lower() or "all tied" in str(c).lower()), None)
        if tie_text:
            raw(f"SELECT {_q(tie_text)}", -0.02)

    # -- Sports patterns --
    if any(w in ql for w in ["total points", "points scored", "scored", "won the most"]):
        teams_tn = next((tn for tn in table_names if "team" in tn.lower()), None)
        games_tn = next((tn for tn in table_names if "game" in tn.lower() or "match" in tn.lower()), None)
        if teams_tn and games_tn:
            T, G = tables[teams_tn], tables[games_tn]
            tid = _find_col(T, ["team_id", "id"])
            tname = _find_col(T, ["team_name", "name"])
            home = _find_col(G, ["home_id", "home", "home_team"])
            away = _find_col(G, ["away_id", "away", "away_team"])
            hs_col = _find_col(G, ["home_score", "home_points"])
            as_col = _find_col(G, ["away_score", "away_points"])
            if tid and tname and home and away:
                mentioned = _mentioned_values_in_table(T, question)
                tval = next((v for c, v in mentioned if c == tname), None)
                tid_val = None
                if tval:
                    idx_n, idx_i = T[0].index(tname), T[0].index(tid)
                    for r in T[1:]:
                        if len(r) > max(idx_n, idx_i) and str(r[idx_n]).lower() == tval.lower():
                            tid_val = str(r[idx_i])
                if tid_val:
                    hsc = sc(hs_col) if hs_col else "0"
                    asc = sc(as_col) if as_col else "0"
                    raw(f"SELECT SUM(CASE WHEN {sc(home)} = {_q(tid_val)} THEN {hsc} ELSE {asc} END) FROM {stn(games_tn)} WHERE {sc(home)} = {_q(tid_val)} OR {sc(away)} = {_q(tid_val)}", -0.01)
                if "won the most" in ql:
                    raw(f"SELECT {sc(tname)} FROM {stn(teams_tn)} JOIN (SELECT winner, COUNT(*) AS wins FROM (SELECT CASE WHEN {sc(hs_col or home)} > {sc(as_col or away)} THEN {sc(home)} ELSE {sc(away)} END AS winner FROM {stn(games_tn)}) GROUP BY winner) ON {stn(teams_tn)}.{sc(tid)} = winner ORDER BY wins DESC LIMIT 1", -0.01)


def multi_table_candidates(sample: Dict[str, Any], debug: bool = False):
    """Generate multi-table aware deterministic candidates.

    For each pair of tables, generates:
      - Simple JOIN + aggregate queries
      - Filtered JOIN queries
      - Multi-condition queries
    """
    tables = sample.get("tables", {})
    if len(tables) < 2:
        # Fall back to single-table candidate generation
        from utils.beam_search import deterministic_candidates
        return deterministic_candidates(sample, debug=debug)

    table_names = _get_table_names(tables)
    question = str(sample.get("question", "")).lower()
    candidates = []

    def add(terminals, score=-0.30):
        tree = _make_join_tree(terminals)
        from utils.beam_search import tree_to_operations
        candidates.append(({
            "parse_tree": tree,
            "chain": tree_to_operations(tree),
            "log_prior": score,
        }, score))

    # Add robust deterministic SQL candidates before generic symbolic patterns.
    # These are generated from schema/question cues and do not use gold SQL.
    _add_heuristic_sql_candidates(sample, tables, question, add)

    # Find numeric and text columns across all tables
    all_num_cols = []
    all_text_cols = []
    for tn in table_names:
        if tn not in tables:
            continue
        from utils.pcfg import _is_numeric_column
        header = tables[tn][0]
        for ci, col in enumerate(header):
            if _is_numeric_column(tables[tn], ci):
                all_num_cols.append((tn, col))
            else:
                all_text_cols.append((tn, col))

    numeric_tab_cols = [f"{tn}.{c}" for tn, c in all_num_cols]
    text_tab_cols = [f"{tn}.{c}" for tn, c in all_text_cols]

    # ── Pattern 1: JOIN two most-related tables ──
    for i, ta in enumerate(table_names):
        for j, tb in enumerate(table_names):
            if i >= j:
                continue
            join_col = _find_join_column(ta, tb, tables)
            if not join_col:
                continue

            join_terminal = ("JoinTables", {
                "operation": "JoinTables",
                "table_a": ta,
                "table_b": tb,
                "on_col": join_col,
            })

            # Simple JOIN with aggregate
            if any(x in question for x in ["how many", "count", "number of"]):
                add([
                    join_terminal,
                    ("Aggregate", {"operation": "Aggregate", "function": "COUNT", "column": "*"}),
                ], -0.20)

            # JOIN with relevant column selection
            rel_num = [c for tn, c in all_num_cols if tn in (ta, tb)]
            rel_text = [c for tn, c in all_text_cols if tn in (ta, tb)]
            if rel_num:
                add([
                    join_terminal,
                    ("SelectCols", {"operation": "SelectCols", "columns": (rel_text[:1] + rel_num[:1])}),
                ], -0.25)
                add([
                    join_terminal,
                    ("Aggregate", {"operation": "Aggregate", "function": "AVG", "column": rel_num[0]}),
                ], -0.30)

            # Max/Min across joined tables
            if any(x in question for x in ["highest", "most", "maximum", "top"]) and rel_num:
                add([
                    join_terminal,
                    ("Aggregate", {"operation": "Aggregate", "function": "MAX", "column": rel_num[0]}),
                ], -0.20)
            if any(x in question for x in ["lowest", "least", "minimum", "bottom"]) and rel_num:
                add([
                    join_terminal,
                    ("Aggregate", {"operation": "Aggregate", "function": "MIN", "column": rel_num[0]}),
                ], -0.20)

    # ── Pattern 2: Single-table queries (for comparison) ──
    for tn in table_names:
        if tn not in tables:
            continue
        header = tables[tn][0]
        cols = header
        num_cols = [c for c in cols if any(True for _ in [0])]  # placeholder

        # COUNT on single table
        if any(x in question for x in ["how many", "count", "number"]):
            add([
                ("SelectCols", {"operation": "SelectCols", "columns": cols[:2]}),
                ("Aggregate", {"operation": "Aggregate", "function": "COUNT", "column": "*"}),
            ], -0.40)

    # ── Pattern 3: JOIN + WHERE + Aggregate (for revenue/sum type questions) ──
    for i, ta in enumerate(table_names):
        for j, tb in enumerate(table_names):
            if i >= j:
                continue
            join_col = _find_join_column(ta, tb, tables)
            if not join_col:
                continue

            join_terminal = ("JoinTables", {
                "operation": "JoinTables", "table_a": ta, "table_b": tb, "on_col": join_col,
            })

            # If question mentions specific categories/values, add WHERE + SUM
            for tn in [ta, tb]:
                if tn not in tables:
                    continue
                from utils.beam_search import _find_mentioned_value
                fv = _find_mentioned_value(tables[tn], question)
                if fv and any(x in question for x in ["total", "sum", "revenue", "amount", "average", "how many"]):
                    # JOIN + WHERE value match + SUM on a numeric column
                    num_cols_for_tn = [c for t, c in all_num_cols if t == tn]
                    agg_col = num_cols_for_tn[0] if num_cols_for_tn else (all_num_cols[0][1] if all_num_cols else None)
                    if agg_col:
                        filter_term = ("SelectRows", {
                            "operation": "SelectRows", "column": fv[0],
                            "operator": "=", "value": fv[1],
                        })
                        agg_fn = "SUM" if any(x in question for x in ["total", "sum", "revenue", "amount"]) else "COUNT"
                        add([
                            join_terminal, filter_term,
                            ("Aggregate", {"operation": "Aggregate", "function": agg_fn, "column": agg_col}),
                        ], -0.15)

            # JOIN + AVG for average questions
            if any(x in question for x in ["average", "avg", "mean"]):
                num_cols_joined = [c for tn, c in all_num_cols if tn in (ta, tb)]
                if num_cols_joined:
                    add([
                        join_terminal,
                        ("Aggregate", {"operation": "Aggregate", "function": "AVG", "column": num_cols_joined[0]}),
                    ], -0.20)

    # ── Pattern 4: Filtered multi-table query ──
    # Find values mentioned in question that exist in tables
    for tn in table_names:
        if tn not in tables:
            continue
        from utils.beam_search import _find_mentioned_value
        fv = _find_mentioned_value(tables[tn], question)
        if fv:
            filter_term = ("SelectRows", {
                "operation": "SelectRows",
                "column": fv[0],
                "operator": "=",
                "value": fv[1],
            })
            add([
                filter_term,
                ("SelectCols", {"operation": "SelectCols", "columns": tables[tn][0][:3]}),
            ], -0.25)

    # Deduplicate
    from utils.beam_search import _deduplicate_by_chain
    if not candidates:
        return []
    unique = _deduplicate_by_chain(candidates)
    if debug:
        print(f"[MultiTable] Generated {len(unique)} multi-table candidates")
    return unique


# ══════════════════════════════════════════════════════════════════════
# Multi-choice evaluation
# ══════════════════════════════════════════════════════════════════════

def _choice_value_pairs(choices: List[str]):
    pairs = []
    for choice in (choices or []):
        parts = str(choice).split(")", 1)
        if len(parts) < 2:
            continue
        pairs.append((parts[0].strip().upper(), parts[1].strip()))
    return pairs


def _numeric_match(pred_val: str, gold_val: str) -> bool:
    try:
        pn = float(str(pred_val).replace(",", "").replace("$", "").replace("%", ""))
        vn = float(str(gold_val).replace(",", "").replace("$", "").replace("%", ""))
        if abs(pn - vn) <= 1e-6:
            return True
        # Accept normal display rounding, e.g. 72666.6667 -> 72667, 2.3333 -> 2.33.
        decimals = 0
        if "." in str(gold_val):
            decimals = len(str(gold_val).split(".", 1)[1])
        return round(pn, decimals) == round(vn, decimals)
    except Exception:
        return False


def _map_value_to_choice(pred_val: Any, choices: List[str]) -> str:
    pred_text = str(pred_val).strip()
    best_choice = "?"
    best_score = -1.0
    for letter, value in _choice_value_pairs(choices):
        if pred_text.lower() == value.lower():
            return letter
        if _numeric_match(pred_text, value):
            return letter
        pl, vl = pred_text.lower(), value.lower()
        if pl and vl and (pl in vl or vl in pl):
            score = min(len(pl), len(vl)) / max(len(pl), len(vl))
            if score > best_score:
                best_score = score
                best_choice = letter
    return best_choice


def _sql_result_to_choice(
    exec_result: Any,
    choices: List[str],
    question: str = "",
    program: str = "",
) -> str:
    """Map a SQL execution result to the closest multiple-choice option.

    Improvements over the original version:
      - COUNT questions with row-returning SQL use ``len(rows)`` instead of
        the first cell, so ``SELECT rows WHERE ...`` can still be evaluated.
      - Multi-column rows try every returned cell before giving up.
      - Numeric comparison tolerates normal answer-option rounding.
    """
    if exec_result is None:
        return "?"

    q = str(question or "").lower()
    rows = exec_result if isinstance(exec_result, list) else None

    # Tie answer support for choices such as "All have same count" / "All tied".
    if rows and any("all have same" in v.lower() or "all tied" in v.lower() for _, v in _choice_value_pairs(choices)):
        if len(rows) > 1 and all(len(r) >= 2 for r in rows if isinstance(r, (list, tuple))):
            try:
                vals = [float(r[1]) for r in rows]
                if vals and len(set(vals)) == 1:
                    for letter, value in _choice_value_pairs(choices):
                        if "all have same" in value.lower() or "all tied" in value.lower():
                            return letter
            except Exception:
                pass

    # If a COUNT-style question returned raw rows instead of COUNT(*), count rows.
    if rows is not None and any(x in q for x in ["how many", "number of", "count"]):
        if not (len(rows) == 1 and isinstance(rows[0], (list, tuple)) and len(rows[0]) == 1 and isinstance(rows[0][0], (int, float))):
            mapped = _map_value_to_choice(len(rows), choices)
            if mapped != "?":
                return mapped

    values_to_try = []
    if isinstance(exec_result, list):
        for row in exec_result[:20]:
            if isinstance(row, (list, tuple)):
                values_to_try.extend(list(row))
            else:
                values_to_try.append(row)
    else:
        values_to_try.append(exec_result)

    for val in values_to_try:
        mapped = _map_value_to_choice(val, choices)
        if mapped != "?":
            return mapped

    # Last resort: stringify the entire result.
    return _map_value_to_choice(str(exec_result), choices)


def evaluate_tqabench(
    results: List[Optional[Dict[str, Any]]],
    dataset: List[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Evaluate TQA-Bench results — multiple-choice accuracy.

    Maps PCFG-BF SQL execution results to multiple-choice letters
    by comparing numeric/string values against choice options.
    """
    # Build lookup for choices by sample id
    choices_map = {}
    if dataset:
        for s in dataset:
            choices_map[s.get("id", "")] = s.get("choices", [])

    total = 0
    correct = 0
    rows = []
    for s in results:
        if s is None:
            continue
        total += 1

        # Get gold answer letter
        gold = str(s.get("answer_gold", "")).strip().upper()

        # Get choices for this sample
        sid = s.get("id", "")
        choices = choices_map.get(sid, [])

        # Map execution result to choice letter
        exec_result = s.get("execution_result")
        pred = _sql_result_to_choice(
            exec_result, choices,
            question=s.get("question", ""),
            program=s.get("program", ""),
        )

        is_correct = pred == gold if gold else False
        if is_correct:
            correct += 1

        rows.append({
            "id": sid,
            "question": s.get("question"),
            "gold": gold,
            "prediction": pred,
            "exec_result": str(exec_result)[:100] if exec_result else None,
            "correct": is_correct,
            "program": s.get("program"),
            "bayes_factor": s.get("bayes_factor"),
        })

    n = max(total, 1)
    return {
        "total": total,
        "correct": correct,
        "accuracy": round(correct / n, 4),
        "rows": rows,
    }


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main(
    dataset_path: str = "data/tqa_bench/test.jsonl",
    result_dir: str = "results/tqa_bench",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    openai_api_key: str = None,
    openai_api_base: str = None,
    first_n: int = -1,
    n_proc: int = 1,
    chunk_size: int = 1,
    use_pcfg_bf: bool = True,
    pcfg_beam_width: int = 8,
    pcfg_n_mcmc: int = 40,
    pcfg_max_refinement: int = 3,
):
    os.makedirs(result_dir, exist_ok=True)

    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base

    # ── Load dataset ─────────────────────────────────────────────
    dataset = load_tqabench_dataset(dataset_path, first_n=first_n, tag="tqabench")
    print(f"Loaded {len(dataset)} TQA-Bench samples", flush=True)

    if use_pcfg_bf:
        # ── PCFG-BF multi-table pipeline ─────────────────────────
        from utils.chain import pcfg_bf_chain_exec_one_sample
        from tqdm import tqdm

        result_samples = []
        pipeline_reports = []
        cache_dir = os.path.join(result_dir, "pcfg_bf_cache")
        os.makedirs(cache_dir, exist_ok=True)

        for idx in tqdm(range(len(dataset)), total=len(dataset),
                        desc="TQA-Bench PCFG-BF"):
            try:
                sample = dataset[idx]
                sample_id = sample.get("id", idx)

                # Monkey-patch: override beam_search deterministic candidates
                # to use our multi-table generator for multi-table samples.
                # Always restore in finally; otherwise an exception can corrupt
                # later samples.
                import utils.beam_search as bs_mod
                orig_det = bs_mod.deterministic_candidates

                # Store gold answer before execution overwrites it
                gold_answer = sample.get("answer", "")
                sample["_gold_answer"] = gold_answer

                try:
                    tables = sample.get("tables", {})
                    if len(tables) >= 2:
                        bs_mod.deterministic_candidates = (
                            lambda s, debug=False: multi_table_candidates(s, debug)
                        )

                    result, report = pcfg_bf_chain_exec_one_sample(
                        sample,
                        llm=None,
                        llm_options=None,
                        beam_width=pcfg_beam_width,
                        n_mcmc=pcfg_n_mcmc,
                        max_refinement_rounds=pcfg_max_refinement,
                        debug=False,
                    )
                finally:
                    bs_mod.deterministic_candidates = orig_det

                if result:
                    result["_raw_sample"] = sample
                    result["answer_gold"] = gold_answer

                result_samples.append(result)
                pipeline_reports.append(report)

            except Exception as e:
                print(f"[TQA-Bench] Error on sample {idx}: {e}", flush=True)
                result_samples.append(None)
                pipeline_reports.append(None)

        metrics = evaluate_tqabench(result_samples, dataset)
        print(f"TQA-Bench Accuracy (PCFG-BF): {metrics['accuracy']:.4f} "
              f"({metrics['correct']}/{metrics['total']})")

    else:
        # ── LLM Chain-of-Table pipeline ──────────────────────────
        from utils.llm import create_llm
        from utils.chain import dynamic_chain_exec_with_cache_mp, fixed_chain_exec_mp
        from operations.final_query import simple_query

        api_key = openai_api_key or os.environ.get("OPENAI_API_KEY", "vllm")
        gpt_llm = create_llm(model_name=model_name, key=api_key)

        # Convert multi-table format for LLM pipeline
        for s in dataset:
            if "table_text" not in s and "tables" in s:
                # Flatten tables into a single representation for the LLM
                table_parts = []
                for tn, tdata in s["tables"].items():
                    table_parts.append(f"Table: {tn}")
                    for row in tdata:
                        table_parts.append(" | ".join(str(c) for c in row))
                s["table_text"] = [s["tables"][tn][0] for tn in s["tables"]]
                if table_parts:
                    s["_serialized_tables"] = "\n".join(table_parts)

        proc_samples, dynamic_chain_log_list = dynamic_chain_exec_with_cache_mp(
            dataset, llm=gpt_llm,
            llm_options=gpt_llm.get_model_options(
                temperature=0.0, per_example_max_decode_steps=200,
                per_example_top_p=1.0,
            ),
            strategy="top",
            cache_dir=os.path.join(result_dir, "cache"),
            n_proc=n_proc, chunk_size=chunk_size,
        )

        fixed_chain = [
            ("simpleQuery", simple_query, dict(use_demo=True),
             dict(temperature=0, per_example_max_decode_steps=200,
                  per_example_top_p=1.0)),
        ]
        final_result, _ = fixed_chain_exec_mp(gpt_llm, proc_samples, fixed_chain)
        metrics = evaluate_tqabench(final_result, dataset)
        print(f"TQA-Bench Accuracy (LLM): {metrics['accuracy']:.4f}")

    # ── Save ─────────────────────────────────────────────────────
    report = {k: v for k, v in metrics.items() if k != "rows"}
    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    with open(os.path.join(result_dir, "predictions.jsonl"), "w", encoding="utf-8") as f:
        for row in metrics["rows"]:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    pickle.dump(
        result_samples if use_pcfg_bf else final_result,
        open(os.path.join(result_dir, "results.pkl"), "wb")
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description="Chain-of-Table TQA-Bench Multi-Table QA experiment runner"
    )
    parser.add_argument("--dataset_path", default="data/tqa_bench/test.jsonl")
    parser.add_argument("--result_dir", default="results/tqa_bench")
    parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct")
    parser.add_argument("--openai_api_key", default=None)
    parser.add_argument("--openai_api_base", default=None)
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--n_proc", type=int, default=1)
    parser.add_argument("--chunk_size", type=int, default=1)
    parser.add_argument("--use_pcfg_bf", action="store_true", default=True)
    parser.add_argument("--pcfg_beam_width", type=int, default=8)
    parser.add_argument("--pcfg_n_mcmc", type=int, default=40)
    parser.add_argument("--pcfg_max_refinement", type=int, default=3)
    parser.add_argument("--no_pcfg_bf", dest="use_pcfg_bf", action="store_false")
    args = parser.parse_args()
    main(**vars(args))
