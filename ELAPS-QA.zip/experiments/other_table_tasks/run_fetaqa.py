# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""
FeTaQA experiment runner — free-form table question answering.

FeTaQA requires generating a descriptive natural-language answer from table
data (avg. 18.9 words per answer).  This runner uses the LLM pipeline
(Chain-of-Table dynamic operations + final long-answer generation) and
evaluates with BLEU, ROUGE, and exact-match variants.

Input format (JSONL):
  {
    "id": "fetaqa-0",
    "table_text": [["h1","h2"], ["v1","v2"], ...],
    "question": "What was the score trend across the season?",
    "answers": ["The team started strong with 3 wins ..."],
    "table_caption": "optional"
  }

Example:
  python run_fetaqa.py --dataset_path data/fetaqa/test.jsonl --first_n 20
"""

import json
import os
import pickle
import sys
from typing import Any, Dict, List, Optional

from utils.load_data import load_wikitablequestions_dataset


# ══════════════════════════════════════════════════════════════════════
# Evaluation metrics
# ══════════════════════════════════════════════════════════════════════

def _compute_bleu(references: List[str], candidate: str) -> float:
    """Compute SacreBLEU score (corpus-level approximation per-sample)."""
    try:
        from sacrebleu import sentence_bleu
        return float(sentence_bleu(candidate, references).score) / 100.0
    except ImportError:
        # Fallback: simple BLEU-1 approximation
        import re
        ref_tokens = [set(re.findall(r'\w+', r.lower())) for r in references]
        cand_tokens = set(re.findall(r'\w+', candidate.lower()))
        if not ref_tokens or not cand_tokens:
            return 0.0
        overlaps = [len(cand_tokens & r) / max(len(cand_tokens), 1) for r in ref_tokens]
        return max(overlaps) * 0.25


def _compute_rouge_l(references: List[str], candidate: str) -> float:
    """Compute ROUGE-L F1 score."""
    try:
        from rouge import Rouge
        rouge = Rouge()
        scores = [rouge.get_scores(candidate, r)[0]['rouge-l']['f'] for r in references]
        return max(scores)
    except ImportError:
        import re
        def _lcs(a, b):
            m, n = len(a), len(b)
            dp = [[0] * (n + 1) for _ in range(m + 1)]
            for i in range(m):
                for j in range(n):
                    dp[i + 1][j + 1] = dp[i][j] + 1 if a[i] == b[j] else max(dp[i + 1][j], dp[i][j + 1])
            return dp[m][n]
        import re
        cand_words = re.findall(r'\w+', candidate.lower())
        best = 0.0
        for r in references:
            ref_words = re.findall(r'\w+', r.lower())
            lcs = _lcs(cand_words, ref_words)
            p = lcs / max(len(cand_words), 1)
            r_score = lcs / max(len(ref_words), 1)
            if p + r_score > 0:
                f1 = 2 * p * r_score / (p + r_score)
                best = max(best, f1)
        return best


def evaluate_fetaqa(results: List[Optional[Dict[str, Any]]]) -> Dict[str, Any]:
    """Compute BLEU and ROUGE-L over FeTaQA results."""
    total = 0
    bleu_sum = 0.0
    rouge_sum = 0.0
    rows = []
    for s in results:
        if s is None:
            continue
        total += 1
        pred = str(s.get("answer") or s.get("statement") or "")
        gold = s.get("answers", s.get("answer", []))
        if isinstance(gold, str):
            gold = [gold]
        if not isinstance(gold, list):
            gold = [str(gold)]

        bleu = _compute_bleu(gold, pred)
        rouge = _compute_rouge_l(gold, pred)
        bleu_sum += bleu
        rouge_sum += rouge

        rows.append({
            "id": s.get("id"),
            "question": s.get("question"),
            "gold_answers": gold,
            "prediction": pred,
            "bleu": round(bleu, 4),
            "rouge_l": round(rouge, 4),
        })

    n = max(total, 1)
    return {
        "total": total,
        "avg_bleu": round(bleu_sum / n, 4),
        "avg_rouge_l": round(rouge_sum / n, 4),
        "rows": rows,
    }


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main(
    dataset_path: str = "data/fetaqa/test.jsonl",
    result_dir: str = "results/fetaqa",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    openai_api_key: str = None,
    openai_api_base: str = None,
    first_n: int = -1,
    n_proc: int = 1,
    chunk_size: int = 1,
    use_fewshot: bool = True,
):
    os.makedirs(result_dir, exist_ok=True)

    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base

    # ── Load dataset ─────────────────────────────────────────────
    dataset = load_wikitablequestions_dataset(
        dataset_path, first_n=first_n, tag="fetaqa"
    )
    print(f"Loaded {len(dataset)} FeTaQA samples", flush=True)

    from utils.llm import create_llm
    from utils.chain import dynamic_chain_exec_with_cache_mp, fixed_chain_exec_mp
    from operations.final_query import simple_query
    from operations.final_query import general_demo

    api_key = openai_api_key or os.environ.get("OPENAI_API_KEY", "vllm")
    gpt_llm = create_llm(model_name=model_name, key=api_key)

    # ── Step 1: Dynamic chain (table evolution) ──────────────────
    proc_samples, dynamic_chain_log_list = dynamic_chain_exec_with_cache_mp(
        dataset,
        llm=gpt_llm,
        llm_options=gpt_llm.get_model_options(
            temperature=0.0,
            per_example_max_decode_steps=200,
            per_example_top_p=1.0,
        ),
        strategy="top",
        cache_dir=os.path.join(result_dir, "cache"),
        n_proc=n_proc,
        chunk_size=chunk_size,
    )

    # ── Step 2: Final free-form answer generation ────────────────
    # Override simple_query to ask for a descriptive answer, not YES/NO.
    def fetaqa_final_query(sample, table_info, llm, debug=False, use_demo=True,
                           llm_options=None):
        from utils.helper import table2string
        import numpy as np

        table_text = table_info["table_text"]
        caption = sample.get("table_caption", "")
        question = sample.get("question", sample.get("statement", ""))

        prompt = ""
        if use_demo:
            # Few-shot: show examples of descriptive table QA
            prompt += (
                "You are answering questions about tables. "
                "Write a complete, descriptive sentence using information "
                "from the table. Include specific numbers and names.\n\n"
                "Example 1:\n"
                "Table:\n"
                "col : player | team | points | rebounds\n"
                "row 1 : LeBron James | Lakers | 30 | 8\n"
                "row 2 : Anthony Davis | Lakers | 25 | 12\n"
                "Question: How did the Lakers players perform?\n"
                "Answer: LeBron James scored 30 points with 8 rebounds, "
                "while Anthony Davis contributed 25 points and 12 rebounds.\n\n"
                "Example 2:\n"
                "Table:\n"
                "col : year | revenue | profit\n"
                "row 1 : 2020 | 100M | 10M\n"
                "row 2 : 2021 | 150M | 20M\n"
                "row 3 : 2022 | 120M | 5M\n"
                "Question: Describe the revenue trend.\n"
                "Answer: Revenue increased from 100M in 2020 to 150M in 2021, "
                "then declined to 120M in 2022, while profit peaked at 20M in 2021.\n\n"
            )

        prompt += "Table:\n" + table2string(table_text, caption=caption) + "\n"
        prompt += "Question: " + question + "\n"
        prompt += "Answer:"

        responses = llm.generate_plus_with_score(prompt, options=llm_options)
        responses = [(res.strip(), np.exp(score)) for res, score in responses]

        return {
            "chain": sample.get("chain", []) + [{
                "operation_name": "fetaqa_final_answer",
                "parameter_and_conf": responses,
            }],
            "answer": responses[0][0] if responses else "",
            **{k: v for k, v in sample.items()
               if k not in ("chain", "answer")},
        }

    fixed_chain = [
        (
            "fetaqa_final_answer",
            fetaqa_final_query,
            dict(use_demo=use_fewshot),
            dict(
                temperature=0.3,  # Slight temperature for diversity in free-form
                per_example_max_decode_steps=300,  # Longer answers need more tokens
                per_example_top_p=0.95,
            ),
        ),
    ]
    final_result, _ = fixed_chain_exec_mp(gpt_llm, proc_samples, fixed_chain)

    # ── Evaluate ─────────────────────────────────────────────────
    metrics = evaluate_fetaqa(final_result)
    print(f"FeTaQA results ({len(final_result)} samples):")
    print(f"  Avg BLEU:    {metrics['avg_bleu']:.4f}")
    print(f"  Avg ROUGE-L: {metrics['avg_rouge_l']:.4f}")

    # ── Save ─────────────────────────────────────────────────────
    report = {k: v for k, v in metrics.items() if k != "rows"}
    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    with open(os.path.join(result_dir, "predictions.jsonl"), "w", encoding="utf-8") as f:
        for row in metrics["rows"]:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    pickle.dump(final_result, open(os.path.join(result_dir, "results.pkl"), "wb"))


if __name__ == "__main__":
    try:
        import fire
        fire.Fire(main)
    except ModuleNotFoundError:
        import argparse
        parser = argparse.ArgumentParser(
            description="Chain-of-Table FeTaQA experiment runner"
        )
        parser.add_argument("--dataset_path", default="data/fetaqa/test.jsonl")
        parser.add_argument("--result_dir", default="results/fetaqa")
        parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct")
        parser.add_argument("--openai_api_key", default=None)
        parser.add_argument("--openai_api_base", default=None)
        parser.add_argument("--first_n", type=int, default=-1)
        parser.add_argument("--n_proc", type=int, default=1)
        parser.add_argument("--chunk_size", type=int, default=1)
        parser.add_argument("--no_fewshot", dest="use_fewshot", action="store_false")
        args = parser.parse_args()
        main(**vars(args))
