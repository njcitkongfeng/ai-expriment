from __future__ import annotations
# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""Batch runner — runs all datasets through enhanced Chain-of-Table.

Usage:
  # Quick batch (symbolic only, zero LLM)
  python run_all_experiments.py --output_root results/batch_symbolic

  # Enhanced batch (PCFG-BF + LLM refinement)
  python run_all_experiments.py --mode enhanced \
    --model_name "Qwen/Qwen2.5-Coder-14B-Instruct" \
    --output_root results/batch_enhanced

  # Specific datasets only
  python run_all_experiments.py --datasets tabfact,wikitq,spider --first_n 50
"""


import argparse
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List


# ── Supported datasets ────────────────────────────────────────────
ALL_DATASETS = ["tabfact", "wikitq", "finqa", "spider"]
LLM_ONLY_DATASETS = ["fetaqa", "tqabench"]


def run_batch(
    datasets: List[str],
    output_root: Path,
    mode: str = "symbolic",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    first_n: int = -1,
    beam_width: int = 8,
    n_mcmc: int = 40,
    **kwargs,
) -> List[Dict[str, Any]]:
    """Run multiple datasets through run_reasoning_pipeline.py and collect results."""
    import subprocess
    import sys

    batch_summary: List[Dict[str, Any]] = []

    for ds in datasets:
        result_dir = output_root / ds
        started = time.time()

        cmd = [
            sys.executable, "run_reasoning_pipeline.py",
            "--dataset", ds,
            "--mode", mode,
            "--model_name", model_name,
            "--first_n", str(first_n),
            "--beam_width", str(beam_width),
            "--n_mcmc", str(n_mcmc),
            "--result_dir", str(result_dir),
        ]
        if kwargs.get("openai_api_base"):
            cmd += ["--openai_api_base", kwargs["openai_api_base"]]

        print(f"\n[Batch] {ds} ({mode}) -> {result_dir}", flush=True)
        try:
            subprocess.run(cmd, check=True, timeout=7200)
            status = "ok"
            error = None
        except subprocess.TimeoutExpired:
            status = "timeout"
            error = "2 hour timeout"
        except subprocess.CalledProcessError as e:
            status = "error"
            error = str(e)

        elapsed = time.time() - started

        # Read metrics
        metrics_path = result_dir / "metrics.json"
        metrics = {}
        if metrics_path.exists():
            with open(metrics_path, "r", encoding="utf-8") as f:
                metrics = json.load(f)

        row = {
            "dataset": ds,
            "mode": mode,
            "model": model_name,
            "status": status,
            "metrics": metrics,
            "elapsed_sec": round(elapsed, 1),
            "result_dir": str(result_dir),
        }
        batch_summary.append(row)

        # Print inline result
        acc = metrics.get("accuracy", metrics.get("denotation_accuracy",
              metrics.get("execution_accuracy", metrics.get("avg_bleu_approx", "?"))))
        print(f"  {status:5s}  acc={acc}  time={elapsed:.0f}s", flush=True)

    return batch_summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Batch run enhanced Chain-of-Table across multiple datasets")
    parser.add_argument("--output_root", default="results/batch")
    parser.add_argument("--datasets", default="tabfact,wikitq,finqa,spider",
                        help="Comma-separated dataset list")
    parser.add_argument("--mode", default="symbolic",
                        choices=["symbolic", "enhanced", "llm"])
    parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct")
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--beam_width", type=int, default=8)
    parser.add_argument("--n_mcmc", type=int, default=40)
    parser.add_argument("--openai_api_base", default=None)
    args = parser.parse_args()

    datasets = [d.strip() for d in args.datasets.split(",") if d.strip()]

    # Validate
    valid = set(ALL_DATASETS + LLM_ONLY_DATASETS)
    for ds in datasets:
        if ds not in valid:
            print(f"Unknown dataset: {ds}. Choices: {sorted(valid)}")
            return

    # LLM-only datasets require LLM mode
    for ds in datasets:
        if ds in LLM_ONLY_DATASETS and args.mode == "symbolic":
            print(f"WARNING: {ds} requires LLM. Skipping (use --mode enhanced or --mode llm).")
            datasets.remove(ds)

    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    summary = run_batch(
        datasets=datasets,
        output_root=output_root,
        mode=args.mode,
        model_name=args.model_name,
        first_n=args.first_n,
        beam_width=args.beam_width,
        n_mcmc=args.n_mcmc,
        openai_api_base=args.openai_api_base,
    )

    # Save summary
    with open(output_root / "batch_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, default=str)

    # Markdown table
    lines = ["# Batch Summary", "",
             f"Mode: {args.mode} | Model: {args.model_name} | First N: {args.first_n}",
             "",
             "| Dataset | Status | Accuracy | Time (s) |",
             "|---------|--------|----------|----------|"]
    for row in summary:
        m = row.get("metrics", {})
        acc = m.get("accuracy", m.get("denotation_accuracy",
              m.get("execution_accuracy", "?")))
        lines.append(f"| {row['dataset']} | {row['status']} | {acc} | {row['elapsed_sec']} |")

    with open(output_root / "batch_summary.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"\nSummary saved to {output_root}/batch_summary.json")
    print(f"Markdown report: {output_root}/batch_summary.md")


if __name__ == "__main__":
    main()
