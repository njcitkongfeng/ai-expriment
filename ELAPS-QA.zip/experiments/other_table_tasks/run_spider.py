# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""
Spider Text-to-SQL experiment runner.

Spider is the classic multi-table Text-to-SQL benchmark.  Each sample has a
natural-language question, a multi-table database, and a gold SQL query.
Evaluation compares the PCFG-BF generated answer against the gold SQL result.

Supports both PCFG-BF (symbolic) and LLM Chain-of-Table pipelines.

Input format (JSONL):
  {
    "id": "spider-concert_singer-0",
    "database": "concert_singer",
    "tables": {"singer": [...], "concert": [...], ...},
    "question": "How many singers do we have?",
    "gold_sql": "SELECT count(*) FROM singer",
    "answers": [5]
  }

Example:
  python scripts/convert_spider.py --split dev --output data/spider/test.jsonl
  python run_spider.py --dataset_path data/spider/test.jsonl --first_n 20 --use_pcfg_bf
"""

import json
import os
import pickle
import sys
from typing import Any, Dict, List, Optional


# ══════════════════════════════════════════════════════════════════════
# Data loading
# ══════════════════════════════════════════════════════════════════════

def _quote_ident(name: str) -> str:
    """Quote a SQLite identifier safely."""
    return '"' + str(name).replace('"', '""') + '"'


def _normalize_sql_result(rows):
    """Convert SQLite rows to a compact, JSON-friendly answer object."""
    rows = [list(r) for r in rows]
    if len(rows) == 1 and len(rows[0]) == 1:
        return rows[0][0]
    if rows and all(len(r) == 1 for r in rows):
        return [r[0] for r in rows]
    return rows


def _execute_gold_sql(db_path: str, sql: str):
    """Execute official Spider gold SQL to obtain denotation supervision.

    This is used only to build the evaluation target; it must not be used by
    candidate generation, repair, or ranking.
    """
    import sqlite3
    if not sql:
        return None
    try:
        con = sqlite3.connect(db_path)
        cur = con.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        con.close()
        return _normalize_sql_result(rows)
    except Exception:
        try:
            con.close()
        except Exception:
            pass
        return None


def _load_sqlite_tables(db_path: str):
    """Load all user tables from a Spider SQLite DB as Chain-of-Table tables.

    Returned format: {table_name: [[header...], [row...], ...]}.
    """
    import sqlite3
    con = sqlite3.connect(db_path)
    cur = con.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    table_names = [r[0] for r in cur.fetchall()]
    tables = {}
    for table in table_names:
        try:
            cur.execute(f"PRAGMA table_info({_quote_ident(table)})")
            header = [r[1] for r in cur.fetchall()]
            cur.execute(f"SELECT * FROM {_quote_ident(table)}")
            rows = [list(r) for r in cur.fetchall()]
            tables[table] = [header] + rows
        except Exception:
            continue
    con.close()
    return tables


def _infer_spider_root(path: str) -> str:
    """Infer the Spider root containing database/, tables.json, dev.json."""
    from pathlib import Path
    p = Path(path)
    if p.is_dir():
        return str(p)
    parent = p.parent
    if (parent / "database").exists():
        return str(parent)
    if parent.name in {"spider", "spider_data"}:
        return str(parent)
    # common fallback in this project
    return "data/spider_data"


def _load_spider_official_json(path: str, first_n=-1, tag="spider", spider_root=None):
    """Load official Spider dev/test/train JSON directly.

    Official format contains db_id, question, query, and sql.  We materialize
    the corresponding SQLite DB into the table format expected by the existing
    Chain-of-Table/PCFG-BF pipeline and execute the gold SQL to obtain answers.
    """
    from tqdm import tqdm
    from pathlib import Path

    spider_root = spider_root or _infer_spider_root(path)
    root = Path(spider_root)
    raw = json.load(open(path, "r", encoding="utf-8"))
    if first_n != -1:
        raw = raw[:first_n]

    dataset = []
    table_cache = {}
    answer_cache = {}
    for i, info in tqdm(enumerate(raw), total=len(raw), desc=f"Loading {tag} official"):
        db_id = info.get("db_id") or info.get("database")
        if not db_id:
            continue
        db_path = root / "database" / db_id / f"{db_id}.sqlite"
        if not db_path.exists():
            # Some distributions use .db, so fall back gracefully.
            alt = root / "database" / db_id / f"{db_id}.db"
            db_path = alt if alt.exists() else db_path
        if not db_path.exists():
            raise FileNotFoundError(f"Spider database not found for db_id={db_id}: {db_path}")

        if db_id not in table_cache:
            table_cache[db_id] = _load_sqlite_tables(str(db_path))
        tables = table_cache[db_id]
        first_table = next(iter(tables.values()), [])

        gold_sql = info.get("query") or info.get("gold_sql") or ""
        ans_key = (str(db_path), gold_sql)
        if ans_key not in answer_cache:
            answer_cache[ans_key] = _execute_gold_sql(str(db_path), gold_sql)
        gold_answer = answer_cache[ans_key]

        sample = {
            "id": info.get("id", f"{tag}-{db_id}-{i}"),
            "db_id": db_id,
            "database": db_id,
            "db_path": str(db_path),
            "question": info.get("question", ""),
            "statement": info.get("question", ""),
            "gold_sql": gold_sql,
            "answers": [gold_answer] if not isinstance(gold_answer, list) else gold_answer,
            "tables": tables,
            "table_text": first_table,
            "chain": info.get("chain", []),
            "spider_sql_ast": info.get("sql"),
            "source_format": "official_spider_json",
        }
        dataset.append(sample)
    return dataset


def _load_spider_jsonl(path: str, first_n=-1, tag="spider"):
    from tqdm import tqdm

    dataset = []
    all_lines = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            all_lines.append(line)
            if first_n != -1 and len(all_lines) >= first_n:
                break

    for i, line in tqdm(enumerate(all_lines), total=len(all_lines),
                        desc=f"Loading {tag} jsonl"):
        info = json.loads(line)
        info["id"] = info.get("id", f"{tag}-{i}")
        info["chain"] = info.get("chain", [])
        dataset.append(info)
    return dataset


def load_spider_dataset(path, first_n=-1, tag="spider", spider_root=None):
    """Load Spider either from project JSONL or official Spider format.

    Supported inputs:
    1. data/spider/test.jsonl — already-converted project format.
    2. data/spider_data/dev.json / test.json / train_spider.json — official format.
    3. data/spider_data — directory; defaults to dev.json.

    This avoids forcing an offline conversion step while preserving the old
    JSONL path for backward compatibility.
    """
    from pathlib import Path
    p = Path(path)
    if p.is_dir():
        # Prefer dev.json for evaluation because official test labels may be
        # unavailable in some Spider releases.  In this project test.json also
        # contains queries, but dev.json is the conventional validation split.
        cand = p / "dev.json"
        if not cand.exists():
            cand = p / "test.json"
        path = str(cand)
        p = Path(path)

    if not p.exists():
        raise FileNotFoundError(f"Spider dataset path not found: {path}")

    if p.suffix.lower() == ".jsonl":
        return _load_spider_jsonl(str(p), first_n=first_n, tag=tag)

    # Official Spider uses a JSON array with db_id/question/query fields.
    if p.suffix.lower() == ".json":
        return _load_spider_official_json(str(p), first_n=first_n, tag=tag, spider_root=spider_root)

    raise ValueError(f"Unsupported Spider dataset format: {path}")


# ══════════════════════════════════════════════════════════════════════
# Evaluation
# ══════════════════════════════════════════════════════════════════════

def _compare_answer(pred, gold):
    """Compare predicted answer with gold answer."""
    if pred is None and gold is None:
        return True
    if pred is None or gold is None:
        return False

    # Normalize types
    ps = str(pred).strip().lower()
    gs = str(gold).strip().lower()
    if ps == gs:
        return True

    # Numeric comparison
    try:
        pn = float(str(pred).replace(",", ""))
        gn = float(str(gold).replace(",", ""))
        if abs(gn) < 1e-12:
            return abs(pn - gn) < 1e-6
        return abs(pn - gn) / abs(gn) <= 1e-3
    except (ValueError, ZeroDivisionError):
        pass

    # List comparison — handle extra columns/rows gracefully
    if isinstance(pred, list) and isinstance(gold, list):
        if not pred or not gold:
            return pred == gold
        # If both are list-of-lists, trim to common column count
        if all(isinstance(x, list) for x in gold) and all(isinstance(x, list) for x in pred):
            min_cols = min(len(gold[0]) if gold else 0, len(pred[0]) if pred else 0)
            if min_cols > 0:
                gold_t = [row[:min_cols] for row in gold]
                pred_t = [row[:min_cols] for row in pred]
                if len(gold_t) != len(pred_t):
                    return False
                return all(_compare_answer(p, g) for p, g in zip(pred_t, gold_t))
        if len(pred) != len(gold):
            return False
        return all(_compare_answer(p, g) for p, g in zip(pred, gold))

    return False


def evaluate_spider(results):
    total = 0
    correct = 0
    rows = []
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("answer")
        gold = s.get("answers", s.get("answer"))
        if isinstance(gold, list) and len(gold) == 1:
            gold = gold[0]

        is_correct = _compare_answer(pred, gold)
        if is_correct:
            correct += 1

        rows.append({
            "id": s.get("id"),
            "question": s.get("question"),
            "gold": gold,
            "prediction": pred,
            "correct": is_correct,
            "program": s.get("program"),
            "gold_sql": s.get("gold_sql", ""),
        })

    n = max(total, 1)
    return {"total": total, "correct": correct,
            "execution_accuracy": round(correct / n, 4), "rows": rows}


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════

def main(
    dataset_path="data/spider_data/dev.json",
    spider_root=None,
    result_dir="results/spider",
    model_name="Qwen/Qwen2.5-Coder-14B-Instruct",
    openai_api_key=None,
    openai_api_base=None,
    llm_backend=None,
    first_n=-1,
    n_proc=1,
    use_pcfg_bf=True,
    use_candidate_framework=False,
    candidate_sources="all",
    max_sql_candidates=3,
    max_repair_rounds=1,
    pcfg_beam_width=8,
    pcfg_n_mcmc=40,
    pcfg_max_refinement=3,
    debug=False,
):
    os.makedirs(result_dir, exist_ok=True)
    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base

    dataset = load_spider_dataset(dataset_path, first_n, "spider", spider_root=spider_root)
    print(f"Loaded {len(dataset)} Spider samples", flush=True)

    if use_candidate_framework:
        from utils.relational_program_framework import solve_spider_dataset_with_framework
        from utils.llm import create_llm, configure_llm_usage_logger, write_llm_usage_summary, get_llm_usage_summary

        configure_llm_usage_logger(result_dir, enabled=True)
        llm = None
        llm_options = None
        if str(candidate_sources or "all").lower() != "schema_rule" and "llm" in str(candidate_sources or "all").lower() or str(candidate_sources or "all").lower() == "all":
            api_key = openai_api_key or os.environ.get("OPENAI_API_KEY") or os.environ.get("HF_TOKEN") or None
            llm = create_llm(model_name=model_name, key=api_key, backend=llm_backend)
            llm_options = llm.get_model_options(
                temperature=0.0, per_example_max_decode_steps=700,
                per_example_top_p=1.0, n_sample=1)
        result_samples = solve_spider_dataset_with_framework(
            dataset,
            llm=llm,
            llm_options=llm_options,
            candidate_sources=candidate_sources,
            max_sql_candidates=max_sql_candidates,
            max_repair_rounds=max_repair_rounds,
            debug=debug,
        )
        metrics = evaluate_spider(result_samples)
        metrics["candidate_framework_engine_used"] = True
        metrics["candidate_framework_engine_scope"] = "sample_candidate_pool"
        metrics["candidate_sources"] = candidate_sources
        metrics["max_sql_candidates"] = max_sql_candidates
        metrics["max_repair_rounds"] = max_repair_rounds
        metrics["llm_usage"] = get_llm_usage_summary()
        write_llm_usage_summary(result_dir)
        print(f"Spider Exec-Accuracy (CandidateProgramEngine): {metrics['execution_accuracy']:.4f} "
              f"({metrics['correct']}/{metrics['total']})")

    elif use_pcfg_bf:
        from utils.chain import pcfg_bf_chain_exec_one_sample
        from tqdm import tqdm

        # Use multi-table candidate generation for Spider (all multi-table DBs)
        import utils.beam_search as bs_mod
        orig_det = bs_mod.deterministic_candidates

        result_samples = []
        pipeline_reports = []

        for idx in tqdm(range(len(dataset)), total=len(dataset), desc="Spider PCFG-BF"):
            try:
                sample = dataset[idx]
                tables = sample.get("tables", {})

                if len(tables) >= 2:
                    # Use multi-table candidates for multi-table databases
                    from run_tqabench import multi_table_candidates
                    bs_mod.deterministic_candidates = (
                        lambda s, debug=False: multi_table_candidates(s, debug))
                else:
                    bs_mod.deterministic_candidates = orig_det

                result, report = pcfg_bf_chain_exec_one_sample(
                    sample, llm=None, llm_options=None,
                    beam_width=pcfg_beam_width, n_mcmc=pcfg_n_mcmc,
                    max_refinement_rounds=pcfg_max_refinement, debug=False,
                )

                bs_mod.deterministic_candidates = orig_det

                if result:
                    result["gold_sql"] = sample.get("gold_sql", "")
                    result["answers"] = sample.get("answers", [])

                result_samples.append(result)
                pipeline_reports.append(report)

            except Exception as e:
                print(f"[Spider] Error {idx}: {e}", flush=True)
                result_samples.append(None)
                pipeline_reports.append(None)

        metrics = evaluate_spider(result_samples)
        print(f"Spider Exec-Accuracy (PCFG-BF): {metrics['execution_accuracy']:.4f} "
              f"({metrics['correct']}/{metrics['total']})")

    else:
        from utils.llm import create_llm
        from utils.chain import dynamic_chain_exec_with_cache_mp, fixed_chain_exec_mp
        from operations.final_query import simple_query

        api_key = openai_api_key or os.environ.get("OPENAI_API_KEY", "vllm")
        gpt_llm = create_llm(model_name=model_name, key=api_key)

        proc_samples, _ = dynamic_chain_exec_with_cache_mp(
            dataset, llm=gpt_llm,
            llm_options=gpt_llm.get_model_options(
                temperature=0.0, per_example_max_decode_steps=200,
                per_example_top_p=1.0),
            strategy="top", cache_dir=os.path.join(result_dir, "cache"),
            n_proc=n_proc, chunk_size=1,
        )
        final_result, _ = fixed_chain_exec_mp(
            gpt_llm, proc_samples,
            [("simpleQuery", simple_query, dict(use_demo=True),
              dict(temperature=0, per_example_max_decode_steps=200,
                   per_example_top_p=1.0))],
        )
        metrics = evaluate_spider(final_result)
        print(f"Spider Exec-Accuracy (LLM): {metrics['execution_accuracy']:.4f}")

    # Save
    report = {k: v for k, v in metrics.items() if k != "rows"}
    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    with open(os.path.join(result_dir, "predictions.jsonl"), "w", encoding="utf-8") as f:
        for row in metrics["rows"]:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    # Full records keep candidate-framework diagnostics, ranked candidates,
    # posterior mass, and selected SQL for paper analysis.
    full_records = result_samples if (use_pcfg_bf or use_candidate_framework) else final_result
    with open(os.path.join(result_dir, "results.jsonl"), "w", encoding="utf-8") as f:
        for row in full_records:
            f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    pickle.dump(full_records, open(os.path.join(result_dir, "results.pkl"), "wb"))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Spider Text-to-SQL experiment")
    parser.add_argument("--dataset_path", default="data/spider_data/dev.json")
    parser.add_argument("--spider_root", default=None, help="Root folder containing Spider database/, tables.json, dev.json")
    parser.add_argument("--result_dir", default="results/spider")
    parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct")
    parser.add_argument("--openai_api_key", default=None)
    parser.add_argument("--openai_api_base", default=None)
    parser.add_argument("--llm_backend", default=None, help="local_hf, hf_api, openai/OpenAI-compatible")
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--n_proc", type=int, default=1)
    parser.add_argument("--use_pcfg_bf", action="store_true", default=True)
    parser.add_argument("--no_pcfg_bf", dest="use_pcfg_bf", action="store_false")
    parser.add_argument("--use_candidate_framework", action="store_true", help="Route Spider through CandidateProgramEngine as SQL candidate programs")
    parser.add_argument("--candidate_sources", default="all", choices=["all", "llm", "schema_rule", "llm,schema_rule", "schema_rule,llm"], help="Candidate sources for framework mode")
    parser.add_argument("--max_sql_candidates", type=int, default=3)
    parser.add_argument("--max_repair_rounds", type=int, default=1)
    parser.add_argument("--pcfg_beam_width", type=int, default=8)
    parser.add_argument("--pcfg_n_mcmc", type=int, default=40)
    parser.add_argument("--pcfg_max_refinement", type=int, default=3)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    main(**vars(args))
