#!/usr/bin/env python
from __future__ import annotations
# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""Run TQA-Bench directly from data/symDataset (v41 adaptive value hints).

This runner is additive.  It does not use data/tqa_bench/test.jsonl and does not
modify the original Agent90 / WikiTQ / TabFact code.  It builds evaluation cases
from:
  - data/tableQA/task.json
  - data/symDataset/<scale>/<domain>/<id>.sqlite

Gold answers are computed by executing the official Python code in task.json on
the selected SQLite database, but v39 does not pass official code, choices, rightIdx, or gold values into the LLM prompt, repair modules, result selector, or normalization. It adds leakage-safe conservative primary-vote selection, optional value hints, optional result selection, and execution-feedback SQL repair.
"""

import json
import os
from typing import Optional

from utils.llm import create_llm, configure_llm_usage_logger, get_llm_usage_summary, write_llm_usage_summary
from utils.symbolic_dataset_agent import (
    build_symdataset_samples,
    solve_dataset,
    write_json,
    write_jsonl,
    write_report_csv,
)
from utils.symbolic_dataset_safe_repairs import leakage_audit_metadata


def _candidate_sources_need_llm(candidate_sources: str, enable_result_selector: bool) -> bool:
    raw = str(candidate_sources or "all").lower().strip()
    if raw in {"", "all", "default"}:
        return True
    toks = {t.strip() for t in raw.replace(";", ",").replace("+", ",").split(",") if t.strip()}
    return enable_result_selector or any(t in {"llm", "model", "model_sql", "llm_sql"} for t in toks)


def main(
    task_path: str = "data/tableQA/task.json",
    symdataset_dir: str = "data/symDataset",
    scales: str = "16k",
    domains: str = "all",
    db_ids: str = "0",
    first_n: int = -1,
    model_name: str = "deepseek-v4-pro",
    openai_api_key: Optional[str] = None,
    openai_api_base: Optional[str] = None,
    llm_backend: Optional[str] = None,
    votes: int = 1,
    parallel_votes: int = 1,
    max_schema_chars: int = 14000,
    max_sql_candidates: int = 2,
    enable_result_selector: bool = False,
    repair_rounds: int = 0,
    enable_value_hints: bool = False,
    value_hint_mode: str = "off",
    selection_policy: str = "primary_majority",
    candidate_sources: str = "all",
    disable_safe_repairs: bool = False,
    posterior_selection: str = "answer_marginal",
    bf_threshold: float = 3.0,
    schema_graph_ablation: str = "none",
    save_full_candidate_trace: bool = False,
    enable_usage_logging: bool = True,
    result_dir: str = "results/tqabench_symdataset_v42",
    no_resume: bool = False,
    skip_gold_errors: bool = True,
    debug: bool = False,
):
    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base
    # This branch usually sends one request per vote.  Do not locally throttle
    # unless the user explicitly sets these env vars.
    os.environ.setdefault("OPENAI_TPM_LIMIT", "0")
    os.environ.setdefault("OPENAI_MIN_INTERVAL_SECONDS", "0")
    os.environ.setdefault("DEEPSEEK_PARALLEL_VOTES", str(max(1, int(parallel_votes or 1))))
    os.makedirs(result_dir, exist_ok=True)
    configure_llm_usage_logger(result_dir, enabled=enable_usage_logging)

    print("=" * 64)
    print("  TQA-Bench SymDataset SQL Instance v52 pooled CandidateProgramEngine guarded multitable candidate-bayes repair")
    print("=" * 64)
    print(f"  task_path     : {task_path}")
    print(f"  symDataset    : {symdataset_dir}")
    print(f"  scales        : {scales}")
    print(f"  domains       : {domains}")
    print(f"  db_ids        : {db_ids}")
    print(f"  first_n       : {first_n}")
    print(f"  model         : {model_name}")
    print(f"  result        : {result_dir}")
    print(f"  votes         : {votes}, parallel_votes={parallel_votes}")
    resolved_hint_mode = "always" if enable_value_hints and value_hint_mode == "off" else value_hint_mode
    print(f"  candidates    : max_sql_candidates={max_sql_candidates}, selector={enable_result_selector}, repair_rounds={repair_rounds}, value_hint_mode={resolved_hint_mode}, selection_policy={selection_policy}")
    print(f"  ablations     : candidate_sources={candidate_sources}, disable_safe_repairs={disable_safe_repairs}, posterior_selection={posterior_selection}, bf_threshold={bf_threshold}, schema_graph_ablation={schema_graph_ablation}")
    print(f"  usage logging : {enable_usage_logging}")
    print("=" * 64)
    print()

    samples, build_stats = build_symdataset_samples(
        task_path=task_path,
        symdataset_dir=symdataset_dir,
        scales=scales,
        domains=domains,
        db_ids=db_ids,
        first_n=first_n,
        skip_gold_errors=skip_gold_errors,
        cache_gold=True,
        result_dir=result_dir,
    )
    with open(os.path.join(result_dir, "build_stats.json"), "w", encoding="utf-8") as f:
        json.dump(build_stats, f, ensure_ascii=False, indent=2, default=str)
    audit = leakage_audit_metadata()
    audit.update({"result_dir": result_dir, "task_path": task_path, "symdataset_dir": symdataset_dir})
    with open(os.path.join(result_dir, "leakage_audit.json"), "w", encoding="utf-8") as f:
        json.dump(audit, f, ensure_ascii=False, indent=2, default=str)
    write_jsonl(os.path.join(result_dir, "built_samples.jsonl"), samples)
    print(f"Built {len(samples)} usable samples; gold_errors={build_stats.get('gold_errors')}, missing_db={build_stats.get('missing_db')}\n")
    if not samples:
        print("No usable samples. Check task_path, symdataset_dir, scales/domains/db_ids, and build_stats.json.")
        return

    api_key = openai_api_key or os.environ.get("OPENAI_API_KEY") or os.environ.get("HF_TOKEN") or None
    if _candidate_sources_need_llm(candidate_sources, enable_result_selector):
        llm = create_llm(model_name=model_name, key=api_key, backend=llm_backend)
    else:
        llm = None
        print("[LLM] skipped: candidate_sources do not include llm and selector is disabled", flush=True)

    results, reports, metrics = solve_dataset(
        samples,
        llm,
        result_dir=result_dir,
        votes=votes,
        parallel_votes=parallel_votes,
        max_schema_chars=max_schema_chars,
        max_sql_candidates=max_sql_candidates,
        enable_result_selector=enable_result_selector,
        repair_rounds=repair_rounds,
        enable_value_hints=enable_value_hints,
        value_hint_mode=resolved_hint_mode,
        selection_policy=selection_policy,
        candidate_sources=candidate_sources,
        disable_safe_repairs=disable_safe_repairs,
        posterior_selection=posterior_selection,
        bf_threshold=bf_threshold,
        schema_graph_ablation=schema_graph_ablation,
        save_full_candidate_trace=save_full_candidate_trace,
        resume=not no_resume,
        debug=debug,
    )

    write_jsonl(os.path.join(result_dir, "results.jsonl"), results)
    write_jsonl(os.path.join(result_dir, "reports.jsonl"), reports)
    write_report_csv(os.path.join(result_dir, "report.csv"), reports)
    usage_summary = get_llm_usage_summary()
    metrics["llm_usage"] = usage_summary
    # Duplicate critical ablation/reproducibility settings at the top level so
    # generic collectors do not have to know this runner's internal schema.
    metrics.update({
        "candidate_sources": candidate_sources,
        "posterior_selection": posterior_selection,
        "selection_policy": selection_policy,
        "disable_safe_repairs": bool(disable_safe_repairs),
        "value_hint_mode": resolved_hint_mode,
        "schema_graph_ablation": schema_graph_ablation,
        "save_full_candidate_trace": bool(save_full_candidate_trace),
        "votes": votes,
        "parallel_votes": parallel_votes,
        "max_schema_chars": max_schema_chars,
        "max_sql_candidates": max_sql_candidates,
        "repair_rounds": repair_rounds,
        "bf_threshold": bf_threshold,
        "model_name": model_name,
        "temperature_settings": {"TQA_VOTE_TEMPERATURE": os.environ.get("TQA_VOTE_TEMPERATURE", "")},
    })
    metrics.setdefault("experiment_config", {}).update({
        "task_path": task_path,
        "symdataset_dir": symdataset_dir,
        "scales": scales,
        "domains": domains,
        "db_ids": db_ids,
        "first_n": first_n,
        "model_name": model_name,
        "openai_api_base": openai_api_base or os.environ.get("OPENAI_API_BASE", ""),
        "TQA_VOTE_TEMPERATURE": os.environ.get("TQA_VOTE_TEMPERATURE", ""),
    })
    write_llm_usage_summary(result_dir)
    write_json(os.path.join(result_dir, "metrics.json"), metrics)

    print("\n" + "=" * 64)
    print(f"  Result: Accuracy: {metrics.get('accuracy', 0):.4f}")
    print(f"  ({metrics.get('correct', 0)}/{metrics.get('total', 0)}), invalid={metrics.get('invalid', 0)}")
    print(f"  Valid Accuracy: {metrics.get('valid_accuracy', 0):.4f}")
    print("=" * 64)
    print(f"Results saved to {result_dir}/metrics.json")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="TQA-Bench direct SymDataset SQL runner v41 with leakage-safe adaptive value hints")
    parser.add_argument("--task_path", default="data/tableQA/task.json")
    parser.add_argument("--symdataset_dir", default="data/symDataset")
    parser.add_argument("--scales", default="16k", help="Comma list such as 16k,32k or all")
    parser.add_argument("--domains", default="all", help="Comma list such as airline,cookbook or all")
    parser.add_argument("--db_ids", default="0", help="Comma list such as 0,1,2 or all")
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--model_name", default="deepseek-v4-pro")
    parser.add_argument("--openai_api_key", default=None)
    parser.add_argument("--openai_api_base", default=None)
    parser.add_argument("--llm_backend", default=None)
    parser.add_argument("--votes", type=int, default=1)
    parser.add_argument("--parallel_votes", type=int, default=1)
    parser.add_argument("--max_schema_chars", type=int, default=14000)
    parser.add_argument("--max_sql_candidates", type=int, default=2)
    parser.add_argument("--enable_result_selector", action="store_true", help="Use a leakage-safe LLM selector over executed SQL candidates.")
    parser.add_argument("--repair_rounds", type=int, default=0, help="LLM SQL repair rounds for failed/NULL candidates only.")
    parser.add_argument("--enable_value_hints", action="store_true", help="Expose sampled database values to the SQL generator. Off by default for v35-compatible stability.")
    parser.add_argument("--value_hint_mode", choices=["off", "always", "adaptive"], default="off", help="Value-hint policy. adaptive retries only after leakage-safe execution diagnostics. The legacy --enable_value_hints flag maps to always.")
    parser.add_argument("--selection_policy", choices=["primary_majority", "selector", "candidate_majority", "multitable_bayes", "hybrid_multitable_bayes"], default="primary_majority", help="Final selection policy. Use multitable_bayes to enable schema-graph/rule candidates, Bayesian-style candidate ranking, answer posterior aggregation, and optional guarded low-confidence LLM referee. Use hybrid_multitable_bayes to keep the same diagnostics while applying a conservative primary-majority guard.")
    parser.add_argument("--candidate_sources", default="all", help="Candidate source ablation: all, llm, schema_rule, llm,schema_rule, or none. Repairs are controlled by --disable_safe_repairs.")
    parser.add_argument("--disable_schema_graph_candidates", action="store_true", help="Convenience flag equivalent to removing schema_rule from --candidate_sources.")
    parser.add_argument("--disable_llm_candidates", action="store_true", help="Convenience flag equivalent to removing llm from --candidate_sources. Useful for pure symbolic runs with multitable_bayes.")
    parser.add_argument("--disable_safe_repairs", action="store_true", help="Disable leakage-safe execution-feedback SQL repairs for repair ablation.")
    parser.add_argument("--posterior_selection", choices=["answer_marginal", "program_map"], default="answer_marginal", help="Use answer-level posterior marginalization or single program MAP for Bayes selection ablation.")
    parser.add_argument("--bf_threshold", type=float, default=3.0, help="Bayes-factor threshold for low-confidence gating and sensitivity analysis.")
    parser.add_argument("--schema_graph_ablation", choices=["none", "no_edges", "no_foreign_keys", "no_fk", "no_inferred_edges", "no_inferred", "no_column_links", "no_column_linking", "no_table_links", "no_table_linking"], default="none", help="Schema-graph attribution ablation.")
    parser.add_argument("--save_full_candidate_trace", action="store_true", help="Store the full executed candidate trace in results.jsonl for offline analysis.")
    parser.add_argument("--disable_usage_logging", action="store_true", help="Disable llm_usage.jsonl and llm_usage_summary.json logging.")
    parser.add_argument("--result_dir", default="results/tqabench_symdataset_v42")
    parser.add_argument("--no_resume", action="store_true")
    parser.add_argument("--no_skip_gold_errors", action="store_true")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    # Convenience source-ablation flags.  They edit --candidate_sources without
    # changing the default behavior when the flags are absent.
    src = str(args.candidate_sources or "all").lower().strip()
    src_set = {"llm", "schema_rule"} if src in {"", "all", "default"} else {x for x in src.replace(";", ",").replace("+", ",").split(",") if x}
    if args.disable_schema_graph_candidates:
        src_set.discard("schema_rule"); src_set.discard("schema"); src_set.discard("rule")
    if args.disable_llm_candidates:
        src_set.discard("llm"); src_set.discard("model"); src_set.discard("llm_sql")
    args.candidate_sources = "none" if not src_set else ",".join(sorted(src_set))
    main(
        task_path=args.task_path,
        symdataset_dir=args.symdataset_dir,
        scales=args.scales,
        domains=args.domains,
        db_ids=args.db_ids,
        first_n=args.first_n,
        model_name=args.model_name,
        openai_api_key=args.openai_api_key,
        openai_api_base=args.openai_api_base,
        llm_backend=args.llm_backend,
        votes=args.votes,
        parallel_votes=args.parallel_votes,
        max_schema_chars=args.max_schema_chars,
        max_sql_candidates=args.max_sql_candidates,
        enable_result_selector=args.enable_result_selector,
        repair_rounds=args.repair_rounds,
        enable_value_hints=args.enable_value_hints,
        value_hint_mode=args.value_hint_mode,
        selection_policy=args.selection_policy,
        candidate_sources=args.candidate_sources,
        disable_safe_repairs=args.disable_safe_repairs,
        posterior_selection=args.posterior_selection,
        bf_threshold=args.bf_threshold,
        schema_graph_ablation=args.schema_graph_ablation,
        save_full_candidate_trace=args.save_full_candidate_trace,
        enable_usage_logging=not args.disable_usage_logging,
        result_dir=args.result_dir,
        no_resume=args.no_resume,
        skip_gold_errors=not args.no_skip_gold_errors,
        debug=args.debug,
    )
