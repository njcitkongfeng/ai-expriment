#!/usr/bin/env python
from __future__ import annotations
# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""Additive TQA-Bench SQL-execution runner.

This runner does not replace run_reasoning_pipeline.py or Agent90.  It adds a dedicated
TQA-Bench branch that uses full SQLite execution instead of truncated table text.
"""

import json
import os
import sys
from typing import Any, Dict, List

from run_tqabench import load_tqabench_dataset
from utils.llm import create_llm
from utils.sql_reasoning_agent import solve_dataset_sql


def main(
    dataset_path: str = "data/tqa_bench/test.jsonl",
    first_n: int = -1,
    model_name: str = "deepseek-v4-pro",
    openai_api_key: str = None,
    openai_api_base: str = None,
    llm_backend: str = None,
    votes: int = 3,
    parallel_votes: int = 1,
    max_schema_chars: int = 14000,
    max_sql_candidates: int = 3,
    result_dir: str = "results/tqabench_sql_v30",
    resume: bool = True,
    debug: bool = False,
):
    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base
    # SQL branch calls DeepSeek one request per vote; no local throttling by default.
    os.environ.setdefault("OPENAI_TPM_LIMIT", "0")
    os.environ.setdefault("OPENAI_MIN_INTERVAL_SECONDS", "0")
    os.makedirs(result_dir, exist_ok=True)

    print("=" * 60)
    print("  TQA-Bench SQL-Execution Agent v30")
    print("=" * 60)
    print(f"  Dataset: {dataset_path}")
    print(f"  First N: {first_n}")
    print(f"  Model:   {model_name}")
    print(f"  Result:  {result_dir}")
    print(f"  Votes:   {votes}, parallel_votes={parallel_votes}")
    print("=" * 60)
    print()

    samples = load_tqabench_dataset(dataset_path, first_n=first_n, tag="tqa_sql")
    print(f"Loaded {len(samples)} samples\n")

    api_key = openai_api_key or os.environ.get("OPENAI_API_KEY") or os.environ.get("HF_TOKEN") or None
    llm = create_llm(model_name=model_name, key=api_key, backend=llm_backend)

    results, reports, metrics = solve_dataset_sql(
        samples, llm, result_dir=result_dir, votes=votes, parallel_votes=parallel_votes,
        max_schema_chars=max_schema_chars, max_sql_candidates=max_sql_candidates,
        resume=resume, debug=debug,
    )

    with open(os.path.join(result_dir, "results.jsonl"), "w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
    with open(os.path.join(result_dir, "reports.jsonl"), "w", encoding="utf-8") as f:
        for r in reports:
            f.write(json.dumps(r, ensure_ascii=False, default=str) + "\n")
    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 60)
    print(f"  Result: Accuracy: {metrics.get('accuracy', 0):.4f}")
    print(f"  ({metrics.get('correct', 0)}/{metrics.get('total', 0)}), invalid={metrics.get('invalid', 0)}")
    print("=" * 60)
    print(f"Results saved to {result_dir}/metrics.json")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="TQA-Bench SQL-execution Agent v30")
    parser.add_argument("--dataset_path", default="data/tqa_bench/test.jsonl")
    parser.add_argument("--first_n", type=int, default=-1)
    parser.add_argument("--model_name", default="deepseek-v4-pro")
    parser.add_argument("--openai_api_key", default=None)
    parser.add_argument("--openai_api_base", default=None)
    parser.add_argument("--llm_backend", default=None)
    parser.add_argument("--votes", type=int, default=3)
    parser.add_argument("--parallel_votes", type=int, default=1)
    parser.add_argument("--max_schema_chars", type=int, default=14000)
    parser.add_argument("--max_sql_candidates", type=int, default=3)
    parser.add_argument("--result_dir", default="results/tqabench_sql_v30")
    parser.add_argument("--no_resume", action="store_true")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    main(
        dataset_path=args.dataset_path,
        first_n=args.first_n,
        model_name=args.model_name,
        openai_api_key=args.openai_api_key,
        openai_api_base=args.openai_api_base,
        llm_backend=args.llm_backend,
        votes=args.votes,
        parallel_votes=args.parallel_votes,
        max_schema_chars=args.max_schema_chars,
        max_sql_candidates=args.max_sql_candidates,
        result_dir=args.result_dir,
        resume=not args.no_resume,
        debug=args.debug,
    )
