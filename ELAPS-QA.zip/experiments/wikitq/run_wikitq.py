# Path guard: allow running this file directly from its experiment folder.
from pathlib import Path as _Path
import sys as _sys
_PROJECT_ROOT = _Path(__file__).resolve().parents[2]
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))

"""
WikiTableQuestions experiment runner.

WikiTQ is a table QA task: given a table and a natural-language question,
extract the answer from table cells.  The evaluation metric is *denotation
accuracy* — the predicted answer set must match the gold answer set exactly.

This runner supports two backends:
  1. --use_pcfg_bf  (symbolic PCFG + Bayes Factor, no LLM required)
  2. default        (original Chain-of-Table LLM pipeline)

Input format (JSONL, one sample per line):
  {
    "id": "nt-0",
    "table_text": [["header1","header2"], ["val1","val2"], ...],
    "question": "Which team had the most wins?",
    "answers": ["answer1", "answer2"],
    "table_caption": "optional"
  }

Example usage:
  # Symbolic mode (fast, free)
  python run_table_qa.py --dataset_path data/wikitq/test.jsonl --first_n 20 --use_pcfg_bf

  # LLM mode (paper-equivalent)
  python run_table_qa.py --dataset_path data/wikitq/test.jsonl --first_n 20
"""

import json
import os
import pickle
import sys
from typing import Any, Dict, List, Optional

from utils.load_data import load_wikitablequestions_dataset


def denotation_match(pred: Any, gold_list: List[str]) -> bool:
    """Check if predicted answer matches the WikiTQ denotation.

    The previous implementation treated list answers as Python strings, which
    penalized CandidateProgramEngine outputs that return a set/list of cells.
    This version compares scalar and list denotations after normalization.
    """
    if pred is None:
        return False

    def _norm_ans(x: Any) -> str:
        return " ".join(str(x).strip().lower().split())

    def _scalar_match(a: Any, b: Any) -> bool:
        a_str = _norm_ans(a); b_str = _norm_ans(b)
        if a_str == b_str:
            return True
        try:
            an = float(a_str.replace(",", "").replace("%", ""))
            bn = float(b_str.replace(",", "").replace("%", ""))
            if abs(an - bn) / max(abs(bn), 1e-9) < 1e-3:
                return True
        except (ValueError, ZeroDivisionError):
            pass
        if len(b_str) > 5 and b_str in a_str:
            return True
        if len(a_str) > 5 and a_str in b_str:
            return True
        return False

    if isinstance(gold_list, str):
        gold_list = [gold_list]
    if not isinstance(gold_list, list):
        gold_list = [str(gold_list)]

    if isinstance(pred, (list, tuple, set)):
        pred_vals = list(pred)
        if len(pred_vals) == 1:
            return any(_scalar_match(pred_vals[0], g) for g in gold_list)
        pred_norm = sorted(_norm_ans(x) for x in pred_vals)
        gold_norm = sorted(_norm_ans(x) for x in gold_list)
        if pred_norm == gold_norm:
            return True
        # Some WikiTQ gold files store multi-cell answers as a single pipe/comma string.
        joined_variants = {"|".join(pred_norm), ", ".join(pred_norm), ",".join(pred_norm)}
        return any(_norm_ans(g) in joined_variants for g in gold_list)

    return any(_scalar_match(pred, gold) for gold in gold_list)


def evaluate_wikitq(results: List[Optional[Dict[str, Any]]]) -> Dict[str, Any]:
    """Compute denotation accuracy over WikiTQ results."""
    total = 0
    correct = 0
    rows = []
    for s in results:
        if s is None:
            continue
        total += 1
        pred = s.get("answer")
        gold = s.get("answers", s.get("answer", []))

        if isinstance(gold, str):
            gold = [gold]
        if not isinstance(gold, list):
            gold = [str(gold)]

        is_correct = denotation_match(pred, gold)
        if is_correct:
            correct += 1

        rows.append({
            "id": s.get("id"),
            "question": s.get("question", s.get("statement")),
            "gold": gold,
            "prediction": pred,
            "correct": is_correct,
            "program": s.get("program"),
            "bayes_factor": s.get("bayes_factor"),
        })

    return {
        "total": total,
        "correct": correct,
        "denotation_accuracy": correct / max(total, 1),
        "rows": rows,
    }


def main(
    dataset_path: str = "data/wikitq/test.jsonl",
    result_dir: str = "results/wikitq",
    model_name: str = "Qwen/Qwen2.5-Coder-14B-Instruct",
    openai_api_key: str = None,
    openai_api_base: str = None,
    first_n: int = -1,
    n_proc: int = 1,
    chunk_size: int = 1,
    use_pcfg_bf: bool = False,
    pcfg_beam_width: int = 8,
    pcfg_n_mcmc: int = 40,
    pcfg_max_refinement: int = 3,
    use_candidate_framework: bool = False,
    framework_max_candidates: int = 18,
    candidate_sources: str = "all",
    max_repair_rounds: int = 1,
    agent90_votes: int = 3,
    posterior_selection: str = "answer_marginal",
    disable_safe_repairs: bool = False,
    disable_semantic_votes: bool = False,
    disable_bucket_verifier: bool = False,
    disable_structural_prior: bool = False,
):
    os.makedirs(result_dir, exist_ok=True)

    # ── vLLM / custom endpoint ────────────────────────────────────
    if openai_api_base:
        os.environ["OPENAI_API_BASE"] = openai_api_base

    # ── Load dataset ─────────────────────────────────────────────
    dataset = load_wikitablequestions_dataset(
        dataset_path, first_n=first_n, tag="wikitq"
    )
    print(f"Loaded {len(dataset)} WikiTQ samples", flush=True)

    if use_candidate_framework:
        # ── Active universal CandidateProgramEngine path ───────────
        # CandidateProgram = table operation chain.
        # This path demonstrates that WikiTQ is integrated through the
        # same framework as SQL/pandas/TabFact instead of bypassing it.
        from utils.table_program_framework import solve_wikitq_dataset_with_framework
        from utils.llm import configure_llm_usage_logger, write_llm_usage_summary

        configure_llm_usage_logger(result_dir, enabled=True)
        final_result = solve_wikitq_dataset_with_framework(
            dataset,
            max_candidates=framework_max_candidates,
            candidate_sources=candidate_sources,
            model_name=model_name,
            openai_api_key=openai_api_key,
            openai_api_base=openai_api_base,
            max_repair_rounds=max_repair_rounds,
            agent90_votes=agent90_votes,
            posterior_selection=posterior_selection,
            disable_safe_repairs=disable_safe_repairs,
            disable_semantic_votes=disable_semantic_votes,
            disable_bucket_verifier=disable_bucket_verifier,
            disable_structural_prior=disable_structural_prior,
        )
        write_llm_usage_summary(result_dir)
        metrics = evaluate_wikitq(final_result)
        metrics["candidate_framework_engine_used"] = True
        metrics["framework_task_type"] = "wikitq_candidate_ours"
        metrics["framework_max_candidates"] = framework_max_candidates
        metrics["candidate_sources"] = candidate_sources
        metrics["max_repair_rounds"] = max_repair_rounds
        metrics["agent90_votes"] = agent90_votes
        metrics["posterior_selection"] = posterior_selection
        metrics["disable_safe_repairs"] = bool(disable_safe_repairs)
        metrics["disable_semantic_votes"] = bool(disable_semantic_votes)
        metrics["disable_bucket_verifier"] = bool(disable_bucket_verifier)
        metrics["disable_structural_prior"] = bool(disable_structural_prior)
        metrics["temperature_settings"] = {
            "WIKITQ_VOTE_TEMPERATURE": os.environ.get("WIKITQ_VOTE_TEMPERATURE", ""),
        }
        metrics["experiment_config"] = {
            "dataset_path": dataset_path,
            "model_name": model_name,
            "first_n": first_n,
            "framework_max_candidates": framework_max_candidates,
            "candidate_sources": candidate_sources,
            "max_repair_rounds": max_repair_rounds,
            "agent90_votes": agent90_votes,
            "posterior_selection": posterior_selection,
            "disable_safe_repairs": bool(disable_safe_repairs),
            "disable_semantic_votes": bool(disable_semantic_votes),
            "disable_bucket_verifier": bool(disable_bucket_verifier),
            "disable_structural_prior": bool(disable_structural_prior),
            "WIKITQ_VOTE_TEMPERATURE": os.environ.get("WIKITQ_VOTE_TEMPERATURE", ""),
            "openai_api_base": openai_api_base or os.environ.get("OPENAI_API_BASE", ""),
        }
        metrics["framework_task_type"] = "wikitq_agent_candidate_posterior"
        # Diagnostics for posterior selection, computed after prediction using gold only for evaluation.
        oracle = 0; ranking_error = 0; valid_counts = []
        for sample in final_result:
            cf = sample.get("candidate_framework", {}) or {}
            ranked = cf.get("ranked_candidates", []) or []
            valid = [c for c in ranked if ((c.get("execution") or {}).get("ok") and (c.get("execution") or {}).get("answer") is not None)]
            valid_counts.append(len(valid))
            gold = sample.get("answers", [])
            if isinstance(gold, str): gold = [gold]
            has_gold = False
            for c in valid:
                if denotation_match((c.get("execution") or {}).get("answer"), gold):
                    has_gold = True; break
            if has_gold:
                oracle += 1
                if not denotation_match(sample.get("answer"), gold):
                    ranking_error += 1
        total = max(len(final_result), 1)
        metrics["topk_oracle_coverage"] = oracle / total
        metrics["generation_miss_rate"] = 1.0 - metrics["topk_oracle_coverage"]
        metrics["ranking_error_rate"] = ranking_error / total
        metrics["avg_valid_candidate_count"] = sum(valid_counts) / max(len(valid_counts), 1)
        print(f"Denotation Accuracy (CandidateProgramEngine Ours): {metrics['denotation_accuracy']:.4f}")

    elif use_pcfg_bf:
        # ── PCFG + Bayes Factor pipeline ─────────────────────────
        from utils.chain import pcfg_bf_chain_exec_dataset
        from utils.evaluate import tabfact_match_from_pcfg_result

        print(f"[PCFG-BF] beam_width={pcfg_beam_width}, "
              f"n_mcmc={pcfg_n_mcmc}", flush=True)

        result_samples, pipeline_reports = pcfg_bf_chain_exec_dataset(
            dataset,
            llm=None,
            llm_options=None,
            beam_width=pcfg_beam_width,
            n_mcmc=pcfg_n_mcmc,
            max_refinement_rounds=pcfg_max_refinement,
            debug=False,
            cache_dir=os.path.join(result_dir, "pcfg_bf_cache"),
        )

        metrics = evaluate_wikitq(result_samples)
        print(f"Denotation Accuracy (PCFG-BF): {metrics['denotation_accuracy']:.4f}")

    else:
        # ── Original Chain-of-Table LLM pipeline ─────────────────
        from utils.llm import create_llm
        from utils.chain import dynamic_chain_exec_with_cache_mp, fixed_chain_exec_mp
        from operations.final_query import simple_query

        api_key = openai_api_key or os.environ.get("OPENAI_API_KEY", "vllm")
        gpt_llm = create_llm(model_name=model_name, key=api_key)

        proc_samples, dynamic_chain_log_list = dynamic_chain_exec_with_cache_mp(
            dataset,
            llm=gpt_llm,
            llm_options=gpt_llm.get_model_options(
                temperature=0.0,
                per_example_max_decode_steps=200,
                per_example_top_p=1.0,
            ),
            strategy="top",
            cache_dir=os.path.join(result_dir, "cache"),
            n_proc=n_proc,
            chunk_size=chunk_size,
        )

        fixed_chain = [
            (
                "simpleQuery",
                simple_query,
                dict(use_demo=True),
                dict(
                    temperature=0,
                    per_example_max_decode_steps=200,
                    per_example_top_p=1.0,
                ),
            ),
        ]
        final_result, _ = fixed_chain_exec_mp(
            gpt_llm,
            proc_samples,
            fixed_chain,
            n_proc=n_proc,
            chunk_size=chunk_size,
        )

        metrics = evaluate_wikitq(final_result)
        print(f"Denotation Accuracy (LLM): {metrics['denotation_accuracy']:.4f}")

    # ── Save results ─────────────────────────────────────────────
    report = {k: v for k, v in metrics.items() if k != "rows"}
    with open(os.path.join(result_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    with open(os.path.join(result_dir, "predictions.jsonl"), "w", encoding="utf-8") as f:
        for row in metrics["rows"]:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    with open(os.path.join(result_dir, "results.pkl"), "wb") as f:
        pickle.dump(final_result if (not use_pcfg_bf or use_candidate_framework) else result_samples, f)


if __name__ == "__main__":
    try:
        import fire
        fire.Fire(main)
    except ModuleNotFoundError:
        import argparse
        parser = argparse.ArgumentParser(
            description="Chain-of-Table WikiTableQuestions experiment runner"
        )
        parser.add_argument("--dataset_path", default="data/wikitq/test.jsonl")
        parser.add_argument("--result_dir", default="results/wikitq")
        parser.add_argument("--model_name", default="Qwen/Qwen2.5-Coder-14B-Instruct")
        parser.add_argument("--openai_api_key", default=None)
        parser.add_argument("--openai_api_base", default=None)
        parser.add_argument("--first_n", type=int, default=-1)
        parser.add_argument("--n_proc", type=int, default=1)
        parser.add_argument("--chunk_size", type=int, default=1)
        parser.add_argument("--use_pcfg_bf", action="store_true")
        parser.add_argument("--pcfg_beam_width", type=int, default=8)
        parser.add_argument("--pcfg_n_mcmc", type=int, default=40)
        parser.add_argument("--pcfg_max_refinement", type=int, default=3)
        parser.add_argument("--use_candidate_framework", action="store_true",
                            help="Route WikiTQ samples through CandidateProgramEngine as single-table CandidateProgram Ours")
        parser.add_argument("--framework_max_candidates", type=int, default=18)
        parser.add_argument("--candidate_sources", default="all", choices=["all", "schema_rule", "llm", "llm_only"],
                            help="Candidate sources for single-table Ours")
        parser.add_argument("--max_repair_rounds", type=int, default=1)
        parser.add_argument("--agent90_votes", type=int, default=3,
                            help="Number of semantic answer votes for WikiTQ candidate_ours posterior")
        parser.add_argument("--posterior_selection", default="answer_marginal", choices=["answer_marginal", "program_map"],
                            help="answer_marginal = answer-bucket posterior; program_map = single executable program MAP ablation")
        parser.add_argument("--disable_safe_repairs", action="store_true",
                            help="Disable execution-feedback local repairers in the CandidateProgramEngine")
        parser.add_argument("--disable_semantic_votes", action="store_true",
                            help="Disable LLM semantic answer votes, leaving executable candidates only")
        parser.add_argument("--disable_bucket_verifier", action="store_true",
                            help="Disable the risk-aware answer-bucket verifier/reranker")
        parser.add_argument("--disable_structural_prior", action="store_true",
                            help="Disable schema-rule structural candidates; use LLM-only candidate generation")
        args = parser.parse_args()
        main(**vars(args))
