# ELAPS-QA

ELAPS-QA is an execution-guided candidate reasoning framework for structured
table question answering, fact verification, and relational SQL reasoning.  The
core idea is to avoid relying on a single generated program.  Instead, the
system builds a candidate pool from multiple sources, executes and verifies the
candidates, applies guarded local repair when needed, and selects the final
answer with posterior aggregation.

## Framework Overview

The framework treats different table reasoning tasks as executable candidate
programs:

- single-table QA: table-operation candidates
- fact verification: evidence-chain candidates
- relational and multi-table QA: SQL candidates
- symbolic long-context table QA: SQL candidates with schema/value guidance

The common workflow is:

```text
Input question/table/schema
  -> multi-source candidate generation
  -> execution and normalization
  -> structural and task-aware verification
  -> guarded local repair
  -> program-level scoring
  -> answer-level posterior aggregation
  -> final prediction
```

## Project Layout

```text
.
|-- adapters/                  # task adapters for executable programs
|-- candidate_framework/        # shared candidate-program engine
|-- data/                       # local datasets
|-- experiments/                # dataset runners and baselines
|-- paper_experiments/          # paper-oriented experiment suites
|-- results/                    # generated experiment outputs
|-- runners/                    # small runnable demos
|-- scripts/                    # controlled baselines, ablations, analysis
|-- utils/                      # implementation modules
|-- run_table_qa.py             # single-table QA launcher
|-- run_fact_verification.py    # fact-verification launcher
|-- run_relational_candidate_agent.py
|-- run_symbolic_dataset_agent.py
`-- run_reasoning_pipeline.py
```

Important implementation modules in `utils/`:

- `table_program_framework.py`: single-table executable reasoning
- `fact_program_framework.py`: fact-verification framework wrapper
- `relational_candidate_agent.py`: relational SQL candidate agent
- `relational_program_framework.py`: relational program framework
- `symbolic_dataset_agent.py`: symbolic long-context SQL agent
- `symbolic_dataset_safe_repairs.py`: guarded SQL repair utilities
- `multitable_bayes.py`: posterior and Bayes-factor selection utilities
- `multitable_program_framework.py`: multi-table candidate execution wrapper
- `sql_reasoning_agent.py`: SQL baseline agent
- `agent_engine.py`: vote/adjudication/verification engine
- `agent_rule_verifiers.py`: conservative rule verifiers
- `table_answer_utils.py`: answer normalization and comparison helpers
- `table_symbolic_verifier.py`: symbolic table verification utilities

## Environment

Create or activate the project environment, then install dependencies:

```bash
conda activate cotable
pip install -r requirements.txt
```

For API-based runs, set keys in the shell instead of writing them into files.

PowerShell:

```powershell
$env:DEEPSEEK_API_KEY="your_key_here"
$env:OPENAI_API_KEY="your_key_here"
```

Linux/macOS:

```bash
export DEEPSEEK_API_KEY="your_key_here"
export OPENAI_API_KEY="your_key_here"
```

For local Hugging Face runs, set `HF_TOKEN` only in the shell if the selected
model requires gated access.

## Data Layout

The environment check expects these paths:

```text
data/wikitq/test.jsonl
data/tabfact/test.jsonl
data/tabfact/raw2clean.jsonl
data/spider_data/dev.json
data/spider_data/tables.json
data/spider_data/database/
data/tableQA/task.json
data/symDataset/
```

Run the checker:

```bash
python scripts/00_check_env_and_data.py --project_root G:\CoT\BF\general
```

## Main Launchers

### Single-Table QA

```bash
python run_table_qa.py ^
  --dataset_path data/wikitq/test.jsonl ^
  --first_n 20 ^
  --model_name deepseek-v4-pro ^
  --openai_api_base https://api.deepseek.com ^
  --result_dir results/demo/table_qa
```

### Fact Verification

```bash
python run_fact_verification.py ^
  --dataset_path data/tabfact/test.jsonl ^
  --raw2clean_path data/tabfact/raw2clean.jsonl ^
  --first_n 20 ^
  --model_name deepseek-v4-pro ^
  --openai_api_base https://api.deepseek.com ^
  --result_dir results/demo/fact_verification
```

### Relational Candidate Reasoning

```bash
python run_relational_candidate_agent.py ^
  --spider_root data/spider_data ^
  --split dev ^
  --db_ids all ^
  --max_per_db 0 ^
  --first_n -1 ^
  --votes 3 ^
  --parallel_votes 1 ^
  --max_schema_chars 8000 ^
  --max_sql_candidates 5 ^
  --selection_policy hybrid_multitable_bayes ^
  --candidate_sources all ^
  --posterior_selection answer_marginal ^
  --bf_threshold 3.0 ^
  --max_repair_rounds 1 ^
  --model_name deepseek-v4-pro ^
  --openai_api_base https://api.deepseek.com ^
  --result_dir results/demo/relational_candidate ^
  --no_resume
```

### Symbolic Long-Context SQL QA

```bash
python run_symbolic_dataset_agent.py ^
  --task_path data/tableQA/task.json ^
  --symdataset_dir data/symDataset ^
  --scales 128k ^
  --domains all ^
  --db_ids all ^
  --first_n -1 ^
  --votes 3 ^
  --parallel_votes 1 ^
  --max_schema_chars 8000 ^
  --max_sql_candidates 3 ^
  --selection_policy hybrid_multitable_bayes ^
  --candidate_sources all ^
  --posterior_selection answer_marginal ^
  --bf_threshold 1.0 ^
  --max_repair_rounds 1 ^
  --model_name deepseek-v4-pro ^
  --openai_api_base https://api.deepseek.com ^
  --result_dir results/demo/symbolic_dataset ^
  --no_resume
```

## Paper Experiment Scripts

The main experiment scripts are in `scripts/`.

```text
02_baselines_single_table_deepseek_v4pro.py  # controlled single-table baselines
03_baselines_multitable_deepseek_v4pro.py    # controlled relational/multi-table baselines
04_ablation_4datasets_deepseek_v4pro.py      # component ablations
05_mechanism_efficiency_deepseek_v4pro.py    # mechanism, budget, and efficiency runs
07_candidate_source_complementarity.py       # candidate source analysis
08_repair_transition_analysis.py             # repair transition statistics
09_offline_selector_comparison.py            # offline selector comparison
10_spider_breakdown_and_export.py            # relational breakdown/export
11_tqa_scale_curve_deepseek_v4pro.py         # context-scale curve
12_tqa_breakdown_and_export.py               # symbolic dataset breakdown/export
14_section4_structured_tables.py             # paper table/figure summaries
15_stepwise_mechanism_replay.py              # stepwise mechanism replay
16_open_source_backbone_suite.py             # open-source backbone suite
```

Example controlled runs:

```bash
python scripts/02_baselines_single_table_deepseek_v4pro.py --project_root G:\CoT\BF\general --tag deepseek_v4pro_controlled_full --first_n -1 --model_name deepseek-v4-pro --openai_api_base https://api.deepseek.com
```

```bash
python scripts/03_baselines_multitable_deepseek_v4pro.py --project_root G:\CoT\BF\general --tag deepseek_v4pro_controlled_full --first_n -1 --model_name deepseek-v4-pro --openai_api_base https://api.deepseek.com --continue_on_error
```

```bash
python scripts/04_ablation_4datasets_deepseek_v4pro.py --project_root G:\CoT\BF\general --tag deepseek_v4pro_ablation_full --first_n -1 --model_name deepseek-v4-pro --openai_api_base https://api.deepseek.com --continue_on_error
```

## Open-Source Backbone Runs

Local Hugging Face runs use downloaded model weights and do not use remote
Inference API credits.  Use smaller models when GPU memory is limited.

```bash
python scripts/16_open_source_backbone_suite.py ^
  --project_root G:\CoT\BF\general ^
  --backend local_hf ^
  --models qwen3_4b_instruct,qwen25_coder_7b,qwen25_7b,llama32_3b ^
  --datasets tqa ^
  --tqa_scales 128k ^
  --first_n -1 ^
  --hf_quantization 4bit ^
  --hf_torch_dtype bfloat16 ^
  --continue_on_error
```

If a gated model fails to load, confirm that the account has access and that
`HF_TOKEN` is set in the same shell.

## Outputs

Most runs write the following files under the selected `--result_dir`:

```text
results.jsonl or predictions.jsonl
metrics.json
reports.jsonl or report.csv
llm_usage.jsonl
llm_usage_summary.json
run_meta.json
```

The paper table builder reads saved traces and metrics from `results/` and
exports consolidated tables or figures into the configured paper-output
directory.

## Notes

- Invalid programs, execution failures, and unparseable outputs are counted as
  errors unless a script explicitly documents a different protocol.
- Do not store API keys or Hugging Face tokens in this repository.
- File names have been normalized to avoid dataset-specific module names.  Some
  CLI arguments still refer to benchmark-specific paths because they describe
  the input data layout.
